import { d as defineEventHandler } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';

const myApi = defineEventHandler(async (event) => {
  const sentry = event.context.$sentry;
  if (sentry) {
    sentry.setUser({
      /*...*/
    });
  }
});

export { myApi as default };
//# sourceMappingURL=my-api.mjs.map
