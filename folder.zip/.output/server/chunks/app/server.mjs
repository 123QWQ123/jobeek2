import { hasInjectionContext, inject, version, ref, watchEffect, watch, getCurrentInstance, h, defineComponent, provide, createElementBlock, toRaw, isRef, isReactive, toRef, computed, unref, Suspense, nextTick, mergeProps, Transition, createApp, effectScope, reactive, useSSRContext, getCurrentScope, onScopeDispose, shallowRef, shallowReactive, isReadonly, defineAsyncComponent, onErrorCaptured, onServerPrefetch, createVNode, resolveDynamicComponent, markRaw, toRefs, isShallow } from 'vue';
import { f as useRuntimeConfig$1, $ as $fetch, w as withQuery, m as hasProtocol, p as parseURL, n as isScriptProtocol, j as joinURL, i as createError$1, o as getRequestURL, q as sanitizeStatusCode, r as createHooks, t as getRequestHeaders } from '../nitro/node-server.mjs';
import { getActiveHead } from 'unhead';
import { defineHeadPlugin, composableNames } from '@unhead/shared';
import { useRoute as useRoute$1, createMemoryHistory, createRouter, START_LOCATION } from 'vue-router';
import { getToken, onMessage } from 'firebase/messaging';
import axios from 'axios';
import https from 'node:https';
import MobileDetect from 'mobile-detect';
import IMask from 'imask';
import { createI18n } from 'vue-i18n';
import moment from 'moment';
import vClickOutside from 'click-outside-vue3';
import Vue3Toastify, { toast } from 'vue3-toastify';
import VueTelInput from 'vue3-tel-input';
import { ssrRenderSuspense, ssrRenderComponent, ssrRenderVNode, ssrRenderAttrs } from 'vue/server-renderer';
import 'node:http';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';

function createContext$1(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als && currentInstance === void 0) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers$1.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers$1.delete(onLeave);
      }
    }
  };
}
function createNamespace$1(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext$1({ ...defaultOpts, ...opts });
      }
      contexts[key];
      return contexts[key];
    }
  };
}
const _globalThis$1 = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey$2 = "__unctx__";
const defaultNamespace = _globalThis$1[globalKey$2] || (_globalThis$1[globalKey$2] = createNamespace$1());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey$1 = "__unctx_async_handlers__";
const asyncHandlers$1 = _globalThis$1[asyncHandlersKey$1] || (_globalThis$1[asyncHandlersKey$1] = /* @__PURE__ */ new Set());

const appConfig = useRuntimeConfig$1().app;
const baseURL = () => appConfig.baseURL;
if (!globalThis.$fetch) {
  globalThis.$fetch = $fetch.create({
    baseURL: baseURL()
  });
}
const nuxtAppCtx = /* @__PURE__ */ getContext("nuxt-app", {
  asyncContext: false
});
const NuxtPluginIndicator = "__nuxt_plugin";
function createNuxtApp(options) {
  let hydratingCount = 0;
  const nuxtApp = {
    _scope: effectScope(),
    provide: void 0,
    globalName: "nuxt",
    versions: {
      get nuxt() {
        return "3.10.2";
      },
      get vue() {
        return nuxtApp.vueApp.version;
      }
    },
    payload: reactive({
      data: {},
      state: {},
      once: /* @__PURE__ */ new Set(),
      _errors: {},
      ...{ serverRendered: true }
    }),
    static: {
      data: {}
    },
    runWithContext: (fn) => nuxtApp._scope.run(() => callWithNuxt(nuxtApp, fn)),
    isHydrating: false,
    deferHydration() {
      if (!nuxtApp.isHydrating) {
        return () => {
        };
      }
      hydratingCount++;
      let called = false;
      return () => {
        if (called) {
          return;
        }
        called = true;
        hydratingCount--;
        if (hydratingCount === 0) {
          nuxtApp.isHydrating = false;
          return nuxtApp.callHook("app:suspense:resolve");
        }
      };
    },
    _asyncDataPromises: {},
    _asyncData: {},
    _payloadRevivers: {},
    ...options
  };
  nuxtApp.hooks = createHooks();
  nuxtApp.hook = nuxtApp.hooks.hook;
  {
    const contextCaller = async function(hooks, args) {
      for (const hook of hooks) {
        await nuxtApp.runWithContext(() => hook(...args));
      }
    };
    nuxtApp.hooks.callHook = (name, ...args) => nuxtApp.hooks.callHookWith(contextCaller, name, ...args);
  }
  nuxtApp.callHook = nuxtApp.hooks.callHook;
  nuxtApp.provide = (name, value) => {
    const $name = "$" + name;
    defineGetter(nuxtApp, $name, value);
    defineGetter(nuxtApp.vueApp.config.globalProperties, $name, value);
  };
  defineGetter(nuxtApp.vueApp, "$nuxt", nuxtApp);
  defineGetter(nuxtApp.vueApp.config.globalProperties, "$nuxt", nuxtApp);
  {
    if (nuxtApp.ssrContext) {
      nuxtApp.ssrContext.nuxt = nuxtApp;
      nuxtApp.ssrContext._payloadReducers = {};
      nuxtApp.payload.path = nuxtApp.ssrContext.url;
    }
    nuxtApp.ssrContext = nuxtApp.ssrContext || {};
    if (nuxtApp.ssrContext.payload) {
      Object.assign(nuxtApp.payload, nuxtApp.ssrContext.payload);
    }
    nuxtApp.ssrContext.payload = nuxtApp.payload;
    nuxtApp.ssrContext.config = {
      public: options.ssrContext.runtimeConfig.public,
      app: options.ssrContext.runtimeConfig.app
    };
  }
  const runtimeConfig = options.ssrContext.runtimeConfig;
  nuxtApp.provide("config", runtimeConfig);
  return nuxtApp;
}
async function applyPlugin(nuxtApp, plugin2) {
  if (plugin2.hooks) {
    nuxtApp.hooks.addHooks(plugin2.hooks);
  }
  if (typeof plugin2 === "function") {
    const { provide: provide2 } = await nuxtApp.runWithContext(() => plugin2(nuxtApp)) || {};
    if (provide2 && typeof provide2 === "object") {
      for (const key in provide2) {
        nuxtApp.provide(key, provide2[key]);
      }
    }
  }
}
async function applyPlugins(nuxtApp, plugins2) {
  var _a, _b;
  const resolvedPlugins = [];
  const unresolvedPlugins = [];
  const parallels = [];
  const errors = [];
  let promiseDepth = 0;
  async function executePlugin(plugin2) {
    var _a2;
    const unresolvedPluginsForThisPlugin = ((_a2 = plugin2.dependsOn) == null ? void 0 : _a2.filter((name) => plugins2.some((p) => p._name === name) && !resolvedPlugins.includes(name))) ?? [];
    if (unresolvedPluginsForThisPlugin.length > 0) {
      unresolvedPlugins.push([new Set(unresolvedPluginsForThisPlugin), plugin2]);
    } else {
      const promise = applyPlugin(nuxtApp, plugin2).then(async () => {
        if (plugin2._name) {
          resolvedPlugins.push(plugin2._name);
          await Promise.all(unresolvedPlugins.map(async ([dependsOn, unexecutedPlugin]) => {
            if (dependsOn.has(plugin2._name)) {
              dependsOn.delete(plugin2._name);
              if (dependsOn.size === 0) {
                promiseDepth++;
                await executePlugin(unexecutedPlugin);
              }
            }
          }));
        }
      });
      if (plugin2.parallel) {
        parallels.push(promise.catch((e) => errors.push(e)));
      } else {
        await promise;
      }
    }
  }
  for (const plugin2 of plugins2) {
    if (((_a = nuxtApp.ssrContext) == null ? void 0 : _a.islandContext) && ((_b = plugin2.env) == null ? void 0 : _b.islands) === false) {
      continue;
    }
    await executePlugin(plugin2);
  }
  await Promise.all(parallels);
  if (promiseDepth) {
    for (let i = 0; i < promiseDepth; i++) {
      await Promise.all(parallels);
    }
  }
  if (errors.length) {
    throw errors[0];
  }
}
// @__NO_SIDE_EFFECTS__
function defineNuxtPlugin(plugin2) {
  if (typeof plugin2 === "function") {
    return plugin2;
  }
  const _name = plugin2._name || plugin2.name;
  delete plugin2.name;
  return Object.assign(plugin2.setup || (() => {
  }), plugin2, { [NuxtPluginIndicator]: true, _name });
}
function callWithNuxt(nuxt, setup, args) {
  const fn = () => args ? setup(...args) : setup();
  {
    return nuxt.vueApp.runWithContext(() => nuxtAppCtx.callAsync(nuxt, fn));
  }
}
// @__NO_SIDE_EFFECTS__
function tryUseNuxtApp() {
  var _a;
  let nuxtAppInstance;
  if (hasInjectionContext()) {
    nuxtAppInstance = (_a = getCurrentInstance()) == null ? void 0 : _a.appContext.app.$nuxt;
  }
  nuxtAppInstance = nuxtAppInstance || nuxtAppCtx.tryUse();
  return nuxtAppInstance || null;
}
// @__NO_SIDE_EFFECTS__
function useNuxtApp() {
  const nuxtAppInstance = /* @__PURE__ */ tryUseNuxtApp();
  if (!nuxtAppInstance) {
    {
      throw new Error("[nuxt] instance unavailable");
    }
  }
  return nuxtAppInstance;
}
// @__NO_SIDE_EFFECTS__
function useRuntimeConfig(_event) {
  return (/* @__PURE__ */ useNuxtApp()).$config;
}
function defineGetter(obj, key, val) {
  Object.defineProperty(obj, key, { get: () => val });
}
const LayoutMetaSymbol = Symbol("layout-meta");
const PageRouteSymbol = Symbol("route");
const useRouter = () => {
  var _a;
  return (_a = /* @__PURE__ */ useNuxtApp()) == null ? void 0 : _a.$router;
};
const useRoute = () => {
  if (hasInjectionContext()) {
    return inject(PageRouteSymbol, (/* @__PURE__ */ useNuxtApp())._route);
  }
  return (/* @__PURE__ */ useNuxtApp())._route;
};
// @__NO_SIDE_EFFECTS__
function defineNuxtRouteMiddleware(middleware) {
  return middleware;
}
const isProcessingMiddleware = () => {
  try {
    if ((/* @__PURE__ */ useNuxtApp())._processingMiddleware) {
      return true;
    }
  } catch {
    return true;
  }
  return false;
};
const navigateTo = (to, options) => {
  if (!to) {
    to = "/";
  }
  const toPath = typeof to === "string" ? to : withQuery(to.path || "/", to.query || {}) + (to.hash || "");
  if (options == null ? void 0 : options.open) {
    return Promise.resolve();
  }
  const isExternal = (options == null ? void 0 : options.external) || hasProtocol(toPath, { acceptRelative: true });
  if (isExternal) {
    if (!(options == null ? void 0 : options.external)) {
      throw new Error("Navigating to an external URL is not allowed by default. Use `navigateTo(url, { external: true })`.");
    }
    const protocol = parseURL(toPath).protocol;
    if (protocol && isScriptProtocol(protocol)) {
      throw new Error(`Cannot navigate to a URL with '${protocol}' protocol.`);
    }
  }
  const inMiddleware = isProcessingMiddleware();
  const router = useRouter();
  const nuxtApp = /* @__PURE__ */ useNuxtApp();
  {
    if (nuxtApp.ssrContext) {
      const fullPath = typeof to === "string" || isExternal ? toPath : router.resolve(to).fullPath || "/";
      const location2 = isExternal ? toPath : joinURL((/* @__PURE__ */ useRuntimeConfig()).app.baseURL, fullPath);
      const redirect = async function(response) {
        await nuxtApp.callHook("app:redirected");
        const encodedLoc = location2.replace(/"/g, "%22");
        nuxtApp.ssrContext._renderResponse = {
          statusCode: sanitizeStatusCode((options == null ? void 0 : options.redirectCode) || 302, 302),
          body: `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`,
          headers: { location: location2 }
        };
        return response;
      };
      if (!isExternal && inMiddleware) {
        router.afterEach((final) => final.fullPath === fullPath ? redirect(false) : void 0);
        return to;
      }
      return redirect(!inMiddleware ? void 0 : (
        /* abort route navigation */
        false
      ));
    }
  }
  if (isExternal) {
    nuxtApp._scope.stop();
    if (options == null ? void 0 : options.replace) {
      (void 0).replace(toPath);
    } else {
      (void 0).href = toPath;
    }
    if (inMiddleware) {
      if (!nuxtApp.isHydrating) {
        return false;
      }
      return new Promise(() => {
      });
    }
    return Promise.resolve();
  }
  return (options == null ? void 0 : options.replace) ? router.replace(to) : router.push(to);
};
const NUXT_ERROR_SIGNATURE = "__nuxt_error";
const useError = () => toRef((/* @__PURE__ */ useNuxtApp()).payload, "error");
const showError = (error) => {
  const nuxtError = createError(error);
  try {
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const error2 = useError();
    if (false)
      ;
    error2.value = error2.value || nuxtError;
  } catch {
    throw nuxtError;
  }
  return nuxtError;
};
const isNuxtError = (error) => !!error && typeof error === "object" && NUXT_ERROR_SIGNATURE in error;
const createError = (error) => {
  const nuxtError = createError$1(error);
  Object.defineProperty(nuxtError, NUXT_ERROR_SIGNATURE, {
    value: true,
    configurable: false,
    writable: false
  });
  return nuxtError;
};
version.startsWith("3");
function resolveUnref(r) {
  return typeof r === "function" ? r() : unref(r);
}
function resolveUnrefHeadInput(ref2, lastKey = "") {
  if (ref2 instanceof Promise)
    return ref2;
  const root = resolveUnref(ref2);
  if (!ref2 || !root)
    return root;
  if (Array.isArray(root))
    return root.map((r) => resolveUnrefHeadInput(r, lastKey));
  if (typeof root === "object") {
    return Object.fromEntries(
      Object.entries(root).map(([k, v]) => {
        if (k === "titleTemplate" || k.startsWith("on"))
          return [k, unref(v)];
        return [k, resolveUnrefHeadInput(v, k)];
      })
    );
  }
  return root;
}
defineHeadPlugin({
  hooks: {
    "entries:resolve": function(ctx) {
      for (const entry2 of ctx.entries)
        entry2.resolvedInput = resolveUnrefHeadInput(entry2.input);
    }
  }
});
const headSymbol = "usehead";
const _global = typeof globalThis !== "undefined" ? globalThis : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
const globalKey$1 = "__unhead_injection_handler__";
function setHeadInjectionHandler(handler) {
  _global[globalKey$1] = handler;
}
function injectHead() {
  if (globalKey$1 in _global) {
    return _global[globalKey$1]();
  }
  const head = inject(headSymbol);
  if (!head && "production" !== "production")
    console.warn("Unhead is missing Vue context, falling back to shared context. This may have unexpected results.");
  return head || getActiveHead();
}
function useHead(input, options = {}) {
  const head = options.head || injectHead();
  if (head) {
    if (!head.ssr)
      return clientUseHead(head, input, options);
    return head.push(input, options);
  }
}
function clientUseHead(head, input, options = {}) {
  const deactivated = ref(false);
  const resolvedInput = ref({});
  watchEffect(() => {
    resolvedInput.value = deactivated.value ? {} : resolveUnrefHeadInput(input);
  });
  const entry2 = head.push(resolvedInput.value, options);
  watch(resolvedInput, (e) => {
    entry2.patch(e);
  });
  getCurrentInstance();
  return entry2;
}
const coreComposableNames = [
  "injectHead"
];
({
  "@unhead/vue": [...coreComposableNames, ...composableNames]
});
const unhead_KgADcZ0jPj = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:head",
  enforce: "pre",
  setup(nuxtApp) {
    const head = nuxtApp.ssrContext.head;
    setHeadInjectionHandler(
      // need a fresh instance of the nuxt app to avoid parallel requests interfering with each other
      () => (/* @__PURE__ */ useNuxtApp()).vueApp._context.provides.usehead
    );
    nuxtApp.vueApp.use(head);
  }
});
function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als && currentInstance === void 0) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      contexts[key];
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
_globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());
function executeAsync(function_) {
  const restores = [];
  for (const leaveHandler of asyncHandlers) {
    const restore2 = leaveHandler();
    if (restore2) {
      restores.push(restore2);
    }
  }
  const restore = () => {
    for (const restore2 of restores) {
      restore2();
    }
  };
  let awaitable = function_();
  if (awaitable && typeof awaitable === "object" && "catch" in awaitable) {
    awaitable = awaitable.catch((error) => {
      restore();
      throw error;
    });
  }
  return [awaitable, restore];
}
const interpolatePath = (route, match) => {
  return match.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, (r) => {
    var _a;
    return ((_a = route.params[r.slice(1)]) == null ? void 0 : _a.toString()) || "";
  });
};
const generateRouteKey$1 = (routeProps, override) => {
  const matchedRoute = routeProps.route.matched.find((m) => {
    var _a;
    return ((_a = m.components) == null ? void 0 : _a.default) === routeProps.Component.type;
  });
  const source = override ?? (matchedRoute == null ? void 0 : matchedRoute.meta.key) ?? (matchedRoute && interpolatePath(routeProps.route, matchedRoute));
  return typeof source === "function" ? source(routeProps.route) : source;
};
const wrapInKeepAlive = (props, children) => {
  return { default: () => children };
};
function toArray(value) {
  return Array.isArray(value) ? value : [value];
}
const __nuxt_page_meta$S = {
  layout: "index"
};
const __nuxt_page_meta$R = {
  layout: "advice-post"
};
const __nuxt_page_meta$Q = {
  layout: "advice"
};
const __nuxt_page_meta$P = {
  layout: "cabinet"
};
const __nuxt_page_meta$O = {
  layout: "cabinet",
  middleware: ["auth"]
};
const __nuxt_page_meta$M = {
  layout: "cabinet"
};
const __nuxt_page_meta$L = {
  layout: "cabinet"
};
const __nuxt_page_meta$K = {
  layout: "cabinet"
};
const __nuxt_page_meta$J = {
  layout: "cabinet"
};
const __nuxt_page_meta$I = {
  layout: "cabinet"
};
const __nuxt_page_meta$H = {
  layout: "cabinet"
};
const __nuxt_page_meta$G = {
  layout: "cabinet"
};
const __nuxt_page_meta$F = {
  layout: "cabinet"
};
const __nuxt_page_meta$D = {
  layout: "cabinet"
};
const __nuxt_page_meta$C = {
  layout: "cabinet"
};
const __nuxt_page_meta$B = {
  layout: "cabinet"
};
const __nuxt_page_meta$A = {
  layout: "custom"
};
const __nuxt_page_meta$z = {
  layout: "cabinet"
};
const __nuxt_page_meta$y = {
  layout: "cabinet"
};
const __nuxt_page_meta$x = {
  layout: "cabinet"
};
const __nuxt_page_meta$w = {
  layout: "cabinet"
};
const __nuxt_page_meta$v = {
  layout: "cabinet"
};
const __nuxt_page_meta$u = {
  layout: "cabinet"
};
const __nuxt_page_meta$t = {
  layout: "cabinet"
};
const __nuxt_page_meta$r = {
  layout: "cabinet"
};
const __nuxt_page_meta$q = {
  layout: "cabinet"
};
const __nuxt_page_meta$p = {
  layout: "cabinet"
};
const __nuxt_page_meta$o = {
  layout: "cabinet"
};
const __nuxt_page_meta$n = {
  layout: "cabinet"
};
const __nuxt_page_meta$m = {
  layout: "cabinet"
};
const __nuxt_page_meta$l = {
  layout: "cabinet"
};
const __nuxt_page_meta$j = {
  layout: "main"
};
const __nuxt_page_meta$i = {
  layout: "cabinet"
};
const __nuxt_page_meta$h = {
  layout: "cabinet"
};
const __nuxt_page_meta$g = {
  layout: "cabinet"
};
const __nuxt_page_meta$f = {
  layout: "cabinet"
};
const __nuxt_page_meta$e = {
  layout: "cabinet"
};
const __nuxt_page_meta$d = {
  layout: "custom"
};
const __nuxt_page_meta$c = {
  layout: "custom"
};
const __nuxt_page_meta$b = {
  layout: "default"
};
const __nuxt_page_meta$9 = {
  layout: "cabinet"
};
const __nuxt_page_meta$8 = {
  layout: "cabinet"
};
const __nuxt_page_meta$3 = {
  layout: "cabinet"
};
const __nuxt_page_meta$2 = {
  layout: "cabinet"
};
const __nuxt_page_meta$1 = {
  layout: "cabinet"
};
const __nuxt_page_meta = {
  layout: "cabinet"
};
const _routes = [
  {
    name: "4042",
    path: "/4042",
    meta: {},
    alias: [],
    redirect: void 0 ,
    component: () => import('./_nuxt/4042-BWLhW_MR.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$S == null ? void 0 : __nuxt_page_meta$S.name) ?? "about",
    path: (__nuxt_page_meta$S == null ? void 0 : __nuxt_page_meta$S.path) ?? "/about",
    meta: __nuxt_page_meta$S || {},
    alias: (__nuxt_page_meta$S == null ? void 0 : __nuxt_page_meta$S.alias) || [],
    redirect: __nuxt_page_meta$S == null ? void 0 : __nuxt_page_meta$S.redirect,
    component: () => import('./_nuxt/about-D1cyxAQF.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$P == null ? void 0 : __nuxt_page_meta$P.name) ?? "advice",
    path: (__nuxt_page_meta$P == null ? void 0 : __nuxt_page_meta$P.path) ?? "/advice",
    meta: __nuxt_page_meta$P || {},
    alias: (__nuxt_page_meta$P == null ? void 0 : __nuxt_page_meta$P.alias) || [],
    redirect: __nuxt_page_meta$P == null ? void 0 : __nuxt_page_meta$P.redirect,
    component: () => import('./_nuxt/advice-CyhqNz9C.mjs').then((m) => m.default || m),
    children: [
      {
        name: (__nuxt_page_meta$Q == null ? void 0 : __nuxt_page_meta$Q.name) ?? "advice-category",
        path: (__nuxt_page_meta$Q == null ? void 0 : __nuxt_page_meta$Q.path) ?? ":category()",
        meta: __nuxt_page_meta$Q || {},
        alias: (__nuxt_page_meta$Q == null ? void 0 : __nuxt_page_meta$Q.alias) || [],
        redirect: __nuxt_page_meta$Q == null ? void 0 : __nuxt_page_meta$Q.redirect,
        component: () => import('./_nuxt/_category_-CcmnHxAd.mjs').then((m) => m.default || m),
        children: [
          {
            name: (__nuxt_page_meta$R == null ? void 0 : __nuxt_page_meta$R.name) ?? "advice-category-slug",
            path: (__nuxt_page_meta$R == null ? void 0 : __nuxt_page_meta$R.path) ?? ":slug()",
            meta: __nuxt_page_meta$R || {},
            alias: (__nuxt_page_meta$R == null ? void 0 : __nuxt_page_meta$R.alias) || [],
            redirect: __nuxt_page_meta$R == null ? void 0 : __nuxt_page_meta$R.redirect,
            component: () => import('./_nuxt/index-BMZKoR-E.mjs').then((m) => m.default || m)
          }
        ]
      }
    ]
  },
  {
    name: (__nuxt_page_meta$O == null ? void 0 : __nuxt_page_meta$O.name) ?? "cabinet",
    path: (__nuxt_page_meta$O == null ? void 0 : __nuxt_page_meta$O.path) ?? "/cabinet",
    meta: __nuxt_page_meta$O || {},
    alias: (__nuxt_page_meta$O == null ? void 0 : __nuxt_page_meta$O.alias) || [],
    redirect: __nuxt_page_meta$O == null ? void 0 : __nuxt_page_meta$O.redirect,
    component: () => import('./_nuxt/cabinet-BKpUXPx_.mjs').then((m) => m.default || m)
  },
  {
    name: "component",
    path: "/component",
    meta: {},
    alias: [],
    redirect: void 0 ,
    component: () => import('./_nuxt/component-CgM5zabi.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$M == null ? void 0 : __nuxt_page_meta$M.name) ?? "courses",
    path: (__nuxt_page_meta$M == null ? void 0 : __nuxt_page_meta$M.path) ?? "/courses",
    meta: __nuxt_page_meta$M || {},
    alias: (__nuxt_page_meta$M == null ? void 0 : __nuxt_page_meta$M.alias) || [],
    redirect: __nuxt_page_meta$M == null ? void 0 : __nuxt_page_meta$M.redirect,
    component: () => import('./_nuxt/courses-DwzKULno.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$L == null ? void 0 : __nuxt_page_meta$L.name) ?? "create-resume",
    path: (__nuxt_page_meta$L == null ? void 0 : __nuxt_page_meta$L.path) ?? "/create-resume",
    meta: __nuxt_page_meta$L || {},
    alias: (__nuxt_page_meta$L == null ? void 0 : __nuxt_page_meta$L.alias) || [],
    redirect: __nuxt_page_meta$L == null ? void 0 : __nuxt_page_meta$L.redirect,
    component: () => import('./_nuxt/create-resume-B-FTvy04.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$K == null ? void 0 : __nuxt_page_meta$K.name) ?? "create-resume2",
    path: (__nuxt_page_meta$K == null ? void 0 : __nuxt_page_meta$K.path) ?? "/create-resume2",
    meta: __nuxt_page_meta$K || {},
    alias: (__nuxt_page_meta$K == null ? void 0 : __nuxt_page_meta$K.alias) || [],
    redirect: __nuxt_page_meta$K == null ? void 0 : __nuxt_page_meta$K.redirect,
    component: () => import('./_nuxt/create-resume2-BemIL92F.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$J == null ? void 0 : __nuxt_page_meta$J.name) ?? "create-subscription",
    path: (__nuxt_page_meta$J == null ? void 0 : __nuxt_page_meta$J.path) ?? "/create-subscription",
    meta: __nuxt_page_meta$J || {},
    alias: (__nuxt_page_meta$J == null ? void 0 : __nuxt_page_meta$J.alias) || [],
    redirect: __nuxt_page_meta$J == null ? void 0 : __nuxt_page_meta$J.redirect,
    component: () => import('./_nuxt/create-subscription-BnMPWAwN.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$I == null ? void 0 : __nuxt_page_meta$I.name) ?? "create-vacancy-old",
    path: (__nuxt_page_meta$I == null ? void 0 : __nuxt_page_meta$I.path) ?? "/create-vacancy-old",
    meta: __nuxt_page_meta$I || {},
    alias: (__nuxt_page_meta$I == null ? void 0 : __nuxt_page_meta$I.alias) || [],
    redirect: __nuxt_page_meta$I == null ? void 0 : __nuxt_page_meta$I.redirect,
    component: () => import('./_nuxt/create-vacancy-old-CIwDqPJJ.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$H == null ? void 0 : __nuxt_page_meta$H.name) ?? "create-vacancy",
    path: (__nuxt_page_meta$H == null ? void 0 : __nuxt_page_meta$H.path) ?? "/create-vacancy",
    meta: __nuxt_page_meta$H || {},
    alias: (__nuxt_page_meta$H == null ? void 0 : __nuxt_page_meta$H.alias) || [],
    redirect: __nuxt_page_meta$H == null ? void 0 : __nuxt_page_meta$H.redirect,
    component: () => import('./_nuxt/create-vacancy-Bi8i9haU.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$G == null ? void 0 : __nuxt_page_meta$G.name) ?? "create-vacancy2",
    path: (__nuxt_page_meta$G == null ? void 0 : __nuxt_page_meta$G.path) ?? "/create-vacancy2",
    meta: __nuxt_page_meta$G || {},
    alias: (__nuxt_page_meta$G == null ? void 0 : __nuxt_page_meta$G.alias) || [],
    redirect: __nuxt_page_meta$G == null ? void 0 : __nuxt_page_meta$G.redirect,
    component: () => import('./_nuxt/create-vacancy2-DODWGShb.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$F == null ? void 0 : __nuxt_page_meta$F.name) ?? "create-vacancy22",
    path: (__nuxt_page_meta$F == null ? void 0 : __nuxt_page_meta$F.path) ?? "/create-vacancy22",
    meta: __nuxt_page_meta$F || {},
    alias: (__nuxt_page_meta$F == null ? void 0 : __nuxt_page_meta$F.alias) || [],
    redirect: __nuxt_page_meta$F == null ? void 0 : __nuxt_page_meta$F.redirect,
    component: () => import('./_nuxt/create-vacancy22-guiW5s_y.mjs').then((m) => m.default || m)
  },
  {
    name: "dd",
    path: "/dd",
    meta: {},
    alias: [],
    redirect: void 0 ,
    component: () => import('./_nuxt/dd-_TNkAkmQ.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$D == null ? void 0 : __nuxt_page_meta$D.name) ?? "favorite-resumes",
    path: (__nuxt_page_meta$D == null ? void 0 : __nuxt_page_meta$D.path) ?? "/favorite/resumes",
    meta: __nuxt_page_meta$D || {},
    alias: (__nuxt_page_meta$D == null ? void 0 : __nuxt_page_meta$D.alias) || [],
    redirect: __nuxt_page_meta$D == null ? void 0 : __nuxt_page_meta$D.redirect,
    component: () => import('./_nuxt/resumes-CBxSYxX2.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$C == null ? void 0 : __nuxt_page_meta$C.name) ?? "favorite-vacancies",
    path: (__nuxt_page_meta$C == null ? void 0 : __nuxt_page_meta$C.path) ?? "/favorite/vacancies",
    meta: __nuxt_page_meta$C || {},
    alias: (__nuxt_page_meta$C == null ? void 0 : __nuxt_page_meta$C.alias) || [],
    redirect: __nuxt_page_meta$C == null ? void 0 : __nuxt_page_meta$C.redirect,
    component: () => import('./_nuxt/vacancies-BHt0K-Q9.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$B == null ? void 0 : __nuxt_page_meta$B.name) ?? "favorites-has-favs",
    path: (__nuxt_page_meta$B == null ? void 0 : __nuxt_page_meta$B.path) ?? "/favorites-has-favs",
    meta: __nuxt_page_meta$B || {},
    alias: (__nuxt_page_meta$B == null ? void 0 : __nuxt_page_meta$B.alias) || [],
    redirect: __nuxt_page_meta$B == null ? void 0 : __nuxt_page_meta$B.redirect,
    component: () => import('./_nuxt/favorites-has-favs-C1-nFbqc.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$A == null ? void 0 : __nuxt_page_meta$A.name) ?? "forgot-password",
    path: (__nuxt_page_meta$A == null ? void 0 : __nuxt_page_meta$A.path) ?? "/forgot-password",
    meta: __nuxt_page_meta$A || {},
    alias: (__nuxt_page_meta$A == null ? void 0 : __nuxt_page_meta$A.alias) || [],
    redirect: __nuxt_page_meta$A == null ? void 0 : __nuxt_page_meta$A.redirect,
    component: () => import('./_nuxt/forgot-password-mpPDpwdf.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$z == null ? void 0 : __nuxt_page_meta$z.name) ?? "index",
    path: (__nuxt_page_meta$z == null ? void 0 : __nuxt_page_meta$z.path) ?? "/",
    meta: __nuxt_page_meta$z || {},
    alias: (__nuxt_page_meta$z == null ? void 0 : __nuxt_page_meta$z.alias) || [],
    redirect: __nuxt_page_meta$z == null ? void 0 : __nuxt_page_meta$z.redirect,
    component: () => import('./_nuxt/index-De9AoKx_.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$y == null ? void 0 : __nuxt_page_meta$y.name) ?? "my-resume-id",
    path: (__nuxt_page_meta$y == null ? void 0 : __nuxt_page_meta$y.path) ?? "/my-resume/:id()",
    meta: __nuxt_page_meta$y || {},
    alias: (__nuxt_page_meta$y == null ? void 0 : __nuxt_page_meta$y.alias) || [],
    redirect: __nuxt_page_meta$y == null ? void 0 : __nuxt_page_meta$y.redirect,
    component: () => import('./_nuxt/_id_-DOBshS61.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$x == null ? void 0 : __nuxt_page_meta$x.name) ?? "my-resumes",
    path: (__nuxt_page_meta$x == null ? void 0 : __nuxt_page_meta$x.path) ?? "/my-resumes",
    meta: __nuxt_page_meta$x || {},
    alias: (__nuxt_page_meta$x == null ? void 0 : __nuxt_page_meta$x.alias) || [],
    redirect: __nuxt_page_meta$x == null ? void 0 : __nuxt_page_meta$x.redirect,
    component: () => import('./_nuxt/index-CGcvSv-4.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$w == null ? void 0 : __nuxt_page_meta$w.name) ?? "my-subscriptions",
    path: (__nuxt_page_meta$w == null ? void 0 : __nuxt_page_meta$w.path) ?? "/my-subscriptions",
    meta: __nuxt_page_meta$w || {},
    alias: (__nuxt_page_meta$w == null ? void 0 : __nuxt_page_meta$w.alias) || [],
    redirect: __nuxt_page_meta$w == null ? void 0 : __nuxt_page_meta$w.redirect,
    component: () => import('./_nuxt/my-subscriptions-vsI45dIO.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$v == null ? void 0 : __nuxt_page_meta$v.name) ?? "my-vacancies-old",
    path: (__nuxt_page_meta$v == null ? void 0 : __nuxt_page_meta$v.path) ?? "/my-vacancies-old",
    meta: __nuxt_page_meta$v || {},
    alias: (__nuxt_page_meta$v == null ? void 0 : __nuxt_page_meta$v.alias) || [],
    redirect: __nuxt_page_meta$v == null ? void 0 : __nuxt_page_meta$v.redirect,
    component: () => import('./_nuxt/index-dwpsun4I.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$u == null ? void 0 : __nuxt_page_meta$u.name) ?? "my-vacancies",
    path: (__nuxt_page_meta$u == null ? void 0 : __nuxt_page_meta$u.path) ?? "/my-vacancies",
    meta: __nuxt_page_meta$u || {},
    alias: (__nuxt_page_meta$u == null ? void 0 : __nuxt_page_meta$u.alias) || [],
    redirect: __nuxt_page_meta$u == null ? void 0 : __nuxt_page_meta$u.redirect,
    component: () => import('./_nuxt/index-B2lKJMB9.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$t == null ? void 0 : __nuxt_page_meta$t.name) ?? "my-vacancy-id",
    path: (__nuxt_page_meta$t == null ? void 0 : __nuxt_page_meta$t.path) ?? "/my-vacancy/:id()",
    meta: __nuxt_page_meta$t || {},
    alias: (__nuxt_page_meta$t == null ? void 0 : __nuxt_page_meta$t.alias) || [],
    redirect: __nuxt_page_meta$t == null ? void 0 : __nuxt_page_meta$t.redirect,
    component: () => import('./_nuxt/_id_-Dz9yyfyw.mjs').then((m) => m.default || m)
  },
  {
    name: "notification",
    path: "/notification",
    meta: {},
    alias: [],
    redirect: void 0 ,
    component: () => import('./_nuxt/index-CAr87S86.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$r == null ? void 0 : __nuxt_page_meta$r.name) ?? "profile-email-verify",
    path: (__nuxt_page_meta$r == null ? void 0 : __nuxt_page_meta$r.path) ?? "/profile/email-verify",
    meta: __nuxt_page_meta$r || {},
    alias: (__nuxt_page_meta$r == null ? void 0 : __nuxt_page_meta$r.alias) || [],
    redirect: __nuxt_page_meta$r == null ? void 0 : __nuxt_page_meta$r.redirect,
    component: () => import('./_nuxt/email-verify-CW1JBelO.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$q == null ? void 0 : __nuxt_page_meta$q.name) ?? "profile-employer",
    path: (__nuxt_page_meta$q == null ? void 0 : __nuxt_page_meta$q.path) ?? "/profile/employer",
    meta: __nuxt_page_meta$q || {},
    alias: (__nuxt_page_meta$q == null ? void 0 : __nuxt_page_meta$q.alias) || [],
    redirect: __nuxt_page_meta$q == null ? void 0 : __nuxt_page_meta$q.redirect,
    component: () => import('./_nuxt/index-C9_3ReZ3.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$p == null ? void 0 : __nuxt_page_meta$p.name) ?? "profile",
    path: (__nuxt_page_meta$p == null ? void 0 : __nuxt_page_meta$p.path) ?? "/profile",
    meta: __nuxt_page_meta$p || {},
    alias: (__nuxt_page_meta$p == null ? void 0 : __nuxt_page_meta$p.alias) || [],
    redirect: __nuxt_page_meta$p == null ? void 0 : __nuxt_page_meta$p.redirect,
    component: () => import('./_nuxt/index-Dc9hBNll.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$o == null ? void 0 : __nuxt_page_meta$o.name) ?? "profile-negotiations",
    path: (__nuxt_page_meta$o == null ? void 0 : __nuxt_page_meta$o.path) ?? "/profile/negotiations",
    meta: __nuxt_page_meta$o || {},
    alias: (__nuxt_page_meta$o == null ? void 0 : __nuxt_page_meta$o.alias) || [],
    redirect: __nuxt_page_meta$o == null ? void 0 : __nuxt_page_meta$o.redirect,
    component: () => import('./_nuxt/negotiations-CQejsBHo.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$n == null ? void 0 : __nuxt_page_meta$n.name) ?? "profile-seeker",
    path: (__nuxt_page_meta$n == null ? void 0 : __nuxt_page_meta$n.path) ?? "/profile/seeker",
    meta: __nuxt_page_meta$n || {},
    alias: (__nuxt_page_meta$n == null ? void 0 : __nuxt_page_meta$n.alias) || [],
    redirect: __nuxt_page_meta$n == null ? void 0 : __nuxt_page_meta$n.redirect,
    component: () => import('./_nuxt/index-DeoGGE6K.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$m == null ? void 0 : __nuxt_page_meta$m.name) ?? "profile-service-verify",
    path: (__nuxt_page_meta$m == null ? void 0 : __nuxt_page_meta$m.path) ?? "/profile/service-verify",
    meta: __nuxt_page_meta$m || {},
    alias: (__nuxt_page_meta$m == null ? void 0 : __nuxt_page_meta$m.alias) || [],
    redirect: __nuxt_page_meta$m == null ? void 0 : __nuxt_page_meta$m.redirect,
    component: () => import('./_nuxt/service-verify-lbxR4ayt.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$l == null ? void 0 : __nuxt_page_meta$l.name) ?? "profile-service-verify2",
    path: (__nuxt_page_meta$l == null ? void 0 : __nuxt_page_meta$l.path) ?? "/profile/service-verify2",
    meta: __nuxt_page_meta$l || {},
    alias: (__nuxt_page_meta$l == null ? void 0 : __nuxt_page_meta$l.alias) || [],
    redirect: __nuxt_page_meta$l == null ? void 0 : __nuxt_page_meta$l.redirect,
    component: () => import('./_nuxt/service-verify2-ZuB5rwqX.mjs').then((m) => m.default || m)
  },
  {
    name: "responses",
    path: "/responses",
    meta: {},
    alias: [],
    redirect: void 0 ,
    component: () => import('./_nuxt/responses-CuWy6S3m.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$j == null ? void 0 : __nuxt_page_meta$j.name) ?? "results",
    path: (__nuxt_page_meta$j == null ? void 0 : __nuxt_page_meta$j.path) ?? "/results",
    meta: __nuxt_page_meta$j || {},
    alias: (__nuxt_page_meta$j == null ? void 0 : __nuxt_page_meta$j.alias) || [],
    redirect: __nuxt_page_meta$j == null ? void 0 : __nuxt_page_meta$j.redirect,
    component: () => import('./_nuxt/results-DB7kG1lM.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$h == null ? void 0 : __nuxt_page_meta$h.name) ?? "resumes",
    path: (__nuxt_page_meta$h == null ? void 0 : __nuxt_page_meta$h.path) ?? "/resumes",
    meta: __nuxt_page_meta$h || {},
    alias: (__nuxt_page_meta$h == null ? void 0 : __nuxt_page_meta$h.alias) || [],
    redirect: __nuxt_page_meta$h == null ? void 0 : __nuxt_page_meta$h.redirect,
    component: () => import('./_nuxt/resumes-C-amlP9u.mjs').then((m) => m.default || m),
    children: [
      {
        name: (__nuxt_page_meta$i == null ? void 0 : __nuxt_page_meta$i.name) ?? "resumes-slug",
        path: (__nuxt_page_meta$i == null ? void 0 : __nuxt_page_meta$i.path) ?? ":slug()",
        meta: __nuxt_page_meta$i || {},
        alias: (__nuxt_page_meta$i == null ? void 0 : __nuxt_page_meta$i.alias) || [],
        redirect: __nuxt_page_meta$i == null ? void 0 : __nuxt_page_meta$i.redirect,
        component: () => import('./_nuxt/index-DAsK5cYC.mjs').then((m) => m.default || m)
      }
    ]
  },
  {
    name: (__nuxt_page_meta$g == null ? void 0 : __nuxt_page_meta$g.name) ?? "search-resumes",
    path: (__nuxt_page_meta$g == null ? void 0 : __nuxt_page_meta$g.path) ?? "/search/resumes",
    meta: __nuxt_page_meta$g || {},
    alias: (__nuxt_page_meta$g == null ? void 0 : __nuxt_page_meta$g.alias) || [],
    redirect: __nuxt_page_meta$g == null ? void 0 : __nuxt_page_meta$g.redirect,
    component: () => import('./_nuxt/resumes-CbYjYH3r.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$f == null ? void 0 : __nuxt_page_meta$f.name) ?? "search-vacancies",
    path: (__nuxt_page_meta$f == null ? void 0 : __nuxt_page_meta$f.path) ?? "/search/vacancies",
    meta: __nuxt_page_meta$f || {},
    alias: (__nuxt_page_meta$f == null ? void 0 : __nuxt_page_meta$f.alias) || [],
    redirect: __nuxt_page_meta$f == null ? void 0 : __nuxt_page_meta$f.redirect,
    component: () => import('./_nuxt/vacancies-7tyaLKDi.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$e == null ? void 0 : __nuxt_page_meta$e.name) ?? "services-search-phone",
    path: (__nuxt_page_meta$e == null ? void 0 : __nuxt_page_meta$e.path) ?? "/services/search-phone",
    meta: __nuxt_page_meta$e || {},
    alias: (__nuxt_page_meta$e == null ? void 0 : __nuxt_page_meta$e.alias) || [],
    redirect: __nuxt_page_meta$e == null ? void 0 : __nuxt_page_meta$e.redirect,
    component: () => import('./_nuxt/search-phone-C-uYOCEh.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$d == null ? void 0 : __nuxt_page_meta$d.name) ?? "sign-in",
    path: (__nuxt_page_meta$d == null ? void 0 : __nuxt_page_meta$d.path) ?? "/sign-in",
    meta: __nuxt_page_meta$d || {},
    alias: (__nuxt_page_meta$d == null ? void 0 : __nuxt_page_meta$d.alias) || [],
    redirect: __nuxt_page_meta$d == null ? void 0 : __nuxt_page_meta$d.redirect,
    component: () => import('./_nuxt/sign-in-DvqtyouH.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$c == null ? void 0 : __nuxt_page_meta$c.name) ?? "sign-up",
    path: (__nuxt_page_meta$c == null ? void 0 : __nuxt_page_meta$c.path) ?? "/sign-up",
    meta: __nuxt_page_meta$c || {},
    alias: (__nuxt_page_meta$c == null ? void 0 : __nuxt_page_meta$c.alias) || [],
    redirect: __nuxt_page_meta$c == null ? void 0 : __nuxt_page_meta$c.redirect,
    component: () => import('./_nuxt/sign-up-j9BjpdcP.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$b == null ? void 0 : __nuxt_page_meta$b.name) ?? "support",
    path: (__nuxt_page_meta$b == null ? void 0 : __nuxt_page_meta$b.path) ?? "/support",
    meta: __nuxt_page_meta$b || {},
    alias: (__nuxt_page_meta$b == null ? void 0 : __nuxt_page_meta$b.alias) || [],
    redirect: __nuxt_page_meta$b == null ? void 0 : __nuxt_page_meta$b.redirect,
    component: () => import('./_nuxt/support-ST_9SeC7.mjs').then((m) => m.default || m)
  },
  {
    name: "test",
    path: "/test",
    meta: {},
    alias: [],
    redirect: void 0 ,
    component: () => import('./_nuxt/test-C6_voID1.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$9 == null ? void 0 : __nuxt_page_meta$9.name) ?? "vacancies-slug",
    path: (__nuxt_page_meta$9 == null ? void 0 : __nuxt_page_meta$9.path) ?? "/vacancies/:slug()",
    meta: __nuxt_page_meta$9 || {},
    alias: (__nuxt_page_meta$9 == null ? void 0 : __nuxt_page_meta$9.alias) || [],
    redirect: __nuxt_page_meta$9 == null ? void 0 : __nuxt_page_meta$9.redirect,
    component: () => import('./_nuxt/index-Dq-Enc_I.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$8 == null ? void 0 : __nuxt_page_meta$8.name) ?? "vacancies-favorite",
    path: (__nuxt_page_meta$8 == null ? void 0 : __nuxt_page_meta$8.path) ?? "/vacancies/favorite",
    meta: __nuxt_page_meta$8 || {},
    alias: (__nuxt_page_meta$8 == null ? void 0 : __nuxt_page_meta$8.alias) || [],
    redirect: __nuxt_page_meta$8 == null ? void 0 : __nuxt_page_meta$8.redirect,
    component: () => import('./_nuxt/favorite-B_bC2YJ7.mjs').then((m) => m.default || m)
  },
  {
    name: "vacancy",
    path: "/vacancy",
    meta: {},
    alias: [],
    redirect: void 0 ,
    component: () => import('./_nuxt/vacancy-DxDrwkqM.mjs').then((m) => m.default || m)
  },
  {
    name: "vee",
    path: "/vee",
    meta: {},
    alias: [],
    redirect: void 0 ,
    component: () => import('./_nuxt/vee-Oex2ZD3Y.mjs').then((m) => m.default || m)
  },
  {
    name: "vee2",
    path: "/vee2",
    meta: {},
    alias: [],
    redirect: void 0 ,
    component: () => import('./_nuxt/vee2-C1XX7X0G.mjs').then((m) => m.default || m)
  },
  {
    name: "vee3",
    path: "/vee3",
    meta: {},
    alias: [],
    redirect: void 0 ,
    component: () => import('./_nuxt/vee3-Doppn02j.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.name) ?? "your-favorites",
    path: (__nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.path) ?? "/your-favorites",
    meta: __nuxt_page_meta$3 || {},
    alias: (__nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.alias) || [],
    redirect: __nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.redirect,
    component: () => import('./_nuxt/your-favorites-BwJQwLTK.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.name) ?? "your-messages",
    path: (__nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.path) ?? "/your-messages",
    meta: __nuxt_page_meta$2 || {},
    alias: (__nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.alias) || [],
    redirect: __nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.redirect,
    component: () => import('./_nuxt/your-messages-CqQfM7mT.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.name) ?? "your-responses",
    path: (__nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.path) ?? "/your-responses",
    meta: __nuxt_page_meta$1 || {},
    alias: (__nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.alias) || [],
    redirect: __nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.redirect,
    component: () => import('./_nuxt/your-responses-g0oTvyAw.mjs').then((m) => m.default || m)
  },
  {
    name: (__nuxt_page_meta == null ? void 0 : __nuxt_page_meta.name) ?? "your-resumes",
    path: (__nuxt_page_meta == null ? void 0 : __nuxt_page_meta.path) ?? "/your-resumes",
    meta: __nuxt_page_meta || {},
    alias: (__nuxt_page_meta == null ? void 0 : __nuxt_page_meta.alias) || [],
    redirect: __nuxt_page_meta == null ? void 0 : __nuxt_page_meta.redirect,
    component: () => import('./_nuxt/your-resumes-DtNuE1VS.mjs').then((m) => m.default || m)
  }
];
const _wrapIf = (component, props, slots) => {
  props = props === true ? {} : props;
  return { default: () => {
    var _a;
    return props ? h(component, props, slots) : (_a = slots.default) == null ? void 0 : _a.call(slots);
  } };
};
function generateRouteKey(route) {
  const source = (route == null ? void 0 : route.meta.key) ?? route.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, (r) => {
    var _a;
    return ((_a = route.params[r.slice(1)]) == null ? void 0 : _a.toString()) || "";
  });
  return typeof source === "function" ? source(route) : source;
}
function isChangingPage(to, from) {
  if (to === from || from === START_LOCATION) {
    return false;
  }
  if (generateRouteKey(to) !== generateRouteKey(from)) {
    return true;
  }
  const areComponentsSame = to.matched.every(
    (comp, index) => {
      var _a, _b;
      return comp.components && comp.components.default === ((_b = (_a = from.matched[index]) == null ? void 0 : _a.components) == null ? void 0 : _b.default);
    }
  );
  if (areComponentsSame) {
    return false;
  }
  return true;
}
const appLayoutTransition = false;
const appPageTransition = false;
const appKeepalive = false;
const nuxtLinkDefaults = { "componentName": "NuxtLink" };
const routerOptions0 = {
  scrollBehavior(to, from, savedPosition) {
    var _a;
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const behavior = ((_a = useRouter().options) == null ? void 0 : _a.scrollBehaviorType) ?? "auto";
    let position = savedPosition || void 0;
    const routeAllowsScrollToTop = typeof to.meta.scrollToTop === "function" ? to.meta.scrollToTop(to, from) : to.meta.scrollToTop;
    if (!position && from && to && routeAllowsScrollToTop !== false && isChangingPage(to, from)) {
      position = { left: 0, top: 0 };
    }
    if (to.path === from.path) {
      if (from.hash && !to.hash) {
        return { left: 0, top: 0 };
      }
      if (to.hash) {
        return { el: to.hash, top: _getHashElementScrollMarginTop(to.hash), behavior };
      }
    }
    const hasTransition = (route) => !!(route.meta.pageTransition ?? appPageTransition);
    const hookToWait = hasTransition(from) && hasTransition(to) ? "page:transition:finish" : "page:finish";
    return new Promise((resolve) => {
      nuxtApp.hooks.hookOnce(hookToWait, async () => {
        await nextTick();
        if (to.hash) {
          position = { el: to.hash, top: _getHashElementScrollMarginTop(to.hash), behavior };
        }
        resolve(position);
      });
    });
  }
};
function _getHashElementScrollMarginTop(selector) {
  try {
    const elem = (void 0).querySelector(selector);
    if (elem) {
      return parseFloat(getComputedStyle(elem).scrollMarginTop);
    }
  } catch {
  }
  return 0;
}
const configRouterOptions = {
  hashMode: false,
  scrollBehaviorType: "auto"
};
const routerOptions = {
  ...configRouterOptions,
  ...routerOptions0
};
const validate = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to) => {
  var _a;
  let __temp, __restore;
  if (!((_a = to.meta) == null ? void 0 : _a.validate)) {
    return;
  }
  useRouter();
  const result = ([__temp, __restore] = executeAsync(() => Promise.resolve(to.meta.validate(to))), __temp = await __temp, __restore(), __temp);
  if (result === true) {
    return;
  }
  {
    return result;
  }
});
function useRequestEvent(nuxtApp = /* @__PURE__ */ useNuxtApp()) {
  var _a;
  return (_a = nuxtApp.ssrContext) == null ? void 0 : _a.event;
}
function useRequestHeaders(include) {
  const event = useRequestEvent();
  const _headers = event ? getRequestHeaders(event) : {};
  if (!include || !event) {
    return _headers;
  }
  const headers = /* @__PURE__ */ Object.create(null);
  for (const _key of include) {
    const key = _key.toLowerCase();
    const header = _headers[key];
    if (header) {
      headers[key] = header;
    }
  }
  return headers;
}
function useRequestURL() {
  {
    return getRequestURL(useRequestEvent());
  }
}
function useFcm() {
  const { $fcm } = /* @__PURE__ */ useNuxtApp();
  async function getToken$1() {
    return $fcm && getToken($fcm.messaging).catch(() => "");
  }
  function onMessage$1(cb) {
    $fcm && onMessage($fcm.messaging, cb);
  }
  return { getToken: getToken$1, onMessage: onMessage$1 };
}
function definePayloadReducer(name, reduce) {
  {
    (/* @__PURE__ */ useNuxtApp()).ssrContext._payloadReducers[name] = reduce;
  }
}
const clientOnlySymbol = Symbol.for("nuxt:client-only");
const __nuxt_component_0$1 = defineComponent({
  name: "ClientOnly",
  inheritAttrs: false,
  // eslint-disable-next-line vue/require-prop-types
  props: ["fallback", "placeholder", "placeholderTag", "fallbackTag"],
  setup(_, { slots, attrs }) {
    const mounted = ref(false);
    provide(clientOnlySymbol, true);
    return (props) => {
      var _a;
      if (mounted.value) {
        return (_a = slots.default) == null ? void 0 : _a.call(slots);
      }
      const slot = slots.fallback || slots.placeholder;
      if (slot) {
        return slot();
      }
      const fallbackStr = props.fallback || props.placeholder || "";
      const fallbackTag = props.fallbackTag || props.placeholderTag || "span";
      return createElementBlock(fallbackTag, attrs, fallbackStr);
    };
  }
});
const isVue2 = false;
/*!
 * pinia v2.1.7
 * (c) 2023 Eduardo San Martin Morote
 * @license MIT
 */
let activePinia;
const setActivePinia = (pinia) => activePinia = pinia;
const piniaSymbol = (
  /* istanbul ignore next */
  Symbol()
);
function isPlainObject(o) {
  return o && typeof o === "object" && Object.prototype.toString.call(o) === "[object Object]" && typeof o.toJSON !== "function";
}
var MutationType;
(function(MutationType2) {
  MutationType2["direct"] = "direct";
  MutationType2["patchObject"] = "patch object";
  MutationType2["patchFunction"] = "patch function";
})(MutationType || (MutationType = {}));
function createPinia() {
  const scope = effectScope(true);
  const state = scope.run(() => ref({}));
  let _p = [];
  let toBeInstalled = [];
  const pinia = markRaw({
    install(app) {
      setActivePinia(pinia);
      {
        pinia._a = app;
        app.provide(piniaSymbol, pinia);
        app.config.globalProperties.$pinia = pinia;
        toBeInstalled.forEach((plugin2) => _p.push(plugin2));
        toBeInstalled = [];
      }
    },
    use(plugin2) {
      if (!this._a && !isVue2) {
        toBeInstalled.push(plugin2);
      } else {
        _p.push(plugin2);
      }
      return this;
    },
    _p,
    // it's actually undefined here
    // @ts-expect-error
    _a: null,
    _e: scope,
    _s: /* @__PURE__ */ new Map(),
    state
  });
  return pinia;
}
const noop = () => {
};
function addSubscription(subscriptions, callback, detached, onCleanup = noop) {
  subscriptions.push(callback);
  const removeSubscription = () => {
    const idx = subscriptions.indexOf(callback);
    if (idx > -1) {
      subscriptions.splice(idx, 1);
      onCleanup();
    }
  };
  if (!detached && getCurrentScope()) {
    onScopeDispose(removeSubscription);
  }
  return removeSubscription;
}
function triggerSubscriptions(subscriptions, ...args) {
  subscriptions.slice().forEach((callback) => {
    callback(...args);
  });
}
const fallbackRunWithContext = (fn) => fn();
function mergeReactiveObjects(target, patchToApply) {
  if (target instanceof Map && patchToApply instanceof Map) {
    patchToApply.forEach((value, key) => target.set(key, value));
  }
  if (target instanceof Set && patchToApply instanceof Set) {
    patchToApply.forEach(target.add, target);
  }
  for (const key in patchToApply) {
    if (!patchToApply.hasOwnProperty(key))
      continue;
    const subPatch = patchToApply[key];
    const targetValue = target[key];
    if (isPlainObject(targetValue) && isPlainObject(subPatch) && target.hasOwnProperty(key) && !isRef(subPatch) && !isReactive(subPatch)) {
      target[key] = mergeReactiveObjects(targetValue, subPatch);
    } else {
      target[key] = subPatch;
    }
  }
  return target;
}
const skipHydrateSymbol = (
  /* istanbul ignore next */
  Symbol()
);
function shouldHydrate(obj) {
  return !isPlainObject(obj) || !obj.hasOwnProperty(skipHydrateSymbol);
}
const { assign } = Object;
function isComputed(o) {
  return !!(isRef(o) && o.effect);
}
function createOptionsStore(id, options, pinia, hot) {
  const { state, actions, getters } = options;
  const initialState = pinia.state.value[id];
  let store;
  function setup() {
    if (!initialState && (!("production" !== "production") )) {
      {
        pinia.state.value[id] = state ? state() : {};
      }
    }
    const localState = toRefs(pinia.state.value[id]);
    return assign(localState, actions, Object.keys(getters || {}).reduce((computedGetters, name) => {
      computedGetters[name] = markRaw(computed(() => {
        setActivePinia(pinia);
        const store2 = pinia._s.get(id);
        return getters[name].call(store2, store2);
      }));
      return computedGetters;
    }, {}));
  }
  store = createSetupStore(id, setup, options, pinia, hot, true);
  return store;
}
function createSetupStore($id, setup, options = {}, pinia, hot, isOptionsStore) {
  let scope;
  const optionsForPlugin = assign({ actions: {} }, options);
  const $subscribeOptions = {
    deep: true
    // flush: 'post',
  };
  let isListening;
  let isSyncListening;
  let subscriptions = [];
  let actionSubscriptions = [];
  let debuggerEvents;
  const initialState = pinia.state.value[$id];
  if (!isOptionsStore && !initialState && (!("production" !== "production") )) {
    {
      pinia.state.value[$id] = {};
    }
  }
  ref({});
  let activeListener;
  function $patch(partialStateOrMutator) {
    let subscriptionMutation;
    isListening = isSyncListening = false;
    if (typeof partialStateOrMutator === "function") {
      partialStateOrMutator(pinia.state.value[$id]);
      subscriptionMutation = {
        type: MutationType.patchFunction,
        storeId: $id,
        events: debuggerEvents
      };
    } else {
      mergeReactiveObjects(pinia.state.value[$id], partialStateOrMutator);
      subscriptionMutation = {
        type: MutationType.patchObject,
        payload: partialStateOrMutator,
        storeId: $id,
        events: debuggerEvents
      };
    }
    const myListenerId = activeListener = Symbol();
    nextTick().then(() => {
      if (activeListener === myListenerId) {
        isListening = true;
      }
    });
    isSyncListening = true;
    triggerSubscriptions(subscriptions, subscriptionMutation, pinia.state.value[$id]);
  }
  const $reset = isOptionsStore ? function $reset2() {
    const { state } = options;
    const newState = state ? state() : {};
    this.$patch(($state) => {
      assign($state, newState);
    });
  } : (
    /* istanbul ignore next */
    noop
  );
  function $dispose() {
    scope.stop();
    subscriptions = [];
    actionSubscriptions = [];
    pinia._s.delete($id);
  }
  function wrapAction(name, action) {
    return function() {
      setActivePinia(pinia);
      const args = Array.from(arguments);
      const afterCallbackList = [];
      const onErrorCallbackList = [];
      function after(callback) {
        afterCallbackList.push(callback);
      }
      function onError(callback) {
        onErrorCallbackList.push(callback);
      }
      triggerSubscriptions(actionSubscriptions, {
        args,
        name,
        store,
        after,
        onError
      });
      let ret;
      try {
        ret = action.apply(this && this.$id === $id ? this : store, args);
      } catch (error) {
        triggerSubscriptions(onErrorCallbackList, error);
        throw error;
      }
      if (ret instanceof Promise) {
        return ret.then((value) => {
          triggerSubscriptions(afterCallbackList, value);
          return value;
        }).catch((error) => {
          triggerSubscriptions(onErrorCallbackList, error);
          return Promise.reject(error);
        });
      }
      triggerSubscriptions(afterCallbackList, ret);
      return ret;
    };
  }
  const partialStore = {
    _p: pinia,
    // _s: scope,
    $id,
    $onAction: addSubscription.bind(null, actionSubscriptions),
    $patch,
    $reset,
    $subscribe(callback, options2 = {}) {
      const removeSubscription = addSubscription(subscriptions, callback, options2.detached, () => stopWatcher());
      const stopWatcher = scope.run(() => watch(() => pinia.state.value[$id], (state) => {
        if (options2.flush === "sync" ? isSyncListening : isListening) {
          callback({
            storeId: $id,
            type: MutationType.direct,
            events: debuggerEvents
          }, state);
        }
      }, assign({}, $subscribeOptions, options2)));
      return removeSubscription;
    },
    $dispose
  };
  const store = reactive(partialStore);
  pinia._s.set($id, store);
  const runWithContext = pinia._a && pinia._a.runWithContext || fallbackRunWithContext;
  const setupStore = runWithContext(() => pinia._e.run(() => (scope = effectScope()).run(setup)));
  for (const key in setupStore) {
    const prop = setupStore[key];
    if (isRef(prop) && !isComputed(prop) || isReactive(prop)) {
      if (!isOptionsStore) {
        if (initialState && shouldHydrate(prop)) {
          if (isRef(prop)) {
            prop.value = initialState[key];
          } else {
            mergeReactiveObjects(prop, initialState[key]);
          }
        }
        {
          pinia.state.value[$id][key] = prop;
        }
      }
    } else if (typeof prop === "function") {
      const actionValue = wrapAction(key, prop);
      {
        setupStore[key] = actionValue;
      }
      optionsForPlugin.actions[key] = prop;
    } else ;
  }
  {
    assign(store, setupStore);
    assign(toRaw(store), setupStore);
  }
  Object.defineProperty(store, "$state", {
    get: () => pinia.state.value[$id],
    set: (state) => {
      $patch(($state) => {
        assign($state, state);
      });
    }
  });
  pinia._p.forEach((extender) => {
    {
      assign(store, scope.run(() => extender({
        store,
        app: pinia._a,
        pinia,
        options: optionsForPlugin
      })));
    }
  });
  if (initialState && isOptionsStore && options.hydrate) {
    options.hydrate(store.$state, initialState);
  }
  isListening = true;
  isSyncListening = true;
  return store;
}
function defineStore(idOrOptions, setup, setupOptions) {
  let id;
  let options;
  const isSetupStore = typeof setup === "function";
  if (typeof idOrOptions === "string") {
    id = idOrOptions;
    options = isSetupStore ? setupOptions : setup;
  } else {
    options = idOrOptions;
    id = idOrOptions.id;
  }
  function useStore(pinia, hot) {
    const hasContext = hasInjectionContext();
    pinia = // in test mode, ignore the argument provided as we can always retrieve a
    // pinia instance with getActivePinia()
    (pinia) || (hasContext ? inject(piniaSymbol, null) : null);
    if (pinia)
      setActivePinia(pinia);
    pinia = activePinia;
    if (!pinia._s.has(id)) {
      if (isSetupStore) {
        createSetupStore(id, setup, options, pinia);
      } else {
        createOptionsStore(id, options, pinia);
      }
    }
    const store = pinia._s.get(id);
    return store;
  }
  useStore.$id = id;
  return useStore;
}
function storeToRefs(store) {
  {
    store = toRaw(store);
    const refs = {};
    for (const key in store) {
      const value = store[key];
      if (isRef(value) || isReactive(value)) {
        refs[key] = // ---
        toRef(store, key);
      }
    }
    return refs;
  }
}
const useApi = async (method, options = {}) => {
  const CONFIG = /* @__PURE__ */ useRuntimeConfig();
  options.headers = {
    "Content-Type": "application/json"
  };
  let url = CONFIG.public.base + "api/" + method;
  if (options.method.toUpperCase() === "PUT" || options.method.toUpperCase() === "GET" || options.method.toUpperCase() === "POST") {
    if (options.content_type === "multipart/form-data") {
      options.headers["Content-Type"] = "multipart/form-data";
      options.data = options.payload;
    } else {
      options.data = JSON.stringify(options.payload);
    }
  }
  {
    try {
      const {
        data: data2,
        statusText,
        status: statusCode
      } = await axios.request({
        url,
        ...options,
        headers: {
          "Content-Type": "application/json"
        },
        responseType: "json",
        transformRequest: [
          function(data22, headers) {
            return data22;
          }
        ],
        httpsAgent: new https.Agent({
          rejectUnauthorized: false
        })
      });
      let status = "error";
      if (statusCode >= 200 && statusCode < 300) {
        status = "success";
      }
      return {
        data: data2 ?? {},
        message: statusText,
        status
      };
    } catch (res) {
      if (res instanceof Object) {
        if (res.hasOwnProperty("response")) {
          const { data: data2 } = res.response;
          if (data2) {
            const { errors, message } = data2;
            if (errors) {
              return {
                errors,
                message,
                status: "error"
              };
            }
          }
        }
        return {
          data: {},
          message: res.message,
          status: "error"
        };
      }
      return {
        data: {},
        message: res,
        status: "error"
      };
    }
  }
};
const useAuthStore = defineStore("auth", {
  state: () => {
    return {
      user: null,
      employer: null,
      seeker: null,
      isAuthed: null,
      isEmployerMode: false,
      isSubscribed: false,
      geo: null,
      premium_url: null
    };
  },
  getters: {
    token(state) {
      var _a;
      return (_a = state.user) == null ? void 0 : _a.token;
    },
    userId(state) {
      var _a;
      return (_a = state.user) == null ? void 0 : _a.userId;
    },
    isEmployer(state) {
      return state.isEmployerMode;
    },
    isAuthenticated(state) {
      let authed = false;
      if (state.isAuthed === true) {
        authed = true;
      }
      return authed;
    }
  },
  actions: {
    toggleUserMode() {
      this.isEmployerMode = !this.isEmployerMode;
    },
    setUser(payload) {
      this.user = payload;
    },
    async signUp(payload) {
      console.log(payload);
      const response = await useApi("auth/register", {
        method: "post",
        payload
      });
      return response;
    },
    async confirmPhoneCode(payload) {
      var _a;
      const response = await useApi("auth/register/confirm", {
        method: "post",
        payload
      });
      console.log(response);
      if (response && response.data && response.data.data.hasOwnProperty("token")) {
        localStorage.setItem("token", (_a = response.data) == null ? void 0 : _a.data.token);
      }
      return response;
    },
    async sendRecoveryCode(payload) {
      const CONFIG = /* @__PURE__ */ useRuntimeConfig();
      let url = CONFIG.public.apiBase + "auth/forgot-password";
      try {
        const response = await axios.post(url, payload, {
          headers: {
            "Content-Type": "application/json"
          }
        });
        if ("data" in response) {
          return {
            status: "success",
            data: response.data.data
          };
        } else {
          return {
            status: "error",
            data: response.message
          };
        }
      } catch (error) {
        if ("data" in error.response) {
          return {
            status: "error",
            data: error.response.data
          };
        }
        return {
          status: "error",
          message: error.message
        };
      }
    },
    async recoverPasswordCode(payload) {
      const CONFIG = /* @__PURE__ */ useRuntimeConfig();
      let url = CONFIG.public.apiBase + "auth/check-reset-password-code";
      try {
        const response = await axios.post(url, payload, {
          headers: {
            "Content-Type": "application/json"
          }
        });
        return {
          status: "success",
          data: response.data.data
        };
      } catch (error) {
        console.log(error);
        if ("data" in error.response) {
          return {
            status: "error",
            data: error.response.data
          };
        }
        return {
          status: "error",
          message: error.message
        };
      }
    },
    async resetPassword(payload) {
      const CONFIG = /* @__PURE__ */ useRuntimeConfig();
      let url = CONFIG.public.apiBase + "auth/reset-password";
      try {
        const response = await axios.post(url, payload, {
          headers: {
            "Content-Type": "application/json"
          }
        });
        console.log(response);
        return {
          status: "success",
          data: response.data.data
        };
      } catch (error) {
        console.log(error);
        if ("data" in error.response) {
          return {
            status: "error",
            data: error.response.data
          };
        }
        return {
          status: "error",
          message: error.message
        };
      }
    },
    async refreshSeeker(url = "seeker/profile") {
      var _a;
      const { data: data2 } = await useApi(url, {
        method: "get"
      });
      if (data2 && "data" in data2) {
        this.seeker = data2.data;
        this.user = { phone: (_a = this.seeker) == null ? void 0 : _a.phone };
      }
      return data2;
    },
    async refreshEmployer(url = "employer/profile") {
      var _a;
      const response = await useApi(url, {
        method: "get"
      });
      if (response && response.data && "data" in response.data) {
        this.employer = response.data.data;
        this.user = { phone: (_a = this.employer) == null ? void 0 : _a.phone };
      }
      return response;
    },
    async tryLogin(token = "") {
      const CONFIG = /* @__PURE__ */ useRuntimeConfig();
      let url = CONFIG.public.apiBase + "seeker/profile";
      let url2 = CONFIG.public.apiBase + "employer/profile";
      if (!token)
        token = localStorage.getItem("token");
      if (token) {
        try {
          const response = await axios.get(url, {
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              Authorization: `Bearer ${token}`,
              proxyHeaders: false,
              credentials: false
            }
          });
          if (response.status !== 200 || response.data.status === "failed") {
            this.isAuthed = false;
            return false;
          }
          this.user = response.data.data;
          this.seeker = this.user;
          this.isAuthed = true;
          const response2 = await axios.get(url2, {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`
            }
          });
          this.user = { ...response2.data.data };
          this.employer = this.user;
          return true;
        } catch (error) {
          console.log("UnAuthorized");
          this.logout();
          return false;
        }
      }
      this.setUser(null);
      this.isAuthed = false;
      return false;
    },
    clearAuth() {
      localStorage.removeItem("token");
    },
    async signIn(payload) {
      const CONFIG = /* @__PURE__ */ useRuntimeConfig();
      let url = CONFIG.public.apiBase + "auth/login";
      try {
        const response = await axios.post(url, payload);
        const resData = response.data.data;
        if (response.status === 200) {
          localStorage.setItem("token", resData.token);
          this.user = resData.user;
          this.isAuthed = true;
          setTimeout(async () => {
            const token = await useFcm().getToken();
            const { data: data2 } = await useApi("fcm/setToken", {
              method: "post",
              payload: {
                fcm_token: token
              }
            });
          });
          return {
            status: "success",
            data: this.user
          };
        }
      } catch (error) {
        if (error.response && "data" in error.response) {
          if ("errors" in error.response.data) {
            return {
              status: "error",
              message: error.response.data.message,
              errors: error.response.data.errors
            };
          } else {
            return {
              status: "error",
              message: error.response.message
            };
          }
        }
        return {
          status: "error",
          message: error.message
        };
      }
    },
    autoLogout() {
      this.logout();
    },
    logout() {
      this.clearAuth();
      this.setUser(null);
      this.isAuthed = false;
      navigateTo("/");
    },
    async getLocation(payload = {}) {
      await useApi("area/location", {
        method: "get",
        params: payload
      });
    },
    async getPremium(payload = {}) {
      const response = await useApi("premium", {
        method: "get",
        params: payload
      });
      if (response.status === "success") {
        this.isSubscribed = response.data.data.premium;
        return this.isSubscribed;
      }
      return response;
    },
    async getPremiumUrl() {
      const url = useRequestURL();
      const hostname = url.hostname;
      const response = await useApi("getSettings", {
        method: "get",
        params: {
          setting_key: "sub_url",
          host: hostname
        }
      });
      if (response.status === "success") {
        this.premium_url = response.data.data;
        return this.premium_url;
      }
      return response;
    }
  }
});
const useProfileStore = defineStore("profile", {
  state: () => {
    return {
      user: null,
      seeker: null,
      employer: null,
      specializations: [],
      countries: [],
      regions: [],
      cities: [],
      professional_roles: [],
      hh_professional_roles: [],
      superjob_professional_roles: [],
      artifacts: [],
      my_resume_photo_artifact: []
    };
  },
  getters: {
    countryOptions(state) {
      return state.countries.map((item) => {
        return { name: item.name, value: item.id };
      });
    },
    cityOptions: (state) => {
      return state.cities.map((item) => {
        return { name: item.name, value: item.id };
      });
    },
    professional_roles_with_parent: (state) => {
      return state.professional_roles.filter((item) => item.parent_id !== 0).map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    hh_professional_roles_with_parent: (state) => {
      return state.hh_professional_roles.filter((item) => item.parent_id !== 0).map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    superjob_professional_roles_with_parent: (state) => {
      return state.superjob_professional_roles.filter((item) => item.parent_id !== 0).map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    hh_professional_roles_with_parent_ids: (state) => {
      return state.hh_professional_roles.filter((item) => item.parent_id !== 0).map((item) => item.id);
    },
    superjob_professional_roles_with_parent_ids: (state) => {
      return state.superjob_professional_roles.filter((item) => item.parent_id !== 0).map((item) => item.id);
    }
  },
  actions: {
    async getCountries(payload = {}) {
      const { data: data2 } = await useApi("area/countries", {
        method: "get",
        payload
      });
      if (data2 && "data" in data2) {
        if (data2.data.hasOwnProperty("countries")) {
          this.countries = data2.data.countries;
        } else {
          this.countries = data2.data;
        }
      }
      return data2;
    },
    async searchPhone(payload = {}) {
      const { data: data2 } = await useApi("scam/getPhoneInfo", {
        method: "get",
        payload
      });
      if (data2 && "data" in data2) {
        this.searched_phones = data2.data;
        return data2.data;
      }
      return data2;
    },
    async getRegions(payload = {}) {
      const { data: data2 } = await useApi("area/regions", {
        method: "get",
        payload
      });
      if ("data" in data2) {
        this.regions = data2.data.regions;
      }
      return data2;
    },
    async getCities(payload = {}) {
      const { data: data2 } = await useApi("area/cities", {
        method: "get",
        params: payload
      });
      if (data2 && "data" in data2) {
        if (data2.data.hasOwnProperty("cities")) {
          this.cities = data2.data.cities;
        } else {
          this.cities = data2.data;
        }
      }
      return data2;
    },
    async searchAreas(payload = {}) {
      const response = await useApi("area", {
        method: "get",
        params: payload
      });
      if (response.status === "failed") {
        return [];
      }
      return response.data.data ?? [];
    },
    async searchCities(payload = {}) {
      const response = await useApi("area/cities", {
        method: "get",
        params: payload
      });
      if (response.status !== "success") {
        return [];
      }
      return response.data.data ?? [];
    },
    async searchProfessionalRoles(payload = {}) {
      if (this.professional_roles.length > 0) {
        if (payload.search) {
          return this.professional_roles.filter(
            (item) => item.name.toLowerCase().includes(payload.search)
          );
        }
        return this.professional_roles;
      }
      const response = await useApi("professional_roles", {
        method: "get",
        params: payload
      });
      if (response.status === "failed") {
        return [];
      }
      this.professional_roles = response.data.data ?? [];
      return response.data.data ?? [];
    },
    async searchHHProfessionalRoles(payload = {}) {
      if (this.professional_roles.length > 0) {
        if (payload.search) {
          return this.professional_roles.filter(
            (item) => item.name.toLowerCase().includes(payload.search)
          );
        }
        return this.hh_professional_roles;
      }
      const response = await useApi("professional_roles", {
        method: "get",
        params: { providers: ["hh"] }
      });
      if (response.status === "failed") {
        return [];
      }
      this.hh_professional_roles = response.data.data ?? [];
      return response.data.data ?? [];
    },
    async searchSuperjobProfessionalRoles(payload = {}) {
      if (this.superjob_professional_roles.length > 0) {
        if (payload.search) {
          return this.superjob_professional_roles.filter(
            (item) => item.name.toLowerCase().includes(payload.search)
          );
        }
        return this.superjob_professional_roles;
      }
      const response = await useApi("professional_roles", {
        method: "get",
        params: { providers: ["superjob"] }
      });
      if (response.status === "failed") {
        return [];
      }
      this.superjob_professional_roles = response.data.data ?? [];
      return response.data.data ?? [];
    },
    async getCountryCities(payload = {}) {
      const response = await useApi("area/cities", {
        method: "get",
        params: payload
      });
      if (response.status === "success") {
        return response.data.data;
      }
      return [];
    },
    async getUser(payload = "") {
      const { isEmployer } = useAuthStore();
      let url = "seeker/profile";
      if (isEmployer) {
        url = "employer/profile";
        return this.getEmployer(url);
      } else {
        return this.getSeeker(url);
      }
    },
    async getSeeker(url = "") {
      var _a;
      const response = await useApi(url, {
        method: "get"
      });
      if (response.status === "success") {
        const { data: data2 } = response;
        if (!data2)
          return;
        this.seeker = data2.data;
        this.user = { phone: (_a = this.seeker) == null ? void 0 : _a.phone };
      }
      return response;
    },
    async getEmployer(url = "") {
      var _a;
      const response = await useApi(url, {
        method: "get"
      });
      if (response && response.data && "data" in response.data) {
        this.employer = response.data.data;
        this.user = { phone: (_a = this.employer) == null ? void 0 : _a.phone };
      }
      return response;
    },
    async updateSeeker(payload) {
      var _a;
      const response = await useApi("seeker/profile", {
        method: "post",
        content_type: "multipart/form-data",
        payload
      });
      if ("data" in response) {
        this.user = (_a = response.data) == null ? void 0 : _a.data;
      }
      return response;
    },
    async updateEmployer(payload) {
      var _a;
      payload.forEach(function(value, key) {
      });
      const response = await useApi("employer/profile", {
        method: "post",
        content_type: "multipart/form-data",
        payload
      });
      if ("data" in response) {
        this.user = (_a = response.data) == null ? void 0 : _a.data;
      }
      return response;
    },
    async sendMessage(payload) {
      return await useApi("support", {
        method: "post",
        payload
      });
    },
    async confirmEmail(payload) {
      return await useApi("profile/email/confirmation", {
        method: "post",
        payload
      });
    },
    async verifyEmailConfirmation(payload) {
      return await useApi("profile/email/verify", {
        method: "post",
        payload
      });
    },
    async upload(payload) {
      var _a;
      const CONFIG = /* @__PURE__ */ useRuntimeConfig();
      let url = CONFIG.public.apiBase + "upload";
      try {
        const response = await axios.post(url, payload, {
          headers: {
            "Content-Type": "multipart/form-data"
          }
        });
        if ("data" in response) {
          return {
            status: "success",
            path: response.data.path
          };
        }
      } catch (error) {
        console.log(error);
        if ("response" in error && ((_a = error.response.data) == null ? void 0 : _a.errors)) {
          return {
            status: "error",
            message: error.message,
            errors: error.response.data.errors
          };
        }
        return {
          status: "error",
          message: error.message
        };
      }
    },
    async getArtifacts(payload) {
      const response = await useApi("seeker/artifacts", {
        method: "get",
        params: payload
      });
      if (response.status === "success") {
        this.artifacts = response.data.data;
      }
      return response.data;
    },
    async uploadArtifact(payload) {
      const response = await useApi("seeker/artifact", {
        method: "POST",
        content_type: "multipart/form-data",
        payload
      });
      return response;
    },
    async getArtifact(id) {
      const response = await useApi("seeker/artifact/" + id, {
        method: "GET",
        params: {}
      });
      if (response.status === "success") {
        this.my_resume_photo_artifact = response.data.data;
      }
      return response;
    },
    async deleteArtifact(id) {
      const response = await useApi("seeker/artifact/" + id, {
        method: "DELETE",
        payload: {}
      });
      return response;
    }
  }
});
const auth_45global = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to, from) => {
});
const manifest_45route_45rule = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to) => {
  {
    return;
  }
});
const globalMiddleware = [
  validate,
  auth_45global,
  manifest_45route_45rule
];
const namedMiddleware = {};
const plugin$1 = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:router",
  enforce: "pre",
  async setup(nuxtApp) {
    var _a, _b, _c;
    let __temp, __restore;
    let routerBase = (/* @__PURE__ */ useRuntimeConfig()).app.baseURL;
    if (routerOptions.hashMode && !routerBase.includes("#")) {
      routerBase += "#";
    }
    const history = ((_a = routerOptions.history) == null ? void 0 : _a.call(routerOptions, routerBase)) ?? createMemoryHistory(routerBase);
    const routes = ((_b = routerOptions.routes) == null ? void 0 : _b.call(routerOptions, _routes)) ?? _routes;
    let startPosition;
    const initialURL = nuxtApp.ssrContext.url;
    const router = createRouter({
      ...routerOptions,
      scrollBehavior: (to, from, savedPosition) => {
        if (from === START_LOCATION) {
          startPosition = savedPosition;
          return;
        }
        if (routerOptions.scrollBehavior) {
          router.options.scrollBehavior = routerOptions.scrollBehavior;
          if ("scrollRestoration" in (void 0).history) {
            const unsub = router.beforeEach(() => {
              unsub();
              (void 0).history.scrollRestoration = "manual";
            });
          }
          return routerOptions.scrollBehavior(to, START_LOCATION, startPosition || savedPosition);
        }
      },
      history,
      routes
    });
    nuxtApp.vueApp.use(router);
    const previousRoute = shallowRef(router.currentRoute.value);
    router.afterEach((_to, from) => {
      previousRoute.value = from;
    });
    Object.defineProperty(nuxtApp.vueApp.config.globalProperties, "previousRoute", {
      get: () => previousRoute.value
    });
    const _route = shallowRef(router.resolve(initialURL));
    const syncCurrentRoute = () => {
      _route.value = router.currentRoute.value;
    };
    nuxtApp.hook("page:finish", syncCurrentRoute);
    router.afterEach((to, from) => {
      var _a2, _b2, _c2, _d;
      if (((_b2 = (_a2 = to.matched[0]) == null ? void 0 : _a2.components) == null ? void 0 : _b2.default) === ((_d = (_c2 = from.matched[0]) == null ? void 0 : _c2.components) == null ? void 0 : _d.default)) {
        syncCurrentRoute();
      }
    });
    const route = {};
    for (const key in _route.value) {
      Object.defineProperty(route, key, {
        get: () => _route.value[key]
      });
    }
    nuxtApp._route = shallowReactive(route);
    nuxtApp._middleware = nuxtApp._middleware || {
      global: [],
      named: {}
    };
    useError();
    try {
      if (true) {
        ;
        [__temp, __restore] = executeAsync(() => router.push(initialURL)), await __temp, __restore();
        ;
      }
      ;
      [__temp, __restore] = executeAsync(() => router.isReady()), await __temp, __restore();
      ;
    } catch (error2) {
      [__temp, __restore] = executeAsync(() => nuxtApp.runWithContext(() => showError(error2))), await __temp, __restore();
    }
    if ((_c = nuxtApp.ssrContext) == null ? void 0 : _c.islandContext) {
      return { provide: { router } };
    }
    const initialLayout = nuxtApp.payload.state._layout;
    router.beforeEach(async (to, from) => {
      var _a2, _b2;
      await nuxtApp.callHook("page:loading:start");
      to.meta = reactive(to.meta);
      if (nuxtApp.isHydrating && initialLayout && !isReadonly(to.meta.layout)) {
        to.meta.layout = initialLayout;
      }
      nuxtApp._processingMiddleware = true;
      if (!((_a2 = nuxtApp.ssrContext) == null ? void 0 : _a2.islandContext)) {
        const middlewareEntries = /* @__PURE__ */ new Set([...globalMiddleware, ...nuxtApp._middleware.global]);
        for (const component of to.matched) {
          const componentMiddleware = component.meta.middleware;
          if (!componentMiddleware) {
            continue;
          }
          for (const entry2 of toArray(componentMiddleware)) {
            middlewareEntries.add(entry2);
          }
        }
        for (const entry2 of middlewareEntries) {
          const middleware = typeof entry2 === "string" ? nuxtApp._middleware.named[entry2] || await ((_b2 = namedMiddleware[entry2]) == null ? void 0 : _b2.call(namedMiddleware).then((r) => r.default || r)) : entry2;
          if (!middleware) {
            throw new Error(`Unknown route middleware: '${entry2}'.`);
          }
          const result = await nuxtApp.runWithContext(() => middleware(to, from));
          {
            if (result === false || result instanceof Error) {
              const error2 = result || createError$1({
                statusCode: 404,
                statusMessage: `Page Not Found: ${initialURL}`
              });
              await nuxtApp.runWithContext(() => showError(error2));
              return false;
            }
          }
          if (result === true) {
            continue;
          }
          if (result || result === false) {
            return result;
          }
        }
      }
    });
    router.onError(async () => {
      delete nuxtApp._processingMiddleware;
      await nuxtApp.callHook("page:loading:end");
    });
    router.afterEach(async (to, _from, failure) => {
      delete nuxtApp._processingMiddleware;
      if (failure) {
        await nuxtApp.callHook("page:loading:end");
      }
      if ((failure == null ? void 0 : failure.type) === 4) {
        return;
      }
      if (to.matched.length === 0) {
        await nuxtApp.runWithContext(() => showError(createError$1({
          statusCode: 404,
          fatal: false,
          statusMessage: `Page not found: ${to.fullPath}`,
          data: {
            path: to.fullPath
          }
        })));
      } else if (to.redirectedFrom && to.fullPath !== initialURL) {
        await nuxtApp.runWithContext(() => navigateTo(to.fullPath || "/"));
      }
    });
    nuxtApp.hooks.hookOnce("app:created", async () => {
      try {
        await router.replace({
          ...router.resolve(initialURL),
          name: void 0,
          // #4920, #4982
          force: true
        });
        router.options.scrollBehavior = routerOptions.scrollBehavior;
      } catch (error2) {
        await nuxtApp.runWithContext(() => showError(error2));
      }
    });
    return { provide: { router } };
  }
});
const plugin = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  const pinia = createPinia();
  nuxtApp.vueApp.use(pinia);
  setActivePinia(pinia);
  {
    nuxtApp.payload.pinia = pinia.state.value;
  }
  return {
    provide: {
      pinia
    }
  };
});
const reducers = {
  NuxtError: (data2) => isNuxtError(data2) && data2.toJSON(),
  EmptyShallowRef: (data2) => isRef(data2) && isShallow(data2) && !data2.value && (typeof data2.value === "bigint" ? "0n" : JSON.stringify(data2.value) || "_"),
  EmptyRef: (data2) => isRef(data2) && !data2.value && (typeof data2.value === "bigint" ? "0n" : JSON.stringify(data2.value) || "_"),
  ShallowRef: (data2) => isRef(data2) && isShallow(data2) && data2.value,
  ShallowReactive: (data2) => isReactive(data2) && isShallow(data2) && toRaw(data2),
  Ref: (data2) => isRef(data2) && data2.value,
  Reactive: (data2) => isReactive(data2) && toRaw(data2)
};
const revive_payload_server_eJ33V7gbc6 = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:revive-payload:server",
  setup() {
    for (const reducer in reducers) {
      definePayloadReducer(reducer, reducers[reducer]);
    }
  }
});
const components_plugin_KR1HBZs4kY = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:global-components"
});
const device_VEtfIepYun = /* @__PURE__ */ defineNuxtPlugin(() => {
  let headers = useRequestHeaders();
  const md = new MobileDetect(headers["user-agent"]);
  const isMobile = md.phone() !== null || md.mobile() === "UnknownMobile";
  const isTablet = md.tablet() !== null || md.mobile() === "UnknownTablet";
  const isDesktop = !isMobile && !isTablet;
  return {
    provide: {
      isMobile: () => isMobile,
      isTablet: () => isTablet,
      isDesktop: () => isDesktop
    }
  };
});
const formatNumber_RGZB4gXTbG = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  return {
    provide: {
      format_number: function(value) {
        return new Intl.NumberFormat().format(value);
      },
      format_years: (years) => {
        if (years === 1) {
          return years + " год";
        } else if (years >= 2 && years <= 4) {
          return years + " года";
        } else {
          return years + " лет";
        }
      },
      format_months: (months) => {
        if (months === 1) {
          return months + " месяц";
        } else if (months >= 2 && months <= 4) {
          return months + " месяца";
        } else {
          return months + " месяцев";
        }
      },
      convert_month_to_text: (month_number) => {
        var months = [
          "Январь",
          "Февраль",
          "Март",
          "Апрель",
          "Май",
          "Июнь",
          "Июль",
          "Август",
          "Сентябрь",
          "Октябрь",
          "Ноябрь",
          "Декабрь"
        ];
        const monthIndex = parseInt(month_number, 10) - 1;
        return months[monthIndex];
      },
      format_phone: function(value = null) {
        const phone_mask = new IMask.createMask({
          mask: "+7 (000) 000-00-00"
        });
        if (value) {
          phone_mask.resolve(value.toString());
          return phone_mask.value;
        } else {
          return phone_mask.resolve("77777777777".toString());
        }
      }
    }
  };
});
const en = {
  name: "name"
};
const ru = {
  name: "Имя",
  create_resume: {
    validation: {
      required: "Обязательно для заполнения",
      invalid_email: "Неверный формат email"
    }
  }
};
const i18n_sVHQBgnb3t = /* @__PURE__ */ defineNuxtPlugin(({ vueApp }) => {
  const i18n = createI18n({
    legacy: false,
    globalInjection: true,
    locale: "ru",
    messages: {
      en,
      ru
    }
  });
  vueApp.use(i18n);
});
const moment_lgOtqBZZj3 = /* @__PURE__ */ defineNuxtPlugin(() => {
  moment.locale("ru");
  return {
    provide: {
      moment
    }
  };
});
const vClickOutside_m9zfvNnopr = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  nuxtApp.vueApp.use(vClickOutside);
});
const vue3_toastify_OGYNDsiW9E = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  nuxtApp.vueApp.use(Vue3Toastify, { autoClose: 1e3 });
  return {
    provide: { toast }
  };
});
const vueNumberFormat = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
});
const VueTelInputOptions = {
  defaultCountry: "RU",
  autoDefaultCountry: false,
  autoFormat: true,
  mode: "international"
};
const vueTelInput_OfB3YnbU52 = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  nuxtApp.vueApp.use(VueTelInput, VueTelInputOptions);
});
const plugins = [
  unhead_KgADcZ0jPj,
  plugin$1,
  plugin,
  revive_payload_server_eJ33V7gbc6,
  components_plugin_KR1HBZs4kY,
  device_VEtfIepYun,
  formatNumber_RGZB4gXTbG,
  i18n_sVHQBgnb3t,
  moment_lgOtqBZZj3,
  vClickOutside_m9zfvNnopr,
  vue3_toastify_OGYNDsiW9E,
  vueNumberFormat,
  vueTelInput_OfB3YnbU52
];
const layouts = {
  "advice-post": () => import('./_nuxt/advice-post-DbdGG4ZZ.mjs').then((m) => m.default || m),
  advice: () => import('./_nuxt/advice-Bu7U6lTW.mjs').then((m) => m.default || m),
  cabinet: () => import('./_nuxt/cabinet-LyybTwjJ.mjs').then((m) => m.default || m),
  custom: () => import('./_nuxt/custom-Bt6Romwo.mjs').then((m) => m.default || m),
  default: () => import('./_nuxt/default-BcQ6WfIB.mjs').then((m) => m.default || m),
  main: () => import('./_nuxt/main-kr42hMXt.mjs').then((m) => m.default || m)
};
const LayoutLoader = defineComponent({
  name: "LayoutLoader",
  inheritAttrs: false,
  props: {
    name: String,
    layoutProps: Object
  },
  async setup(props, context) {
    const LayoutComponent = await layouts[props.name]().then((r) => r.default || r);
    return () => h(LayoutComponent, props.layoutProps, context.slots);
  }
});
const __nuxt_component_0 = defineComponent({
  name: "NuxtLayout",
  inheritAttrs: false,
  props: {
    name: {
      type: [String, Boolean, Object],
      default: null
    },
    fallback: {
      type: [String, Object],
      default: null
    }
  },
  setup(props, context) {
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const injectedRoute = inject(PageRouteSymbol);
    const route = injectedRoute === useRoute() ? useRoute$1() : injectedRoute;
    const layout = computed(() => {
      let layout2 = unref(props.name) ?? route.meta.layout ?? "default";
      if (layout2 && !(layout2 in layouts)) {
        if (props.fallback) {
          layout2 = unref(props.fallback);
        }
      }
      return layout2;
    });
    const layoutRef = ref();
    context.expose({ layoutRef });
    const done = nuxtApp.deferHydration();
    return () => {
      const hasLayout = layout.value && layout.value in layouts;
      const transitionProps = route.meta.layoutTransition ?? appLayoutTransition;
      return _wrapIf(Transition, hasLayout && transitionProps, {
        default: () => h(Suspense, { suspensible: true, onResolve: () => {
          nextTick(done);
        } }, {
          default: () => h(
            LayoutProvider,
            {
              layoutProps: mergeProps(context.attrs, { ref: layoutRef }),
              key: layout.value || void 0,
              name: layout.value,
              shouldProvide: !props.name,
              hasTransition: !!transitionProps
            },
            context.slots
          )
        })
      }).default();
    };
  }
});
const LayoutProvider = defineComponent({
  name: "NuxtLayoutProvider",
  inheritAttrs: false,
  props: {
    name: {
      type: [String, Boolean]
    },
    layoutProps: {
      type: Object
    },
    hasTransition: {
      type: Boolean
    },
    shouldProvide: {
      type: Boolean
    }
  },
  setup(props, context) {
    const name = props.name;
    if (props.shouldProvide) {
      provide(LayoutMetaSymbol, {
        isCurrent: (route) => name === (route.meta.layout ?? "default")
      });
    }
    return () => {
      var _a, _b;
      if (!name || typeof name === "string" && !(name in layouts)) {
        return (_b = (_a = context.slots).default) == null ? void 0 : _b.call(_a);
      }
      return h(
        LayoutLoader,
        { key: name, layoutProps: props.layoutProps, name },
        context.slots
      );
    };
  }
});
const useVacancyStore = defineStore("vacancy", {
  state: () => {
    return {
      vacancies: [],
      vacancies_in_my_city: [],
      vacancy: null,
      my_vacancy: null,
      total: 0,
      my_total: 0,
      my_draft_total: 0,
      data: null,
      current_page: 1,
      my_draft_current_page: 1,
      my_draft_last_page: 0,
      my_vacancies: [],
      my_drafts: [],
      my_archived_vacancies: [],
      my_archived_vacancies_current_page: 1,
      my_archived_vacancies_last_page: 0,
      my_archived_vacancies_total: 0,
      my_favorite_vacancies: [],
      specializations: [],
      professional_roles: [],
      industries: [],
      areas: [],
      countries: [],
      regions: [],
      cities: [],
      work_types: [],
      schedules: [],
      experiences: [],
      part_times: [],
      metros: [],
      driver_licenses: [],
      genders: [],
      place_of_works: [],
      foreign_languages: [],
      language_levels: [],
      marital_statuses: [],
      childrens: [],
      vacancy_billing_types: [],
      vacancy_types: [],
      can_create_vacancy: null,
      can_create_vacancy_count: 1,
      providers: {
        hh: null,
        superjob: null
      },
      employerMessage: ""
    };
  },
  getters: {
    top_10: (state) => {
      return state.vacancies.slice(0, 10);
    },
    top_20: (state) => {
      return state.vacancies.slice(0, 20);
    },
    top_30: (state) => {
      return state.vacancies.slice(0, 30);
    },
    top_20_industries: (state) => {
      return state.industries.slice(0, 20);
    },
    industries_formatted_for_filter: (state) => {
      let new_items = JSON.parse(JSON.stringify(state.industries));
      new_items = new_items.map((item) => {
        item.parent_id = null;
        item.items = item.industries.map((sub_item) => {
          sub_item.parent_id = item.id;
          return sub_item;
        });
        delete item.industries;
        return item;
      });
      let items = [];
      new_items.map((item) => {
        items.push(item);
        items.concat(item.items);
      });
      return items;
    },
    professional_roles_formatted_for_filter: (state) => {
      let new_items = JSON.parse(JSON.stringify(state.professional_roles));
      const parent_items = new_items.filter((item) => item.parent_id === 0);
      for (let key in parent_items) {
        parent_items[key].professional_roles = new_items.filter(
          (item) => item.parent_id === item.id
        );
      }
      new_items = parent_items.map((item) => {
        item.parent_id = null;
        item.items = item.professional_roles.map((sub_item) => {
          sub_item.parent_id = item.id;
          return sub_item;
        });
        delete item.professional_roles;
        return item;
      });
      let items = [];
      new_items.map((item) => {
        items.push(item);
        items.concat(item.items);
      });
      return items.map((item) => {
        item.title = item.name;
        return item;
      });
    },
    my_city_vacancies: (state) => {
      return state.vacancies_in_my_city.slice(0, 3);
    },
    regions_formatted: (state) => {
      return state.regions.map((item) => ({ name: item.name, value: item.id }));
    },
    cities_formatted: (state) => {
      return state.cities.map((item) => ({ name: item.name, value: item.id }));
    },
    metros_formatted: (state) => {
      return state.metros.map((item) => ({ name: item.name, value: item.id }));
    }
  },
  actions: {
    async getConnectedEmployerProviders() {
      const response = await useApi("employer/used_providers", {
        method: "get",
        params: {}
      });
      if ("data" in response) {
        this.providers = response.data.data;
        return response;
      }
      return response;
    },
    async importVacancies() {
      const payload = [];
      if (this.providers.hh) {
        payload.push("hh");
      }
      if (this.providers.superjob) {
        payload.push("superjob");
      }
      const { data: data2 } = await useApi("employer/vacancies/import", {
        method: "post",
        payload: { providers: payload }
      });
      return data2;
    },
    async synVacancies() {
      const { data: data2 } = await useApi("employer/vacancies/sync", {
        method: "POST",
        payload: {
          providers: ["hh", "superjob"]
        }
      });
      return data2;
    },
    async getEmployerProvidersAuthEndpoints(payload, redirect_to = "/profile/service-verify") {
      const response = await useApi("services/auth/redirect-url", {
        method: "get",
        params: { ...payload, redirect_to, profile: "employer" }
      });
      if ("data" in response) {
        return response.data;
      }
      return response;
    },
    async getAreas(payload) {
      const { data: data2 } = await useApi("area", {
        method: "get",
        payload
      });
      if (data2) {
        this.areas = data2;
      }
      return data2;
    },
    async getVacancies(payload, add = false) {
      const response = await useApi("vacancies/search", {
        method: "get",
        params: payload
      });
      if (response.status === "success") {
        if (add) {
          console.log(response.data);
          this.vacancies = this.vacancies.concat(response.data.items);
          this.current_page++;
        } else {
          this.vacancies = response.data.items;
          this.current_page = 1;
        }
        this.total = response.data.found;
        return response;
      }
      return response;
    },
    async getCurrencyCityVacancies(payload) {
      const { data: data2 } = await useApi("vacancies/search", {
        method: "get",
        params: payload
      });
      if (data2 && "items" in data2) {
        this.vacancies_in_my_city = data2.items;
        return this.vacancies_in_my_city;
      }
      return data2;
    },
    async getVacancy(id, payload) {
      const response = await useApi("vacancy/" + id, {
        method: "get",
        params: payload
      });
      if (response.hasOwnProperty("data")) {
        this.vacancy = response.data;
      }
      return response.data;
    },
    async clearVacancies() {
      this.vacancies = [];
    },
    async getCreateAvailability(payload = {}) {
      const response = await useApi("employer/vacancy/availability_create", {
        method: "get",
        params: payload
      });
      console.log(response);
      if (response.status === "success") {
        this.can_create_vacancy = response.data.data.available;
        this.can_create_vacancy_count = response.data.data.free ?? 0;
        return;
      }
      return response;
    },
    async createDraft(payload, content_type = "application/json") {
      const response = await useApi("employer/vacancy/draft/create", {
        method: "post",
        content_type,
        payload
      });
      return response;
    },
    async updateDraft(id, payload, content_type = "application/json") {
      const response = await useApi("employer/vacancy/draft/" + id, {
        method: "PUT",
        content_type,
        payload
      });
      if ("data" in response && response.data.hasOwnProperty("data")) {
        this.my_vacancy = response.data.data;
      }
      return response;
    },
    async createDraftFromActiveVacancy(id, content_type = "application/json") {
      const response = await useApi("employer/vacancy/create/draft/" + id, {
        method: "POST",
        content_type,
        payload: {}
      });
      return response;
    },
    async updateVacancy(id, payload, content_type = "application/json") {
      const response = await useApi("employer/vacancy/" + id, {
        method: "PUT",
        content_type,
        payload
      });
      if ("data" in response && response.data.hasOwnProperty("data")) {
        return await this.getMyVacancy(id);
      }
      return response;
    },
    async publishDraft(id, payload = {}, content_type = "application/json") {
      const response = await useApi("employer/vacancy/publish/" + id, {
        method: "POST",
        content_type,
        payload
      });
      return response;
    },
    async getUserVacancies(payload) {
      return useApi("employer/vacancies", {
        method: "get",
        params: payload
      });
    },
    async getMyVacancies(payload) {
      const response = await this.getUserVacancies({
        status: "active",
        ...payload
      });
      if (response.hasOwnProperty("data") && "data" in response.data) {
        this.my_vacancies = response.data.data;
        this.my_total = response.data.meta.total;
        this.my_current_page = response.data.meta.current_page;
        this.my_last_page = response.data.meta.last_page;
      }
      return response;
    },
    async getArchivedVacancies(payload = {}) {
      const response = await this.getUserVacancies({
        status: "archived",
        ...payload
      });
      if (response.hasOwnProperty("data") && "data" in response.data) {
        this.my_archived_vacancies = response.data.data;
        this.my_archived_vacancies_total = response.data.meta.total;
        this.my_archived_vacancies_current_page = response.data.meta.current_page;
        this.my_archived_vacancies_last_page = response.data.meta.last_page;
      }
      return response;
    },
    async getMyDrafts(payload = {}) {
      const response = await useApi("employer/vacancy/drafts", {
        method: "get",
        params: {
          status: "draft",
          ...payload
        }
      });
      if (response.hasOwnProperty("data") && "data" in response.data) {
        this.my_drafts = response.data.data;
        this.my_draft_total = response.data.meta.total;
        this.my_draft_current_page = response.data.meta.current_page;
        this.my_draft_last_page = response.data.meta.last_page;
        return this.my_drafts;
      }
      return response;
    },
    async getMyDraft(payload) {
      const response = await useApi("employer/vacancy/draft/" + payload, {
        method: "get"
      });
      if (response && "data" in response && response.data && "data" in response.data) {
        this.my_vacancy = response.data.data;
      }
      return response;
    },
    async getMyVacancy(id) {
      const response = await useApi("employer/vacancy/" + id, {
        method: "get"
      });
      if (response && "data" in response && response.data && "data" in response.data) {
        this.my_vacancy = response.data.data;
      }
      return response;
    },
    async getMyFavoriteVacancies(payload) {
      const { data: data2 } = await useApi("seeker/favorites", {
        method: "get",
        params: payload
      });
      console.log(data2);
      if (data2 && data2.data && "items" in data2.data) {
        this.my_favorite_vacancies = data2.data.items;
        if (payload.page) {
          this.current_page = payload.page;
        }
      }
      return data2;
    },
    async getRegions(payload = {}) {
      const { data: data2 } = await useApi("area/regions", {
        method: "get",
        params: payload
      });
      if (data2 && "data" in data2) {
        this.regions = data2.data ?? [];
      }
      return data2;
    },
    async getCities(payload = {}) {
      const { data: data2 } = await useApi("area/cities", {
        method: "get",
        params: payload
      });
      if (data2 && "data" in data2) {
        this.cities = data2.data ?? [];
      }
      return data2;
    },
    async getSpecializations(payload = URLSearchParams) {
      if (this.specializations.length > 0) {
        return this.specializations;
      }
      const { data: data2 } = await useApi("specializations", {
        method: "get",
        params: payload
      });
      if (data2 && "data" in data2) {
        this.specializations = data2.data ?? [];
      }
      return data2;
    },
    async getIndustries(payload = {}) {
      if (this.industries.length > 0) {
        return this.industries;
      }
      const response = await useApi("industries", {
        method: "get",
        params: payload
      });
      if (response && "data" in response) {
        this.industries = response.data.data ?? [];
        return this.industries;
      }
      return response;
    },
    async getProfessionalRoles(payload = {}) {
      if (this.professional_roles.length > 0) {
        return this.professional_roles;
      }
      const response = await useApi("professional_roles", {
        method: "get",
        params: payload
      });
      console.log(response);
      if (response && "data" in response) {
        this.professional_roles = response.data.data ?? [];
        console.log(this.professional_roles);
        return this.professional_roles;
      }
      return response;
    },
    async getMetros(payload = URLSearchParams) {
      const { data: data2 } = await useApi("metro", {
        method: "get",
        params: payload
      });
      if (data2 && "data" in data2) {
        this.metros = data2.data ?? [];
        return this.metros;
      }
      return data2;
    },
    async addToFavorite(payload = URLSearchParams) {
      const response = await useApi("seeker/favorite", {
        method: "post",
        payload
      });
      return response;
    },
    async removeFromFavorite(id, payload) {
      const response = await useApi("seeker/favorite/" + id, {
        method: "delete",
        data: JSON.stringify(payload)
      });
      return response;
    },
    async deleteVacancy(id, payload = URLSearchParams) {
      const response = await useApi(
        "employer/vacancy/" + id + "?" + payload.toString(),
        {
          method: "delete"
        }
      );
      console.log(response);
      return response;
    },
    async deleteDraft(id) {
      const response = await useApi("employer/vacancy/draft/" + id, {
        method: "delete"
      });
      return response;
    },
    async archiveActiveVacancy(id, payload = URLSearchParams) {
      const response = await useApi("employer/vacancy/archiving/" + id, {
        method: "PUT",
        content_type: "application/json",
        payload
      });
      return response;
    }
  }
});
const useResumeStore = defineStore("resume", {
  state: () => {
    return {
      resumes: [],
      resume: null,
      my_resume: null,
      total: 0,
      my_total: 0,
      data: null,
      current_page: 1,
      my_resumes: [],
      my_favorite_resumes: [],
      specializations: [],
      industries: [],
      areas: [],
      countries: [],
      regions: [],
      cities: [],
      work_types: [],
      schedules: [],
      experiences: [],
      part_times: [],
      metros: [],
      can_create_resume: {},
      providers: {
        hh: null,
        superjob: null
      }
    };
  },
  getters: {
    top_10: (state) => {
      return state.resumes.slice(0, 10);
    },
    top_20: (state) => {
      return state.resumes.slice(0, 20);
    },
    top_30: (state) => {
      return state.resumes.slice(0, 30);
    }
  },
  actions: {
    async getAreas(payload) {
      const { data: data2 } = await useApi("area", {
        method: "get",
        payload
      });
      if (data2) {
        this.areas = data2;
      }
      return data2;
    },
    async getConnectedSeekerProviders(payload) {
      const response = await useApi("seeker/used_providers", {
        method: "get"
      });
      if (response.data && "data" in response.data) {
        this.providers = response.data.data;
        return this.providers;
      }
      return response;
    },
    async importResumes() {
      const { data: data2 } = await useApi("seeker/resumes/import", {
        method: "get"
      });
      return data2;
    },
    async syncResumes() {
      const { data: data2 } = await useApi("seeker/resumes/sync", {
        method: "get",
        params: {
          providers: ["hh", "superjob"]
        }
      });
      return data2;
    },
    async disconnectProviders(payload) {
      const { data: data2 } = await useApi("seeker/disconnect_providers", {
        method: "DELETE",
        params: payload
      });
      return data2;
    },
    async getSeekerProvidersAuthEndpoints(payload, redirect_to = "/profile/service-verify") {
      const { data: data2 } = await useApi(
        "services/auth/redirect-url?profile=seeker&redirect_to=" + redirect_to,
        {
          method: "get",
          payload
        }
      );
      if ("data" in data2) {
        return data2.data;
      }
      return data2;
    },
    async getResumes(payload, add = false, new_data = false) {
      console.log(payload, add);
      if (new_data !== true && this.resumes.length > 0) {
        return {
          status: "success",
          data: this.resumes
        };
      }
      const response = await useApi("resumes/search", {
        method: "get",
        params: payload
      });
      console.log(response);
      if (response.status === "status") {
        if (add) {
          this.resumes = this.resumes.concat(response.data.items);
          this.current_page++;
        } else {
          this.resumes = response.data.items;
          this.current_page = 1;
        }
        this.total = response.data.found;
      }
      return response;
    },
    async getMyNegotiations(payload) {
      const response = await useApi("seeker/negotiations", {
        method: "get",
        params: payload
      });
      if (response.hasOwnProperty("data")) {
        console.log(response.data);
        this.my_negotiations = response.data.items;
      }
      return response;
    },
    async getUserResumes(payload) {
      return useApi("seeker/resumes", {
        method: "get",
        payload
      });
    },
    async getMyResumes(payload) {
      const response = await this.getUserResumes(payload);
      if (response.hasOwnProperty("data") && "data" in response.data) {
        this.my_resumes = response.data.data;
        this.my_total = response.data.found;
        this.current_page = response.data.current_page;
      }
      return response;
    },
    async getMyResume(id) {
      const response = await useApi("seeker/resumes/" + id, {
        method: "GET"
      });
      if (response.hasOwnProperty("data") && "data" in response.data) {
        this.my_resume = response.data.data;
      }
      return response;
    },
    async deleteResume(id) {
      console.log(id);
      const response = await useApi("seeker/resumes/" + id, {
        method: "delete",
        payload: {}
      });
      console.log(response);
      return response;
    },
    // async getMyDrafts(payload, add = false) {
    //   const {data} = await useApi('resumes/search', {
    //     method: 'get',
    //     payload
    //   });
    //   if (data && 'items' in data){
    //       this.my_drafts = data.items;
    //       this.my_current_page = data.current_page;
    //       this.my_total = data.total;
    //   }
    //   return data;
    // },
    async getAvailabilityCreate(payload = {}) {
      const response = await useApi("seeker/resumes/availability_create", {
        method: "get",
        params: payload
      });
      console.log(response);
      if (response.status === "success") {
        this.can_create_resume = response.data.data.available;
        this.can_create_resume_count = response.data.data.free ?? 0;
        return;
      }
      return response;
    },
    async createResume(payload) {
      console.log(payload);
      const response = await useApi("seeker/resumes/create", {
        method: "post",
        payload
      });
      console.log(response);
      return response;
    },
    async submitResume(payload) {
      console.log(payload);
      const response = await useApi("seeker/negotiations", {
        method: "post",
        payload
      });
      console.log(response);
      return response;
    },
    async modifyNotifications(payload) {
      const response = await useApi("seeker/resumes/notifications", {
        method: "PUT",
        payload
      });
      return response;
    },
    async updateResume(id, payload) {
      const response = await useApi("seeker/resumes/" + id, {
        method: "PUT",
        payload
      });
      return response;
    },
    async publishResume(id, payload, content_type = "application/json") {
      console.log(payload);
      const response = await useApi("seeker/resumes/publish/" + id, {
        method: "PUT",
        content_type,
        payload
      });
      return response;
    },
    async getResume(id, payload) {
      const response = await useApi("seeker/resumes/" + id, {
        method: "get",
        params: payload
      });
      if (response.status === "success") {
        this.resume = data.data;
        return this.resume;
      }
      return response;
    },
    async clearResumes() {
      this.resumes = [];
    },
    async getMyFavoriteResumes(payload) {
      const response = await useApi("employer/resume/favorites", {
        method: "get",
        payload
      });
      console.log(response);
      if (response.status === "success") {
        this.my_favorite_resumes = response.data.data;
        if (payload.page) {
          this.current_page = payload.page;
        }
      }
      return response;
    },
    async getRegions(payload = {}) {
      const { data: data2 } = await useApi("area/regions", {
        method: "get",
        payload
      });
      if (data2) {
        this.regions = data2.data.regions;
      }
      return data2;
    },
    async getCities(payload = {}) {
      console.log(payload);
      const { data: data2 } = await useApi("area/cities", {
        method: "get",
        payload
      });
      if (data2) {
        console.log(data2);
        this.cities = data2.data.cities;
      }
      return data2;
    },
    async getSpecializations(payload) {
      const { data: data2 } = await useApi("specializations", {
        method: "get",
        payload
      });
      if (data2) {
        this.specializations = data2.data;
      }
      return data2;
    },
    async getWorkTypes(payload) {
      const { data: data2 } = await useApi("dictionaries?group=work_type", {
        method: "get",
        payload
      });
      if (data2) {
        this.work_types = data2.data.work_type;
      }
      return data2;
    },
    async getSchedules(payload = {}) {
      const { data: data2 } = await useApi("dictionaries?group=schedule", {
        method: "get",
        payload
      });
      if (data2) {
        this.schedules = data2.data.schedule;
      }
      return data2;
    },
    async getExperiences(payload = {}) {
      const { data: data2 } = await useApi("dictionaries?group=experience", {
        method: "get",
        payload
      });
      if (data2) {
        this.experiences = data2.data.experience;
      }
      return data2;
    },
    async getPartTimes(payload = {}) {
      const { data: data2 } = await useApi("dictionaries?group=part_time", {
        method: "get",
        payload
      });
      if (data2) {
        this.part_times = data2.data.part_time;
      }
      return data2;
    },
    async getIndustries(payload) {
      const { data: data2 } = await useApi("industries", {
        method: "get",
        payload
      });
      if (data2) {
        this.industries = data2.data;
      }
      return data2.data;
    },
    async getMetros(payload) {
      const { data: data2 } = await useApi("metro", {
        method: "get",
        payload
      });
      if (data2) {
        this.metros = data2.data;
      }
      return data2.data;
    },
    async addToFavorite(payload) {
      const response = await useApi("employer/resume/favorite", {
        method: "post",
        payload
      });
      console.log(this.resumes);
      if (response.status === "success") {
        this.resumes = this.resumes.map((resume) => {
          if (String(resume.id) === payload.resume_id) {
            resume.is_favorite = false;
            resume.favorite_id = response.data.data.id;
          }
          return resume;
        });
      }
      return response;
    },
    async getPhoneInfo(payload) {
      const response = await useApi("seeker/phone/info", {
        method: "get",
        params: payload
      });
      return response;
    },
    async getPhoneConfirmationCode(payload) {
      const response = await useApi("seeker/phone/send_code_to_verify", {
        method: "post",
        payload
      });
      return response;
    },
    async confirmPhoneConfirmationCode(payload) {
      const response = await useApi("seeker/phone/confirm", {
        method: "post",
        payload
      });
      return response;
    },
    async removeFromFavorite(id) {
      const response = await useApi("employer/resume/favorite/" + id, {
        method: "delete"
      });
      if (response.status === "success") {
        this.resumes = this.resumes.map((resume) => {
          if (resume.id === id) {
            resume.is_favorite = false;
          }
          return resume;
        });
      }
      return response;
    }
  }
});
const _sfc_main$2 = {
  __name: "app",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      meta: [
        {
          name: "viewport",
          content: "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"
        }
      ]
    });
    useVacancyStore();
    useResumeStore();
    useVacancyStore();
    useAuthStore();
    const route = useRoute();
    watch(
      () => route.query.message,
      () => {
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLayout = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_NuxtLayout, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("app.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const AppComponent = _sfc_main$2;
const _sfc_main$1 = {
  __name: "nuxt-error-page",
  __ssrInlineRender: true,
  props: {
    error: Object
  },
  setup(__props) {
    const props = __props;
    const _error = props.error;
    (_error.stack || "").split("\n").splice(1).map((line) => {
      const text = line.replace("webpack:/", "").replace(".vue", ".js").trim();
      return {
        text,
        internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
      };
    }).map((i) => `<span class="stack${i.internal ? " internal" : ""}">${i.text}</span>`).join("\n");
    const statusCode = Number(_error.statusCode || 500);
    const is404 = statusCode === 404;
    const statusMessage = _error.statusMessage ?? (is404 ? "Page Not Found" : "Internal Server Error");
    const description = _error.message || _error.toString();
    const stack = void 0;
    const _Error404 = defineAsyncComponent(() => import('./_nuxt/error-404-Bov4flsP.mjs').then((r) => r.default || r));
    const _Error = defineAsyncComponent(() => import('./_nuxt/error-500-Du5uvk0X.mjs').then((r) => r.default || r));
    const ErrorTemplate = is404 ? _Error404 : _Error;
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(ErrorTemplate), mergeProps({ statusCode: unref(statusCode), statusMessage: unref(statusMessage), description: unref(description), stack: unref(stack) }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/nuxt-error-page.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const ErrorComponent = _sfc_main$1;
const _sfc_main = {
  __name: "nuxt-root",
  __ssrInlineRender: true,
  setup(__props) {
    const IslandRenderer = defineAsyncComponent(() => import('./_nuxt/island-renderer-DoLBKaKP.mjs').then((r) => r.default || r));
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    nuxtApp.deferHydration();
    nuxtApp.ssrContext.url;
    const SingleRenderer = false;
    provide(PageRouteSymbol, useRoute());
    nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup");
    const error = useError();
    onErrorCaptured((err, target, info) => {
      nuxtApp.hooks.callHook("vue:error", err, target, info).catch((hookError) => console.error("[nuxt] Error in `vue:error` hook", hookError));
      {
        const p = nuxtApp.runWithContext(() => showError(err));
        onServerPrefetch(() => p);
        return false;
      }
    });
    const islandContext = nuxtApp.ssrContext.islandContext;
    return (_ctx, _push, _parent, _attrs) => {
      ssrRenderSuspense(_push, {
        default: () => {
          if (unref(error)) {
            _push(ssrRenderComponent(unref(ErrorComponent), { error: unref(error) }, null, _parent));
          } else if (unref(islandContext)) {
            _push(ssrRenderComponent(unref(IslandRenderer), { context: unref(islandContext) }, null, _parent));
          } else if (unref(SingleRenderer)) {
            ssrRenderVNode(_push, createVNode(resolveDynamicComponent(unref(SingleRenderer)), null, null), _parent);
          } else {
            _push(ssrRenderComponent(unref(AppComponent), null, null, _parent));
          }
        },
        _: 1
      });
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/nuxt-root.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const RootComponent = _sfc_main;
let entry;
{
  entry = async function createNuxtAppServer(ssrContext) {
    const vueApp = createApp(RootComponent);
    const nuxt = createNuxtApp({ vueApp, ssrContext });
    try {
      await applyPlugins(nuxt, plugins);
      await nuxt.hooks.callHook("app:created", vueApp);
    } catch (error) {
      await nuxt.hooks.callHook("app:error", error);
      nuxt.payload.error = nuxt.payload.error || createError(error);
    }
    if (ssrContext == null ? void 0 : ssrContext._renderResponse) {
      throw new Error("skipping render");
    }
    return vueApp;
  };
}
const entry$1 = (ssrContext) => entry(ssrContext);

export { LayoutMetaSymbol as L, PageRouteSymbol as P, __nuxt_component_0 as _, useRouter as a, useRuntimeConfig as b, createError as c, navigateTo as d, entry$1 as default, useRoute as e, appPageTransition as f, generateRouteKey$1 as g, appKeepalive as h, _wrapIf as i, useNuxtApp as j, useAuthStore as k, useVacancyStore as l, useProfileStore as m, nuxtLinkDefaults as n, defineStore as o, useRequestURL as p, useApi as q, useResumeStore as r, storeToRefs as s, toArray as t, useHead as u, vueNumberFormat as v, wrapInKeepAlive as w, __nuxt_component_0$1 as x };
//# sourceMappingURL=server.mjs.map
