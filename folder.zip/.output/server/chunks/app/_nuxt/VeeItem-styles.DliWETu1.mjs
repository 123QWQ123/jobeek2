const VeeItem_vue_vue_type_style_index_0_scoped_90ccc832_lang = ".absoluted_icon[data-v-90ccc832]{cursor:pointer;font-size:1rem;max-width:3rem;position:absolute;right:-2rem;top:.5rem;z-index:1}.absoluted_icon svg[data-v-90ccc832]{height:24px;width:24px}";

const VeeItemStyles_DliWETu1 = [VeeItem_vue_vue_type_style_index_0_scoped_90ccc832_lang];

export { VeeItemStyles_DliWETu1 as default };
//# sourceMappingURL=VeeItem-styles.DliWETu1.mjs.map
