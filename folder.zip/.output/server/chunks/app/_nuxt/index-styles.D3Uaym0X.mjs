const index_vue_vue_type_style_index_0_scoped_56917ac8_lang = ".progress[data-v-56917ac8]{background:none}";

const indexStyles_D3Uaym0X = [index_vue_vue_type_style_index_0_scoped_56917ac8_lang];

export { indexStyles_D3Uaym0X as default };
//# sourceMappingURL=index-styles.D3Uaym0X.mjs.map
