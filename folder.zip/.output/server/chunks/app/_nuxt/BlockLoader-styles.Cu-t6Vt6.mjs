const BlockLoader_vue_vue_type_style_index_0_scoped_0b087cd0_lang = ".loading[data-v-0b087cd0]{display:block;left:0;right:0;top:0;z-index:11}";

const BlockLoaderStyles_CuT6Vt6 = [BlockLoader_vue_vue_type_style_index_0_scoped_0b087cd0_lang];

export { BlockLoaderStyles_CuT6Vt6 as default };
//# sourceMappingURL=BlockLoader-styles.Cu-t6Vt6.mjs.map
