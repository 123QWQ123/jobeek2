import { useSSRContext, withAsyncContext, mergeProps, unref } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';
import { k as useAuthStore } from '../server.mjs';

const _sfc_main = {
  __name: "Premium",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const authStore = useAuthStore();
    const { getPremium, getPremiumUrl } = authStore;
    [__temp, __restore] = withAsyncContext(() => getPremiumUrl()), __temp = await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => getPremium()), __temp = await __temp, __restore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "premium-col sticky-item" }, _attrs))}>`);
      if (unref(authStore).isSubscribed) {
        _push(`<div class="title">\u041F\u0440\u0435\u043C\u0438\u0443\u043C</div>`);
      } else {
        _push(`<div class="title">\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u041F\u0440\u0435\u043C\u0438\u0443\u043C \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443</div>`);
      }
      if (unref(authStore).isSubscribed) {
        _push(`<a class="btn button-xs" href="#">\u041E\u0442\u043A\u043B\u044E\u0447\u0438\u0442\u044C </a>`);
      } else {
        _push(`<a class="notification-button button-accent">\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C </a>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MyVacancies/Premium.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Premium = _sfc_main;

export { Premium as P };
//# sourceMappingURL=Premium-A3GoIzm5.mjs.map
