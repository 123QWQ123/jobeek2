import { S as SeekerEditForm_vue_vue_type_style_index_0_lang } from './SeekerEditForm-styles-1.mjs-D7IIqgMQ.mjs';

const SeekerEditFormStyles_DzDNDbru = [SeekerEditForm_vue_vue_type_style_index_0_lang];

export { SeekerEditFormStyles_DzDNDbru as default };
//# sourceMappingURL=SeekerEditForm-styles.DzDNDbru.mjs.map
