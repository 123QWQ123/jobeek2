import { _ as __nuxt_component_0 } from './TheMainHeader-BNhvozaC.mjs';
import { _ as __nuxt_component_1 } from './page-DRc_CJ9B.mjs';
import { _ as __nuxt_component_2 } from './TheFooter-D-Qn_ABY.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderSlot, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './nuxt-link-BdrY0gEc.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import '../server.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './jobeek-dark-BM969tB2.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import './ui-DaXXToyC.mjs';

const _sfc_main = {
  computed: {
    hasHeaderSlot() {
      return !!this.$slots.header;
    },
    hasFooterSlot() {
      return !!this.$slots.footer;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_HeaderTheMainHeader = __nuxt_component_0;
  const _component_NuxtPage = __nuxt_component_1;
  const _component_the_footer = __nuxt_component_2;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "layout" }, _attrs))}>`);
  if ($options.hasHeaderSlot) {
    _push(`<header class="header">`);
    ssrRenderSlot(_ctx.$slots, "header", {}, null, _push, _parent);
    _push(`</header>`);
  } else {
    _push(ssrRenderComponent(_component_HeaderTheMainHeader, null, null, _parent));
  }
  _push(`<main class="main" role="main">`);
  _push(ssrRenderComponent(_component_NuxtPage, {
    key: _ctx.$route.fullPath
  }, null, _parent));
  _push(`</main>`);
  if ($options.hasFooterSlot) {
    _push(`<footer class="footer">`);
    ssrRenderSlot(_ctx.$slots, "footer", {}, null, _push, _parent);
    _push(`</footer>`);
  } else {
    _push(ssrRenderComponent(_component_the_footer, null, null, _parent));
  }
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/main.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const main = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { main as default };
//# sourceMappingURL=main-kr42hMXt.mjs.map
