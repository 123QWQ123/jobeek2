const Industry_vue_vue_type_style_index_0_scoped_e023a2ee_lang = ".check-block label[data-v-e023a2ee]{white-space:pre-wrap}";

const IndustryStyles_Yg02tLVt = [Industry_vue_vue_type_style_index_0_scoped_e023a2ee_lang];

export { IndustryStyles_Yg02tLVt as default };
//# sourceMappingURL=Industry-styles.Yg02tLVt.mjs.map
