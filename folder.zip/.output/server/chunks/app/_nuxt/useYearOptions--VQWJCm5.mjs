function useYearOptions(start = null, end = null, reverse = true) {
  const items = [];
  if (!start) {
    start = (/* @__PURE__ */ new Date()).getFullYear() - 50;
  }
  if (!end) {
    end = (/* @__PURE__ */ new Date()).getFullYear();
  }
  for (let i = start; i <= end; i++) {
    items.push({ name: i, value: i });
  }
  if (reverse) {
    items.reverse();
  }
  return items;
}

export { useYearOptions as u };
//# sourceMappingURL=useYearOptions--VQWJCm5.mjs.map
