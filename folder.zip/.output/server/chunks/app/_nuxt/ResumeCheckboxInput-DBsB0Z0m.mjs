import { useSSRContext, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrInterpolate } from 'vue/server-renderer';
import { _ as _imports_0 } from './check-BGWLIG1L.mjs';
import { useField } from 'vee-validate';

const __default__ = {
  name: "ResumeCheckboxInput"
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    name: String,
    label: String
  },
  setup(__props) {
    const props = __props;
    const { value, errorMessage } = useField(() => props.name);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="check-block"><div class="checkbox"><input type="checkbox"${ssrRenderAttr("name", props.name)}${ssrRenderAttr("id", props.name)}${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label${ssrRenderAttr("for", props.name)} class="fs-14">${ssrInterpolate(props.label)}</label></div><div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/ResumeCheckboxInput.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ResumeCheckboxInput = _sfc_main;

export { ResumeCheckboxInput as R };
//# sourceMappingURL=ResumeCheckboxInput-DBsB0Z0m.mjs.map
