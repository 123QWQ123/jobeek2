const List_vue_vue_type_style_index_0_scoped_72c59c3c_lang = ".vacancy_tabs .nav-link[data-v-72c59c3c]{padding:.8rem 2rem .5rem}.theme-checker input~.theme-checker-ui .circle.left[data-v-72c59c3c]{transform:translate(3px,-50%)}.theme-checker input~.theme-checker-ui .circle.right[data-v-72c59c3c]{transform:translate(30px,-50%)}";

const ListStyles_qVBxMpQM = [List_vue_vue_type_style_index_0_scoped_72c59c3c_lang];

export { ListStyles_qVBxMpQM as default };
//# sourceMappingURL=List-styles.qVBxMpQM.mjs.map
