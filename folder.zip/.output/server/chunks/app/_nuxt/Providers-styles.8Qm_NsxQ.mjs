const Providers_vue_vue_type_style_index_0_scoped_d45aaadf_lang = ".import-box[data-v-d45aaadf]{cursor:pointer}.import-box.is-loading[data-v-d45aaadf]{align-items:center;justify-content:center}.is-connected .import-box-dvnld .logo .check[data-v-d45aaadf]{display:block}.import-box.disabled[data-v-d45aaadf]{background:#fff;border-radius:12px;box-shadow:0 0 20px rgb(0 0 0/4%)}.import-box.disabled .import-box-dvnld[data-v-d45aaadf]{border:1px dashed #8c8c8c;color:#8c8c8c}.import-box.disabled .import-box-dvnld .logo[data-v-d45aaadf]{filter:grayscale(100%)}.import-box.disabled .import-box-dvnld span[data-v-d45aaadf]{color:#8c8c8c}";

const ProvidersStyles_8Qm_NsxQ = [Providers_vue_vue_type_style_index_0_scoped_d45aaadf_lang];

export { ProvidersStyles_8Qm_NsxQ as default };
//# sourceMappingURL=Providers-styles.8Qm_NsxQ.mjs.map
