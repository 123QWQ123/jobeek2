const searchPhone_vue_vue_type_style_index_0_scoped_4a99e80e_lang = ".search-phone-input[data-v-4a99e80e]::-moz-placeholder{color:#78757e}.search-phone-input[data-v-4a99e80e]::placeholder{color:#78757e}";

const searchPhoneStyles_foYY3_MF = [searchPhone_vue_vue_type_style_index_0_scoped_4a99e80e_lang];

export { searchPhoneStyles_foYY3_MF as default };
//# sourceMappingURL=search-phone-styles.foYY3_MF.mjs.map
