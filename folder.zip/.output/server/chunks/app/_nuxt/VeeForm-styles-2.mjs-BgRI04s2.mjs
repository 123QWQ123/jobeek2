const VeeForm_vue_vue_type_style_index_1_scoped_3f4bdef7_lang = ".selection[data-v-3f4bdef7]{border-radius:4px;left:0}.selected-options[data-v-3f4bdef7]{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.5rem;padding:0 .1rem .2rem}.multi-select_selected-item[data-v-3f4bdef7]{border:1px solid;border-radius:4px;padding:2px 4px 2px 2px}";

export { VeeForm_vue_vue_type_style_index_1_scoped_3f4bdef7_lang as V };
//# sourceMappingURL=VeeForm-styles-2.mjs-BgRI04s2.mjs.map
