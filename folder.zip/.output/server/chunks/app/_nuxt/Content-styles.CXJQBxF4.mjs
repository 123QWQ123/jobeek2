const Content_vue_vue_type_style_index_0_scoped_6eebcc62_lang = ".selection[data-v-6eebcc62]{border-radius:4px;left:0}.selected-options[data-v-6eebcc62]{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.5rem;padding:0 .1rem .2rem}.multi-select_selected-item[data-v-6eebcc62]{border:1px solid;border-radius:4px;padding:2px}";

const ContentStyles_CXJQBxF4 = [Content_vue_vue_type_style_index_0_scoped_6eebcc62_lang];

export { ContentStyles_CXJQBxF4 as default };
//# sourceMappingURL=Content-styles.CXJQBxF4.mjs.map
