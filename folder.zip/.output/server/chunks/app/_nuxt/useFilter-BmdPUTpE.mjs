function useFilter(defaultOptions = null) {
  const items = [];
  function uniq(array, field = null) {
    const unique_field_list = [];
    if (array.length === 0)
      return array;
    const first_item = array[0];
    if (first_item instanceof Object && field) {
      array.filter((item) => {
        if (!unique_field_list.includes(item[field])) {
          unique_field_list.push(item[field]);
          return true;
        }
      });
    }
    if (!(first_item instanceof Object)) {
      Array.from(new Set(array));
    }
    return items;
  }
  return { items, uniq };
}

export { useFilter as u };
//# sourceMappingURL=useFilter-BmdPUTpE.mjs.map
