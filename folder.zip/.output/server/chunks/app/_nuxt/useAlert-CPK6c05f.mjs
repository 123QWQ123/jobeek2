import { computed } from 'vue';
import { k as useAuthStore, e as useRoute, a as useRouter, d as navigateTo } from '../server.mjs';
import { toast } from 'vue3-toastify';

function useCheckJSON(str) {
  try {
    JSON.parse(str);
  } catch (e) {
    return false;
  }
  return true;
}
function useAlert(my_message = null) {
  const message = computed(() => {
    if (useCheckJSON(route.query.message)) {
      return JSON.parse(route.query.message);
    }
    return route.query.message;
  });
  const authStore = useAuthStore();
  const route = useRoute();
  const errorMessage = computed(() => {
    if (useCheckJSON(route.query.message)) {
      return JSON.parse(route.query.message).text;
    }
    return route.query.message;
  });
  const isAuthed = computed(() => authStore.isAuthenticated);
  const redirect = computed(() => {
    var _a;
    return (_a = message.value) == null ? void 0 : _a.redirect;
  });
  const alertType = computed(() => {
    if (useCheckJSON(route.query.message)) {
      const alert = JSON.parse(route.query.message);
      return alert.type;
    }
    return "success";
  });
  const router = useRouter();
  const handleAlert = () => {
    if (errorMessage.value) {
      if (alertType.value === "success") {
        toast.success(errorMessage, { autoClose: 3e3 });
      }
      if (alertType.value === "error") {
        toast.error(errorMessage, { autoClose: 3e3 });
      }
      if (alertType.value === "warning") {
        toast.warning(errorMessage, { autoClose: 3e3 });
      }
      if (!redirect.value) {
        console.log(redirect.value);
        if (isAuthed.value) {
          setTimeout(() => {
            navigateTo({
              name: "profile"
            });
          }, 3e3);
        } else {
          setTimeout(() => {
            navigateTo({
              name: "sign-in"
            });
          }, 3e3);
        }
      } else {
        console.log(redirect);
        setTimeout(() => {
          const queryParams = { ...route.query };
          delete queryParams.message;
          router.push({ query: queryParams });
        }, 3e3);
      }
    }
  };
  return { message, handleAlert };
}

export { useCheckJSON as a, useAlert as u };
//# sourceMappingURL=useAlert-CPK6c05f.mjs.map
