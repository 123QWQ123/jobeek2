const ModeSwitcher_vue_vue_type_style_index_0_scoped_a2404eb6_lang = ".right__box[data-v-a2404eb6]{margin-left:auto}.theme-checker input~.theme-checker-ui .circle.left[data-v-a2404eb6]{transform:translate(3px,-50%)}.theme-checker input~.theme-checker-ui .circle.right[data-v-a2404eb6]{transform:translate(30px,-50%)}@media only screen and (max-width:960px){.checker-box .v[data-v-a2404eb6]:not(.active){width:auto}}.theme-checker input~.theme-checker-ui[data-v-a2404eb6]{background:#5375fd}.theme-checker input~.theme-checker-ui .circle[data-v-a2404eb6]{background:#fff}";

const ModeSwitcherStyles_Bakusc65 = [ModeSwitcher_vue_vue_type_style_index_0_scoped_a2404eb6_lang];

export { ModeSwitcherStyles_Bakusc65 as default };
//# sourceMappingURL=ModeSwitcher-styles.Bakusc65.mjs.map
