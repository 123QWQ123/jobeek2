const _id__vue_vue_type_style_index_0_scoped_d6a61b4a_lang = ".button-accent.disabled[data-v-d6a61b4a]{filter:grayscale(180%)}@media (max-width:768px){.form-submit-container[data-v-d6a61b4a]{flex-direction:column-reverse}.button-accent[data-v-d6a61b4a]{margin-bottom:1rem}}";

const _id_Styles_CxDgTi4_ = [_id__vue_vue_type_style_index_0_scoped_d6a61b4a_lang];

export { _id_Styles_CxDgTi4_ as default };
//# sourceMappingURL=_id_-styles.CxDgTi4_.mjs.map
