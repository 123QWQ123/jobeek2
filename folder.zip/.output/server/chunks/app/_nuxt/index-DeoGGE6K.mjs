import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0$3 } from './SearchMobile-WfXJ1gHL.mjs';
import { P as PhoneDisabledInput, _ as __nuxt_component_0$1, a as __nuxt_component_1$1, b as __nuxt_component_4 } from './EmailInput-XpLRM13e.mjs';
import { _ as __nuxt_component_2 } from './VeeBirthDatePicker-7XRn76OG.mjs';
import { _ as __nuxt_component_0$2 } from './VeeSelectWithSearch-CuZCClCB.mjs';
import { _ as __nuxt_component_5 } from './BaseButton-CWRjb9_h.mjs';
import { useSSRContext, computed, ref, watch, withAsyncContext, mergeProps, unref, withCtx, createTextVNode } from 'vue';
import { useForm, useField } from 'vee-validate';
import { m as useProfileStore, k as useAuthStore, s as storeToRefs, e as useRoute, u as useHead, d as navigateTo } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { _ as __nuxt_component_0 } from './PageLoader-CgN00RaA.mjs';
import { a as useCheckJSON, u as useAlert } from './useAlert-CPK6c05f.mjs';
import { u as useFormValidation } from './useFormValidation-BMv_R6aU.mjs';
import { u as useResumeHooks } from './useResumeHooks-BM2nRo7f.mjs';
import { u as useDiff } from './useDiff-Chx28f43.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { P as Premium } from './Premium-A3GoIzm5.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './search-CNCM2ROA.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import 'imask';
import './Loader-UZvrxmyZ.mjs';
import './useYearOptions--VQWJCm5.mjs';
import 'moment';
import './nuxt-link-BdrY0gEc.mjs';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'vue-i18n';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const avatar = "" + buildAssetsURL("russian-man.xYrFsaOm.png");
const _sfc_main$1 = {
  __name: "SeekerEditForm",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const profileStore = useProfileStore();
    useAuthStore();
    const { getCityNameFromArea2 } = useResumeHooks();
    const { searchCities } = profileStore;
    const updateCityInput = async (newValue = "") => {
      if (newValue) {
        const items = await searchCities({
          search: newValue
        });
        cityOptions.value = items.map((item) => ({
          value: item.id,
          name: getCityNameFromArea2(item)
        }));
      }
    };
    computed(() => profileStore.seeker);
    const schema = computed(() => {
      return {
        first_name: "required|min:1|max:100",
        last_name: "required|min:1|max:100",
        email: { required: true, email: true },
        birth_date: "required|date",
        city_id: "required|numeric",
        country_id: "required|numeric"
      };
    });
    const { values, errors, meta, setErrors, resetForm, validate } = useForm({
      initialValues: {
        first_name: null,
        last_name: null,
        email: null,
        birth_date: null,
        city_id: null,
        country_id: 1
      },
      initialTouched: true,
      validationSchema: schema
    });
    const sectionData = ref({});
    const getFields = (newObject) => {
      var _a;
      return {
        first_name: newObject.first_name,
        last_name: newObject.last_name,
        email: newObject.email,
        email_to_verify: newObject.email_to_verify,
        phone: newObject.phone,
        birth_date: newObject.birth_date,
        city_id: newObject.city_id,
        country_id: (_a = newObject.country_id) != null ? _a : 1,
        photo_url: newObject.photo_url
      };
    };
    watch(
      () => profileStore.seeker,
      (newObject) => {
        if (newObject) {
          sectionData.value = getFields(newObject);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
          const country_id2 = newData.country_id;
          if (country_id2) {
            getCities({ country_ids: [country_id2] });
          }
        }
      }
    );
    const { getCountries, getCities } = profileStore;
    [__temp, __restore] = withAsyncContext(() => getCountries()), await __temp, __restore();
    const { countryOptions } = storeToRefs(profileStore);
    const cityOptions = ref([]);
    const { value: country_id, setValue: setCountryId } = useField("country_id");
    watch(
      () => country_id.value,
      (new_value) => {
        if (new_value) {
          getCities({ country_ids: [new_value] });
        }
      }
    );
    watch(
      () => profileStore.cities,
      (newItems) => {
        cityOptions.value = newItems.map((item) => ({
          value: item.id,
          name: getCityNameFromArea2(item)
        }));
      }
    );
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    ref(null);
    const isLoading = ref(false);
    const route = useRoute();
    computed(() => {
      if (useCheckJSON(route.query.message)) {
        return JSON.parse(route.query.message).text;
      }
      return route.query.message;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ProfilePhotoInput = __nuxt_component_0$1;
      const _component_CustomTextInput = __nuxt_component_1$1;
      const _component_VeeBirthDatePicker = __nuxt_component_2;
      const _component_VeeSelectWithSearch = __nuxt_component_0$2;
      const _component_ProfileEmailInput = __nuxt_component_4;
      const _component_base_button = __nuxt_component_5;
      _push(`<form${ssrRenderAttrs(mergeProps({
        class: "w-box-body",
        autocomplete: "off"
      }, _attrs))} data-v-25e47d92>`);
      if (unref(isLoading)) {
        _push(ssrRenderComponent(unref(__nuxt_component_0), null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_ProfilePhotoInput, {
        name: "photo",
        preview: "photo_url",
        avatar: unref(avatar)
      }, null, _parent));
      _push(`<div class="input-row" data-v-25e47d92><label for="name" data-v-25e47d92>\u0418\u043C\u044F \u0438 \u0444\u0430\u043C\u0438\u043B\u0438\u044F <b data-v-25e47d92>*</b></label><div class="input-wrapper" data-v-25e47d92><div class="c2" data-v-25e47d92>`);
      _push(ssrRenderComponent(_component_CustomTextInput, {
        name: "first_name",
        placeholder: "\u0418\u043C\u044F"
      }, null, _parent));
      _push(ssrRenderComponent(_component_CustomTextInput, {
        name: "last_name",
        placeholder: "\u0424\u0430\u043C\u0438\u043B\u0438\u044F"
      }, null, _parent));
      _push(`</div></div></div><div class="input-row" data-v-25e47d92><label data-v-25e47d92>\u0414\u0430\u0442\u0430 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F <b data-v-25e47d92>*</b></label><div class="input-wrapper" data-v-25e47d92>`);
      _push(ssrRenderComponent(_component_VeeBirthDatePicker, { name: "birth_date" }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-25e47d92><label for="country" data-v-25e47d92>\u0413\u043E\u0440\u043E\u0434 \u043F\u0440\u043E\u0436\u0438\u0432\u0430\u043D\u0438\u044F <b data-v-25e47d92>*</b></label><div class="input-wrapper" data-v-25e47d92>`);
      _push(ssrRenderComponent(_component_VeeSelectWithSearch, {
        options: unref(countryOptions),
        name: "country_id",
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0443",
        not_found: "\u0421\u0442\u0440\u0430\u043D\u0430 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E"
      }, null, _parent));
      _push(`<div class="mt-2" data-v-25e47d92>`);
      _push(ssrRenderComponent(_component_VeeSelectWithSearch, {
        options: unref(cityOptions),
        onInput: updateCityInput,
        name: "city_id",
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0433\u043E\u0440\u043E\u0434",
        not_found: "\u0413\u043E\u0440\u043E\u0434 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E"
      }, null, _parent));
      _push(`</div></div><div class="input-wrapper mt-2" data-v-25e47d92></div></div><div class="input-row" data-v-25e47d92><label for="phone" data-v-25e47d92>\u0422\u0435\u043B\u0435\u0444\u043E\u043D</label><div class="input-wrapper" data-v-25e47d92>`);
      _push(ssrRenderComponent(PhoneDisabledInput, { name: "phone" }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-25e47d92><label for="email" data-v-25e47d92>\u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0447\u0442\u0430<b data-v-25e47d92>*</b></label><div class="input-wrapper" data-v-25e47d92>`);
      _push(ssrRenderComponent(_component_ProfileEmailInput, {
        name: "email",
        type: "seeker",
        key: "employer_email"
      }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-25e47d92><label for="password" data-v-25e47d92>\u041F\u0430\u0440\u043E\u043B\u044C<b data-v-25e47d92>*</b></label><div class="input-wrapper position-relative" data-v-25e47d92>`);
      _push(ssrRenderComponent(_component_CustomTextInput, {
        type: "password",
        name: "password",
        placeholder: "********"
      }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-25e47d92><div class="input-wrapper" data-v-25e47d92>`);
      _push(ssrRenderComponent(_component_base_button, { type: "submit" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C`);
          } else {
            return [
              createTextVNode("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></form>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Profile/SeekerEditForm.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-25e47d92"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u0412\u0430\u0448 \u0430\u043A\u043A\u0430\u0443\u043D\u0442"
    });
    const authStore = useAuthStore();
    computed(() => authStore.isEmployer);
    const route = useRoute();
    computed(() => {
      return route.query.message;
    });
    const isCompleted = computed(() => {
      if (!authStore.isEmployer) {
        if (authStore.seeker) {
          return authStore.seeker.is_completed;
        }
        return false;
      }
      if (authStore.isEmployer) {
        if (authStore.employer) {
          return authStore.employer.is_completed;
        }
        return false;
      }
      return false;
    });
    useAlert();
    watch(
      () => authStore.isEmployer,
      (newValue) => {
        console.log(newValue);
        if (newValue) {
          navigateTo({ name: "profile-employer" });
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0$3;
      const _component_ProfileSeekerEditForm = __nuxt_component_1;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet profile-page bg-wrapper",
        role: "main"
      }, _attrs))} data-v-21be425e>`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="has-sidebar has-sidebar--v2 wrapper wrapper-1290" data-v-21be425e><div class="content" data-v-21be425e>`);
      if (!unref(isCompleted)) {
        _push(`<div class="w-box bg-white" data-v-21be425e><p class="text-danger p-3" data-v-21be425e> \u041F\u0435\u0440\u0435\u0434 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u0438 \u0441\u0435\u0440\u0432\u0438\u0441\u0430 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u0432\u0430\u0448\u0435\u0433\u043E \u043F\u0440\u043E\u0444\u0438\u043B\u044F. </p></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="w-box w-box--main" data-v-21be425e><div class="w-box-head" data-v-21be425e><h1 class="title" data-v-21be425e>\u041F\u0440\u043E\u0444\u0438\u043B\u044C</h1></div>`);
      _push(ssrRenderComponent(_component_ProfileSeekerEditForm, null, null, _parent));
      _push(`</div></div><aside class="sidebar" data-v-21be425e>`);
      _push(ssrRenderComponent(Premium, null, null, _parent));
      _push(`</aside></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/profile/seeker/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-21be425e"]]);

export { index as default };
//# sourceMappingURL=index-DeoGGE6K.mjs.map
