import { useSSRContext, ref, watch, computed, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderDynamicModel, ssrIncludeBooleanAttr, ssrRenderComponent, ssrRenderStyle } from 'vue/server-renderer';
import { useField } from 'vee-validate';
import IMask from 'imask';
import { _ as __nuxt_component_2 } from './Loader-UZvrxmyZ.mjs';
import { m as useProfileStore, s as storeToRefs } from '../server.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const _sfc_main$3 = {
  __name: "PhotoInput",
  __ssrInlineRender: true,
  props: ["name", "preview", "avatar"],
  setup(__props) {
    var _a;
    const props = __props;
    const { value, setValue, errorMessage } = useField(() => props.name);
    const { value: previewUrl } = useField(() => props.preview);
    ref();
    const base64 = ref(null);
    const photo_url = ref((_a = previewUrl.value) != null ? _a : null);
    const photo = ref(null);
    watch(
      () => photo.value,
      () => {
        setValue(photo.value);
      }
    );
    watch(
      () => previewUrl.value,
      () => {
        photo_url.value = previewUrl.value;
      }
    );
    watch(
      () => props.avatar,
      () => {
        photo_url.value = previewUrl.value;
      }
    );
    const photoUrl = computed(() => {
      if (base64.value) {
        return base64.value;
      } else if (photo_url.value) {
        return photo_url.value;
      } else
        return props.avatar;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="photo">\u0424\u043E\u0442\u043E</label><div class="dwld-photo"><div class="photo"><input type="file" name="photo" id="photo"><img${ssrRenderAttr("src", unref(photoUrl))} alt="#"><div class="photo-actions"><button class="photo-action redact" type="button"><svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 24.5H24.5" stroke="#D2D2D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M14.2583 6.79933L20.0333 12.5743M14.2583 6.79933L17.5577 3.5L23.3327 9.275L20.0333 12.5743L14.2583 6.79933ZM14.2583 6.79933L7.71683 13.3408C7.49803 13.5596 7.37507 13.8563 7.375 14.1657V19.4577H12.667C12.9764 19.4576 13.2731 19.3346 13.4918 19.1158L20.0333 12.5743L14.2583 6.79933Z" stroke="#D2D2D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></button><button class="photo-action delete" type="button"><svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14.0007 2.04175C14.9691 2.04168 15.901 2.41223 16.6049 3.07737C17.3089 3.7425 17.7317 4.65181 17.7865 5.61875L17.7923 5.83342H23.9173C24.139 5.83348 24.3524 5.9177 24.5144 6.06905C24.6764 6.2204 24.7749 6.4276 24.79 6.64878C24.8051 6.86995 24.7357 7.08862 24.5958 7.2606C24.4559 7.43257 24.2559 7.54503 24.0363 7.57525L23.9173 7.58342H22.9887L21.4953 22.7734C21.4205 23.5307 21.0789 24.2367 20.5316 24.7655C19.9843 25.2942 19.2669 25.6111 18.5075 25.6597L18.3022 25.6667H9.69915C8.93786 25.6667 8.20138 25.396 7.62132 24.9029C7.04127 24.4099 6.65546 23.7266 6.53282 22.9753L6.50598 22.7722L5.01148 7.58342H4.08398C3.87254 7.58341 3.66825 7.50683 3.5089 7.36785C3.34955 7.22887 3.24591 7.03689 3.21715 6.82742L3.20898 6.70842C3.20899 6.49697 3.28557 6.29268 3.42455 6.13333C3.56352 5.97398 3.75551 5.87034 3.96498 5.84158L4.08398 5.83342H10.209C10.209 4.8278 10.6085 3.86338 11.3195 3.1523C12.0306 2.44123 12.995 2.04175 14.0007 2.04175ZM21.2305 7.58342H6.76965L8.24782 22.6007C8.28055 22.9358 8.42821 23.2493 8.66575 23.4879C8.90328 23.7265 9.21605 23.8755 9.55098 23.9097L9.69915 23.9167H18.3022C19.0022 23.9167 19.596 23.4209 19.7313 22.7477L19.7547 22.6007L21.2293 7.58342H21.2305ZM16.0423 10.7917C16.2538 10.7918 16.4581 10.8683 16.6174 11.0073C16.7768 11.1463 16.8804 11.3383 16.9092 11.5477L16.9173 11.6667V19.8334C16.9173 20.0551 16.833 20.2685 16.6817 20.4305C16.5303 20.5925 16.3231 20.691 16.102 20.7061C15.8808 20.7212 15.6621 20.6518 15.4901 20.5119C15.3182 20.372 15.2057 20.172 15.1755 19.9524L15.1673 19.8334V11.6667C15.1673 11.4347 15.2595 11.2121 15.4236 11.048C15.5877 10.8839 15.8103 10.7917 16.0423 10.7917ZM11.959 10.7917C12.1704 10.7918 12.3747 10.8683 12.5341 11.0073C12.6934 11.1463 12.7971 11.3383 12.8258 11.5477L12.834 11.6667V19.8334C12.8339 20.0551 12.7497 20.2685 12.5983 20.4305C12.447 20.5925 12.2398 20.691 12.0186 20.7061C11.7974 20.7212 11.5788 20.6518 11.4068 20.5119C11.2348 20.372 11.1224 20.172 11.0922 19.9524L11.084 19.8334V11.6667C11.084 11.4347 11.1762 11.2121 11.3403 11.048C11.5044 10.8839 11.7269 10.7917 11.959 10.7917ZM14.0007 3.79175C13.4883 3.79177 12.9946 3.98445 12.6177 4.33154C12.2408 4.67864 12.0081 5.15476 11.966 5.66541L11.959 5.83342H16.0423C16.0423 5.29193 15.8272 4.77263 15.4443 4.38974C15.0614 4.00685 14.5421 3.79175 14.0007 3.79175Z" fill="#D2D2D2"></path></svg></button></div></div></div><div class="text text-danger">${ssrInterpolate(unref(errorMessage))}</div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Profile/PhotoInput.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$3;
const __default__ = {
  name: "CustomTextInput"
};
const _sfc_main$2 = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    name: String,
    type: String,
    placeholder: String
  },
  setup(__props) {
    const props = __props;
    const { value, errorMessage } = useField(() => props.name);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><input${ssrRenderDynamicModel(props.type, unref(value), null)}${ssrRenderAttr("type", props.type)}${ssrRenderAttr("placeholder", props.placeholder)}>`);
      if (unref(errorMessage)) {
        _push(`<span class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/CustomTextInput.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "PhoneDisabledInput",
  __ssrInlineRender: true,
  props: ["name"],
  setup(__props) {
    const props = __props;
    const { value, setValue, error: errorMessage } = useField(() => props.name);
    const phoneInputElement = ref();
    const phoneMask = ref(null);
    watch(
      () => value.value,
      (newPhone) => {
        phoneMask.value = new IMask(phoneInputElement.value, {
          mask: "+{7}(000)000-00-00"
        });
        phoneMask.value.unmaskedValue = newPhone;
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><input type="text" placeholder="\u0422\u0435\u043B\u0435\u0444\u043E\u043D" disabled id="phone"><div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div><!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Profile/PhoneDisabledInput.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const PhoneDisabledInput = _sfc_main$1;
const _sfc_main = {
  __name: "EmailInput",
  __ssrInlineRender: true,
  props: {
    name: {
      type: String,
      default: "email"
    },
    type: {
      type: String,
      default: "seeker",
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const { value, setValue, errorMessage, setErrors } = useField(() => props.name);
    const email_to_verify = ref();
    const email = ref(value.value);
    const is_email_to_verify_sent = ref(false);
    const currentValue = ref(null);
    const isLoading = ref(false);
    const isConfirmButton = ref(false);
    const isCheckButton = ref(false);
    const isConfirmationSent = ref(false);
    ref();
    const profileStore = useProfileStore();
    storeToRefs(profileStore);
    const disabled = computed(() => {
      if (!value.value)
        return false;
      return true;
    });
    const reAssignEmails = (newObject) => {
      var _a;
      email_to_verify.value = newObject.email_to_verify;
      email.value = newObject.email;
      currentValue.value = (_a = newObject.email) != null ? _a : newObject.email_to_verify;
      if (!newObject.is_completed) {
        if (newObject.email !== null) {
          isCheckButton.value = false;
          isConfirmButton.value = false;
        } else {
          isCheckButton.value = false;
          isConfirmButton.value = true;
        }
      } else {
        if (newObject.email_to_verify !== null && newObject.email !== newObject.email_to_verify) {
          isCheckButton.value = false;
          isConfirmButton.value = true;
        } else {
          currentValue.value = email.value;
          isCheckButton.value = true;
          isConfirmButton.value = false;
        }
      }
    };
    watch(
      () => profileStore.seeker,
      (newObject) => {
        if (props.type === "seeker") {
          if (profileStore.seeker) {
            reAssignEmails(profileStore.seeker);
          }
        }
      }
    );
    watch(
      () => profileStore.employer,
      (newObject) => {
        if (props.type === "employer") {
          if (profileStore.employer) {
            reAssignEmails(profileStore.employer);
          }
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Loader = __nuxt_component_2;
      _push(`<!--[--><div class="position-relative" data-v-6f01572e><input type="email"${ssrIncludeBooleanAttr(unref(disabled)) ? " disabled" : ""}${ssrRenderAttr("value", unref(currentValue))} placeholder="\u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0447\u0442\u0430" data-v-6f01572e>`);
      if (unref(isConfirmButton)) {
        _push(`<span class="btn btn-outline-primary absolute_button" data-v-6f01572e> \u041F\u043E\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0442\u044C `);
        if (unref(isLoading)) {
          _push(ssrRenderComponent(_component_Loader, { class: "text-light spinner-border-sm" }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</span>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isConfirmationSent)) {
        _push(`<span class="btn btn-outline-success absolute_button" data-v-6f01572e><svg style="${ssrRenderStyle({ "width": "22px", "height": "22px", "margin-top": "0" })}" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" data-v-6f01572e><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.5 11.5 11 14l4-4m6 2a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" data-v-6f01572e></path></svg> \u041E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E </span>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isCheckButton)) {
        _push(`<span class="btn btn-outline-success absolute_button pe-auto" data-v-6f01572e><svg style="${ssrRenderStyle({ "width": "22px", "height": "22px", "margin-top": "0" })}" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" class="green_icon" viewBox="0 0 24 24" data-v-6f01572e><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.5 11.5 11 14l4-4m6 2a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" data-v-6f01572e></path></svg></span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (unref(is_email_to_verify_sent)) {
        _push(`<div class="text-success" data-v-6f01572e> \u041D\u0430 \u0432\u0430\u0448\u0443 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0443\u044E \u043F\u043E\u0447\u0442\u0443 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E \u043F\u0438\u0441\u044C\u043C\u043E \u0441 \u043A\u043E\u0434\u043E\u043C \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F. </div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="text-danger" data-v-6f01572e>${ssrInterpolate(unref(errorMessage))}</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Profile/EmailInput.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-6f01572e"]]);

export { PhoneDisabledInput as P, __nuxt_component_0 as _, __nuxt_component_1 as a, __nuxt_component_4 as b };
//# sourceMappingURL=EmailInput-XpLRM13e.mjs.map
