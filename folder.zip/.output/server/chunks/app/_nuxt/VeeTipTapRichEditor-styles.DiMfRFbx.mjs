const VeeTipTapRichEditor_vue_vue_type_style_index_0_lang = ".parsed_content{color:#000;font-family:var(--font-family);font-feature-settings:var(--font-feature-settings,normal);font-size:1rem;//background:#d5d5d5;//padding:.5rem .75rem;-webkit-appearance:none;-moz-appearance:none;appearance:none;border:1px solid #bbb;border-radius:6px;outline-color:transparent;padding:1rem;transition:background-color .2s,color .2s,border-color .2s,box-shadow .2s,outline-color .2s}.parsed_content strong{font-weight:bolder}.parsed_content em{font-style:italic}.parsed_content s{text-decoration:line-through}.parsed_content ul{list-style-type:disc;padding-left:1em}.parsed_content ol{list-style-type:number;padding-left:1em}.parsed_content ol li,.parsed_content ul li{padding-left:.5em}";

const VeeTipTapRichEditorStyles_DiMfRFbx = [VeeTipTapRichEditor_vue_vue_type_style_index_0_lang];

export { VeeTipTapRichEditorStyles_DiMfRFbx as default };
//# sourceMappingURL=VeeTipTapRichEditor-styles.DiMfRFbx.mjs.map
