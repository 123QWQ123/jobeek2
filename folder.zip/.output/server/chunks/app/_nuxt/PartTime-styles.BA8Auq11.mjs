const PartTime_vue_vue_type_style_index_0_scoped_4e37f63c_lang = ".check-block label[data-v-4e37f63c]{white-space:pre-wrap}.with_scroll[data-v-4e37f63c]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-4e37f63c]{font-weight:700}.is_header .radio-mask[data-v-4e37f63c],.is_header input[data-v-4e37f63c]{display:none}input[type=search][data-v-4e37f63c]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const PartTimeStyles_BA8Auq11 = [PartTime_vue_vue_type_style_index_0_scoped_4e37f63c_lang];

export { PartTimeStyles_BA8Auq11 as default };
//# sourceMappingURL=PartTime-styles.BA8Auq11.mjs.map
