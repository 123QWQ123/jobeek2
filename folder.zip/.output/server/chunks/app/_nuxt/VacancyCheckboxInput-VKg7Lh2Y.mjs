import { useSSRContext, unref, ref, watch, resolveDirective, mergeProps, computed } from 'vue';
import { ssrRenderDynamicModel, ssrRenderAttr, ssrInterpolate, ssrRenderAttrs, ssrGetDirectiveProps, ssrRenderStyle, ssrRenderList, ssrRenderComponent, ssrIncludeBooleanAttr, ssrLooseContain } from 'vue/server-renderer';
import { useField, useFieldArray, ErrorMessage } from 'vee-validate';
import { u as useSort } from './useSort-Dy_x39w5.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { m as useProfileStore, l as useVacancyStore } from '../server.mjs';
import { u as useFilter } from './useFilter-BmdPUTpE.mjs';
import { u as useProviders } from './useProviders-Ck9yopDY.mjs';
import { _ as _imports_0 } from './check-BGWLIG1L.mjs';

const __default__$2 = {
  name: "ResumeTextInput"
};
const _sfc_main$3 = /* @__PURE__ */ Object.assign(__default__$2, {
  __ssrInlineRender: true,
  props: {
    name: String,
    type: String,
    placeholder: String
  },
  setup(__props) {
    const props = __props;
    const { value, errorMessage } = useField(() => props.name);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><input${ssrRenderDynamicModel(props.type, unref(value), null)}${ssrRenderAttr("type", props.type)}${ssrRenderAttr("placeholder", props.placeholder)}>`);
      if (unref(errorMessage)) {
        _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VacancyTextInput.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0$2 = _sfc_main$3;
const __default__$1 = {
  name: "VeeMultiSelectWithSearchWithSelectedOptions"
};
const _sfc_main$2 = /* @__PURE__ */ Object.assign(__default__$1, {
  __ssrInlineRender: true,
  props: {
    options: {
      required: true,
      default: []
    },
    selected_options: {
      required: true,
      default: []
    },
    placeholder: {
      required: false
    },
    listStyles: {
      required: false
    },
    listItemStyles: {
      required: false
    },
    name: {
      required: true,
      type: String
    },
    sort_by: {
      required: false,
      default: "asc"
    },
    disabled: {
      required: false,
      default: false
    },
    hide_selection: {
      required: false,
      default: false
    }
  },
  emits: [
    "change",
    "update:modelValue",
    "input",
    "unselect",
    "updateSelectedOptions"
  ],
  setup(__props, { emit: __emit }) {
    var _a, _b, _c;
    const props = __props;
    useField(() => props.name);
    const { remove, push, fields, replace } = useFieldArray(() => props.name);
    const isOpen = ref(false);
    const options = ref(props.options);
    ref(props.modelValue);
    const { sort } = useSort();
    watch(
      () => props.options,
      (newValue) => {
        if (props.sort_by === "none") {
          options.value = newValue;
        } else {
          options.value = sort(newValue, { by: "alpha" });
        }
      }
    );
    const selectedOptions = ref((_a = props.selected_options) != null ? _a : []);
    watch(
      () => props.selected_options,
      () => {
        selectedOptions.value = props.selected_options;
      }
    );
    const disabled = ref((_b = props.disabled) != null ? _b : false);
    const getCurrentFieldName = (newValue) => {
      const found = selectedOptions.value.find(
        (item) => String(item.value) === String(newValue)
      );
      if (!found)
        return;
      return found.name;
    };
    const searchInput = ref((_c = props.placeholder) != null ? _c : "");
    watch(
      () => props.placeholder,
      () => searchInput.value = props.placeholder
    );
    watch(
      () => isOpen.value,
      (newOpen) => {
        if (!newOpen) {
          if (searchInput.value === "") {
            searchInput.value = props.placeholder;
          }
        }
      }
    );
    function close() {
      isOpen.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ErrorMessage = ErrorMessage;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "multi-select_wrapper" }, _attrs))} data-v-77767bd8><div${ssrRenderAttrs(mergeProps({
        class: ["select2-container select2-container--default select2-container--below select2-container--focus nice-select n-select d-select", { open: unref(isOpen), disabled: unref(disabled) }],
        tabindex: "0"
      }, ssrGetDirectiveProps(_ctx, _directive_click_outside, close)))} data-v-77767bd8><input class="current"${ssrRenderAttr("value", unref(searchInput))} data-v-77767bd8><ul class="list" style="${ssrRenderStyle(__props.listStyles)}" data-v-77767bd8><!--[-->`);
      ssrRenderList(unref(options), (item) => {
        _push(`<li${ssrRenderAttr("data-value", item.value)} class="option" style="${ssrRenderStyle(__props.listItemStyles)}" data-v-77767bd8>${ssrInterpolate(item.name)}</li>`);
      });
      _push(`<!--]--></ul></div>`);
      if (unref(fields).length > 0) {
        _push(`<div class="selection selected-options" data-v-77767bd8><ul class="selected-options" id="select2--container" data-v-77767bd8><!--[-->`);
        ssrRenderList(unref(fields), (field, idx) => {
          _push(`<div data-v-77767bd8><li class="multi-select_selected-item" data-v-77767bd8><span class="select2-selection__choice__display" data-v-77767bd8>${ssrInterpolate(getCurrentFieldName(field.value))}</span><button type="button" class="select2-selection__choice__remove" data-v-77767bd8><span aria-hidden="true" data-v-77767bd8>\xD7</span></button></li></div>`);
        });
        _push(`<!--]--></ul></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="text-danger" data-v-77767bd8>`);
      _push(ssrRenderComponent(_component_ErrorMessage, {
        name: props.name
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/VeeMultiSelectWithSearchWithSelectedOptions.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-77767bd8"]]);
const _sfc_main$1 = {
  __name: "Cities",
  __ssrInlineRender: true,
  props: {
    name: {
      required: true,
      default: "cities"
    },
    selected_options: {
      required: false,
      default: []
    }
  },
  setup(__props) {
    var _a;
    const props = __props;
    const profileStore = useProfileStore();
    const { providers, getProviderAsArray } = useProviders();
    const selectedProviders = computed(() => getProviderAsArray());
    computed(() => selectedProviders.value.includes("hh"));
    computed(
      () => selectedProviders.value.includes("superjob")
    );
    ref([]);
    const { searchCities, searchProfessionalRoles } = profileStore;
    const cityOptions = ref([]);
    const selectedCityOptions = ref((_a = props.selected_options) != null ? _a : []);
    computed(() => route.params.id);
    computed(() => route.query.type);
    const vacancyStore = useVacancyStore();
    watch(
      () => props.selected_options,
      () => {
        selectedCityOptions.value = props.selected_options;
      }
    );
    const updateCityInput = async (newValue = "") => {
      var _a2;
      const items = (_a2 = await searchCities({
        search: newValue,
        providers: [...selectedProviders.value]
      })) != null ? _a2 : [];
      cityOptions.value = items.map((item) => ({
        value: item.id,
        name: item.name
      }));
    };
    const { uniq } = useFilter();
    const { value: city_ids } = useField(() => props.name);
    watch(
      () => city_ids.value,
      async () => {
        let items = vacancyStore.my_vacancy.cities.map((item) => ({
          name: item.name,
          value: item.id
        }));
        items = items.concat(
          [...cityOptions.value].filter(
            (item) => city_ids.value.includes(item.value)
          )
        );
        items = uniq(items, "value");
        onUpdateSelectedOptions(items);
      }
    );
    const onUpdateSelectedOptions = async (newItems) => {
      selectedCityOptions.value = newItems;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeMultiSelectWithSearchWithSelectedOptions = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearchWithSelectedOptions, {
        options: unref(cityOptions),
        selected_options: unref(selectedCityOptions),
        onUpdateSelectedOptions,
        name: props.name,
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0433\u043E\u0440\u043E\u0434",
        onInput: updateCityInput
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/Cities.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$1;
const __default__ = {
  name: "ResumeCheckboxInput"
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    name: String,
    label: String
  },
  setup(__props) {
    const props = __props;
    const { value, errorMessage } = useField(() => props.name);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="check-block"><div class="checkbox"><input type="checkbox"${ssrRenderAttr("name", props.name)}${ssrRenderAttr("id", props.name)}${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label${ssrRenderAttr("for", props.name)} class="fs-14">${ssrInterpolate(props.label)}</label></div><div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VacancyCheckboxInput.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_0$2 as _, __nuxt_component_0 as a, __nuxt_component_2 as b };
//# sourceMappingURL=VacancyCheckboxInput-VKg7Lh2Y.mjs.map
