import { useField, useFieldArray, ErrorMessage } from 'vee-validate';
import { useSSRContext, ref, watch, resolveDirective, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrGetDirectiveProps, ssrRenderAttr, ssrRenderStyle, ssrRenderList, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { u as useSort } from './useSort-Dy_x39w5.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const __default__ = {
  name: "VeeMultiSelectWithSearch"
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    options: {
      required: true,
      default: []
    },
    placeholder: {
      required: false
    },
    listStyles: {
      required: false
    },
    listItemStyles: {
      required: false
    },
    name: {
      required: true,
      type: String
    },
    sort_by: {
      required: false,
      default: "asc"
    },
    disabled: {
      required: false,
      default: false
    },
    hide_selection: {
      required: false,
      default: false
    }
  },
  emits: ["change", "update:modelValue", "input", "unselect"],
  setup(__props, { emit: __emit }) {
    var _a, _b;
    const props = __props;
    useField(() => props.name);
    const { remove, push, fields, replace } = useFieldArray(() => props.name);
    const isOpen = ref(false);
    const options = ref(props.options);
    ref(props.modelValue);
    const { sort } = useSort();
    watch(
      () => props.options,
      (newValue) => {
        if (props.sort_by === "none") {
          options.value = newValue;
        } else {
          options.value = sort(newValue, { by: "alpha" });
        }
      }
    );
    const selectedOptions = ref([]);
    watch(
      () => [...fields.value],
      () => {
        const selected_ids = [...fields.value.map((item) => item.value)];
        selectedOptions.value = [
          ...options.value.filter((item) => selected_ids.includes(item.value))
        ];
      }
    );
    watch(
      () => options.value,
      () => {
        const selected_ids = [...fields.value.map((item) => item.value)];
        selectedOptions.value = [
          ...options.value.filter((item) => selected_ids.includes(item.value))
        ];
      }
    );
    const disabled = ref((_a = props.disabled) != null ? _a : false);
    const getCurrentFieldName = (newValue) => {
      const found = selectedOptions.value.find(
        (item) => String(item.value) === String(newValue)
      );
      if (!found)
        return;
      return found.name;
    };
    const searchInput = ref((_b = props.placeholder) != null ? _b : "");
    watch(
      () => props.placeholder,
      () => searchInput.value = props.placeholder
    );
    watch(
      () => isOpen.value,
      (newOpen) => {
        if (!newOpen) {
          if (searchInput.value === "") {
            searchInput.value = props.placeholder;
          }
        }
      }
    );
    function close() {
      isOpen.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ErrorMessage = ErrorMessage;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "multi-select_wrapper" }, _attrs))} data-v-5c732ac5><div${ssrRenderAttrs(mergeProps({
        class: ["select2-container select2-container--default select2-container--below select2-container--focus nice-select n-select d-select", { open: unref(isOpen), disabled: unref(disabled) }],
        tabindex: "0"
      }, ssrGetDirectiveProps(_ctx, _directive_click_outside, close)))} data-v-5c732ac5><input class="current"${ssrRenderAttr("value", unref(searchInput))} data-v-5c732ac5><ul class="list" style="${ssrRenderStyle(__props.listStyles)}" data-v-5c732ac5><!--[-->`);
      ssrRenderList(unref(options), (item) => {
        _push(`<li class="option" style="${ssrRenderStyle(__props.listItemStyles)}" data-v-5c732ac5>${ssrInterpolate(item.name)}</li>`);
      });
      _push(`<!--]--></ul></div>`);
      if (unref(fields).length > 0) {
        _push(`<div class="selection selected-options" data-v-5c732ac5><ul class="selected-options" id="select2--container" data-v-5c732ac5><!--[-->`);
        ssrRenderList(unref(fields), (field, idx) => {
          _push(`<div data-v-5c732ac5><li class="multi-select_selected-item" data-v-5c732ac5><span class="select2-selection__choice__display" data-v-5c732ac5>${ssrInterpolate(getCurrentFieldName(field.value))}</span><button type="button" class="select2-selection__choice__remove" data-v-5c732ac5><span aria-hidden="true" data-v-5c732ac5>\xD7</span></button></li></div>`);
        });
        _push(`<!--]--></ul></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="text-danger" data-v-5c732ac5>`);
      _push(ssrRenderComponent(_component_ErrorMessage, {
        name: props.name
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/VeeMultiSelectWithSearch.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-5c732ac5"]]);

export { __nuxt_component_1 as _ };
//# sourceMappingURL=VeeMultiSelectWithSearch-Btd5b5Va.mjs.map
