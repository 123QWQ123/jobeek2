import { _ as __nuxt_component_2 } from './Form-Bl6z4ElR.mjs';
import { computed, ref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import * as yup from 'yup';
import { useForm } from 'vee-validate';
import './VeeCustomSelect-BxrAvA7-.mjs';
import './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './dictionary--F10-rgU.mjs';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './useProviderFields-B2EuWWWy.mjs';
import './useProviders-Ck9yopDY.mjs';
import './state-D1MfAAni.mjs';
import './VuePhoneInput-C5R34atv.mjs';
import './useResumeHooks-BM2nRo7f.mjs';
import './ResumeCheckboxInput-DBsB0Z0m.mjs';
import './check-BGWLIG1L.mjs';

const _sfc_main = {
  __name: "vee",
  __ssrInlineRender: true,
  setup(__props) {
    const schema = computed(() => {
      return {
        email: "required|email",
        phones: yup.array().of(
          yup.object().shape({
            type_id: yup.number().required(),
            comment: yup.string().required()
          })
        ).strict()
      };
    });
    const initialValues = ref({
      email: null,
      phones: [
        {
          type_id: 151,
          comment: "sdkmfksd",
          phone: "+998942638523",
          is_preferred: false,
          start_available_time_phone: "08:00",
          end_available_time_phone: "08:00"
        }
      ]
    });
    useForm({
      initialValues,
      validationSchema: schema
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeVeePhoneFieldsForm = __nuxt_component_2;
      _push(`<form${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_CreateResumeVeePhoneFieldsForm, { name: "phones" }, null, _parent));
      _push(`</form>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vee.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=vee-Oex2ZD3Y.mjs.map
