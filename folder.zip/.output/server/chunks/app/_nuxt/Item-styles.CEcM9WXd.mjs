const Item_vue_vue_type_style_index_0_scoped_c98a61b2_lang = ".absoluted_icon[data-v-c98a61b2]{cursor:pointer;font-size:1rem;left:-.5rem;max-width:3rem;position:absolute;top:.5rem;z-index:1}.absoluted_icon svg[data-v-c98a61b2]{height:24px;width:24px}";

const ItemStyles_CEcM9WXd = [Item_vue_vue_type_style_index_0_scoped_c98a61b2_lang];

export { ItemStyles_CEcM9WXd as default };
//# sourceMappingURL=Item-styles.CEcM9WXd.mjs.map
