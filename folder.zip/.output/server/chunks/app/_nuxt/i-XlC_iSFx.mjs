import { _ as __nuxt_component_5 } from './BaseButton-CWRjb9_h.mjs';
import { useSSRContext, withCtx, createTextVNode } from 'vue';
import { ssrRenderTeleport, ssrRenderClass, ssrRenderStyle, ssrRenderSlot, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const _sfc_main = {
  props: {
    type: {
      type: String,
      required: false
    },
    show: {
      type: Boolean,
      required: true
    },
    title: {
      type: String,
      required: false
    },
    fixed: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  emits: ["close"],
  methods: {
    tryClose() {
      if (this.fixed) {
        return;
      }
      this.$emit("close");
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_base_button = __nuxt_component_5;
  ssrRenderTeleport(_push, (_push2) => {
    if ($props.show) {
      _push2(`<div class="backdrop" data-v-868d9d13></div>`);
    } else {
      _push2(`<!---->`);
    }
    if ($props.show) {
      _push2(`<div class="${ssrRenderClass([$props.type, "modal fade show"])}" data-v-868d9d13><div class="modal-dialog modal-dialog-centered" style="${ssrRenderStyle({ "min-width": "320px" })}" data-v-868d9d13><div class="modal-content" data-v-868d9d13><div class="modal-header" data-v-868d9d13>`);
      ssrRenderSlot(_ctx.$slots, "header", {}, () => {
        _push2(`<h2 data-v-868d9d13>${ssrInterpolate($props.title)}</h2>`);
      }, _push2, _parent);
      _push2(`</div><div class="modal-body" data-v-868d9d13>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent);
      _push2(`</div>`);
      if (!$props.fixed) {
        _push2(`<div class="modal-footer" data-v-868d9d13>`);
        ssrRenderSlot(_ctx.$slots, "actions", {}, () => {
          _push2(ssrRenderComponent(_component_base_button, {
            to: null,
            onClick: $options.tryClose
          }, {
            default: withCtx((_, _push3, _parent2, _scopeId) => {
              if (_push3) {
                _push3(`Close`);
              } else {
                return [
                  createTextVNode("Close")
                ];
              }
            }),
            _: 1
          }, _parent));
        }, _push2, _parent);
        _push2(`</div>`);
      } else {
        _push2(`<!---->`);
      }
      _push2(`</div></div></div>`);
    } else {
      _push2(`<!---->`);
    }
  }, "body", false, _parent);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/BaseModal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-868d9d13"]]);
const _imports_0 = "data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M12%2022.5C17.799%2022.5%2022.5%2017.799%2022.5%2012C22.5%206.20101%2017.799%201.5%2012%201.5C6.20101%201.5%201.5%206.20101%201.5%2012C1.5%2017.799%206.20101%2022.5%2012%2022.5Z'%20fill='%235375FD'/%3e%3cpath%20d='M11%2011H13V16.5H11V11Z'%20fill='white'/%3e%3cpath%20d='M12%209.5C12.6904%209.5%2013.25%208.94036%2013.25%208.25C13.25%207.55964%2012.6904%207%2012%207C11.3096%207%2010.75%207.55964%2010.75%208.25C10.75%208.94036%2011.3096%209.5%2012%209.5Z'%20fill='white'/%3e%3c/svg%3e";

export { _imports_0 as _, __nuxt_component_0 as a };
//# sourceMappingURL=i-XlC_iSFx.mjs.map
