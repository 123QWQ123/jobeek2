const ProvidersInput_vue_vue_type_style_index_0_scoped_5f246e03_lang = ".import-box[data-v-5f246e03]{cursor:pointer}.is-connected .import-box-dvnld .logo .check[data-v-5f246e03]{display:block}.import-box.disabled[data-v-5f246e03]{background:#fff;border-radius:12px;box-shadow:0 0 20px rgb(0 0 0/4%)}.import-box.disabled .import-box-dvnld[data-v-5f246e03]{border:1px dashed #8c8c8c;color:#8c8c8c}.import-box.disabled .import-box-dvnld .logo[data-v-5f246e03]{filter:grayscale(100%)}.import-box.disabled .import-box-dvnld span[data-v-5f246e03]{color:#8c8c8c}";

const ProvidersInputStyles_v0mFDQKm = [ProvidersInput_vue_vue_type_style_index_0_scoped_5f246e03_lang];

export { ProvidersInputStyles_v0mFDQKm as default };
//# sourceMappingURL=ProvidersInput-styles.v0mFDQKm.mjs.map
