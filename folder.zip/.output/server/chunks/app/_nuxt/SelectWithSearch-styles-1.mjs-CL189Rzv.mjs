const SelectWithSearch_vue_vue_type_style_index_0_lang = ".select2-container .select2-selection--multiple .select2-selection__rendered{flex-wrap:wrap!important}";

export { SelectWithSearch_vue_vue_type_style_index_0_lang as S };
//# sourceMappingURL=SelectWithSearch-styles-1.mjs-CL189Rzv.mjs.map
