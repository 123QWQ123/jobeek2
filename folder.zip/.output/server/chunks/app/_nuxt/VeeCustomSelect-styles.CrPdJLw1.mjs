const VeeCustomSelect_vue_vue_type_style_index_0_scoped_280b0657_lang = ".current[data-v-280b0657]{color:#0a2540}.d-select[data-v-280b0657]{padding-right:3.125rem;width:auto}";

const VeeCustomSelectStyles_CrPdJLw1 = [VeeCustomSelect_vue_vue_type_style_index_0_scoped_280b0657_lang];

export { VeeCustomSelectStyles_CrPdJLw1 as default };
//# sourceMappingURL=VeeCustomSelect-styles.CrPdJLw1.mjs.map
