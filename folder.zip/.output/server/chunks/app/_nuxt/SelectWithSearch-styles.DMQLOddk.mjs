import { S as SelectWithSearch_vue_vue_type_style_index_0_lang } from './SelectWithSearch-styles-1.mjs-CL189Rzv.mjs';
import { S as SelectWithSearch_vue_vue_type_style_index_1_scoped_75e232fb_lang } from './SelectWithSearch-styles-2.mjs-YiKsBPV1.mjs';

const SelectWithSearchStyles_DMQLOddk = [SelectWithSearch_vue_vue_type_style_index_0_lang, SelectWithSearch_vue_vue_type_style_index_1_scoped_75e232fb_lang];

export { SelectWithSearchStyles_DMQLOddk as default };
//# sourceMappingURL=SelectWithSearch-styles.DMQLOddk.mjs.map
