const VeeTypeAndUrlCard_vue_vue_type_style_index_0_lang = "";

const VeeTypeAndUrlCardStyles_BtwP5mcg = [VeeTypeAndUrlCard_vue_vue_type_style_index_0_lang];

export { VeeTypeAndUrlCardStyles_BtwP5mcg as default };
//# sourceMappingURL=VeeTypeAndUrlCard-styles.BtwP5mcg.mjs.map
