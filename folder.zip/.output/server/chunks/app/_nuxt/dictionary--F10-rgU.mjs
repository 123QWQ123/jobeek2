import { o as defineStore, v as vueNumberFormat, q as useApi } from '../server.mjs';

const useDictionaryStore = defineStore("dictionary", {
  state: () => {
    return {
      work_types: [],
      hh_work_types: [],
      superjob_work_types: [],
      schedules: [],
      experiences: [],
      part_times: [],
      metros: [],
      driver_licenses: [],
      educations: [],
      resume_educations: [],
      genders: [],
      resume_genders: [],
      place_of_works: [],
      foreign_languages: [],
      language_levels: [],
      marital_statuses: [],
      resume_marital_statuses: [],
      children: [],
      vacancy_billing_types: [],
      vacancy_types: [],
      payment_period: [],
      addresses: [],
      metro: [],
      working_days: [],
      working_time_intervals: [],
      working_time_modes: [],
      extend_vac: [],
      covid_vaccination_requirement: [],
      subscription_keywords_srws: [],
      subscription_keywords_skwc: [],
      relocation_types: [],
      business_trips: [],
      preferred_contact_types: [],
      resume_education_forms: [],
      travel_times: [],
      resume_children: [],
      resume_access_types: [],
      resume_language_levels: []
    };
  },
  getters: {
    addresses_formatted() {
      return this.addresses.map((item) => ({
        name: item.raw,
        value: item.id
      }));
    },
    vacancy_types_formatted() {
      return this.vacancy_types.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    payment_period_formatted() {
      return this.payment_period.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    work_types_formatted() {
      return this.work_types.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    experiences_formatted() {
      return this.experiences.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    schedules_formatted() {
      return this.schedules.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    working_days_formatted() {
      return this.working_days.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    working_time_intervals_formatted() {
      return this.working_time_intervals.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    working_time_modes_formatted() {
      return this.working_time_modes.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    extend_vac_formatted() {
      return this.extend_vac.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    educations_formatted() {
      return this.educations.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    place_of_works_formatted() {
      return this.place_of_works.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    marital_statuses_formatted() {
      return this.marital_statuses.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    genders_formatted() {
      return this.genders.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    children_formatted() {
      return this.children.map((item) => ({
        name: item.name,
        value: item.id
      }));
    },
    covid_vaccination_requirement_formatted() {
      return this.covid_vaccination_requirement.map((item) => ({
        name: item.name,
        value: item.id
      }));
    }
  },
  actions: {
    numberFormat(value) {
      return vueNumberFormat(value, {});
    },
    async getWorkTypes(payload) {
      var _a2;
      var _a;
      if (this.work_types.length > 0) {
        return this.work_types;
      }
      const { data } = await useApi("dictionaries?groups[]=work_type", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.work_types = (_a2 = (_a = data.data) == null ? void 0 : _a.work_type) != null ? _a2 : [];
      }
      return data;
    },
    async getHHWorkTypes(payload) {
      var _a2;
      var _a;
      if (this.hh_work_types.length > 0) {
        return this.hh_work_types;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=work_type&providers[]=hh",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.hh_work_types = (_a2 = (_a = data.data) == null ? void 0 : _a.work_type) != null ? _a2 : [];
      }
      return [];
    },
    async getSuperjobWorkTypes(payload) {
      var _a2;
      var _a;
      if (this.superjob_work_types.length > 0) {
        return this.superjob_work_types;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=work_type&providers[]=superjob",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.superjob_work_types = (_a2 = (_a = data.data) == null ? void 0 : _a.work_type) != null ? _a2 : [];
      }
      return [];
    },
    async getVacancyBillingTypes(payload) {
      var _a2;
      var _a;
      if (this.vacancy_billing_types.length > 0) {
        return this.vacancy_billing_types;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=vacancy_billing_type",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.vacancy_billing_types = (_a2 = (_a = data.data) == null ? void 0 : _a.vacancy_billing_type) != null ? _a2 : [];
      }
      return data;
    },
    async getResumeAccessTypes(payload) {
      var _a2;
      var _a;
      if (this.resume_access_types.length > 0) {
        return this.resume_access_types;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=resume_access_type_merge",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.resume_access_types = (_a2 = (_a = data.data) == null ? void 0 : _a.resume_access_type_merge) != null ? _a2 : [];
      }
      return data;
    },
    async getVacancyTypes(payload) {
      var _a2;
      var _a;
      if (this.vacancy_types.length > 0) {
        return this.vacancy_types;
      }
      const { data } = await useApi("dictionaries?groups[]=vacancy_type", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.vacancy_types = (_a2 = (_a = data.data) == null ? void 0 : _a.vacancy_type) != null ? _a2 : [];
      }
      return data;
    },
    async searchAddresses(payload) {
      var _a, _b;
      if (this.addresses.length > 0) {
        return this.addresses;
      }
      const response = await useApi(
        "employer/addresses?providers[]=hh&page=0&per_page=100",
        {
          method: "get",
          payload
        }
      );
      if (response && "data" in response) {
        if (response && "data" in response && response.data.hasOwnProperty("data")) {
          this.addresses = (_a = response.data) != null ? _a : [];
          return this.addresses;
        }
        this.addresses = (_b = response.data) != null ? _b : [];
        return this.addresses;
      }
      return response;
    },
    async searchMetro(payload) {
      var _a;
      if (this.metro.length > 0) {
        return this.metro;
      }
      const { data } = await useApi("metro", {
        method: "get",
        params: payload
      });
      if (data) {
        this.metro = (_a = data.data) != null ? _a : [];
        return this.metro;
      }
      return data;
    },
    async getGenders(payload, is_for_resume = false) {
      var _a2, _b2;
      var _a, _b;
      if (is_for_resume) {
        if (this.resume_genders.length > 0) {
          return this.resume_genders;
        }
        const { data } = await useApi("dictionaries?groups[]=gender_resume", {
          method: "get",
          payload
        });
        if (data && "data" in data) {
          this.resume_genders = (_a2 = (_a = data.data) == null ? void 0 : _a.gender_resume) != null ? _a2 : [];
        }
        return data;
      } else {
        if (this.genders.length > 0) {
          return this.genders;
        }
        const { data } = await useApi("dictionaries?groups[]=gender", {
          method: "get",
          payload
        });
        if (data && "data" in data) {
          this.genders = (_b2 = (_b = data.data) == null ? void 0 : _b.gender) != null ? _b2 : [];
        }
        return data;
      }
    },
    async getChildren(payload) {
      var _a2;
      var _a;
      if (this.children.length > 0) {
        return this.children;
      }
      const { data } = await useApi("dictionaries?groups[]=children", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.children = (_a2 = (_a = data.data) == null ? void 0 : _a.children) != null ? _a2 : [];
      }
      return data;
    },
    async getResumeChildren(payload) {
      var _a2;
      var _a;
      if (this.resume_children.length > 0) {
        return this.children;
      }
      const { data } = await useApi("dictionaries?groups[]=children_resume", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.resume_children = (_a2 = (_a = data.data) == null ? void 0 : _a.children_resume) != null ? _a2 : [];
      }
      return data;
    },
    async getMaritalStatus(payload) {
      var _a2;
      var _a;
      if (this.marital_statuses.length > 0) {
        return this.marital_statuses;
      }
      const { data } = await useApi("dictionaries?groups[]=marital_status", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.marital_statuses = (_a2 = (_a = data.data) == null ? void 0 : _a.marital_status) != null ? _a2 : [];
      }
      return data;
    },
    async getMaritalStatusForResume(payload) {
      var _a2;
      var _a;
      if (this.resume_marital_statuses.length > 0) {
        return this.resume_marital_statuses;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=marital_status_resume",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.resume_marital_statuses = (_a2 = (_a = data.data) == null ? void 0 : _a.marital_status_resume) != null ? _a2 : [];
      }
      return data;
    },
    async getTravelTimeOptions(payload) {
      var _a2;
      var _a;
      if (this.travel_times.length > 0) {
        return this.travel_times;
      }
      const { data } = await useApi("dictionaries?groups[]=travel_time", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.travel_times = (_a2 = (_a = data.data) == null ? void 0 : _a.travel_time) != null ? _a2 : [];
      }
      return data;
    },
    async getPlaceOfWorks(payload) {
      var _a2;
      var _a;
      if (this.place_of_works.length > 0) {
        return this.place_of_works;
      }
      const { data } = await useApi("dictionaries?groups[]=place_of_work", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.place_of_works = (_a2 = (_a = data.data) == null ? void 0 : _a.place_of_work) != null ? _a2 : [];
      }
      return data;
    },
    async getForeignLanguages(payload) {
      var _a;
      if (this.foreign_languages.length > 0) {
        return this.foreign_languages;
      }
      const { data } = await useApi("languages", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.foreign_languages = (_a = data.data) != null ? _a : [];
      }
      return data;
    },
    async getLanguageLevels(payload) {
      var _a2;
      var _a;
      if (this.language_levels.length > 0) {
        return this.language_levels;
      }
      const { data } = await useApi("dictionaries?groups[]=language_level", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.language_levels = (_a2 = (_a = data.data) == null ? void 0 : _a.language_level) != null ? _a2 : [];
      }
      return data;
    },
    async getResumeLanguageLevels(payload) {
      var _a2;
      var _a;
      if (this.resume_language_levels.length > 0) {
        return this.resume_language_levels;
      }
      const { data } = await useApi("dictionaries?groups[]=lang_level_resume", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.resume_language_levels = (_a2 = (_a = data.data) == null ? void 0 : _a.lang_level_resume) != null ? _a2 : [];
      }
      return data;
    },
    async getDriverLicenses(payload) {
      var _a2;
      var _a;
      if (this.driver_licenses.length > 0) {
        return this.driver_licenses;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=driver_license_types",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.driver_licenses = (_a2 = (_a = data.data) == null ? void 0 : _a.driver_license_types) != null ? _a2 : [];
      }
      return data;
    },
    async getSchedules(payload = {}) {
      var _a2;
      var _a;
      if (this.schedules.length > 0) {
        return this.schedules;
      }
      const { data } = await useApi("dictionaries?groups[]=schedule", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.schedules = (_a2 = (_a = data.data) == null ? void 0 : _a.schedule) != null ? _a2 : [];
      }
      return data;
    },
    async getExperiences(payload = {}) {
      var _a2;
      var _a;
      if (this.experiences.length > 0) {
        return this.experiences;
      }
      const { data } = await useApi("dictionaries?groups[]=experience", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.experiences = (_a2 = (_a = data.data) == null ? void 0 : _a.experience) != null ? _a2 : [];
      }
      return data;
    },
    async getPartTimes(payload = {}) {
      var _a2;
      var _a;
      if (this.part_times.length > 0) {
        return this.part_times;
      }
      const { data } = await useApi("dictionaries?groups[]=part_time", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.part_times = (_a2 = (_a = data.data) == null ? void 0 : _a.part_time) != null ? _a2 : [];
      }
      return data;
    },
    async getPaymentPeriodOptions(payload) {
      var _a2;
      var _a;
      if (this.payment_period.length > 0) {
        return this.payment_period;
      }
      const { data } = await useApi("dictionaries?groups[]=payment_period", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.payment_period = (_a2 = (_a = data.data) == null ? void 0 : _a.payment_period) != null ? _a2 : [];
      }
      return data.data;
    },
    async getWorkingDayOptions(payload) {
      var _a2;
      var _a;
      if (this.working_days.length > 0) {
        return this.working_days;
      }
      const { data } = await useApi("dictionaries?groups[]=working_days", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.working_days = (_a2 = (_a = data.data) == null ? void 0 : _a.working_days) != null ? _a2 : [];
      }
      return data.data;
    },
    async getWorkingTimeIntervalsOptions(payload) {
      var _a2;
      var _a;
      if (this.working_time_intervals.length > 0) {
        return this.working_time_intervals;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=working_time_intervals",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.working_time_intervals = (_a2 = (_a = data.data) == null ? void 0 : _a.working_time_intervals) != null ? _a2 : [];
      }
      return data.data;
    },
    async getWorkingTimeModesOptions(payload) {
      var _a2;
      var _a;
      if (this.working_time_modes.length > 0) {
        return this.working_time_modes;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=working_time_modes",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.working_time_modes = (_a2 = (_a = data.data) == null ? void 0 : _a.working_time_modes) != null ? _a2 : [];
      }
      return data.data;
    },
    async getExtendVacOptions(payload) {
      var _a2;
      var _a;
      if (this.extend_vac.length > 0) {
        return this.extend_vac;
      }
      const { data } = await useApi("dictionaries?groups[]=extend_vac", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.extend_vac = (_a2 = (_a = data.data) == null ? void 0 : _a.extend_vac) != null ? _a2 : [];
      }
      return data.data;
    },
    async getCovidVacRequirements(payload) {
      var _a2;
      var _a;
      const nullableOption = { id: null, name: "\u041D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D" };
      if (this.covid_vaccination_requirement.length > 0) {
        return this.covid_vaccination_requirement;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=covid_vaccination_requirement",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.covid_vaccination_requirement = (_a2 = (_a = data.data) == null ? void 0 : _a.covid_vaccination_requirement) != null ? _a2 : [];
        this.covid_vaccination_requirement.unshift(nullableOption);
        return this.covid_vaccination_requirement;
      }
      return data.data;
    },
    async getEducations(payload) {
      var _a2;
      var _a;
      if (this.educations.length > 0) {
        return this.educations;
      }
      const { data } = await useApi("dictionaries?groups[]=education", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.educations = (_a2 = (_a = data.data) == null ? void 0 : _a.education) != null ? _a2 : [];
      }
      return data.data;
    },
    async getResumeEducations(payload) {
      var _a2;
      var _a;
      if (this.resume_educations.length > 0) {
        return this.resume_educations;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=education_type_resume",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.resume_educations = (_a2 = (_a = data.data) == null ? void 0 : _a.education_type_resume) != null ? _a2 : [];
      }
      return data.data;
    },
    async getResumeEducationForms(payload) {
      var _a2;
      var _a;
      if (this.resume_education_forms.length > 0) {
        return this.resume_education_forms;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=education_form_resume",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.resume_education_forms = (_a2 = (_a = data.data) == null ? void 0 : _a.education_form_resume) != null ? _a2 : [];
      }
      return data.data;
    },
    async getSubscriptionKeywordsSrws(payload) {
      var _a2;
      var _a;
      if (this.subscription_keywords_srws.length > 0) {
        return this.subscription_keywords_srws;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=subscriptionKeywords_srws",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.subscription_keywords_srws = (_a2 = (_a = data.data) == null ? void 0 : _a.subscriptionKeywords_srws) != null ? _a2 : [];
      }
      return data.data;
    },
    async getSubscriptionKeywordsSkwc(payload) {
      var _a2;
      var _a;
      if (this.subscription_keywords_skwc.length > 0) {
        return this.subscription_keywords_skwc;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=subscriptionKeywords_skwc",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.subscription_keywords_skwc = (_a2 = (_a = data.data) == null ? void 0 : _a.subscriptionKeywords_skwc) != null ? _a2 : [];
      }
      return data.data;
    },
    async getRelocationTypes(payload) {
      var _a2;
      var _a;
      if (this.relocation_types.length > 0) {
        return this.relocation_types;
      }
      const { data } = await useApi("dictionaries?groups[]=relocation_type", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.relocation_types = (_a2 = (_a = data.data) == null ? void 0 : _a.relocation_type) != null ? _a2 : [];
      }
      return data.data;
    },
    async getBusinessTrips(payload) {
      var _a2;
      var _a;
      if (this.business_trips.length > 0) {
        return this.business_trips;
      }
      const { data } = await useApi("dictionaries?groups[]=business_trip", {
        method: "get",
        payload
      });
      if (data && "data" in data) {
        this.business_trips = (_a2 = (_a = data.data) == null ? void 0 : _a.business_trip) != null ? _a2 : [];
      }
      return data.data;
    },
    async getPreferredContactTypes(payload) {
      var _a2;
      var _a;
      if (this.preferred_contact_types.length > 0) {
        return this.preferred_contact_types;
      }
      const { data } = await useApi(
        "dictionaries?groups[]=preferred_contact_type",
        {
          method: "get",
          payload
        }
      );
      if (data && "data" in data) {
        this.preferred_contact_types = (_a2 = (_a = data.data) == null ? void 0 : _a.preferred_contact_type) != null ? _a2 : [];
      }
      return data.data;
    }
  }
});

export { useDictionaryStore as u };
//# sourceMappingURL=dictionary--F10-rgU.mjs.map
