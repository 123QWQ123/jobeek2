import { useSSRContext, ref, computed, watch, resolveDirective, mergeProps, unref, isRef } from 'vue';
import { ssrRenderAttrs, ssrGetDirectiveProps, ssrInterpolate, ssrRenderStyle, ssrRenderList, ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const __default__ = {
  name: "CustomSelect"
};
const _sfc_main$1 = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    options: {
      default: []
    },
    modelValue: {},
    label: {},
    listStyles: {}
  },
  emits: ["change", "update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const isOpen = ref(false);
    const options = computed(() => props.options);
    const label = computed(() => {
      if (selectedOption.value) {
        return selectedOption.value.name;
      }
      return props.label;
    });
    computed(() => props.modelValue);
    const selectedOption = ref(null);
    const reApply = (newValue) => {
      const selectedItem = props.options.find(
        (item) => String(props.modelValue) === String(item.value)
      );
      if (selectedItem) {
        selectedOption.value = selectedItem;
      }
    };
    watch(() => props.modelValue, reApply);
    watch(() => props.options, reApply);
    function close() {
      isOpen.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({
        onfocusout: "close",
        class: ["nice-select n-select d-select", { open: unref(isOpen) }],
        style: props.style,
        tabindex: "0"
      }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, close)))} data-v-765ad150><span class="current" data-v-765ad150>${ssrInterpolate(unref(label))}</span>`);
      if (unref(isOpen)) {
        _push(`<ul class="list" style="${ssrRenderStyle(__props.listStyles)}" data-v-765ad150><!--[-->`);
        ssrRenderList(unref(options), (item) => {
          _push(`<li${ssrRenderAttr("data-value", item.value)} class="option" data-v-765ad150>${ssrInterpolate(item.name)}</li>`);
        });
        _push(`<!--]--></ul>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/CustomSelect.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const CustomSelect = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-765ad150"]]);
function useSalaryOptions() {
  return [
    { value: void 0, name: "\u0412\u0441\u0435" },
    { value: 1, name: "10K-30K \u20BD", min: 1e4, max: 3e4 },
    { value: 2, name: "30K-50K \u20BD", min: 3e4, max: 5e4 },
    { value: 3, name: "50K-100K \u20BD", min: 5e4, max: 1e5 },
    { value: 4, name: "100K-200K \u20BD", min: 1e5, max: 2e5 },
    { value: 5, name: "200K-300K \u20BD", min: 2e5, max: 3e5 },
    { value: 6, name: "300K-400K \u20BD", min: 3e5, max: 4e5 },
    { value: 7, name: "400K-500K \u20BD", min: 4e5, max: 5e5 },
    { value: 8, name: "500K+", min: 5e5 }
  ];
}
const _sfc_main = {
  __name: "SalarySelectInForm",
  __ssrInlineRender: true,
  props: ["modelValue", "currency"],
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    var _a2;
    var _a;
    const props = __props;
    const emit = __emit;
    const selectedSalary = ref((_a2 = (_a = props.modelValue) == null ? void 0 : _a.value) != null ? _a2 : void 0);
    watch(
      () => props.modelValue,
      (newValue) => {
        var _a3;
        selectedSalary.value = (_a3 = newValue == null ? void 0 : newValue.value) != null ? _a3 : void 0;
      }
    );
    const salaryOptionsData = useSalaryOptions();
    const salaryOptions = ref(salaryOptionsData);
    const onChange = (id) => {
      let selectedOptionID = salaryOptionsData.findIndex(
        (item) => item.value === parseInt(id)
      );
      if (selectedOptionID === -1) {
        return;
      }
      const selectedOption = salaryOptionsData[selectedOptionID];
      emit("update:modelValue", {
        value: selectedOptionID,
        min: selectedOption.min,
        max: selectedOption.max
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      _push(ssrRenderComponent(_component_CustomSelect, mergeProps({
        class: "no_bg",
        label: "\u0417\u0430\u0440\u043F\u043B\u0430\u0442\u0430",
        modelValue: unref(selectedSalary),
        "onUpdate:modelValue": ($event) => isRef(selectedSalary) ? selectedSalary.value = $event : null,
        options: unref(salaryOptions),
        onChange
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header/SalarySelectInForm.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;
const _imports_0 = "data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3ccircle%20cx='11.7669'%20cy='11.7666'%20r='8.98856'%20stroke='%23B8BFC6'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M18.0186%2018.4851L21.5426%2022'%20stroke='%23B8BFC6'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e";

export { CustomSelect as C, _imports_0 as _, __nuxt_component_0 as a, useSalaryOptions as u };
//# sourceMappingURL=search-CNCM2ROA.mjs.map
