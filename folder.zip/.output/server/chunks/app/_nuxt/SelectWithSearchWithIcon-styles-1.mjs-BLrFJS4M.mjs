const SelectWithSearchWithIcon_vue_vue_type_style_index_0_lang = ".select2-container .select2-selection--multiple .select2-selection__rendered{flex-wrap:wrap!important}";

export { SelectWithSearchWithIcon_vue_vue_type_style_index_0_lang as S };
//# sourceMappingURL=SelectWithSearchWithIcon-styles-1.mjs-BLrFJS4M.mjs.map
