import { useSSRContext, ref, watch, unref, mergeProps } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { VueTelInput } from 'vue3-tel-input';

const _sfc_main = {
  __name: "VuePhoneInput",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      type: String,
      default: ""
    },
    disabled: {
      required: true,
      type: Boolean,
      default: false
    }
  },
  emits: ["update:modelValue", "change-country-code"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const phone = ref(props.modelValue);
    const phoneElement = ref();
    const onInput = (phoneInput, phoneObject, input) => {
      if (phoneObject == null ? void 0 : phoneObject.formatted) {
        phone.value = phoneObject.formatted;
      }
      if (phoneInput.valid) {
        emit("change-country-code", phoneObject.countryCode);
      }
    };
    watch(
      () => phone.value,
      (newValue) => {
        if (phone.value) {
          emit(
            "update:modelValue",
            "+" + phoneElement.value.vueNumberUnformat(newValue)
          );
        }
      }
    );
    watch(
      () => props.modelValue,
      (newValue) => {
        if (newValue) {
          phone.value = newValue;
        }
      }
    );
    const focus = () => {
      console.log(phoneElement.value);
      phoneElement.value.focus();
    };
    __expose({
      focus
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(VueTelInput), mergeProps({
        ref_key: "phoneElement",
        ref: phoneElement,
        value: unref(phone),
        disabled: props.disabled,
        onInput
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/VuePhoneInput.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=VuePhoneInput-C5R34atv.mjs.map
