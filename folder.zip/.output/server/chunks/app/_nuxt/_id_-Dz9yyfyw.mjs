import { _ as __nuxt_component_0$2 } from './SearchMobile-WfXJ1gHL.mjs';
import { _ as __nuxt_component_1$1 } from './Providers-Bui0vB9a.mjs';
import { _ as __nuxt_component_0$2$1, b as __nuxt_component_2$3, a as __nuxt_component_0$4 } from './VacancyCheckboxInput-VKg7Lh2Y.mjs';
import { _ as __nuxt_component_0$3 } from './VeeTipTapRichEditor-C3vw1Km2.mjs';
import __nuxt_component_2$2 from './VeeCustomSelect-BxrAvA7-.mjs';
import { e as useRoute, l as useVacancyStore, u as useHead, m as useProfileStore } from '../server.mjs';
import { useSSRContext, ref, unref, watch, computed, mergeProps, isRef, reactive, resolveDirective } from 'vue';
import { ssrRenderAttr, ssrInterpolate, ssrRenderAttrs, ssrRenderComponent, ssrRenderClass, ssrGetDirectiveProps, ssrIncludeBooleanAttr, ssrLooseContain } from 'vue/server-renderer';
import { u as useFormValidation } from './useFormValidation-BMv_R6aU.mjs';
import { u as useDiff } from './useDiff-Chx28f43.mjs';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { u as useProviderFields } from './useProviderFields-B2EuWWWy.mjs';
import { toTypedSchema } from '@vee-validate/zod';
import { useField, useForm } from 'vee-validate';
import { u as useProviders } from './useProviders-Ck9yopDY.mjs';
import { z } from 'zod';
import { _ as __nuxt_component_1$2 } from './VeeMultiSelectWithSearch-Btd5b5Va.mjs';
import { u as useFilter } from './useFilter-BmdPUTpE.mjs';
import { u as useCurrencyOptions } from './useCurrencyOptions-BsifIVKS.mjs';
import { b as __nuxt_component_0$5, a as __nuxt_component_0$1$1, _ as __nuxt_component_0$2$2 } from './VeeForm-DN2tnu-9.mjs';
import { C as CustomSelect } from './search-CNCM2ROA.mjs';
import { _ as _imports_0 } from './check-BGWLIG1L.mjs';
import { u as useFormData } from './useFormData-CRA6LhaU.mjs';
import { u as useWatchStateValues } from './useWatchStateValues-DimKH74z.mjs';
import { u as useAlert } from './useAlert-CPK6c05f.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import './sb-_CyfLtbf.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './useSort-Dy_x39w5.mjs';
import '@tiptap/pm/state';
import '@tiptap/pm/model';
import '@tiptap/pm/transform';
import '@tiptap/pm/commands';
import '@tiptap/pm/schema-list';
import '@tiptap/pm/dropcursor';
import '@tiptap/pm/gapcursor';
import '@tiptap/pm/history';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './VeeSelectWithSearch-CuZCClCB.mjs';

const _sfc_main$g = {
  __name: "VeeAdvancedFieldsCard",
  __ssrInlineRender: true,
  props: {
    title: {
      default: "-",
      required: false
    }
  },
  setup(__props, { expose: __expose }) {
    const { providers } = useProviders();
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const objectID = computed(() => route.params.id);
    const type = computed(() => route.query.type);
    const { updateVacancy, updateDraft, getMyVacancy } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    function YouTubeGetID(url) {
      url = url.split(/(vi\/|v=|\/v\/|youtu\.be\/|\/embed\/)/);
      return url[2] !== void 0 ? url[2].split(/[^0-9a-z_\-]/i)[0] : url[0];
    }
    computed(() => {
      return YouTubeGetID(state.video_url.val);
    });
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const schema = computed(() => {
      return z.object({
        name: z.string().min(2),
        description: z.string().min(2),
        work_type_id: z.number().optional(),
        experience_id: z.number().optional(),
        accept_kids: z.boolean().optional(),
        accept_temporary: z.boolean().optional(),
        accept_incomplete_resumes: z.boolean().optional(),
        accept_handicapped: z.boolean().optional(),
        allow_messages: z.boolean().optional(),
        schedule_id: z.number().optional().optional(),
        response_notifications: z.boolean().optional(),
        working_days_id: z.number().optional(),
        with_zp: z.boolean().optional(),
        response_letter_required: z.boolean().optional(),
        working_time_intervals_id: z.number().optional(),
        working_time_modes_id: z.number().optional(),
        refresh_vac: z.boolean().optional(),
        extend_vac_id: z.number().optional(),
        resume_subscription_status: z.boolean().optional(),
        // subscriptionKeywords: z
        //   .array(
        //     z.object({
        //       keyword: z.string(),
        //       srws: z.string(),
        //       skwc: z.string(),
        //       is_hidden: z.boolean(),
        //     }),
        //   )
        //   .nullish()
        //   .optional(),
        place_of_work_id: z.number().optional(),
        education_id: z.number().optional(),
        marital_status_id: z.number().optional(),
        children_id: z.number().optional(),
        gender_id: z.number().optional(),
        covid_vaccination_requirement_id: z.number(),
        move_able: z.boolean().optional(),
        video_url: z.string().nullable().optional(),
        age_from: z.number().optional(),
        age_to: z.number().optional()
      });
    });
    const initialValues = {
      name: null,
      description: null,
      work_type_id: null,
      experience_id: null,
      accept_kids: false,
      accept_temporary: false,
      accept_incomplete_resumes: false,
      accept_handicapped: false,
      allow_messages: false,
      schedule_id: null,
      response_notifications: false,
      working_days_id: null,
      with_zp: false,
      response_letter_required: false,
      working_time_intervals_id: null,
      working_time_modes_id: null,
      refresh_vac: false,
      extend_vac_id: null,
      resume_subscription_status: false,
      // subscriptionKeywords: [
      //   {
      //     keyword: null,
      //     srws: null,
      //     skwc: null,
      //     is_hidden: false,
      //   },
      // ],
      place_of_work_id: null,
      education_id: null,
      marital_status_id: null,
      children_id: null,
      gender_id: null,
      covid_vaccination_requirement_id: null,
      move_able: null,
      video_url: null,
      age_from: null,
      age_to: null
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      name: {
        is_hidden: false
      },
      description: {
        is_hidden: false
      },
      work_type_id: {
        is_hidden: false
      },
      experience_id: {
        is_hidden: false
      },
      accept_kids: {
        is_hidden: false
      },
      accept_temporary: {
        is_hidden: false
      },
      accept_incomplete_resumes: {
        is_hidden: false
      },
      accept_handicapped: {
        is_hidden: false
      },
      allow_messages: {
        is_hidden: false
      },
      schedule_id: {
        is_hidden: false
      },
      response_notifications: {
        is_hidden: false
      },
      working_days_id: {
        is_hidden: false
      },
      with_zp: {
        is_hidden: false
      },
      response_letter_required: {
        is_hidden: false
      },
      working_time_intervals_id: {
        is_hidden: false
      },
      working_time_modes_id: {
        is_hidden: false
      },
      refresh_vac: {
        is_hidden: false
      },
      extend_vac_id: {
        is_hidden: false
      },
      resume_subscription_status: {
        is_hidden: false
      },
      subscriptionKeywords: {
        keyword: {
          is_hidden: false
        },
        srws: {
          is_hidden: false
        },
        skwc: {
          is_hidden: false
        },
        is_hidden: false
      },
      place_of_work_id: {
        is_hidden: false
      },
      education_id: {
        is_hidden: false
      },
      marital_status_id: {
        is_hidden: false
      },
      children_id: {
        is_hidden: false
      },
      gender_id: {
        is_hidden: false
      },
      covid_vaccination_requirement_id: {
        is_hidden: false
      },
      move_able: {
        is_hidden: false
      },
      video_url: {
        is_hidden: false
      },
      age_from: {
        is_hidden: false
      },
      age_to: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        name: true,
        description: true,
        work_type_id: false,
        experience_id: false,
        accept_kids: false,
        accept_temporary: false,
        accept_incomplete_resumes: false,
        allow_applicant_without_resume: null,
        accept_handicapped: false,
        allow_messages: false,
        schedule_id: false,
        response_notifications: false,
        working_days_id: false,
        with_zp: false,
        response_letter_required: false,
        working_time_intervals_id: false,
        working_time_modes_id: false,
        refresh_vac: null,
        extend_vac_id: null,
        resume_subscription_status: null,
        subscriptionKeywords: {
          keyword: null,
          srws: null,
          skwc: null,
          is_hidden: false
        },
        place_of_work_id: null,
        education_id: null,
        marital_status_id: null,
        children_id: null,
        gender_id: null,
        covid_vaccination_requirement_id: null,
        move_able: null,
        video_url: null,
        age_from: null,
        age_to: null
      },
      superjob: {
        name: true,
        description: true,
        work_type_id: false,
        experience_id: false,
        accept_kids: null,
        accept_temporary: null,
        accept_incomplete_resumes: null,
        allow_applicant_without_resume: null,
        accept_handicapped: null,
        allow_messages: null,
        schedule_id: false,
        response_notifications: null,
        working_days_id: null,
        with_zp: null,
        response_letter_required: null,
        working_time_intervals_id: null,
        working_time_modes_id: null,
        refresh_vac: false,
        extend_vac_id: false,
        resume_subscription_status: false,
        subscriptionKeywords: {
          keyword: true,
          srws: true,
          skwc: true,
          is_hidden: true
        },
        place_of_work_id: false,
        education_id: false,
        marital_status_id: false,
        children_id: false,
        gender_id: false,
        covid_vaccination_requirement_id: true,
        move_able: false,
        video_url: false,
        age_from: false,
        age_to: false
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    walkThroughFields(providers.value);
    const sectionData = ref({});
    const getFields = (newObject) => {
      var _a2, _b2, _c2, _d2, _e2, _f2, _g2, _h2, _i2, _j2, _k2, _l2, _m2;
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
      return {
        ...initialValues,
        name: newObject.name,
        description: newObject.description,
        accept_kids: (_a2 = newObject.accept_kids) != null ? _a2 : false,
        accept_handicapped: (_b2 = newObject.accept_handicapped) != null ? _b2 : false,
        accept_incomplete_resumes: (_c2 = newObject.accept_incomplete_resumes) != null ? _c2 : false,
        response_letter_required: (_d2 = newObject.response_letter_required) != null ? _d2 : false,
        allow_messages: (_e2 = newObject.allow_messages) != null ? _e2 : false,
        response_notifications: (_f2 = newObject.response_notifications) != null ? _f2 : false,
        work_type_id: (_a = newObject.work_type) == null ? void 0 : _a.id,
        experience_id: (_b = newObject.experience) == null ? void 0 : _b.id,
        accept_temporary: (_g2 = newObject.accept_temporary) != null ? _g2 : false,
        schedule_id: (_c = newObject.schedule) == null ? void 0 : _c.id,
        working_days_id: (_d = newObject.working_days) == null ? void 0 : _d.id,
        working_time_intervals_id: (_e = newObject.working_time_intervals) == null ? void 0 : _e.id,
        working_time_modes_id: (_f = newObject.working_time_modes) == null ? void 0 : _f.id,
        refresh_vac: (_h2 = newObject.refresh_vac) != null ? _h2 : false,
        extend_vac_id: (_g = newObject.extend_vac) == null ? void 0 : _g.id,
        resume_subscription_status: (_i2 = newObject.resume_subscription_status) != null ? _i2 : false,
        place_of_work_id: (_h = newObject.place_of_work) == null ? void 0 : _h.id,
        education_id: (_i = newObject.education) == null ? void 0 : _i.id,
        marital_status_id: (_j = newObject.marital_status) == null ? void 0 : _j.id,
        children_id: (_k = newObject.children) == null ? void 0 : _k.id,
        gender_id: (_l = newObject.gender) == null ? void 0 : _l.id,
        covid_vaccination_requirement_id: (_m = newObject.covid_vaccination_requirement) == null ? void 0 : _m.id,
        move_able: (_j2 = newObject.move_able) != null ? _j2 : false,
        video_url: (_k2 = newObject.video_url) != null ? _k2 : void 0,
        age_from: (_l2 = newObject.age_from) != null ? _l2 : void 0,
        age_to: (_m2 = newObject.age_to) != null ? _m2 : void 0
      };
    };
    watch(
      () => vacancyStore.my_vacancy,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    const dictionaryStore = useDictionaryStore();
    useFormValidation();
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let jsonData = { ...values };
      let resData = {};
      jsonData.action = "UpdateAdvancedField";
      if (type.value === "draft") {
        resData = await updateDraft(objectID.value, jsonData);
      } else {
        resData = await updateVacancy(objectID.value, jsonData);
      }
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.address && myVacancy.address.address;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyTextInput = __nuxt_component_0$2$1;
      const _component_VeeTipTapRichEditor = __nuxt_component_0$3;
      const _component_VeeCustomSelect = __nuxt_component_2$2;
      const _component_CreateVacancyCheckboxInput = __nuxt_component_2$3;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0414\u0435\u0442\u0430\u043B\u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div><div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      if (!unref(state).name.is_hidden) {
        _push(`<div class="input-row"><label>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435:<b>*</b></label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
          name: "name",
          placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="input-row"><label for="description">\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435:<b>*</b></label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_VeeTipTapRichEditor, { name: "description" }, null, _parent));
      _push(`</div></div>`);
      if (!unref(state).work_type_id.is_hidden) {
        _push(`<div class="input-row"><label>\u0422\u0438\u043F \u0440\u0430\u0431\u043E\u0442\u044B:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).work_types_formatted,
          name: "work_type_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).experience_id.is_hidden) {
        _push(`<div class="input-row"><label>\u041E\u043F\u044B\u0442:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).experiences_formatted,
          name: "experience_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).accept_kids.is_hidden) {
        _push(`<div class="input-row"><label>\u0421\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u044C \u0441\u0442\u0430\u0440\u0448\u0435 14 \u043B\u0435\u0442:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
          name: "accept_kids",
          label: "\u0421\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u044C \u0441\u0442\u0430\u0440\u0448\u0435 14 \u043B\u0435\u0442. \u0423\u043A\u0430\u0437\u0430\u043D\u0438\u0435, \u0447\u0442\u043E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044F \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0434\u043B\u044F \u0441\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u0435\u0439 \u0441\u0442\u0430\u0440\u0448\u0435 14 \u043B\u0435\u0442          "
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).accept_temporary.is_hidden) {
        _push(`<div class="input-row"><label>\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0435 \u0442\u0440\u0443\u0434\u043E\u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
          name: "accept_temporary",
          label: "\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0435 \u0442\u0440\u0443\u0434\u043E\u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E. \u0443\u043A\u0430\u0437\u0430\u043D\u0438\u0435, \u0447\u0442\u043E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044F \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0441 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u043C \u0442\u0440\u0443\u0434\u043E\u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E\u043C"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).accept_incomplete_resumes.is_hidden) {
        _push(`<div class="input-row"><label>\u041D\u0435\u043F\u043E\u043B\u043D\u043E\u0435 \u0440\u0435\u0437\u044E\u043C\u0435:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
          name: "accept_incomplete_resumes",
          label: "\u041D\u0435\u043F\u043E\u043B\u043D\u043E\u0435 \u0440\u0435\u0437\u044E\u043C\u0435. \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D \u043B\u0438 \u043E\u0442\u043A\u043B\u0438\u043A \u043D\u0430 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E \u043D\u0435\u043F\u043E\u043B\u043D\u044B\u043C \u0440\u0435\u0437\u044E\u043C\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).accept_handicapped.is_hidden) {
        _push(`<div class="input-row"><label>\u0421\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u044C \u0441 \u0438\u043D\u0432\u0430\u043B\u0438\u0434\u043D\u043E\u0441\u0442\u044C\u044E:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
          name: "accept_handicapped",
          label: "\u0421\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u044C \u0441 \u0438\u043D\u0432\u0430\u043B\u0438\u0434\u043D\u043E\u0441\u0442\u044C\u044E. \u0423\u043A\u0430\u0437\u0430\u043D\u0438\u0435, \u0447\u0442\u043E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044F \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0434\u043B\u044F \u0441\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u0435\u0439 \u0441 \u0438\u043D\u0432\u0430\u043B\u0438\u0434\u043D\u043E\u0441\u0442\u044C\u044E"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).accept_handicapped.is_hidden) {
        _push(`<div class="input-row"><label>\u0421\u043E\u043F\u0440\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u043F\u0438\u0441\u044C\u043C\u043E:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
          name: "response_letter_required",
          label: "\u0421\u043E\u043F\u0440\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u043F\u0438\u0441\u044C\u043C\u043E \u041E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E \u043B\u0438 \u0437\u0430\u043F\u043E\u043B\u043D\u044F\u0442\u044C \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u043F\u0440\u0438 \u043E\u0442\u043A\u043B\u0438\u043A\u0435 \u043D\u0430 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).accept_handicapped.is_hidden) {
        _push(`<div class="input-row"><label>\u0420\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
          name: "allow_messages",
          label: "\u0420\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439. \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u044C \u043F\u0435\u0440\u0435\u043F\u0438\u0441\u043A\u0438 \u0441 \u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442\u0430\u043C\u0438 \u043F\u043E \u0434\u0430\u043D\u043D\u043E\u0439 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).accept_handicapped.is_hidden) {
        _push(`<div class="input-row"><label>\u0423\u0432\u0435\u0434\u043E\u043C\u043B\u044F\u0442\u044C \u043B\u0438 \u043C\u0435\u043D\u0435\u0434\u0436\u0435\u0440\u0430:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
          name: "response_notifications",
          label: "\u0423\u0432\u0435\u0434\u043E\u043C\u043B\u044F\u0442\u044C \u043B\u0438 \u043C\u0435\u043D\u0435\u0434\u0436\u0435\u0440\u0430 \u043E \u043D\u043E\u0432\u044B\u0445 \u043E\u0442\u043A\u043B\u0438\u043A\u0430\u0445"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).schedule_id.is_hidden) {
        _push(`<div class="input-row"><label>\u0433\u0440\u0430\u0444\u0438\u043A \u0440\u0430\u0431\u043E\u0442\u044B:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).schedules_formatted,
          name: "schedule_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).working_days_id.is_hidden) {
        _push(`<div class="input-row"><label>\u0440\u0430\u0431\u043E\u0447\u0438\u0435 \u0434\u043D\u0438:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).working_days_formatted,
          name: "working_days_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).with_zp.is_hidden) {
        _push(`<div class="input-row"><label>\u0417\u0430\u0440\u043F\u043B\u0430\u0442\u0430.\u0440\u0443:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
          name: "with_zp",
          label: "\u0412\u0430\u0448\u0443 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E \u0443\u0432\u0438\u0434\u044F\u0442 \u0431\u043E\u043B\u044C\u0448\u0435 \u043B\u044E\u0434\u0435\u0439. \u041C\u044B \u0440\u0430\u0437\u043C\u0435\u0441\u0442\u0438\u043C \u0435\u0435 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043D\u0430 \u0441\u0435\u0440\u0432\u0438\u0441\u0435 \u0417\u0430\u0440\u043F\u043B\u0430\u0442\u0430.\u0440\u0443"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).working_time_intervals_id.is_hidden) {
        _push(`<div class="input-row"><label>\u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0439 \u0438\u043D\u0442\u0435\u0440\u0432\u0430\u043B \u0440\u0430\u0431\u043E\u0442\u044B \u0438\u0437 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).working_time_intervals_formatted,
          name: "working_time_intervals_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).working_time_modes_id.is_hidden) {
        _push(`<div class="input-row"><label>\u0440\u0435\u0436\u0438\u043C\u044B \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u0440\u0430\u0431\u043E\u0442\u044B \u0438\u0437 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).working_time_modes_formatted,
          name: "working_time_modes_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).refresh_vac.is_hidden) {
        _push(`<div class="input-row"><label>\u041E\u0431\u043D\u043E\u0432\u043B\u044F\u0442\u044C \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
          name: "refresh_vac",
          label: "\u041E\u0431\u043D\u043E\u0432\u043B\u044F\u0442\u044C \u043B\u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).extend_vac_id.is_hidden) {
        _push(`<div class="input-row"><label>\u041F\u0440\u043E\u0434\u043B\u0435\u0432\u0430\u0442\u044C \u043B\u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).extend_vac_formatted,
          name: "extend_vac_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).resume_subscription_status.is_hidden) {
        _push(`<div class="input-row"><label>\u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443 \u043D\u0430 \u0440\u0435\u0437\u044E\u043C\u0435:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
          name: "resume_subscription_status",
          label: "\u0412\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043B\u0438 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443 \u043D\u0430 \u0440\u0435\u0437\u044E\u043C\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).place_of_work_id.is_hidden) {
        _push(`<div class="input-row"><label>\u041C\u0435\u0441\u0442\u043E \u0440\u0430\u0431\u043E\u0442\u044B:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).place_of_works_formatted,
          name: "place_of_work_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).education_id.is_hidden) {
        _push(`<div class="input-row"><label>\u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).educations_formatted,
          name: "education_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).marital_status_id.is_hidden) {
        _push(`<div class="input-row"><label>\u0421\u0435\u043C\u0435\u0439\u043D\u043E\u0435 \u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).marital_statuses_formatted,
          name: "marital_status_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).children_id.is_hidden) {
        _push(`<div class="input-row"><label>\u041D\u0430\u043B\u0438\u0447\u0438\u0435 \u0434\u0435\u0442\u0435\u0439:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).children_formatted,
          name: "children_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).gender_id.is_hidden) {
        _push(`<div class="input-row"><label>\u041F\u043E\u043B:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).genders_formatted,
          name: "gender_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).covid_vaccination_requirement_id.is_hidden) {
        _push(`<div class="input-row"><label>COVID-19:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(dictionaryStore).covid_vaccination_requirement_formatted,
          name: "covid_vaccination_requirement_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).move_able.is_hidden) {
        _push(`<div class="input-row"><label>\u0420\u0435\u043B\u043E\u043A\u0430\u0446\u0438\u044F:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
          name: "move_able",
          label: "\u0420\u0430\u0441\u0441\u043C\u0430\u0442\u0440\u0438\u0432\u0430\u044E\u0442\u0441\u044F \u0441\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u0438 \u0438\u0437 \u0434\u0440\u0443\u0433\u0438\u0445 \u0433\u043E\u0440\u043E\u0434\u043E\u0432"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).video_url.is_hidden) {
        _push(`<div class="input-row"><label>\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u0432\u0438\u0434\u0435\u043E\u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E :</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
          name: "video_url",
          placeholder: "URL"
        }, null, _parent));
        _push(`<p class="text-secondary mt-1"> \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u044E\u0442\u0441\u044F \u0441\u0441\u044B\u043B\u043A\u0438 \u043D\u0430 Youtube \u0438 Vimeo </p></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).age_from.is_hidden && !unref(state).age_to.is_hidden) {
        _push(`<div class="input-row"><label for="remote-work">\u0412\u043E\u0437\u0440\u0430\u0441\u0442\u044C</label><div class="input-wrapper"><div class="c2"><div>`);
        if (!unref(state).age_from.is_hidden) {
          _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
            name: "age_from",
            placeholder: "\u041E\u0442"
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div>`);
        if (!unref(state).age_to.is_hidden) {
          _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
            name: "age_to",
            placeholder: "\u0414\u043E"
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$g = _sfc_main$g.setup;
_sfc_main$g.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeAdvancedFieldsCard.vue");
  return _sfc_setup$g ? _sfc_setup$g(props, ctx) : void 0;
};
const __nuxt_component_2$1 = _sfc_main$g;
const _sfc_main$f = {
  __name: "VeeCitiesCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const { providers } = useProviders();
    const ID = computed(() => route.params.id);
    const type = computed(() => route.query.type);
    const { updateVacancy, updateDraft, getMyVacancy, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    const selectedCityOptions = ref([]);
    const schema = computed(() => {
      return z.object({
        cities: z.array(z.number()).optional()
      });
    });
    const initialValues = {
      cities: []
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      cities: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        cities: true
      },
      superjob: {
        cities: true
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    walkThroughFields(providers.value);
    const sectionData = ref({});
    const getFields = (newObject) => {
      return {
        cities: newObject.cities.map((item) => item.id)
      };
    };
    watch(
      () => vacancyStore.my_vacancy,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    useDictionaryStore();
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let jsonData = { ...values };
      let resData = {};
      jsonData.action = "UpdateCities";
      if (type.value === "draft") {
        resData = await updateDraft(ID.value, jsonData);
      } else {
        resData = await updateVacancy(ID.value, jsonData);
      }
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.cities.length > 0;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyCities = __nuxt_component_0$4;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0413\u0434\u0435 \u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C?(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label>\u0421\u043F\u0438\u0441\u043E\u043A \u0433\u043E\u0440\u043E\u0434\u043E\u0432:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_CreateVacancyCities, {
        name: "cities",
        selected_options: unref(selectedCityOptions)
      }, null, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeCitiesCard.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$f;
const _sfc_main$e = {
  __name: "VeeMetroCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const { providers } = useProviders();
    const ID = computed(() => route.params.id);
    const type = computed(() => route.query.type);
    const { updateVacancy, updateDraft, getMyVacancy, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    const cityHasNoMetro = ref(false);
    const cities = computed(() => {
      if (vacancyStore.my_vacancy && vacancyStore.my_vacancy.cities) {
        return vacancyStore.my_vacancy.cities.map((item) => item.id);
      }
      return [];
    });
    const { searchMetro } = useDictionaryStore();
    const selectedOptions = ref([]);
    const metroOptions = ref([]);
    const updateInput = async (newValue = "") => {
      var _a;
      cityHasNoMetro.value = false;
      const items = (_a = await searchMetro({ city_ids: cities.value })) != null ? _a : [];
      console.log(items);
      let newOptions = items.map((item) => ({
        value: item.id,
        name: `${item.name}`
      }));
      newOptions = newOptions.filter((item) => item.name.includes(newValue));
      if (items.length < 1) {
        cityHasNoMetro.value = true;
        return;
      }
      metroOptions.value = newOptions.concat(selectedOptions.value);
    };
    const schema = computed(() => {
      return z.object({
        metro: z.array(z.number()).optional()
      });
    });
    const initialValues = {
      metro: []
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      metro: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        metro: null
      },
      superjob: {
        metro: true
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    walkThroughFields(providers.value);
    const sectionData = ref({});
    const getFields = (newObject) => {
      return {
        metro: newObject.metro.map((item) => item.id)
      };
    };
    watch(
      () => vacancyStore.my_vacancy,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    useDictionaryStore();
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let jsonData = { ...values };
      let resData = {};
      jsonData.action = "UpdateMetro";
      if (type.value === "draft") {
        resData = await updateDraft(ID.value, jsonData);
      } else {
        resData = await updateVacancy(ID.value, jsonData);
      }
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.cities.length > 0;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeMultiSelectWithSearch = __nuxt_component_1$2;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u041C\u0435\u0442\u0440\u043E(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label>\u0421\u043F\u0438\u0441\u043E\u043A \u0433\u043E\u0440\u043E\u0434\u043E\u0432:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, {
        options: unref(metroOptions),
        name: "metro",
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435",
        onInput: updateInput
      }, null, _parent));
      if (unref(cityHasNoMetro)) {
        _push(`<div class="text text-danger"> \u043C\u0435\u0442\u0440\u043E \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E. </div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeMetroCard.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main$e;
const _sfc_main$d = {
  __name: "VeeProfessionalRoles",
  __ssrInlineRender: true,
  setup(__props) {
    const profileStore = useProfileStore();
    const { providers } = useProviders();
    const selectedProviders = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false)
        return ["hh"];
      if (providers.value.hh === false && providers.value.superjob === true)
        return ["superjob"];
      return ["hh", "superjob"];
    });
    const isHHSelected = computed(() => selectedProviders.value.includes("hh"));
    const isSuperjobSelected = computed(
      () => selectedProviders.value.includes("superjob")
    );
    const professionalRoleOptions = ref([]);
    const {
      searchProfessionalRoles,
      searchHHProfessionalRoles,
      searchSuperjobProfessionalRoles
    } = profileStore;
    const { uniq } = useFilter();
    const { value: prof_role_ids } = useField("professional_roles");
    watch(
      () => prof_role_ids.value,
      async () => {
        let items = [];
        if (isHHProfRolesNeeded.value) {
          const new_h = profileStore.hh_professional_roles_with_parent;
          items = items.concat(new_h);
        }
        if (isSuperjobProfRolesNeeded.value) {
          const new_s = profileStore.superjob_professional_roles_with_parent;
          items = items.concat(new_s);
        }
        if (isHHProfRolesNeeded.value || isSuperjobProfRolesNeeded.value) {
          items = items.concat(profileStore.professional_roles_with_parent);
          items = uniq(items, "value");
          professionalRoleOptions.value = items;
        } else {
          professionalRoleOptions.value = profileStore.professional_roles_with_parent;
        }
      }
    );
    const updateProfessionalInput = async (newValue = "", providers2 = []) => {
      let items = await searchProfessionalRoles();
      if (newValue) {
        items = items.filter((item) => item.parent_id !== 0).filter((item) => item.name.includes(newValue));
      } else {
        items = items.filter((item) => item.parent_id !== 0);
      }
      professionalRoleOptions.value = items.map((item) => ({
        value: item.id,
        name: item.name
      }));
    };
    const isHHProfRolesNeeded = computed(() => {
      if (!isHHSelected.value)
        return false;
      if (prof_role_ids.value.length < 1)
        return true;
      const selected_fields_values = [...prof_role_ids.value];
      return !selected_fields_values.some(
        (item) => profileStore.hh_professional_roles_with_parent_ids.includes(item)
      );
    });
    const isSuperjobProfRolesNeeded = computed(() => {
      if (!isSuperjobSelected.value)
        return false;
      if (prof_role_ids.value.length < 1)
        return true;
      const selected_fields_values = [...prof_role_ids.value];
      return !selected_fields_values.some(
        (item) => profileStore.superjob_professional_roles_with_parent_ids.includes(item)
      );
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeMultiSelectWithSearch = __nuxt_component_1$2;
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, mergeProps({
        name: "professional_roles",
        sort_by: "none",
        options: unref(professionalRoleOptions),
        onInput: updateProfessionalInput,
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeProfessionalRoles.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const __nuxt_component_0$1 = _sfc_main$d;
const _sfc_main$c = {
  __name: "VeeProfessionalRolesCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const { providers } = useProviders();
    const ID = computed(() => route.params.id);
    const type = computed(() => route.query.type);
    const { updateVacancy, updateDraft, getMyVacancy, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    ref([]);
    const schema = computed(() => {
      return z.object({
        professional_roles: z.array(z.number()).optional()
      });
    });
    const initialValues = {
      cities: []
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      professional_roles: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        professional_roles: true
      },
      superjob: {
        professional_roles: true
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    walkThroughFields(providers.value);
    const sectionData = ref({});
    const getFields = (newObject) => {
      return {
        professional_roles: newObject.professional_roles.map((item) => item.id)
      };
    };
    watch(
      () => vacancyStore.my_vacancy,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    useDictionaryStore();
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let jsonData = { ...values };
      let resData = {};
      jsonData.action = "UpdateProfessionalRoles";
      if (type.value === "draft") {
        resData = await updateDraft(ID.value, jsonData);
      } else {
        resData = await updateVacancy(ID.value, jsonData);
      }
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.professional_roles.length > 0;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyVeeProfessionalRoles = __nuxt_component_0$1;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0421\u0444\u0435\u0440\u0430 \u0434\u0435\u044F\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label>\u0421\u043F\u0438\u0441\u043E\u043A \u0434\u0435\u044F\u0442\u0435\u043B\u043D\u043E\u0441\u0442\u0435\u0439:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_CreateVacancyVeeProfessionalRoles, { name: "professional_roles" }, null, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeProfessionalRolesCard.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$c;
const _sfc_main$b = {
  __name: "VeeTypeAndUrlCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const { providers } = useProviders();
    const ID = computed(() => route.params.id);
    const type = computed(() => route.query.type);
    const { updateVacancy, updateDraft, getMyVacancy, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const isAnonymous = computed(() => {
      var _a;
      if (values) {
        return ((_a = values.type_id) == null ? void 0 : _a.toString()) === "48";
      }
      return false;
    });
    const isDirect = computed(() => {
      var _a;
      if (values) {
        return ((_a = values.type_id) == null ? void 0 : _a.toString()) === "49";
      }
      return false;
    });
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    const schema = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false) {
        return z.object({
          type_id: z.number(),
          custom_employer_name: z.string().nullable().optional(),
          response_url: z.string().nullable().optional()
        });
      }
      if (providers.value.hh === false && providers.value.superjob === true) {
        return z.object({
          type_id: z.number(),
          custom_employer_name: z.string().optional().nullable(),
          response_url: z.string().optional().nullable()
        });
      }
      return z.object({
        type_id: z.number(),
        custom_employer_name: z.string().nullable().optional(),
        response_url: z.string().nullable().optional()
      });
    });
    const initialValues = {
      type_id: null
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      type_id: {
        is_hidden: false
      },
      custom_employer_name: {
        is_hidden: false
      },
      response_url: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        type_id: true,
        custom_employer_name: true,
        response_url: true
      },
      superjob: {
        type_id: true,
        custom_employer_name: true,
        response_url: true
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    walkThroughFields(providers.value);
    const sectionData = ref({});
    const getFields = (newObject) => {
      var _a;
      return {
        type_id: (_a = newObject.type) == null ? void 0 : _a.id,
        custom_employer_name: newObject.custom_employer_name,
        response_url: newObject.response_url
      };
    };
    watch(
      () => vacancyStore.my_vacancy,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    const dictionaryStore = useDictionaryStore();
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let jsonData = { ...JSON.parse(JSON.stringify(values)) };
      let resData = {};
      jsonData.action = "UpdateType";
      if (type.value === "draft") {
        resData = await updateDraft(ID.value, jsonData);
      } else {
        resData = await updateVacancy(ID.value, jsonData);
      }
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.type_id !== null;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeCustomSelect = __nuxt_component_2$2;
      const _component_CreateVacancyTextInput = __nuxt_component_0$2$1;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0422\u0438\u043F \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label>\u0422\u0438\u043F \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        name: "type_id",
        options: unref(dictionaryStore).vacancy_types_formatted,
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div>`);
      if (unref(isAnonymous)) {
        _push(`<div class="input-row"><label>\u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438 \u0434\u043B\u044F \u0430\u043D\u043E\u043D\u0438\u043C\u043D\u044B\u0445 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
          name: "custom_employer_name",
          placeholder: "\u041E\u041E\u041E"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isDirect)) {
        _push(`<div class="input-row"><label>URL \u043E\u0442\u043A\u043B\u0438\u043A\u0430 \u0434\u043B\u044F \u043F\u0440\u044F\u043C\u044B\u0445 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
          name: "response_url",
          placeholder: "https://"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeTypeAndUrlCard.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$b;
const _sfc_main$a = {
  __name: "VeeSalaryCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const { providers } = useProviders();
    const ID = computed(() => route.params.id);
    const type = computed(() => route.query.type);
    const { updateVacancy, updateDraft, getMyVacancy, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    const dictionaryStore = useDictionaryStore();
    const currencyOptions = ref(useCurrencyOptions());
    computed(() => {
      return dictionaryStore.payment_period.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const schema = computed(() => {
      return z.object({
        salary: z.object({
          currency: z.string(),
          gross: z.boolean(),
          from: z.number(),
          to: z.number(),
          period: z.number()
        })
      });
    });
    const initialValues = {
      currency: "RUB",
      from: null,
      to: null,
      gross: null,
      period: null
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      salary: {
        currency: {
          is_hidden: false
        },
        gross: {
          is_hidden: false
        },
        from: {
          is_hidden: false
        },
        to: {
          is_hidden: false
        },
        period: {
          is_hidden: false
        }
      }
    });
    const fields = ref({
      hh: {
        salary: {
          currency: false,
          from: false,
          gross: false,
          to: false,
          period: null
        }
      },
      superjob: {
        salary: {
          currency: false,
          from: false,
          gross: null,
          to: false,
          period: false
        }
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    walkThroughFields(providers.value);
    const sectionData = ref({});
    const getFields = (newObject) => {
      var _a;
      return {
        salary: { ...newObject.salary, period: (_a = newObject.salary.period) == null ? void 0 : _a.id }
      };
    };
    watch(
      () => vacancyStore.my_vacancy,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let jsonData = { ...values };
      let resData = {};
      jsonData.action = "UpdateSalary";
      if (type.value === "draft") {
        resData = await updateDraft(ID.value, jsonData);
      } else {
        resData = await updateVacancy(ID.value, jsonData);
      }
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.type_id !== null;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyTextInput = __nuxt_component_0$2$1;
      const _component_VeeCustomSelect = __nuxt_component_2$2;
      const _component_CreateVacancyCheckboxInput = __nuxt_component_2$3;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0417\u0430\u0440\u043F\u043B\u0430\u0442\u0430(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label>\u0417\u0430\u0440\u043F\u043B\u0430\u0442\u0430:</label><div class="row-container"><div class="row mb-2"><div class="col-6"><div class="input-wrapper w-100">`);
      _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
        type: "number",
        name: "salary.from",
        placeholder: "\u041E\u0442"
      }, null, _parent));
      _push(`</div></div><div class="col-6"><div class="input-wrapper w-100">`);
      _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
        type: "number",
        name: "salary.to",
        placeholder: "\u0414\u043E"
      }, null, _parent));
      _push(`</div></div></div><div class="row"><div class="col-6">`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        label: "\u041F\u0435\u0440\u0438\u043E\u0434",
        options: unref(dictionaryStore).payment_period_formatted,
        name: "salary.period"
      }, null, _parent));
      _push(`</div><div class="col-6">`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        label: "\u0412\u0430\u043B\u044E\u0442\u0430",
        options: unref(currencyOptions),
        name: "salary.currency"
      }, null, _parent));
      _push(`</div></div><div class="row mt-2">`);
      _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
        name: "salary.gross",
        label: "\u0434\u043E \u0432\u044B\u0447\u0435\u0442\u0430 \u043D\u0430\u043B\u043E\u0433\u043E\u0432"
      }, null, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeSalaryCard.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main$a;
const _sfc_main$9 = {
  __name: "VeeSkillsCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const { providers } = useProviders();
    const ID = computed(() => route.params.id);
    const type = computed(() => route.query.type);
    const { updateVacancy, updateDraft, getMyVacancy, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const dictionaryStore = useDictionaryStore();
    ref(useCurrencyOptions());
    computed(() => {
      return dictionaryStore.payment_period.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const schema = computed(() => {
      return z.object({
        key_skills: z.array(z.string()).nonempty()
      });
    });
    const initialValues = {
      key_skills: []
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      key_skills: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        key_skills: false
      },
      superjob: {
        key_skills: false
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    walkThroughFields(providers.value);
    const sectionData = ref({});
    const getFields = (newObject) => {
      return {
        key_skills: newObject.key_skills
      };
    };
    watch(
      () => vacancyStore.my_vacancy,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let jsonData = { ...values };
      let resData = {};
      jsonData.action = "UpdateType";
      if (type.value === "draft") {
        resData = await updateDraft(ID.value, jsonData);
      } else {
        resData = await updateVacancy(ID.value, jsonData);
      }
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.type_id !== null;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeKnowledgeAndSkillsVeeForm = __nuxt_component_0$5;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u041D\u0430\u0432\u044B\u043A\u0438(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label>\u041A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043D\u0430\u0432\u044B\u043A\u0438:</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_CreateResumeKnowledgeAndSkillsVeeForm, { name: "key_skills" }, null, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeSkillsCard.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_8 = _sfc_main$9;
const _sfc_main$8 = {
  __name: "AddressCard",
  __ssrInlineRender: true,
  props: {
    title: {
      default: "",
      required: false
    },
    providers: {
      required: true,
      default: {}
    }
  },
  setup(__props, { expose: __expose }) {
    const props = __props;
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const draftID = computed(() => route.query.draft_id);
    computed(() => route.query.vacancy_id);
    const { updateVacancy, updateDraft, getMyVacancy, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const isSaved = ref(false);
    const isChanged = ref(false);
    const isFirst = ref(true);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const state = reactive({
      address: {
        val: null,
        isValid: true,
        is_hidden: false
      },
      address_id: {
        val: null,
        isValid: true,
        is_hidden: false
      },
      show_metro_only: {
        val: false,
        isValid: true,
        is_hidden: false
      },
      isFormValid: true,
      isNew: true,
      isLoading: false,
      error: null,
      success: null
    });
    const fields = ref({
      hh: {
        address_id: false,
        show_metro_only: false
      },
      superjob: {
        address: false
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    watch(() => props.providers, walkThroughFields);
    watch(
      () => useWatchStateValues(state, true, true),
      (newState, oldState) => {
        if (!isFirst.value) {
          isChanged.value = true;
        } else {
          isFirst.value = false;
        }
      }
    );
    const sectionData = ref({});
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          state.address_id.val = newData.address_id;
          state.address.val = newData.address;
          state.show_metro_only.val = newData.show_metro_only;
        }
      }
    );
    watch(
      () => vacancyStore.my_vacancy,
      (newVacancy) => {
        var _a, _b, _c;
        if (isUpdated.value) {
          isUpdated.value = false;
          return;
        }
        if (newVacancy) {
          sectionData.value = {
            address: (_a = newVacancy.address) == null ? void 0 : _a.address,
            address_id: (_b = newVacancy.address) == null ? void 0 : _b.address_id,
            show_metro_only: (_c = newVacancy.address) == null ? void 0 : _c.show_metro_only
          };
        }
      }
    );
    const dictionaryStore = useDictionaryStore();
    const addressOptions = computed(() => {
      var _a;
      return (_a = dictionaryStore.addresses) == null ? void 0 : _a.map((item) => ({
        name: item.raw,
        value: item.id
      }));
    });
    const addressErrorMessage = ref(null);
    const { errors, handleErrorResponse } = useFormValidation();
    const isFocused = ref(false);
    const save = async (is_from_parent = false) => {
      if (is_from_parent === true) {
        isFocused.value = true;
      }
      if (!isFocused.value) {
        return true;
      }
      if (isChanged.value) {
        state.isLoading = true;
        errors.value = {};
        state.errorMessage = "";
        let resData = {};
        const jsonData = { address: useFormData(state) };
        jsonData.action = "UpdateAddress";
        if (draftID.value) {
          resData = await updateDraft(draftID.value, jsonData);
        } else {
          resData = await updateVacancy(draftID.value, jsonData);
        }
        isUpdated.value = true;
        if (resData.status !== "success") {
          return handleErrorResponse(resData.data);
        }
        isChanged.value = false;
        isSaved.value = false;
        isUpdated.value = false;
        if (is_from_parent) {
          return new Promise((resolve, reject) => {
            resolve(true);
          });
        }
      } else {
        return true;
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.address && myVacancy.address.address;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0410\u0434\u0440\u0435\u0441(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      if (!unref(state).address_id.is_hidden) {
        _push(`<div class="input-row"><label>\u0421\u043F\u0438\u0441\u043E\u043A \u0410\u0434\u0440\u0435\u0441\u043E\u0432 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438:<b>*</b></label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CustomSelect, {
          options: unref(addressOptions),
          modelValue: unref(state).address_id.val,
          "onUpdate:modelValue": ($event) => unref(state).address_id.val = $event,
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435",
          onFocusin: () => unref(errors).address_id = ""
        }, null, _parent));
        if (unref(errors).address_id) {
          _push(`<div class="text-danger d-block"> \u0412\u0430\u043C \u043D\u0443\u0436\u043D\u043E \u0432\u044B\u0431\u0440\u0430\u0442\u044C \u0442\u0438\u043F \u0432\u0430\u043A\u0430\u043D\u0446\u0438\u0438! </div>`);
        } else {
          _push(`<!---->`);
        }
        if (unref(addressErrorMessage)) {
          _push(`<div class="text-danger d-block">${ssrInterpolate(unref(addressErrorMessage))}</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).address.is_hidden) {
        _push(`<div class="input-row"><label>\u0410\u0434\u0440\u0435\u0441:</label><div class="input-wrapper mt-2"><input${ssrRenderAttr("value", unref(state).address.val)}>`);
        if (unref(errors).address) {
          _push(`<div class="text-danger d-block"> \u0412\u0430\u043C \u043D\u0443\u0436\u043D\u043E \u0432\u0432\u0435\u0441\u0442\u0438 \u0430\u0434\u0440\u0435\u0441! </div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).show_metro_only.is_hidden) {
        _push(`<div class="input-row"><label>\u041C\u0435\u0442\u0440\u043E:</label><div class="input-wrapper mt-2"><div class="check-block mt-2"><div class="checkbox"><input type="checkbox" id="show_metro_only"${ssrIncludeBooleanAttr(Array.isArray(unref(state).show_metro_only.val) ? ssrLooseContain(unref(state).show_metro_only.val, null) : unref(state).show_metro_only.val) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="show_metro_only" class="fs-14">\u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0442\u044C \u0442\u043E\u043B\u044C\u043A\u043E \u043C\u0435\u0442\u0440\u043E \u0434\u043B\u044F \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u043E\u0433\u043E \u0430\u0434\u0440\u0435\u0441\u0430</label></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/AddressCard.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_9 = _sfc_main$8;
const _sfc_main$7 = {
  __name: "VeeDriverLicensesCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const { providers } = useProviders();
    const ID = computed(() => route.params.id);
    const type = computed(() => route.query.type);
    const { updateVacancy, updateDraft, getMyVacancy, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const schema = computed(() => {
      return z.object({
        driver_license_types: z.array(z.number()).nonempty()
      });
    });
    const initialValues = {
      driver_license_types: []
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      driver_license_types: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        driver_license_types: true
      },
      superjob: {
        driver_license_types: true
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    walkThroughFields(providers.value);
    const sectionData = ref({});
    const getFields = (newObject) => {
      return {
        driver_license_types: newObject.driver_license_types.map((item) => item.id)
      };
    };
    watch(
      () => vacancyStore.my_vacancy,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    useDictionaryStore();
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let jsonData = { ...values };
      let resData = {};
      jsonData.action = "UpdateDriverLicenseTypes";
      if (type.value === "draft") {
        resData = await updateDraft(ID.value, jsonData);
      } else {
        resData = await updateVacancy(ID.value, jsonData);
      }
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.type_id !== null;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeDriverLicensesForm = __nuxt_component_0$1$1;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0412\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0435 \u043F\u0440\u0430\u0432\u0430(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      _push(ssrRenderComponent(_component_CreateResumeDriverLicensesForm, { name: "driver_license_types" }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeDriverLicensesCard.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_10 = _sfc_main$7;
const __default__$1 = {
  name: "PhoneInput"
};
const _sfc_main$6 = /* @__PURE__ */ Object.assign(__default__$1, {
  __ssrInlineRender: true,
  props: ["name"],
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const { value: phone, errorMessage } = useField(() => props.name);
    ref();
    ref();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="input-row border-1"><input class=""${ssrRenderAttr("value", unref(phone))} placeholder="+"></div><div class="text text-danger">${ssrInterpolate(unref(errorMessage))}</div><!--]-->`);
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/PhoneInput.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$6;
const __default__ = {
  name: "ResumeTextarea"
};
const _sfc_main$5 = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    name: String,
    placeholder: String
  },
  setup(__props) {
    const props = __props;
    const { value, errorMessage } = useField(() => props.name);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><textarea class="form-control"${ssrRenderAttr("placeholder", props.placeholder)}>${ssrInterpolate(unref(value))}</textarea>`);
      if (unref(errorMessage)) {
        _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VacancyTextarea.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$5;
const _sfc_main$4 = {
  __name: "VeeContactsPhones",
  __ssrInlineRender: true,
  props: {
    name: {
      default: "phones",
      required: false
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    ref(null);
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const errors = ref(props.errors);
    watch(
      () => props.errors,
      (newValue) => {
        errors.value = newValue;
      }
    );
    computed(() => route.query.draft_id);
    computed(() => route.query.vacancy_id);
    computed(() => vacancyStore.my_vacancy);
    ref(false);
    ref(false);
    ref(true);
    ref(false);
    const isAdditionalPhoneShown = ref(false);
    ref({
      phone: {
        val: null,
        isValid: true,
        is_hidden: false
      },
      phone_comment: {
        val: null,
        isValid: true,
        is_hidden: false
      },
      additional_phone: {
        val: null,
        isValid: true,
        is_hidden: true
      },
      additional_phone_comment: {
        val: null,
        isValid: true,
        is_hidden: true
      }
    });
    useDictionaryStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyPhoneInput = __nuxt_component_0;
      const _component_CreateVacancyTextarea = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="input-row"><label>\u0422\u0435\u043B\u0435\u0444\u043E\u043D:</label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_CreateVacancyPhoneInput, { name: "contacts.phones.phone" }, null, _parent));
      _push(`</div></div><div class="input-row mt-0"><label>\u041A\u043E\u043C\u043C\u0435\u043D\u0442 \u043A \u0442\u0435\u043B\u0435\u0444\u043E\u043D:</label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_CreateVacancyTextarea, { name: "contacts.phones.phone_comment" }, null, _parent));
      if (!unref(isAdditionalPhoneShown)) {
        _push(`<button class="btn btn-primary mt-2"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435 </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (unref(isAdditionalPhoneShown)) {
        _push(`<div class="row"><div class="input-row"><label>\u0414\u043E\u043F. \u0442\u0435\u043B\u0435\u0444\u043E\u043D:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyPhoneInput, { name: "contacts.phones.additional_phone" }, null, _parent));
        _push(`</div></div><div class="input-row mt-0"><label>\u041A\u043E\u043C\u043C\u0435\u043D\u0442 \u043A \u0442\u0435\u043B\u0435\u0444\u043E\u043D:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyTextarea, { name: "contacts.phones.additional_phone_comment" }, null, _parent));
        if (unref(isAdditionalPhoneShown)) {
          _push(`<button class="btn btn-primary mt-2"> \u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C </button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeContactsPhones.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "VeeContactsCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const { providers } = useProviders();
    const ID = computed(() => route.params.id);
    const type = computed(() => route.query.type);
    const { updateVacancy, updateDraft, getMyVacancy, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    useDictionaryStore();
    const schema = computed(() => {
      return z.object({
        contacts: z.object({
          name: z.string(),
          email: z.string(),
          company_name: z.string(),
          company_description: z.string(),
          company_url: z.string(),
          company_logo: z.string(),
          phones: z.object({
            phone: z.string(),
            phone_comment: z.string().optional().nullish(),
            additional_phone: z.string().optional().nullish(),
            additional_phone_comment: z.string().optional().nullish()
          })
        })
      });
    });
    const initialValues = {
      contacts: {
        name: null,
        phones: {},
        email: null,
        company_name: null,
        company_url: null,
        company_logo: null,
        company_description: null
      }
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      contacts: {
        phones: {
          is_hidden: false
        },
        name: {
          is_hidden: false
        },
        email: {
          is_hidden: false
        },
        company_name: {
          is_hidden: false
        },
        company_url: {
          is_hidden: false
        },
        company_logo: {
          is_hidden: false
        },
        company_description: {
          is_hidden: false
        }
      }
    });
    const fields = ref({
      hh: {
        contacts: true
      },
      superjob: {
        contacts: true
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    walkThroughFields(providers.value);
    const sectionData = ref({});
    const getFields = (newObject) => {
      var _a, _b;
      return {
        contacts: {
          ...newObject.contacts,
          phones: {
            ...{
              ...newObject.contacts.phones,
              additional_phone: (_a = newObject.contacts.phones.additional_phone) != null ? _a : void 0,
              additional_phone_comment: (_b = newObject.contacts.phones.additional_phone_comment) != null ? _b : void 0
            }
          }
        }
      };
    };
    watch(
      () => vacancyStore.my_vacancy,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: { ...newData } });
        }
      }
    );
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let jsonData = { ...JSON.parse(JSON.stringify(values)) };
      let resData = {};
      jsonData.action = "UpdateContacts";
      if (type.value === "draft") {
        resData = await updateDraft(ID.value, jsonData);
      } else {
        resData = await updateVacancy(ID.value, jsonData);
      }
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.type_id !== null;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyTextInput = __nuxt_component_0$2$1;
      const _component_VeeTipTapRichEditor = __nuxt_component_0$3;
      const _component_CreateVacancyVeeContactsPhones = __nuxt_component_2;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u041A\u043E\u043D\u0442\u0430\u043A\u0442\u044B(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label>\u0418\u043C\u044F:</label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
        name: "contacts.name",
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div>`);
      if (!unref(state).contacts.email.is_hidden) {
        _push(`<div class="input-row"><label>Email:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
          name: "contacts.email",
          placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).contacts.company_name.is_hidden) {
        _push(`<div class="input-row"><label>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
          name: "contacts.company_name",
          placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).contacts.company_url.is_hidden) {
        _push(`<div class="input-row"><label>\u0410\u0434\u0440\u0435\u0441 \u0441\u0430\u0439\u0442\u0430:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
          name: "contacts.company_url",
          placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).contacts.company_logo.is_hidden) {
        _push(`<div class="input-row"><label>\u041B\u043E\u0433\u043E URL:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
          name: "contacts.company_logo",
          placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(state).contacts.company_description.is_hidden) {
        _push(`<div class="input-row"><label>\u041E \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438(\u043C\u0438\u043D 10 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432):</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeTipTapRichEditor, {
          name: "contacts.company_description",
          placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_CreateVacancyVeeContactsPhones, null, null, _parent));
      _push(` ${ssrInterpolate(unref(values))}</div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeContactsCard.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_11 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "VeeLanguagesCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const { providers } = useProviders();
    const ID = computed(() => route.params.id);
    const type = computed(() => route.query.type);
    const { updateVacancy, updateDraft, getMyVacancy, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    useDictionaryStore();
    const schema = computed(() => {
      return z.object({
        languages: z.array(
          z.object({
            language_id: z.number(),
            level_id: z.number()
          })
        ).nonempty()
      });
    });
    const initialValues = {
      languages: [
        {
          language_id: null,
          level_id: null
        }
      ]
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      languages: {
        language_id: {
          is_hidden: false
        },
        level_id: {
          is_hidden: false
        }
      }
    });
    const fields = ref({
      hh: {
        languages: true
      },
      superjob: {
        languages: true
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    walkThroughFields(providers.value);
    const sectionData = ref({});
    const getFields = (newObject) => {
      return {
        languages: newObject.languages.map((item) => ({
          language_id: item.language.id,
          level_id: item.level.id
        }))
      };
    };
    watch(
      () => vacancyStore.my_vacancy,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: { ...newData } });
        }
      }
    );
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let jsonData = { ...values };
      let resData = {};
      jsonData.action = "UpdateLanguages";
      if (type.value === "draft") {
        resData = await updateDraft(ID.value, jsonData);
      } else {
        resData = await updateVacancy(ID.value, jsonData);
      }
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.type_id !== null;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeForeignLanguagesVeeForm = __nuxt_component_0$2$2;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u042F\u0437\u044B\u043A\u0438(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      _push(ssrRenderComponent(_component_CreateResumeForeignLanguagesVeeForm, { name: "languages" }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeLanguagesCard.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_12 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "VeeBillingTypeCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    var _a;
    const vacancyStore = useVacancyStore();
    useProfileStore();
    const route = useRoute();
    const { providers } = useProviders();
    const isHidden = ref((_a = providers.value.hh) != null ? _a : false);
    watch(
      () => providers.value,
      (newProviders) => {
        isHidden.value = newProviders == null ? void 0 : newProviders.hh;
      }
    );
    const vacancyBillingTypeOptions = computed(() => {
      return dictionaryStore.vacancy_billing_types.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const ID = computed(() => route.params.id);
    const type = computed(() => route.query.type);
    const { updateVacancy, updateDraft, getMyVacancy, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    const schema = computed(() => {
      return z.object({
        billing_type_id: z.number()
      });
    });
    const initialValues = {
      billing_type_id: null
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      billing_type_id: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        billing_type_id: true
      },
      superjob: {
        billing_type_id: null
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    walkThroughFields(providers.value);
    const dictionaryStore = useDictionaryStore();
    const sectionData = ref({});
    const getFields = (newObject) => {
      var _a2;
      return {
        billing_type_id: (_a2 = newObject.billing_type) == null ? void 0 : _a2.id
      };
    };
    watch(
      () => vacancyStore.my_vacancy,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let jsonData = { ...JSON.parse(JSON.stringify(values)) };
      let resData = {};
      jsonData.action = "UpdateBillingType";
      if (type.value === "draft") {
        resData = await updateDraft(ID.value, jsonData);
      } else {
        resData = await updateVacancy(ID.value, jsonData);
      }
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myVacancy = my_vacancy.value;
      if (myVacancy && !isCollapsed.value) {
        return myVacancy.type_id !== null;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeCustomSelect = __nuxt_component_2$2;
      const _directive_click_outside = resolveDirective("click-outside");
      if (unref(isHidden)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0411\u0438\u043B\u043B\u0438\u043D\u0433(${ssrInterpolate(unref(isChanged))})</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
        if (unref(errors).message) {
          _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label>\u0422\u0438\u043F \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438:<b>*</b></label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(vacancyBillingTypeOptions),
          name: "billing_type_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/VeeBillingTypeCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_13 = _sfc_main$1;
const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const vacancyStore = useVacancyStore();
    const providers = ref({
      superjob: false,
      hh: false
    });
    const { setProviders } = useProviders();
    watch(
      () => providers.value,
      (newValues) => {
        setProviders(newValues);
      }
    );
    const { getMyVacancy, publishDraft, getMyDraft } = vacancyStore;
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const vacancyID = computed(() => route.params.id);
    computed(() => route.query.type);
    watch(
      () => route.params.id,
      (newDraftId) => {
        if (newDraftId) {
          getMyVacancy(vacancyID.value);
        }
      }
    );
    watch(
      () => vacancyStore.my_vacancy,
      (newDraft) => {
        if (newDraft) {
          setProviders(newDraft.providers);
        }
      }
    );
    const pageTitle = computed(() => {
      if (my_vacancy.value) {
        return "Jobeek - " + my_vacancy.value.name;
      }
      return "Jobeek - ";
    });
    useHead({
      title: pageTitle
    });
    computed(() => {
      return route.query.message;
    });
    const { handleAlert } = useAlert();
    watch(() => route.query.message, handleAlert);
    computed(() => {
      if (providers.value.hh && providers.value.superjob) {
        return ["hh", "superjob"];
      }
      if (providers.value.hh) {
        return ["hh"];
      }
      if (providers.value.superjob) {
        return ["superjob"];
      }
      return [];
    });
    computed(() => {
      if (hhPublishable.value && superjobPublishable.value)
        return true;
      return false;
    });
    const publishableProviderName = computed(() => {
      if (hhPublishable.value === true || superjobPublishable.value === true) {
        if (hhPublishable.value) {
          return "hh";
        }
        if (superjobPublishable.value) {
          return "superjob";
        }
      }
      return null;
    });
    const hhPublishable = ref(false);
    const superjobPublishable = ref(false);
    watch(
      () => vacancyStore.my_vacancy,
      (newObject) => {
        var _a, _b;
        const { can_publish } = newObject;
        if (can_publish) {
          hhPublishable.value = (_a = can_publish.hh) != null ? _a : false;
          superjobPublishable.value = (_b = can_publish.superjob) != null ? _b : false;
        }
      }
    );
    const advanced_fields_el = ref();
    const cities_el = ref();
    const prof_roles_el = ref();
    const driver_licences_el = ref();
    ref(null);
    ref(null);
    ref(null);
    ref([]);
    const isLoading = ref(false);
    const canOnlyOnePublished = computed(() => {
      if ((hhPublishable.value === true || superjobPublishable.value === true) && (superjobPublishable.value === false || hhPublishable.value === false)) {
        return true;
      }
      return false;
    });
    ref("");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0$2;
      const _component_CreateVacancyProviders = __nuxt_component_1$1;
      const _component_CreateVacancyVeeAdvancedFieldsCard = __nuxt_component_2$1;
      const _component_CreateVacancyVeeCitiesCard = __nuxt_component_3;
      const _component_CreateVacancyVeeMetroCard = __nuxt_component_4;
      const _component_CreateVacancyVeeProfessionalRolesCard = __nuxt_component_5;
      const _component_CreateVacancyVeeTypeAndUrlCard = __nuxt_component_6;
      const _component_CreateVacancyVeeSalaryCard = __nuxt_component_7;
      const _component_CreateVacancyVeeSkillsCard = __nuxt_component_8;
      const _component_CreateVacancyAddressCard = __nuxt_component_9;
      const _component_CreateVacancyVeeDriverLicensesCard = __nuxt_component_10;
      const _component_CreateVacancyVeeContactsCard = __nuxt_component_11;
      const _component_CreateVacancyVeeLanguagesCard = __nuxt_component_12;
      const _component_CreateVacancyVeeBillingTypeCard = __nuxt_component_13;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet my-resumes-page",
        role: "main"
      }, _attrs))} data-v-d6a61b4a><div class="bg-wrapper position-relative" data-v-d6a61b4a>`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="wrapper wrapper-1290" data-v-d6a61b4a><form class="update-resume pt-4 pb-5" data-v-d6a61b4a>`);
      _push(ssrRenderComponent(_component_CreateVacancyProviders, {
        modelValue: unref(providers),
        "onUpdate:modelValue": ($event) => isRef(providers) ? providers.value = $event : null
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyVeeAdvancedFieldsCard, {
        ref_key: "advanced_fields_el",
        ref: advanced_fields_el,
        key: `advanced_fields_el_key_${unref(providers).hh + unref(providers).superjob}`,
        providers: unref(providers)
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyVeeCitiesCard, {
        ref_key: "cities_el",
        ref: cities_el,
        key: `cities_el_key_${unref(providers).hh + unref(providers).superjob}`,
        providers: unref(providers)
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyVeeMetroCard, {
        key: `metro_el_key_${unref(providers).hh + unref(providers).superjob}`,
        ref: "metro_el",
        providers: unref(providers)
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyVeeProfessionalRolesCard, {
        ref_key: "prof_roles_el",
        ref: prof_roles_el,
        key: `prof_roles_el_key_${unref(providers).hh + unref(providers).superjob}`,
        providers: unref(providers)
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyVeeTypeAndUrlCard, {
        ref: "type_el",
        key: `type_el_key_${unref(providers).hh + unref(providers).superjob}`,
        providers: unref(providers)
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyVeeSalaryCard, {
        ref: "salary_el",
        providers: unref(providers),
        key: `salary_el_key_${unref(providers).hh + unref(providers).superjob}`
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyVeeSkillsCard, {
        ref: "skills_el",
        providers: unref(providers),
        key: `skills_el_key_${unref(providers).hh + unref(providers).superjob}`
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyAddressCard, {
        ref: "address_el",
        providers: unref(providers),
        key: `skills_el_key_${unref(providers).hh + unref(providers).superjob}`
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyVeeDriverLicensesCard, {
        key: `driver_licenses_el_${unref(providers).hh + unref(providers).superjob}`,
        ref_key: "driver_licences_el",
        ref: driver_licences_el,
        providers: unref(providers)
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyVeeContactsCard, {
        key: `contacts_el_${unref(providers).hh + unref(providers).superjob}`,
        ref: "contacts_el",
        providers: unref(providers)
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyVeeLanguagesCard, {
        key: `languages_el_${unref(providers).hh + unref(providers).superjob}`,
        ref: "languages_el",
        providers: unref(providers)
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateVacancyVeeBillingTypeCard, {
        key: `billing_el_${unref(providers).hh + unref(providers).superjob}`,
        ref: "billing_el",
        providers: unref(providers)
      }, null, _parent));
      _push(`<p class="text-lg-end" data-v-d6a61b4a> \u041F\u0440\u0438 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0438 \u0432\u0430\u043A\u0430\u043D\u0446\u0438\u0438 \u0432\u044B \u0441\u043E\u0433\u043B\u0430\u0448\u0430\u0435\u0442\u0435\u0441\u044C \u0441 <a href="#" data-v-d6a61b4a>\u043F\u0440\u0430\u0432\u0438\u043B\u0430\u043C\u0438 \u0440\u0430\u0431\u043E\u0442\u044B \u0441\u0435\u0440\u0432\u0438\u0441\u0430</a> \u0438 \u0434\u0430\u0435\u0442\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u0435 \u043D\u0430 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445, \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u0440\u0430\u0441\u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0435\u043D\u0438\u044F </p> ${ssrInterpolate(unref(canOnlyOnePublished))} <div class="form-submit-container mt-2" data-v-d6a61b4a><button class="btn btn-outline-primary" type="button" data-v-d6a61b4a> \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043A\u0430\u043A \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A </button><button class="${ssrRenderClass([{ disabled: !unref(canOnlyOnePublished) }, "button-accent"])}" type="submit" data-v-d6a61b4a>`);
      if (unref(isLoading)) {
        _push(`<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true" data-v-d6a61b4a></span>`);
      } else {
        _push(`<!---->`);
      }
      _push(` \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0438 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C </button></div>`);
      if (unref(canOnlyOnePublished)) {
        _push(`<p class="float-end text-primary-secondary mt-2" data-v-d6a61b4a> \u0411\u0443\u0434\u0435\u0442 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430 <span class="text-primary" data-v-d6a61b4a>${ssrInterpolate(unref(publishableProviderName).toUpperCase())}</span></p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</form></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/my-vacancy/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-d6a61b4a"]]);

export { _id_ as default };
//# sourceMappingURL=_id_-Dz9yyfyw.mjs.map
