import { o as defineStore, p as useRequestURL, q as useApi } from '../server.mjs';

const useUIStore = defineStore("ui", {
  state: () => {
    return {
      isSidebarOpen: true,
      isMobileMode: false,
      footer_settings: {}
    };
  },
  actions: {
    async toggleSidebar() {
      this.isSidebarOpen = !this.isSidebarOpen;
    },
    async turnOnMobileMode() {
      if (this.isSidebarOpen) {
        this.isSidebarOpen = false;
      }
      this.isMobileMode = true;
    },
    async turnOffMobileMode() {
      this.isMobileMode = false;
      if (!this.isSidebarOpen) {
        this.isSidebarOpen = true;
      }
    },
    async getFooterSettings() {
      const url = useRequestURL();
      const hostname = url.hostname;
      const response = await useApi("getSettings", {
        method: "get",
        params: {
          setting_key: "footer",
          host: hostname
        }
      });
      if (response.status === "success") {
        this.footer_settings = response.data.data;
        return this.footer_settings;
      }
      return response;
    }
  }
});

export { useUIStore as u };
//# sourceMappingURL=ui-DaXXToyC.mjs.map
