import { _ as __nuxt_component_0 } from './SearchMobile-WfXJ1gHL.mjs';
import { _ as __nuxt_component_1 } from './ConnectedProviders-DKmnzzBN.mjs';
import { _ as __nuxt_component_1$1 } from './DraftList-BRMHAaUX.mjs';
import { computed, watch, mergeProps, unref, useSSRContext } from 'vue';
import { u as useHead, k as useAuthStore, l as useVacancyStore, d as navigateTo } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './search-CNCM2ROA.mjs';
import './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import './superjob-DOWPfj1m.mjs';
import 'moment';
import './nuxt-link-BdrY0gEc.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import './useCurrencyOptions-BsifIVKS.mjs';
import './sj-CUMJdhcR.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './check-BGWLIG1L.mjs';
import './PageLoader-CgN00RaA.mjs';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u041C\u043E\u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 - Jobeek"
    });
    const authStore = useAuthStore();
    const isEmployer = computed(() => authStore.isEmployer);
    computed(() => authStore.user);
    computed(() => authStore.employer);
    useVacancyStore();
    watch(isEmployer, (new_value) => {
      if (new_value === false) {
        navigateTo({ name: "my-resumes" });
      }
    });
    const vacancyStore = useVacancyStore();
    computed(() => {
      if (vacancyStore.providers.hh === true && vacancyStore.providers.superjob === true) {
        return true;
      }
      return false;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0;
      const _component_MyVacanciesConnectedProviders = __nuxt_component_1;
      const _component_MyVacanciesDraftList = __nuxt_component_1$1;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet my-vacancies-page",
        role: "main"
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="bg-wrapper position-relative pt-4"><div class="has-sidebar has-sidebar--v2 wrapper wrapper-1290"><div class="content mb-4">`);
      _push(ssrRenderComponent(_component_MyVacanciesConnectedProviders, null, null, _parent));
      _push(ssrRenderComponent(_component_MyVacanciesDraftList, {
        items: unref(vacancyStore).my_drafts
      }, null, _parent));
      _push(`</div><aside class="sidebar"><div class="premium-col sticky-item">`);
      if (unref(isEmployer)) {
        _push(`<div class="title">\u041F\u0440\u0435\u043C\u0438\u0443\u043C</div>`);
      } else {
        _push(`<div class="title">\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u041F\u0440\u0435\u043C\u0438\u0443\u043C \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443</div>`);
      }
      if (unref(isEmployer)) {
        _push(`<div class="term"><span>\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 \u0434\u043E</span><strong>24 \u0430\u0432\u0433\u0443\u0441\u0442\u0430 2024</strong></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isEmployer)) {
        _push(`<a class="btn button-xs" href="#">\u041E\u0442\u043A\u043B\u044E\u0447\u0438\u0442\u044C </a>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<a class="notification-button button-accent" href="#">\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C </a></div></aside></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/my-vacancies-old/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-dwpsun4I.mjs.map
