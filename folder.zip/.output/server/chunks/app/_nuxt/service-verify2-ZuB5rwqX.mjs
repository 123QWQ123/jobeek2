import { ref, mergeProps, unref, useSSRContext } from 'vue';
import { k as useAuthStore, m as useProfileStore, s as storeToRefs, e as useRoute } from '../server.mjs';
import { ssrRenderAttrs } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main = {
  __name: "service-verify2",
  __ssrInlineRender: true,
  setup(__props) {
    const authStore = useAuthStore();
    useProfileStore();
    storeToRefs(authStore);
    const route = useRoute();
    const isSuccess = ref("-");
    route.query;
    useAuthStore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet profile-page bg-wrapper",
        role: "main"
      }, _attrs))}><div class="wrapper">`);
      if (unref(isSuccess)) {
        _push(`<div class="w-box"><div class="w-box-head"><h1 class="title">\u0412\u0430\u0448 \u044D\u043C\u0430\u0438\u043B \u043F\u043E\u0434\u0442\u0435\u0440\u0436\u0434\u0435\u043D!</h1></div><div class="w-box-body"><p>\u0427\u0435\u0440\u0435\u0437 5 \u0441\u0435\u043A\u0443\u043D\u0434 \u0440\u0435\u0434\u0438\u0440\u0435\u043A\u0442\u0438\u0442\u0441\u044F!</p></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/profile/service-verify2.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=service-verify2-ZuB5rwqX.mjs.map
