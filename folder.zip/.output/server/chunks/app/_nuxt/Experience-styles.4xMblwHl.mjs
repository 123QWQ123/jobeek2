const Experience_vue_vue_type_style_index_0_scoped_5c12e5a2_lang = ".check-block label[data-v-5c12e5a2]{white-space:pre-wrap}.with_scroll[data-v-5c12e5a2]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-5c12e5a2]{font-weight:700}.is_header .radio-mask[data-v-5c12e5a2],.is_header input[data-v-5c12e5a2]{display:none}input[type=search][data-v-5c12e5a2]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const ExperienceStyles_4xMblwHl = [Experience_vue_vue_type_style_index_0_scoped_5c12e5a2_lang];

export { ExperienceStyles_4xMblwHl as default };
//# sourceMappingURL=Experience-styles.4xMblwHl.mjs.map
