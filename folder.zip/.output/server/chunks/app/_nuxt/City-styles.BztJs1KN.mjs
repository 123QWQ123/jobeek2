const City_vue_vue_type_style_index_0_scoped_2bcdb980_lang = ".check-block label[data-v-2bcdb980]{white-space:pre-wrap}.with_scroll[data-v-2bcdb980]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-2bcdb980]{font-weight:700}.is_header .radio-mask[data-v-2bcdb980],.is_header input[data-v-2bcdb980]{display:none}input[type=search][data-v-2bcdb980]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const CityStyles_BztJs1KN = [City_vue_vue_type_style_index_0_scoped_2bcdb980_lang];

export { CityStyles_BztJs1KN as default };
//# sourceMappingURL=City-styles.BztJs1KN.mjs.map
