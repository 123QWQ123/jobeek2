const vee2_vue_vue_type_style_index_0_lang = "#app{font-family:Arial,Helvetica,sans-serif;max-width:500px}form{border:1px solid #000;padding:20px}form+form{margin-top:20px}";

const vee2Styles_CJ2Dz6D_ = [vee2_vue_vue_type_style_index_0_lang];

export { vee2Styles_CJ2Dz6D_ as default };
//# sourceMappingURL=vee2-styles.CJ2Dz6D_.mjs.map
