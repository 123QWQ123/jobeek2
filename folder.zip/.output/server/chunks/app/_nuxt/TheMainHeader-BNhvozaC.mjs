import { _ as __nuxt_component_0$1 } from './nuxt-link-BdrY0gEc.mjs';
import { useSSRContext, computed, mergeProps, withCtx, createVNode, createTextVNode, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderClass, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import { k as useAuthStore } from '../server.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { _ as _imports_0 } from './jobeek-dark-BM969tB2.mjs';

const _sfc_main$1 = {
  __name: "ModeSwitcher",
  __ssrInlineRender: true,
  setup(__props) {
    const auth = useAuthStore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "theme-checker-box cursor-pointer checker-box right__box" }, _attrs))} data-v-a2404eb6><span class="${ssrRenderClass([{ active: !unref(auth).isEmployer }, "v v1"])}" title="\u0421\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u044C" data-v-a2404eb6>\u0421\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u044C</span><div class="theme-checker" data-v-a2404eb6><input type="checkbox" id="employer"${ssrIncludeBooleanAttr(unref(auth).isEmployer) ? " checked" : ""} data-v-a2404eb6><div class="theme-checker-ui" data-v-a2404eb6><div class="${ssrRenderClass([{ left: !unref(auth).isEmployer, right: unref(auth).isEmployer }, "circle"])}" data-v-a2404eb6></div></div></div><span class="${ssrRenderClass([{ active: unref(auth).isEmployer }, "v v2"])}" title="\u0420\u0430\u0431\u043E\u0442\u043E\u0434\u0430\u0442\u0435\u043B\u044C" data-v-a2404eb6>\u0420\u0430\u0431\u043E\u0442\u043E\u0434\u0430\u0442\u0435\u043B\u044C</span></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/ModeSwitcher.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-a2404eb6"]]);
const _sfc_main = {
  __name: "TheMainHeader",
  __ssrInlineRender: true,
  setup(__props) {
    const auth = useAuthStore();
    computed(() => auth.isAuthed);
    computed(() => auth.isEmployer);
    computed(() => auth.user);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_ModeSwitcher = __nuxt_component_1;
      _push(`<header${ssrRenderAttrs(mergeProps({ class: "main-header" }, _attrs))} data-v-0c411f7e><div class="header-wrapper header-wrapper--fxstart" data-v-0c411f7e><div class="logo" data-v-0c411f7e>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="#" data-v-0c411f7e${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "#"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_ModeSwitcher, { class: "me-3 ms-auto" }, null, _parent));
      _push(`<div class="header-actions" data-v-0c411f7e>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "btn button-xs sign-in-btn",
        to: { name: "sign-in" },
        role: "link"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0412\u043E\u0439\u0442\u0438 `);
          } else {
            return [
              createTextVNode("\u0412\u043E\u0439\u0442\u0438 ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "btn button-xl sign-up-btn",
        to: { name: "sign-up" },
        role: "link"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F `);
          } else {
            return [
              createTextVNode("\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></header>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header/TheMainHeader.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-0c411f7e"]]);

export { __nuxt_component_0 as _, __nuxt_component_1 as a };
//# sourceMappingURL=TheMainHeader-BNhvozaC.mjs.map
