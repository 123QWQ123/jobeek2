function useDiff(obj1, obj2, exclude, is_include = false) {
  var r = {};
  if (!exclude)
    exclude = [];
  for (var prop in obj1) {
    if (obj1.hasOwnProperty(prop) && prop != "__proto__") {
      if (!is_include) {
        if (exclude.includes(prop)) {
          continue;
        }
      } else {
        if (!exclude.includes(prop)) {
          continue;
        }
      }
      if (exclude.indexOf(obj1[prop]) == -1) {
        if (!obj2.hasOwnProperty(prop))
          r[prop] = obj1[prop];
        else if (obj1[prop] === Object(obj1[prop])) {
          var difference = useDiff(obj1[prop], obj2[prop], exclude);
          if (Object.keys(difference).length > 0)
            r[prop] = difference;
        } else if (obj1[prop] !== obj2[prop]) {
          if (obj1[prop] === void 0)
            r[prop] = "undefined";
          if (obj1[prop] === null)
            r[prop] = null;
          else if (typeof obj1[prop] === "function")
            r[prop] = "function";
          else if (typeof obj1[prop] === "object")
            r[prop] = "object";
          else
            r[prop] = obj1[prop];
        }
      }
    }
  }
  return r;
}

export { useDiff as u };
//# sourceMappingURL=useDiff-Chx28f43.mjs.map
