import { _ as __nuxt_component_0 } from './SearchMobile-WfXJ1gHL.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_2, a as _imports_3 } from './sj-CUMJdhcR.mjs';
import { _ as _imports_0 } from './check-BGWLIG1L.mjs';
import { ref, mergeProps, useSSRContext, resolveComponent, unref, isRef } from 'vue';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './search-CNCM2ROA.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main$7 = {};
function _sfc_ssrRender$5(_ctx, _push, _parent, _attrs) {
  _push(`<!--[--><div class="input-row input-row--checkboxes"><label>\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043D\u044B\u0435 \u0441\u0435\u0440\u0432\u0438\u0441\u044B</label><div class="input-wrapper input-wrapper--flex"><div class="custom-check-wrap"><div class="theme-checker theme-checker--blue"><input type="checkbox" id="hh"><div class="theme-checker-ui"><div class="circle"></div></div></div><label for="hh"><img${ssrRenderAttr("src", _imports_2)} alt="#"><span>Hh.ru</span></label></div><div class="custom-check-wrap"><div class="theme-checker theme-checker--blue"><input type="checkbox" id="sj" checked><div class="theme-checker-ui"><div class="circle"></div></div></div><label for="sj"><img${ssrRenderAttr("src", _imports_3)} alt="#"><span>Superjob.ru </span></label></div></div></div><div class="input-row"><label for="search-words">\u0427\u0442\u043E \u0438\u0441\u043A\u0430\u0442\u044C</label><div class="input-wrapper"><input type="text" id="search-words"><div class="prompt">\u0421\u043B\u043E\u0432\u0430 \u0447\u0435\u0440\u0435\u0437 \u0437\u0430\u043F\u044F\u0442\u0443\u044E: \u043D\u0430\u0439\u0434\u0443\u0442\u0441\u044F \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438, \u0433\u0434\u0435 \u0432\u0441\u0442\u0440\u0435\u0447\u0430\u0435\u0442\u0441\u044F \u0445\u043E\u0442\u044F \u0431\u044B \u043E\u0434\u043D\u043E \u0438\u0437 \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u044B\u0445 \u0441\u043B\u043E\u0432. \u0421\u043B\u043E\u0432\u0430 \u0447\u0435\u0440\u0435\u0437 \u043F\u0440\u043E\u0431\u0435\u043B: \u043D\u0430\u0439\u0434\u0443\u0442\u0441\u044F \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438, \u0433\u0434\u0435 \u0432\u0441\u0442\u0440\u0435\u0447\u0430\u044E\u0442\u0441\u044F \u0432\u0441\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u044B\u0435 \u0441\u043B\u043E\u0432\u0430.</div><div class="check-block"><div class="checkbox"><input type="checkbox" id="do-not-show-date" checked><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="do-not-show-date">\u0422\u043E\u043B\u044C\u043A\u043E \u0432 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439</label></div></div></div><div class="input-row"><label for="exclude-words">\u0418\u0441\u043A\u043B\u044E\u0447\u0430\u0442\u044C \u0438\u0437 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</label><div class="input-wrapper"><input type="text" id="exclude-words"></div></div><!--]-->`);
}
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateSubscription/ProvidersAndKeywords.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["ssrRender", _sfc_ssrRender$5]]);
const _sfc_main$6 = {
  __name: "FieldsAndAreas",
  __ssrInlineRender: true,
  setup(__props) {
    const myChangeEvent = (event2) => {
      console.log("myChangeEvent: ", event2);
    };
    const mySelectEvent = (e) => {
      console.log("mySelectEvent: ", event);
    };
    const myOptions = [
      { id: 1, text: "apple" },
      { id: 2, text: "berry" },
      { id: 3, text: "cherry" }
    ];
    const myOptions2 = [
      { id: 1, text: "apple" },
      { id: 2, text: "berry" },
      { id: 3, text: "cherry" }
    ];
    const myValue = ref();
    const myValue2 = ref();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Select2 = resolveComponent("Select2");
      _push(`<!--[--><div class="input-row"><label for="industry">\u041E\u0442\u0440\u0430\u0441\u043B\u044C</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_Select2, {
        modelValue: unref(myValue),
        "onUpdate:modelValue": ($event) => isRef(myValue) ? myValue.value = $event : null,
        options: myOptions,
        settings: { multiple: true },
        onChange: ($event) => myChangeEvent($event),
        onSelect: ($event) => mySelectEvent()
      }, null, _parent));
      _push(`</div></div><div class="input-row"><label for="locations">\u0413\u043E\u0440\u043E\u0434\u0430, \u043E\u0431\u043B\u0430\u0441\u0442\u0438, \u0441\u0442\u0440\u0430\u043D\u044B</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_Select2, {
        modelValue: unref(myValue2),
        "onUpdate:modelValue": ($event) => isRef(myValue2) ? myValue2.value = $event : null,
        options: myOptions2,
        settings: { multiple: true },
        onChange: ($event) => myChangeEvent($event),
        onSelect: ($event) => mySelectEvent()
      }, null, _parent));
      _push(`</div></div><!--]-->`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateSubscription/FieldsAndAreas.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$6;
const _sfc_main$5 = {};
function _sfc_ssrRender$4(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="covid-vaccine">\u0412\u0430\u043A\u0446\u0438\u043D\u0430\u0446\u0438\u044F \u043E\u0442 COVID-19</label><div class="input-wrapper"><select class="d-select" name="covid-vaccine" id="covid-vaccine"><option value="1">\u0421\u0442\u0430\u0442\u0443\u0441 \u043F\u0440\u0438\u0432\u0438\u0442\u043E\u0433\u043E</option><option value="2">Another option</option><option value="3" disabled>A disabled option</option><option value="4">Potato</option></select></div></div>`);
}
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateSubscription/Vaccination.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["ssrRender", _sfc_ssrRender$4]]);
const _sfc_main$4 = {};
function _sfc_ssrRender$3(_ctx, _push, _parent, _attrs) {
  _push(`<!--[--><div class="input-row"><label for="income">\u041A\u0430\u043A\u043E\u0439 \u0434\u043E\u0445\u043E\u0434 \u0432\u044B \u0440\u0430\u0441\u0441\u043C\u0430\u0442\u0440\u0438\u0432\u0430\u0435\u0442\u0435 (\u20BD)?</label><div class="row-container"><div class="c2"><div class="input-wrapper"><input type="text" id="income"></div><div class="tbs-row"><ul><li><div class="tab-btn"><input type="radio" name="income" id="any" checked><div class="mask"><span>\u041B\u044E\u0431\u0430\u044F</span></div></div></li><li><div class="tab-btn"><input type="radio" name="income" id="month"><div class="mask"><span>\u041C\u0435\u0441\u044F\u0446</span></div></div></li><li><div class="tab-btn"><input type="radio" name="income" id="day"><div class="mask"><span>\u0414\u0435\u043D\u044C</span></div></div></li><li><div class="tab-btn"><input type="radio" name="income" id="hour"><div class="mask"><span>\u0427\u0430\u0441 </span></div></div></li></ul></div></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="show-no-salary" checked><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="show-no-salary">\u041D\u0435 \u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0442\u044C \u0431\u0435\u0437 \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u044B</label></div></div></div><div class="input-row"><label for="company">\u041A\u043E\u043C\u043F\u0430\u043D\u0438\u044F</label><div class="input-wrapper"><input type="text" id="company"></div></div><!--]-->`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateSubscription/JobSalaryAndCompany.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$3]]);
const _sfc_main$3 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  _push(`<!--[--><div class="input-row"><label>\u0417\u0430\u043D\u044F\u0442\u043E\u0441\u0442\u044C</label><div class="checkboxes-row input-row--checkboxes"><div class="check-block"><div class="checkbox"><input type="checkbox" id="full"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="full">\u041F\u043E\u043B\u043D\u0430\u044F</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="changeable"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="changeable">\u0421\u043C\u0435\u043D\u043D\u0430\u044F</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="incomplete-distance"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="incomplete-distance">\u041D\u0435\u043F\u043E\u043B\u043D\u0430\u044F \u0434\u0438\u0441\u0442\u0430\u043D\u0446\u0438\u043E\u043D\u043D\u0430\u044F</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="incomplete"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="incomplete">\u041D\u0435\u043F\u043E\u043B\u043D\u0430\u044F</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="rotational"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="rotational">\u0412\u0430\u0445\u0442\u043E\u0432\u0430\u044F</label></div></div></div><div class="input-row"><label for="remote-work">\u0423\u0434\u0430\u043B\u0435\u043D\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0442\u0430</label><div class="input-wrapper"><select class="d-select" name="remote-work" id="remote-work"><option data-display=""></option><option value="1">\u0421\u0442\u0430\u0442\u0443\u0441 \u043F\u0440\u0438\u0432\u0438\u0442\u043E\u0433\u043E</option><option value="2">Another option</option><option value="3" disabled>A disabled option</option><option value="4">Potato</option></select></div></div><div class="input-row input-row--checkboxes"><label>\u0422\u0438\u043F \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</label><div class="checkboxes-row input-row--checkboxes"><div class="check-block"><div class="checkbox"><input type="checkbox" id="video"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="video">\u0412\u0438\u0434\u0435\u043E\u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="no-experience"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="no-experience">\u041E\u043F\u044B\u0442 \u043D\u0435 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="not-requiring-higher-education"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="not-requiring-higher-education">\u041D\u0435 \u0442\u0440\u0435\u0431\u0443\u044E\u0449\u0438\u0435 \u0432\u044B\u0441\u0448\u0435\u0433\u043E \u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u044F</label></div></div></div><div class="input-row input-row--checkboxes"><label>\u041D\u0430\u043B\u0438\u0447\u0438\u0435 \u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0445 \u043F\u0440\u0430\u0432</label><div class="checkboxes-row"><div class="check-block"><div class="checkbox"><input type="checkbox" id="A"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="A">\u0410 - \u043C\u043E\u0442\u043E\u0446\u0438\u043A\u043B\u044B</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="B"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="B">\u0412 - \u043B\u0435\u0433\u043A\u043E\u0432\u044B\u0435 \u0430\u0432\u0442\u043E</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="C"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="C">\u0421 - \u0433\u0440\u0443\u0437\u043E\u0432\u044B\u0435 \u0430\u0432\u0442\u043E</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="D"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="D">D - \u0410\u0432\u0442\u043E\u0431\u0443\u0441\u044B</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="E"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="E">E - \u0410\u0432\u0442\u043E \u0441 \u043F\u0440\u0438\u0446\u0435\u043F\u043E\u043C</label></div></div></div><!--]-->`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateSubscription/JobEmploymentAndLicense.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$2]]);
const _sfc_main$2 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="lenguage">\u0412\u043B\u0430\u0434\u0435\u043D\u0438\u0435 \u0438\u043D\u043E\u0441\u0442\u0440\u0430\u043D\u043D\u044B\u043C\u0438 \u044F\u0437\u044B\u043A\u0430\u043C\u0438</label><div class="c2"><div class="input-wrapper"><select class="d-select" name="lenguage" id="lenguage"><option data-display="\u042F\u0437\u044B\u043A">\u042F\u0437\u044B\u043A</option><option value="1">\u0421\u0442\u0430\u0442\u0443\u0441 \u043F\u0440\u0438\u0432\u0438\u0442\u043E\u0433\u043E</option><option value="2">Another option</option><option value="3" disabled>A disabled option</option><option value="4">Potato</option></select></div><div class="input-wrapper"><select class="d-select" name="lenguage-level" id="lenguage-level"><option data-display="\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0432\u043B\u0430\u0434\u0435\u043D\u0438\u044F">\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0432\u043B\u0430\u0434\u0435\u043D\u0438\u044F</option><option value="1">\u0421\u0442\u0430\u0442\u0443\u0441 \u043F\u0440\u0438\u0432\u0438\u0442\u043E\u0433\u043E</option><option value="2">Another option</option><option value="3" disabled>A disabled option</option><option value="4">Potato</option></select></div></div></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateSubscription/ForeignLanguages.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row input-row--checkboxes" }, _attrs))}><label>\u041A\u0443\u0434\u0430 \u043F\u043E\u043B\u0443\u0447\u0430\u0442\u044C \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F</label><div class="checkboxes-row"><div class="check-block"><div class="checkbox"><input type="checkbox" id="push-notifications"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="push-notifications">Push-\u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="email-notofocations"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0)} alt="#"></div></div><label for="email-notofocations">E-mail \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F</label></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateSubscription/Notifications.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_7 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "create-subscription",
  __ssrInlineRender: true,
  setup(__props) {
    ref();
    ref();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0;
      const _component_CreateSubscriptionProvidersAndKeywords = __nuxt_component_1;
      const _component_CreateSubscriptionFieldsAndAreas = __nuxt_component_2;
      const _component_CreateSubscriptionVaccination = __nuxt_component_3;
      const _component_CreateSubscriptionJobSalaryAndCompany = __nuxt_component_4;
      const _component_CreateSubscriptionJobEmploymentAndLicense = __nuxt_component_5;
      const _component_CreateSubscriptionForeignLanguages = __nuxt_component_6;
      const _component_CreateSubscriptionNotifications = __nuxt_component_7;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet create-subscribe-page bg-wrapper",
        role: "main"
      }, _attrs))}><div class="bg-wrapper pt">`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="wrapper wrapper-1290"><form class="create-subscribe" action="" name="create-subscribe "><div class="w-box w-box--main w-box-subscribe"><div class="w-box-head"><h1 class="title">\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0438</h1><div class="descr">\u041F\u043E\u043B\u0443\u0447\u0430\u0439\u0442\u0435 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u043E \u043D\u043E\u0432\u044B\u0445 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044F\u0445 \u043F\u043E \u0441\u043E\u0437\u0434\u0430\u043D\u043D\u043E\u043C\u0443 \u0437\u0430\u043F\u0440\u043E\u0441\u0443</div></div><div class="w-box-body">`);
      _push(ssrRenderComponent(_component_CreateSubscriptionProvidersAndKeywords, null, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateSubscriptionFieldsAndAreas, null, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateSubscriptionVaccination, null, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateSubscriptionJobSalaryAndCompany, null, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateSubscriptionJobEmploymentAndLicense, null, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateSubscriptionForeignLanguages, null, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateSubscriptionNotifications, null, null, _parent));
      _push(`</div></div><div class="form-submit-container"><p>\u041D\u0430\u0439\u0434\u0435\u043D\u043E 2 012 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439</p><button class="button-accent" type="submit">\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C</button></div></form></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/create-subscription.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=create-subscription-BnMPWAwN.mjs.map
