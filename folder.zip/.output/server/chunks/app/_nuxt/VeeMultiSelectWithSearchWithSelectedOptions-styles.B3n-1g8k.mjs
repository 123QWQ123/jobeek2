import { V as VeeMultiSelectWithSearchWithSelectedOptions_vue_vue_type_style_index_0_lang } from './VeeMultiSelectWithSearchWithSelectedOptions-styles-1.mjs-D9Qj2nIm.mjs';

const VeeMultiSelectWithSearchWithSelectedOptionsStyles_B3n1g8k = [VeeMultiSelectWithSearchWithSelectedOptions_vue_vue_type_style_index_0_lang];

export { VeeMultiSelectWithSearchWithSelectedOptionsStyles_B3n1g8k as default };
//# sourceMappingURL=VeeMultiSelectWithSearchWithSelectedOptions-styles.B3n-1g8k.mjs.map
