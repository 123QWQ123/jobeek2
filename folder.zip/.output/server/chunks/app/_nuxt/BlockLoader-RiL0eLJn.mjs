import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const _sfc_main = {
  name: "PageLoader"
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "loading bg-dark bg-opacity-50 w-100 h-100 position-absolute d-flex align-items-center justify-content-center align-content-center" }, _attrs))} data-v-0b087cd0><div class="d-flex justify-content-center align-items-center" data-v-0b087cd0><div class="spinner-border text-primary" role="status" data-v-0b087cd0><span class="visually-hidden" data-v-0b087cd0>Loading...</span></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/BlockLoader.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-0b087cd0"]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=BlockLoader-RiL0eLJn.mjs.map
