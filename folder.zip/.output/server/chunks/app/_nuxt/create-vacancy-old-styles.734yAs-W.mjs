import { c as createVacancyOld_vue_vue_type_style_index_1_lang } from './create-vacancy-old-styles-2.mjs-CKJ3T12n.mjs';

const createVacancyOldStyles_734yAsW = [createVacancyOld_vue_vue_type_style_index_1_lang];

export { createVacancyOldStyles_734yAsW as default };
//# sourceMappingURL=create-vacancy-old-styles.734yAs-W.mjs.map
