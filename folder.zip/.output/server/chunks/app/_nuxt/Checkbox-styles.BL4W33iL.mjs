const Checkbox_vue_vue_type_style_index_0_scoped_0f2f834e_lang = ".checked .checkbox-mask img[data-v-0f2f834e]{opacity:1}.is_header label[data-v-0f2f834e]{font-weight:700}";

const CheckboxStyles_BL4W33iL = [Checkbox_vue_vue_type_style_index_0_scoped_0f2f834e_lang];

export { CheckboxStyles_BL4W33iL as default };
//# sourceMappingURL=Checkbox-styles.BL4W33iL.mjs.map
