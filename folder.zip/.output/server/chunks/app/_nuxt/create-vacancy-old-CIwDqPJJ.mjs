import { _ as __nuxt_component_0$a } from './SearchMobile-WfXJ1gHL.mjs';
import { useSSRContext, reactive, computed, ref, mergeProps, unref, watch, resolveDirective, withAsyncContext, watchEffect, isRef } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderClass, ssrGetDirectiveProps, ssrInterpolate, ssrRenderStyle, ssrRenderList, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseEqual, ssrLooseContain } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1, b as _imports_2 } from './sb-_CyfLtbf.mjs';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { u as useHead, l as useVacancyStore, s as storeToRefs } from '../server.mjs';
import { u as useSort } from './useSort-Dy_x39w5.mjs';
import { C as CustomSelect } from './search-CNCM2ROA.mjs';
import { u as useCurrencyOptions } from './useCurrencyOptions-BsifIVKS.mjs';
import { _ as _imports_0$1 } from './check-BGWLIG1L.mjs';
import { _ as __nuxt_component_1$4 } from './useQueryParams-Bpl0Cf82.mjs';
import { u as useFormData } from './useFormData-CRA6LhaU.mjs';
import { u as useWatchStateValues } from './useWatchStateValues-DimKH74z.mjs';
import crypto from 'crypto';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './state-D1MfAAni.mjs';

const rnds8Pool = new Uint8Array(256); // # of random values to pre-allocate

let poolPtr = rnds8Pool.length;
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    crypto.randomFillSync(rnds8Pool);
    poolPtr = 0;
  }

  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */

const byteToHex = [];

for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).slice(1));
}

function unsafeStringify(arr, offset = 0) {
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  return byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]];
}

const native = {
  randomUUID: crypto.randomUUID
};

function v4(options, buf, offset) {
  if (native.randomUUID && !buf && !options) {
    return native.randomUUID();
  }

  options = options || {};
  const rnds = options.random || (options.rng || rng)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    offset = offset || 0;

    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }

    return buf;
  }

  return unsafeStringify(rnds);
}

const _sfc_main$I = {
  __name: "Providers",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: false,
      default: {}
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    var _a;
    const emit = __emit;
    const props = __props;
    useDictionaryStore();
    const resetObject = {
      superjob: false,
      hh: false
    };
    const selectedProviders = ref((_a = props.modelValue) != null ? _a : resetObject);
    watch(() => selectedProviders.value, (newSelectedItems) => {
      emit("update:modelValue", newSelectedItems);
    });
    computed(() => props.errors);
    const isHHEnabled = computed(() => selectedProviders.value.hh);
    const isSuperjobEnabled = computed(() => selectedProviders.value.superjob);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "carryover-box border-3" }, _attrs))} data-v-2c852ab4><div class="carryover-box-label" data-v-2c852ab4>\u0415\u0441\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442 \u043D\u0430 HH \u0438\u043B\u0438 SuperJob? \u041C\u043E\u0436\u0435\u0442\u0435 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043E\u0442 \u0441\u0443\u0434\u0430!</div><div class="import-grid" data-v-2c852ab4><div class="${ssrRenderClass([{ "import-is-complete": unref(isHHEnabled) }, "import-box"])}" data-v-2c852ab4><div class="import-box-dvnld" data-v-2c852ab4><div class="logo" data-v-2c852ab4><img${ssrRenderAttr("src", _imports_0)} alt="#" data-v-2c852ab4><div class="check" data-v-2c852ab4><img${ssrRenderAttr("src", _imports_1)} alt="#" data-v-2c852ab4></div></div><span data-v-2c852ab4>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 HeadHunters.ru</span></div><div class="import-complete" data-v-2c852ab4><div class="logo logo-fake" data-v-2c852ab4></div><span data-v-2c852ab4>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 HeadHunters.ru</span><button class="close" type="button" data-v-2c852ab4><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-2c852ab4><path d="M18.9951 4.99512L5.00586 18.9843" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-2c852ab4></path><path d="M19.0009 18.9928L5 4.98901" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-2c852ab4></path></svg></button></div></div><div class="${ssrRenderClass([{ "import-is-complete": unref(isSuperjobEnabled) }, "import-box"])}" data-v-2c852ab4><div class="import-box-dvnld" data-v-2c852ab4><div class="logo" data-v-2c852ab4><img${ssrRenderAttr("src", _imports_2)} alt="#" data-v-2c852ab4><div class="check" data-v-2c852ab4><img${ssrRenderAttr("src", _imports_1)} alt="#" data-v-2c852ab4></div></div><span data-v-2c852ab4>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 Superjob.ru </span></div><div class="import-complete" data-v-2c852ab4><div class="logo logo-fake" data-v-2c852ab4></div><span data-v-2c852ab4>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 Superjob.ru</span><button class="close" type="button" data-v-2c852ab4><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-2c852ab4><path d="M18.9951 4.99512L5.00586 18.9843" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-2c852ab4></path><path d="M19.0009 18.9928L5 4.98901" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-2c852ab4></path></svg></button></div></div></div></div>`);
    };
  }
};
const _sfc_setup$I = _sfc_main$I.setup;
_sfc_main$I.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Providers.vue");
  return _sfc_setup$I ? _sfc_setup$I(props, ctx) : void 0;
};
const __nuxt_component_1$3 = /* @__PURE__ */ _export_sfc(_sfc_main$I, [["__scopeId", "data-v-2c852ab4"]]);
const _sfc_main$H = {
  __name: "Name",
  __ssrInlineRender: true,
  props: ["is_valid"],
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const isValid = computed(() => props.is_valid);
    const keywords = ref();
    watch(keywords, (newValue) => {
      emit("set", "name", newValue);
    });
    useVacancyStore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="name">\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435</label><div class="input-wrapper"><input type="text" id="name"${ssrRenderAttr("value", unref(keywords))}><div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(isValid) }, "text-danger"])}"> \u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439 </div></div></div>`);
    };
  }
};
const _sfc_setup$H = _sfc_main$H.setup;
_sfc_main$H.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Name.vue");
  return _sfc_setup$H ? _sfc_setup$H(props, ctx) : void 0;
};
const __nuxt_component_0$9 = _sfc_main$H;
const __default__$1 = {
  name: "MultiSelectWithSearch"
};
const _sfc_main$G = /* @__PURE__ */ Object.assign(__default__$1, {
  __ssrInlineRender: true,
  props: {
    options: {
      required: true
    },
    label: {
      required: false
    },
    listStyles: {
      required: false
    },
    listItemStyles: {
      required: false
    },
    modelValue: {
      required: true
    },
    sort_by: {
      required: false,
      default: "asc"
    },
    disabled: {
      required: false,
      default: false
    },
    hide_selection: {
      required: false,
      default: false
    }
  },
  emits: ["change", "update:modelValue", "input", "unselect"],
  setup(__props, { emit: __emit }) {
    var _a, _b;
    const props = __props;
    const hide_selection = props.hide_selection;
    const isOpen = ref(false);
    const options = ref(props.options);
    const { sort } = useSort();
    watch(props, (newProps) => {
      options.value = sort(newProps.options, { by: "alpha" });
      if (newProps.modelValue) {
        selectedOptions.value = newProps.modelValue;
      }
    });
    ref();
    const selectedOptions = ref((_a = props.modelValue) != null ? _a : []);
    const disabled = ref((_b = props.disabled) != null ? _b : false);
    const searchInput = ref("");
    const labelOrSearchInput = computed(() => {
      return isOpen.value ? searchInput.value : props.label;
    });
    function getSelectedOptionName(value) {
      const selectedOptionItem = props.options.find(
        (item) => String(item.value) === String(value)
      );
      if (selectedOptionItem)
        return selectedOptionItem.name;
      else
        return "Not found";
    }
    function close() {
      isOpen.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "multi-select_wrapper" }, _attrs))} data-v-06d53309><div${ssrRenderAttrs(mergeProps({
        onfocusout: "close",
        class: ["select2-container select2-container--default select2-container--below select2-container--focus nice-select n-select d-select", { open: unref(isOpen), disabled: unref(disabled) }],
        tabindex: "0"
      }, ssrGetDirectiveProps(_ctx, _directive_click_outside, close)))} data-v-06d53309><span class="current" contenteditable="true" data-v-06d53309>${ssrInterpolate(unref(labelOrSearchInput))}</span><ul class="list" style="${ssrRenderStyle(__props.listStyles)}" data-v-06d53309><!--[-->`);
      ssrRenderList(unref(options), (item) => {
        _push(`<li${ssrRenderAttr("data-value", item.value)} class="option" style="${ssrRenderStyle(__props.listItemStyles)}" data-v-06d53309>${ssrInterpolate(item.name)}</li>`);
      });
      _push(`<!--]--></ul></div>`);
      if (!unref(hide_selection) && unref(selectedOptions).length) {
        _push(`<div class="selection selected-options" data-v-06d53309><ul class="selected-options" id="select2--container" data-v-06d53309><!--[-->`);
        ssrRenderList(unref(selectedOptions), (item) => {
          _push(`<li class="multi-select_selected-item" data-v-06d53309><button type="button" class="select2-selection__choice__remove" data-v-06d53309><span aria-hidden="true" data-v-06d53309>\xD7</span></button><span class="select2-selection__choice__display" data-v-06d53309>${ssrInterpolate(getSelectedOptionName(item))}</span></li>`);
        });
        _push(`<!--]--></ul></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$G = _sfc_main$G.setup;
_sfc_main$G.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/MultiSelectWithSearch.vue");
  return _sfc_setup$G ? _sfc_setup$G(props, ctx) : void 0;
};
const __nuxt_component_0$8 = /* @__PURE__ */ _export_sfc(_sfc_main$G, [["__scopeId", "data-v-06d53309"]]);
const _sfc_main$F = {
  __name: "Fields",
  __ssrInlineRender: true,
  props: ["is_valid"],
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const isValid = computed(() => props.is_valid);
    const fields = reactive([]);
    reactive([]);
    const fieldText = ref("");
    const onFieldChange = (text) => {
      fieldText.value = text;
      industries.value = vacancyStore.industries;
    };
    const vacancyStore = useVacancyStore();
    const industries = ref();
    const industryOptions = ref([]);
    watch(
      () => industries.value,
      (newValues) => {
        industryOptions.value = newValues.filter((item) => item.title.includes(fieldText.value)).map((item) => {
          return { value: item.id, name: item.title };
        });
      }
    );
    const areaOptions = ref([]);
    watch(
      () => vacancyStore.areas,
      (newValues) => {
        areaOptions.value = newValues.map((item) => {
          return { value: item.city_id, name: (item == null ? void 0 : item.c_name) + "," + (item == null ? void 0 : item.r_name) + "," + (item == null ? void 0 : item.city_name) };
        });
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_MultiSelectWithSearch = __nuxt_component_0$8;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="industry">\u041E\u0442\u0440\u0430\u0441\u043B\u044C</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_MultiSelectWithSearch, {
        options: unref(industryOptions),
        onInput: onFieldChange,
        modelValue: unref(fields),
        "onUpdate:modelValue": [($event) => isRef(fields) ? fields.value = $event : null, ($event) => emit("set", "specializations", unref(fields))]
      }, null, _parent));
      _push(`<div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(isValid) }, "text-danger"])}"> \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438 </div></div></div>`);
    };
  }
};
const _sfc_setup$F = _sfc_main$F.setup;
_sfc_main$F.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Fields.vue");
  return _sfc_setup$F ? _sfc_setup$F(props, ctx) : void 0;
};
const __nuxt_component_1$2 = _sfc_main$F;
const _sfc_main$E = {
  __name: "Areas",
  __ssrInlineRender: true,
  props: ["is_valid"],
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const isValid = computed(() => props.is_valid);
    const areas = reactive([]);
    const vacancyStore = useVacancyStore();
    const { getIndustries, countries, getAreas } = vacancyStore;
    ref();
    const areaOptions = ref([]);
    watch(
      () => vacancyStore.areas,
      (newValues) => {
        areaOptions.value = newValues.map((item) => {
          return { value: item.city_id, name: (item == null ? void 0 : item.c_name) + "," + (item == null ? void 0 : item.r_name) + "," + (item == null ? void 0 : item.city_name) };
        });
      }
    );
    const onAreaChange = (text) => {
      if (text.length >= 2) {
        getAreas({ search: text });
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_MultiSelectWithSearch = __nuxt_component_0$8;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="locations">\u0413\u043E\u0440\u043E\u0434\u0430, \u043E\u0431\u043B\u0430\u0441\u0442\u0438, \u0441\u0442\u0440\u0430\u043D\u044B()</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_MultiSelectWithSearch, {
        modelValue: unref(areas),
        "onUpdate:modelValue": [($event) => isRef(areas) ? areas.value = $event : null, ($event) => emit("set", "areas", unref(areas))],
        options: unref(areaOptions),
        onInput: onAreaChange
      }, null, _parent));
      _push(`<div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(isValid) }, "text-danger"])}"> \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0433\u043E\u0440\u043E\u0434 </div></div></div>`);
    };
  }
};
const _sfc_setup$E = _sfc_main$E.setup;
_sfc_main$E.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Areas.vue");
  return _sfc_setup$E ? _sfc_setup$E(props, ctx) : void 0;
};
const __nuxt_component_2$3 = _sfc_main$E;
const _sfc_main$D = {
  __name: "JobSalary",
  __ssrInlineRender: true,
  emits: ["set"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const emit = __emit;
    const currencyOptions = ref(useCurrencyOptions());
    const salary = reactive({
      to: {
        val: null,
        isChecked: false,
        isValid: false
      },
      from: {
        val: null,
        isChecked: false,
        isValid: false
      },
      currency: {
        val: "RUB",
        isChecked: false,
        isValid: false
      }
    });
    const validate = () => {
      salary.from.isChecked = true;
      console.log(parseInt(salary.from.val));
      if (parseInt(salary.from.val) > 0) {
        salary.from.isValid = true;
      } else {
        salary.from.isValid = false;
      }
      salary.to.isChecked = true;
      if (salary.to.val == "" || parseInt(salary.to.val) > parseInt(salary.from.val)) {
        salary.to.isValid = true;
      } else {
        salary.to.isValid = false;
      }
      salary.currency.isChecked = true;
      if (currencyOptions.value.includes(salary.currency.val)) {
        salary.currency.isValid = true;
      } else {
        salary.currency.isValid = false;
      }
      emit("set", "salary", { from: salary.from.val, to: salary.to.val, currency: salary.currency.val });
    };
    watch(salary, validate);
    __expose({ validate });
    const skyBlueBG = {
      background: "#F5F8FA"
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="income">\u041A\u0430\u043A\u043E\u0439 \u0417\u041F \u0432\u044B \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0438\u0442\u0435 (\u20BD)?</label><div class="row-container"><div class="c3"><div class="input-wrapper w-auto"><input id="salary_from" type="number"${ssrRenderAttr("value", unref(salary).from.val)} placeholder="\u041E\u0442"><div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(salary).from.isValid && unref(salary).from.isChecked }, "text-danger"])}"> \u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0441\u0442\u0430\u0440\u0442\u043E\u0432\u0443\u044E \u0432\u0438\u043B\u043A\u0443 </div></div><div class="input-wrapper w-auto"><input id="salary_to" type="number"${ssrRenderAttr("value", unref(salary).to.val)} placeholder="\u0414\u043E"><div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(salary).to.isValid && unref(salary).to.isChecked }, "text-danger"])}"> \u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 \u0447\u0435\u043C \u043E\u0442 </div></div><div class="input-wrapper ms-auto">`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        class: "skyBlueBG",
        options: unref(currencyOptions),
        style: skyBlueBG,
        modelValue: unref(salary).currency.val,
        "onUpdate:modelValue": ($event) => unref(salary).currency.val = $event
      }, null, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup$D = _sfc_main$D.setup;
_sfc_main$D.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/JobSalary.vue");
  return _sfc_setup$D ? _sfc_setup$D(props, ctx) : void 0;
};
const __nuxt_component_3$3 = _sfc_main$D;
const _sfc_main$C = {
  __name: "ContactsPhonesItem",
  __ssrInlineRender: true,
  props: {
    isNew: {
      required: false,
      default: false
    },
    index: {
      required: false,
      default: false
    },
    phone: {
      required: true,
      default: null
    },
    comment: {
      required: true,
      default: ""
    }
  },
  emits: ["add", "delete", "update"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    ref(props.isNew);
    const phone = ref(props.phone);
    const comment = ref(props.comment);
    const isShown = ref(true);
    const close = () => isShown.value = false;
    watch(() => phone.value, (newPhone) => {
      if (newPhone) {
        emit("update", props.index, { phone: newPhone, comment: comment.value });
      }
    });
    watch(() => comment.value, (newComment) => {
      if (newComment && phone.value) {
        emit("update", props.index, { phone: phone.value, comment: newComment });
      }
    });
    ref();
    ref(null);
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "accordion-item" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, close)))} data-v-0521d25c><h2 class="accordion-header position-relative" id="headingOne" data-v-0521d25c><button type="button" class="${ssrRenderClass([{ collapsed: unref(isShown) }, "accordion-button"])}" data-v-0521d25c><div class="input-wrapper me-2" data-v-0521d25c><input type="phone" placeholder="+71651651131" data-v-0521d25c></div></button><span class="position-absolute absoluted_icon" data-v-0521d25c><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" data-v-0521d25c><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-0521d25c></path></svg></span></h2><div id="collapseOne" class="${ssrRenderClass([{ show: unref(isShown) }, "accordion-collapse collapse"])}" data-v-0521d25c><div class="accordion-body" data-v-0521d25c><div class="input-wrapper" data-v-0521d25c><textarea type="text" class="form-control" placeholder="\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0301\u0440\u0438\u044F" data-v-0521d25c>${ssrInterpolate(unref(comment))}</textarea></div></div></div></div>`);
    };
  }
};
const _sfc_setup$C = _sfc_main$C.setup;
_sfc_main$C.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/ContactsPhonesItem.vue");
  return _sfc_setup$C ? _sfc_setup$C(props, ctx) : void 0;
};
const __nuxt_component_0$7 = /* @__PURE__ */ _export_sfc(_sfc_main$C, [["__scopeId", "data-v-0521d25c"]]);
const _sfc_main$B = {
  __name: "ContactsPhones",
  __ssrInlineRender: true,
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const selectedPhones = ref([{ phone: null, comment: null }]);
    ref(0);
    const updateItem = (index, newItem) => {
      selectedPhones.value[index] = newItem;
    };
    const deleteItem = (index) => {
      const newItems = selectedPhones.value.filter((item, key) => key !== index);
      selectedPhones.value = newItems;
    };
    watch(selectedPhones.value, (newValues) => {
      emit("update:modelValue", selectedPhones.value);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyOldContactsPhonesItem = __nuxt_component_0$7;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "right" }, _attrs))}>`);
      if (unref(selectedPhones).length) {
        _push(`<div class="accordion mb-2"><!--[-->`);
        ssrRenderList(unref(selectedPhones), (item, index) => {
          _push(ssrRenderComponent(_component_CreateVacancyOldContactsPhonesItem, {
            item,
            key: index,
            index,
            phone: item.phone,
            comment: item.comment,
            onUpdate: updateItem,
            onDelete: deleteItem
          }, null, _parent));
        });
        _push(`<!--]--></div>`);
      } else if (unref(selectedPhones).length === 0) {
        _push(`<button class="btn btn-primary">\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C</button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(selectedPhones).length !== 0) {
        _push(`<button class="btn btn-primary">\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435</button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$B = _sfc_main$B.setup;
_sfc_main$B.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/ContactsPhones.vue");
  return _sfc_setup$B ? _sfc_setup$B(props, ctx) : void 0;
};
const __nuxt_component_0$6 = _sfc_main$B;
const _sfc_main$A = {
  __name: "Contacts",
  __ssrInlineRender: true,
  props: ["is_valid"],
  emits: ["set"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const emit = __emit;
    const props = __props;
    computed(() => props.is_valid);
    const contacts = reactive({
      email: {
        val: "",
        isChecked: false,
        isValid: false
      },
      name: {
        val: "",
        isChecked: false,
        isValid: false
      },
      phones: {
        val: [],
        isChecked: false,
        isValid: false
      }
      // isValid: isValid
    });
    const validate = () => {
      contacts.name.isChecked = true;
      if (contacts.name.val.length > 0) {
        contacts.name.isValid = true;
      } else {
        contacts.name.isValid = false;
      }
      contacts.email.isChecked = true;
      if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(contacts.email.val)) {
        contacts.name.isValid = true;
      } else {
        contacts.name.isValid = false;
      }
      contacts.phones.isChecked = true;
      if (contacts.phones.val.length >= 0) {
        contacts.phones.isValid = true;
      } else {
        contacts.phones.isValid = false;
      }
      console.log(contacts.name.val);
      emit("set", "contacts", { name: contacts.name.val, email: contacts.email.val });
    };
    watch(() => contacts.name.val, (newValue) => {
      reset("name");
    });
    watch(() => contacts.email.val, (newValue) => {
      reset("email");
    });
    const reset = (prop) => {
      contacts[prop].isValid = true;
    };
    __expose({ validate });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyOldContactsPhones = __nuxt_component_0$6;
      _push(`<!--[--><div class="input-row"><label for="remote-work">\u041A\u043E\u043D\u0442\u0430\u043A\u0442\u044B</label><div class="c2"><div class="input-wrapper"><input type="text"${ssrRenderAttr("value", unref(contacts).name.val)} placeholder="\u0418\u043C\u044F"><div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(contacts).name.isValid && unref(contacts).name.isChecked }, "text-danger"])}"> \u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0438\u043C\u044F </div></div><div class="input-wrapper"><input type="email"${ssrRenderAttr("value", unref(contacts).email.val)} placeholder="Email"><div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(contacts).email.isValid && unref(contacts).email.isChecked }, "text-danger"])}"> \u0412\u0432\u0435\u0434\u0438\u0442\u0435 Email </div></div></div></div><div class="input-row"><label for="remote-work"></label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldContactsPhones, {
        modelValue: unref(contacts).phones,
        "onUpdate:modelValue": ($event) => unref(contacts).phones = $event
      }, null, _parent));
      _push(`</div></div><!--]-->`);
    };
  }
};
const _sfc_setup$A = _sfc_main$A.setup;
_sfc_main$A.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Contacts.vue");
  return _sfc_setup$A ? _sfc_setup$A(props, ctx) : void 0;
};
const __nuxt_component_4$3 = _sfc_main$A;
const _sfc_main$z = {
  __name: "JobEmployment",
  __ssrInlineRender: true,
  props: ["is_valid"],
  emits: ["set"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const emit = __emit;
    const props = __props;
    const isValid = computed(() => props.is_valid);
    useVacancyStore();
    const dictionaryStore = useDictionaryStore();
    const { getWorkTypes } = useDictionaryStore();
    const workTypesOptions = computed(() => dictionaryStore.work_types);
    [__temp, __restore] = withAsyncContext(() => getWorkTypes()), await __temp, __restore();
    console.log(workTypesOptions.value);
    const employment = ref(null);
    watch(employment, (newValues) => {
      emit("set", "employment", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))} data-v-06f5998e><label data-v-06f5998e>\u0422\u0438\u043F \u0437\u0430\u043D\u044F\u0442\u043E\u0441\u0442\u0438</label><div class="checkboxes-row input-row--checkboxes job_employment_types" data-v-06f5998e><!--[-->`);
      ssrRenderList(unref(workTypesOptions), (item) => {
        _push(`<div class="check-block" data-v-06f5998e><div class="checkbox" data-v-06f5998e><input${ssrIncludeBooleanAttr(ssrLooseEqual(unref(employment), item.id)) ? " checked" : ""} type="radio"${ssrRenderAttr("id", item.name)}${ssrRenderAttr("value", item.id)} name="work_type" data-v-06f5998e><div class="checkbox-mask" data-v-06f5998e></div></div><label${ssrRenderAttr("for", item.name)} data-v-06f5998e>${ssrInterpolate(item.name)}</label></div>`);
      });
      _push(`<!--]--></div><div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(isValid) }, "text-danger"])}" data-v-06f5998e> \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 </div></div>`);
    };
  }
};
const _sfc_setup$z = _sfc_main$z.setup;
_sfc_main$z.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/JobEmployment.vue");
  return _sfc_setup$z ? _sfc_setup$z(props, ctx) : void 0;
};
const __nuxt_component_5$2 = /* @__PURE__ */ _export_sfc(_sfc_main$z, [["__scopeId", "data-v-06f5998e"]]);
const _sfc_main$y = {
  __name: "Education",
  __ssrInlineRender: true,
  props: ["is_valid"],
  emits: ["set"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const emit = __emit;
    const props = __props;
    const isValid = computed(() => props.is_valid);
    useVacancyStore();
    const dictionaryStore = useDictionaryStore();
    const { getEducations } = dictionaryStore;
    [__temp, __restore] = withAsyncContext(() => getEducations()), await __temp, __restore();
    const educationOptions = computed(() => dictionaryStore.educations.map((item) => ({ value: item.id, name: item.name })));
    const education = ref(54);
    watch(education, (newValues) => {
      emit("set", "education", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        options: unref(educationOptions),
        modelValue: unref(education),
        "onUpdate:modelValue": ($event) => isRef(education) ? education.value = $event : null
      }, null, _parent));
      _push(`<div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(isValid) }, "text-danger"])}"> \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 </div></div></div>`);
    };
  }
};
const _sfc_setup$y = _sfc_main$y.setup;
_sfc_main$y.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Education.vue");
  return _sfc_setup$y ? _sfc_setup$y(props, ctx) : void 0;
};
const __nuxt_component_6$2 = _sfc_main$y;
const _sfc_main$x = {
  __name: "Gender",
  __ssrInlineRender: true,
  props: ["is_valid"],
  emits: ["set"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const emit = __emit;
    const props = __props;
    const isValid = computed(() => props.is_valid);
    const vacancyStore = useVacancyStore();
    const { getGenders } = useDictionaryStore();
    const { genders } = storeToRefs(vacancyStore);
    [__temp, __restore] = withAsyncContext(() => getGenders()), await __temp, __restore();
    const genderOptions = computed(() => genders == null ? void 0 : genders.value.map((item) => ({ value: item.id, name: item.name })));
    const gender = ref(12);
    watch(gender, (newValues) => {
      emit("set", "gender", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u041F\u043E\u043B</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        options: unref(genderOptions),
        modelValue: unref(gender),
        "onUpdate:modelValue": ($event) => isRef(gender) ? gender.value = $event : null
      }, null, _parent));
      _push(`<div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(isValid) }, "text-danger"])}"> \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 </div></div></div>`);
    };
  }
};
const _sfc_setup$x = _sfc_main$x.setup;
_sfc_main$x.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Gender.vue");
  return _sfc_setup$x ? _sfc_setup$x(props, ctx) : void 0;
};
const __nuxt_component_7$1 = _sfc_main$x;
const _sfc_main$w = {
  __name: "MaritalStatus",
  __ssrInlineRender: true,
  props: ["is_valid"],
  emits: ["set"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const emit = __emit;
    const props = __props;
    const isValid = computed(() => props.is_valid);
    const dictionaryStore = useDictionaryStore();
    const { getMaritalStatus } = dictionaryStore;
    const { marital_statuses } = storeToRefs(dictionaryStore);
    [__temp, __restore] = withAsyncContext(() => getMaritalStatus()), await __temp, __restore();
    const maritalStatusOptions = computed(() => marital_statuses.value.map((item) => ({ value: item.id, name: item.name })));
    const marital_status = ref(18);
    watch(marital_status, (newValues) => {
      emit("set", "marital_status", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u0421\u0435\u043C\u0435\u0439\u043D\u043E\u0435 \u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        options: unref(maritalStatusOptions),
        modelValue: unref(marital_status),
        "onUpdate:modelValue": ($event) => isRef(marital_status) ? marital_status.value = $event : null
      }, null, _parent));
      _push(`<div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(isValid) }, "text-danger"])}"> \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 </div></div></div>`);
    };
  }
};
const _sfc_setup$w = _sfc_main$w.setup;
_sfc_main$w.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/MaritalStatus.vue");
  return _sfc_setup$w ? _sfc_setup$w(props, ctx) : void 0;
};
const __nuxt_component_8$1 = _sfc_main$w;
const _sfc_main$v = {
  __name: "Step01",
  __ssrInlineRender: true,
  props: ["providers"],
  emits: ["set", "next"],
  setup(__props, { emit: __emit }) {
    var _a, _b;
    const props = __props;
    const jobSalary = ref();
    const contacts = ref();
    const state = reactive({
      providers: {
        val: {
          hh: (_a = props.providers.hh.is_connected) != null ? _a : false,
          superjob: (_b = props.providers.superjob.is_connected) != null ? _b : false
        },
        type: "object",
        is_valid: true,
        check: (prop, value, state2) => {
          console.log(value.hh, value.superjob);
          if (value.hh === true || value.superjob === true)
            return true;
          else
            return false;
        },
        is_required: true,
        min: 1
      },
      name: {
        val: "",
        type: "string",
        check: (prop, value, state2) => {
          console.log(prop, value, state2);
          console.log(value.length);
          return value.length >= state2[prop].min;
        },
        is_valid: true,
        is_required: true,
        min: 1
      },
      specializations: {
        val: [],
        type: "array",
        is_valid: true,
        is_required: false
      },
      areas: {
        val: [],
        type: "array",
        is_valid: true,
        is_required: false
      },
      salary: {
        val: {},
        type: "object",
        is_valid: false,
        is_required: true,
        component: jobSalary,
        check: (prop, value, state2) => {
          return state2[prop].component.validate();
        }
      },
      contacts: {
        val: {},
        type: "object",
        is_valid: true,
        is_required: true,
        component: contacts,
        check: (prop, value, state2) => {
          return state2[prop].component.validate();
        }
      },
      employment: {
        val: null,
        type: "number",
        is_valid: true,
        is_required: false
      },
      education: {
        val: null,
        type: "number",
        is_valid: true,
        is_required: false
      },
      gender: {
        val: null,
        type: "number",
        is_valid: true,
        is_required: false
      },
      marital_status: {
        val: null,
        type: "number",
        is_valid: true,
        is_required: false
      },
      is_checked: true
    });
    const updateState = (prop, value) => {
      state[prop].val = value;
      reset(prop);
    };
    const reset = (name) => {
      console.log(name);
      state[name].is_valid = true;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyOldName = __nuxt_component_0$9;
      const _component_CreateVacancyOldFields = __nuxt_component_1$2;
      const _component_CreateVacancyOldAreas = __nuxt_component_2$3;
      const _component_CreateVacancyOldJobSalary = __nuxt_component_3$3;
      const _component_CreateVacancyOldContacts = __nuxt_component_4$3;
      const _component_CreateVacancyOldJobEmployment = __nuxt_component_5$2;
      const _component_CreateVacancyOldEducation = __nuxt_component_6$2;
      const _component_CreateVacancyOldGender = __nuxt_component_7$1;
      const _component_CreateVacancyOldMaritalStatus = __nuxt_component_8$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "step" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldName, {
        is_valid: unref(state).name.is_valid,
        onSet: updateState
      }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldFields, {
        is_valid: unref(state).specializations.is_valid,
        onSet: updateState
      }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldAreas, {
        is_valid: unref(state).areas.is_valid,
        onSet: updateState
      }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldJobSalary, {
        is_valid: unref(state).salary.is_valid,
        onSet: updateState,
        ref_key: "jobSalary",
        ref: jobSalary
      }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldContacts, {
        ref_key: "contacts",
        ref: contacts,
        is_valid: unref(state).contacts.is_valid,
        onSet: updateState
      }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldJobEmployment, {
        is_valid: unref(state).employment.is_valid,
        onSet: updateState
      }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldEducation, {
        is_valid: unref(state).education.is_valid,
        onSet: updateState
      }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldGender, {
        is_valid: unref(state).education.is_valid,
        onSet: updateState
      }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldMaritalStatus, {
        is_valid: unref(state).education.is_valid,
        onSet: updateState
      }, null, _parent));
      _push(`<div class="sep"></div><div class="w-box-foot"><div class="form-footer d-flex"><button type="button" id="nextBtn">\u0414\u0430\u043B\u0435\u0435</button></div></div></div>`);
    };
  }
};
const _sfc_setup$v = _sfc_main$v.setup;
_sfc_main$v.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Step01.vue");
  return _sfc_setup$v ? _sfc_setup$v(props, ctx) : void 0;
};
const __nuxt_component_2$2 = _sfc_main$v;
const _sfc_main$u = {
  __name: "Children",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: false,
      default: 15
    }
  },
  emits: ["set"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const emit = __emit;
    const dictionaryStore = useDictionaryStore();
    const { getChildren } = dictionaryStore;
    [__temp, __restore] = withAsyncContext(() => getChildren()), await __temp, __restore();
    const childrenOptions = computed(() => dictionaryStore.children.map((item) => ({ value: item.id, name: item.name })));
    console.log(childrenOptions);
    const children = ref(15);
    watch(children, (newValues) => {
      emit("set", "children", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u0414\u0435\u0442\u0438</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        options: unref(childrenOptions),
        modelValue: unref(children),
        "onUpdate:modelValue": ($event) => isRef(children) ? children.value = $event : null
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$u = _sfc_main$u.setup;
_sfc_main$u.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Children.vue");
  return _sfc_setup$u ? _sfc_setup$u(props, ctx) : void 0;
};
const __nuxt_component_0$5 = _sfc_main$u;
const __default__ = {
  name: "CustomRadio"
};
const _sfc_main$t = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: ["options", "modelValue", "listStyles"],
  emits: ["change", "update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const options = computed(() => props.options);
    const current = ref(props.modelValue);
    watch(
      current,
      (newValue) => {
        emit("update:modelValue", newValue);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "d-flex flex-column flex-lg-row justify-content-between align-content-center gap-2" }, _attrs))} data-v-426c409e><!--[-->`);
      ssrRenderList(unref(options), (item) => {
        _push(`<label class="${ssrRenderClass([{ "active": unref(current) === item.value }, "radio-label form-control"])}" data-v-426c409e><input class="hidden" type="radio"${ssrRenderAttr("value", item.value)}${ssrIncludeBooleanAttr(ssrLooseEqual(unref(current), item.value)) ? " checked" : ""} data-v-426c409e> ${ssrInterpolate(item.name)}</label>`);
      });
      _push(`<!--]--></div>`);
    };
  }
});
const _sfc_setup$t = _sfc_main$t.setup;
_sfc_main$t.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/CustomRadio.vue");
  return _sfc_setup$t ? _sfc_setup$t(props, ctx) : void 0;
};
const __nuxt_component_0$4 = /* @__PURE__ */ _export_sfc(_sfc_main$t, [["__scopeId", "data-v-426c409e"]]);
const _sfc_main$s = {
  __name: "Experience2",
  __ssrInlineRender: true,
  emits: ["set"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const emit = __emit;
    const dictionaryStore = useDictionaryStore();
    const { getExperiences } = dictionaryStore;
    const { experiences } = storeToRefs(dictionaryStore);
    [__temp, __restore] = withAsyncContext(() => getExperiences()), await __temp, __restore();
    const experienceOptions = computed(() => experiences.value.map((item) => ({ value: item.id, name: item.name })));
    const experience = ref(76);
    watch(experience, (newValues) => {
      emit("set", "experience", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomRadio = __nuxt_component_0$4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u041E\u043F\u044B\u0442 \u0440\u0430\u0431\u043E\u0442\u044B(${ssrInterpolate(unref(experience))})</label>`);
      _push(ssrRenderComponent(_component_CustomRadio, {
        options: unref(experienceOptions),
        modelValue: unref(experience),
        "onUpdate:modelValue": ($event) => isRef(experience) ? experience.value = $event : null
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$s = _sfc_main$s.setup;
_sfc_main$s.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Experience2.vue");
  return _sfc_setup$s ? _sfc_setup$s(props, ctx) : void 0;
};
const __nuxt_component_1$1 = _sfc_main$s;
const _sfc_main$r = {
  __name: "PlaceOfWork",
  __ssrInlineRender: true,
  emits: ["set"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const emit = __emit;
    const dictionaryStore = useDictionaryStore();
    const { getPlaceOfWorks } = dictionaryStore;
    const { place_of_works } = storeToRefs(dictionaryStore);
    [__temp, __restore] = withAsyncContext(() => getPlaceOfWorks()), await __temp, __restore();
    const formatOptions = computed(() => place_of_works.value.map((item) => ({ value: item.id, name: item.name })));
    const place_of_work = ref(21);
    watch(place_of_work, (newValues) => {
      emit("set", "place_of_work", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomRadio = __nuxt_component_0$4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u0424\u043E\u0440\u043C\u0430\u0442 \u0440\u0430\u0431\u043E\u0442\u044B(${ssrInterpolate(unref(place_of_work))})</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_CustomRadio, {
        options: unref(formatOptions),
        modelValue: unref(place_of_work),
        "onUpdate:modelValue": ($event) => isRef(place_of_work) ? place_of_work.value = $event : null
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$r = _sfc_main$r.setup;
_sfc_main$r.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/PlaceOfWork.vue");
  return _sfc_setup$r ? _sfc_setup$r(props, ctx) : void 0;
};
const __nuxt_component_2$1 = _sfc_main$r;
const _sfc_main$q = {
  __name: "Licenses",
  __ssrInlineRender: true,
  emits: ["set"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const dictionaryStore = useDictionaryStore();
    const { getDriverLicenses } = dictionaryStore;
    const { driver_licenses } = storeToRefs(dictionaryStore);
    [__temp, __restore] = withAsyncContext(() => getDriverLicenses()), await __temp, __restore();
    ref([]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row input-row--checkboxes" }, _attrs))}><label>\u041D\u0430\u043B\u0438\u0447\u0438\u0435 \u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0445 \u043F\u0440\u0430\u0432</label><div class="checkboxes-row"><!--[-->`);
      ssrRenderList(unref(driver_licenses), (item) => {
        _push(`<div class="check-block"><div class="checkbox"><input type="checkbox"${ssrRenderAttr("id", item.id)}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label${ssrRenderAttr("for", item.id)}>${ssrInterpolate(item.name)}</label></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup$q = _sfc_main$q.setup;
_sfc_main$q.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Licenses.vue");
  return _sfc_setup$q ? _sfc_setup$q(props, ctx) : void 0;
};
const __nuxt_component_3$2 = _sfc_main$q;
const _sfc_main$p = {
  __name: "SkillsForm",
  __ssrInlineRender: true,
  props: {
    isNew: {
      required: false,
      default: true
    },
    skill: {
      required: true
    },
    id: {
      required: true
    }
  },
  emits: ["add", "delete", "update"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const isNew = ref(props.isNew);
    const skill = ref(props.skill);
    watchEffect(() => {
      skill.value = props.skill;
      isNew.value = props.isNew;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row" }, _attrs))} data-v-4009e766><div class="col-10" data-v-4009e766><div class="input-wrapper" data-v-4009e766><input type="text"${ssrRenderAttr("value", unref(skill))} data-v-4009e766></div></div><div class="col-2" data-v-4009e766><div class="input-wrapper" data-v-4009e766>`);
      if (props.isNew) {
        _push(`<button class="btn btn-primary" type="button" data-v-4009e766>\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C</button>`);
      } else {
        _push(`<button class="btn btn-primary" type="button" data-v-4009e766>\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C</button>`);
      }
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$p = _sfc_main$p.setup;
_sfc_main$p.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/Skills/SkillsForm.vue");
  return _sfc_setup$p ? _sfc_setup$p(props, ctx) : void 0;
};
const __nuxt_component_0$3 = /* @__PURE__ */ _export_sfc(_sfc_main$p, [["__scopeId", "data-v-4009e766"]]);
const _sfc_main$o = {
  __name: "Skills",
  __ssrInlineRender: true,
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    useDictionaryStore();
    const selectedSkills = ref([null]);
    const currentSkillId = ref(null);
    const currentSkill = ref(null);
    const isNew = computed(() => {
      if (currentSkill.value) {
        return false;
      }
      return true;
    });
    const computedSelectedSkills = computed(() => {
      return selectedSkills.value.filter((item) => item);
    });
    const addItem = (newItem) => {
      console.log(newItem);
      const newItems = selectedSkills.value.filter((item) => item);
      newItems.push(newItem);
      newItems.push(null);
      selectedSkills.value = newItems;
    };
    const updateItem = (id, newItem) => {
      console.log(newItem);
      const newItems = selectedSkills.value.map((item, index) => {
        if (index === id) {
          return newItem;
        }
        return item;
      });
      selectedSkills.value = newItems;
      currentSkillId.value = null;
      currentSkill.value = null;
    };
    const deleteItem = (deleteItem2) => {
      const newItems = selectedSkills.value.filter((item) => item !== deleteItem2);
      selectedSkills.value = newItems;
    };
    watch(selectedSkills, (newValues) => {
      emit("set", "key_skills", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancySkillsForm = __nuxt_component_0$3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))} data-v-6255a5e1><div class="left" data-v-6255a5e1><label for="lenguage" data-v-6255a5e1>\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043D\u0430\u0432\u044B\u043A\u0438</label></div><div class="right" data-v-6255a5e1>`);
      if (unref(selectedSkills).length) {
        _push(ssrRenderComponent(_component_CreateVacancySkillsForm, {
          "is-new": unref(isNew),
          id: unref(currentSkillId),
          skill: unref(currentSkill),
          onAdd: addItem,
          onUpdate: updateItem,
          onDelete: deleteItem
        }, null, _parent));
      } else {
        _push(`<button class="btn btn-primary" data-v-6255a5e1>\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C</button>`);
      }
      if (unref(computedSelectedSkills).length > 0) {
        _push(`<div class="selection selected-options" data-v-6255a5e1><ul class="selected-options" id="select2--container" data-v-6255a5e1><!--[-->`);
        ssrRenderList(unref(computedSelectedSkills), (item, index) => {
          _push(`<li class="multi-select_selected-item" data-v-6255a5e1><button type="button" class="select2-selection__choice__remove" data-v-6255a5e1><span aria-hidden="true" data-v-6255a5e1>\xD7</span></button><span class="select2-selection__choice__display" data-v-6255a5e1>${ssrInterpolate(item)}</span></li>`);
        });
        _push(`<!--]--></ul></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$o = _sfc_main$o.setup;
_sfc_main$o.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Skills.vue");
  return _sfc_setup$o ? _sfc_setup$o(props, ctx) : void 0;
};
const __nuxt_component_4$2 = /* @__PURE__ */ _export_sfc(_sfc_main$o, [["__scopeId", "data-v-6255a5e1"]]);
const _sfc_main$n = {
  __name: "Age",
  __ssrInlineRender: true,
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    useVacancyStore();
    const age = reactive({});
    watch(age, (newValues) => {
      emit("set", "age_from", newValues.from);
      emit("set", "age_to", newValues.to);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u0412\u043E\u0437\u0440\u0430\u0441\u0442\u044C</label><div class="input-wrapper"><div class="c2"><input type="number"${ssrRenderAttr("value", unref(age).from)} placeholder="\u041E\u0442"><input type="number"${ssrRenderAttr("value", unref(age).to)} placeholder="\u0414\u043E"></div></div></div>`);
    };
  }
};
const _sfc_setup$n = _sfc_main$n.setup;
_sfc_main$n.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Age.vue");
  return _sfc_setup$n ? _sfc_setup$n(props, ctx) : void 0;
};
const __nuxt_component_5$1 = _sfc_main$n;
const _sfc_main$m = {
  __name: "Item",
  __ssrInlineRender: true,
  props: {
    isNew: {
      required: false,
      default: false
    },
    id: {
      required: true,
      default: null
    },
    language_id: {
      required: true,
      default: null
    },
    level_id: {
      required: true,
      default: null
    },
    errors: {
      required: true,
      default: {}
    }
  },
  emits: ["delete", "update"],
  setup(__props, { emit: __emit }) {
    const dictionaryStore = useDictionaryStore();
    const emit = __emit;
    const props = __props;
    const state = reactive({
      id: {
        val: props.id,
        isValid: true
      },
      language_id: {
        val: props.language_id,
        isValid: true
      },
      level_id: {
        val: props.level_id,
        isValid: true
      }
    });
    ref(props.isNew);
    const languageOptions = computed(() => {
      return dictionaryStore.foreign_languages.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const languageLevelOptions = computed(() => {
      return dictionaryStore.resume_language_levels.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const save = () => {
      emit("update", props.id, useFormData(state));
    };
    watch(() => state.language_id.val, save);
    watch(() => state.level_id.val, save);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SelectWithSearch = __nuxt_component_1$4;
      const _component_CustomSelect = CustomSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row position-relative" }, _attrs))} data-v-90b65a1e><span class="position-absolute absoluted_icon" data-v-90b65a1e><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" data-v-90b65a1e><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-90b65a1e></path></svg></span><div class="col-12" data-v-90b65a1e><div class="c2 w-100" data-v-90b65a1e><div class="input-wrapper" data-v-90b65a1e>`);
      _push(ssrRenderComponent(_component_SelectWithSearch, {
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u044F\u0437\u044B\u043A",
        options: unref(languageOptions),
        modelValue: unref(state).language_id.val,
        "onUpdate:modelValue": ($event) => unref(state).language_id.val = $event,
        modelModifiers: { number: true }
      }, null, _parent));
      if (__props.errors.language_id) {
        _push(`<div class="text-danger d-block" data-v-90b65a1e>${ssrInterpolate(__props.errors.language_id)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="input-wrapper" data-v-90b65a1e>`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        label: "\u0423\u0440\u043E\u0432\u0435\u043D",
        options: unref(languageLevelOptions),
        modelValue: unref(state).level_id.val,
        "onUpdate:modelValue": ($event) => unref(state).level_id.val = $event,
        modelModifiers: { number: true }
      }, null, _parent));
      if (__props.errors.level_id) {
        _push(`<div class="text-danger d-block" data-v-90b65a1e>${ssrInterpolate(__props.errors.level_id)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup$m = _sfc_main$m.setup;
_sfc_main$m.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/ForeignLanguages/Item.vue");
  return _sfc_setup$m ? _sfc_setup$m(props, ctx) : void 0;
};
const __nuxt_component_0$2 = /* @__PURE__ */ _export_sfc(_sfc_main$m, [["__scopeId", "data-v-90b65a1e"]]);
const _sfc_main$l = {
  __name: "Wrapper",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: []
    },
    errors: {
      default: []
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    var _a;
    const emit = __emit;
    const props = __props;
    useDictionaryStore();
    let items = [];
    if (props.modelValue && props.modelValue.length) {
      items = props.modelValue.map((item) => {
        return {
          ...item,
          id: v4()
        };
      });
    }
    const selectedItems = ref(items);
    const errors = ref((_a = props.errors) != null ? _a : []);
    watch(() => props.errors, (newData) => {
      console.log(newData);
      const newItems = selectedItems.value;
      selectedItems.value.map((item, index) => {
        newData == null ? void 0 : newData.map((error, errorIndex) => {
          if (errorIndex === index) {
            if (!newItems[index]) {
              newItems[index] = {};
            }
            if (!newItems[index].errors) {
              newItems[index].errors = {};
            }
            Object.keys(error).map((errorKey) => {
              newItems[index].errors[errorKey] = error[errorKey];
            });
          }
        });
      });
      errors.value = newItems;
    });
    const updateItem = (id, newItem) => {
      const oldItems = [...selectedItems.value];
      const newItems = oldItems.map((item) => {
        if (item.id === id) {
          return newItem;
        }
        return item;
      });
      selectedItems.value = newItems;
    };
    const deleteItem = (deleteItem2) => {
      const newItems = selectedItems.value.filter((item) => item.id !== deleteItem2);
      selectedItems.value = newItems;
    };
    watch(() => useWatchStateValues(selectedItems.value, true, true), (newData) => {
      emit("update:modelValue", selectedItems.value);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeForeignLanguagesItem = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "" }, _attrs))} data-v-34140026>`);
      if (unref(selectedItems).length) {
        _push(`<div class="" data-v-34140026><!--[-->`);
        ssrRenderList(unref(selectedItems), (item) => {
          _push(ssrRenderComponent(_component_CreateResumeForeignLanguagesItem, {
            class: "w-100 language_margin",
            item,
            key: item.id,
            id: item.id,
            language_id: item.language_id,
            level_id: item.level_id,
            errors: item.errors,
            onUpdate: updateItem,
            onDelete: deleteItem
          }, null, _parent));
        });
        _push(`<!--]--></div>`);
      } else if (unref(selectedItems).length === 0) {
        _push(`<button type="button" class="btn btn-primary mt-2" data-v-34140026>\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C</button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(selectedItems).length !== 0) {
        _push(`<button type="button" class="btn btn-primary mt-2" data-v-34140026>\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435</button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$l = _sfc_main$l.setup;
_sfc_main$l.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SharedComponents/ForeignLanguages/Wrapper.vue");
  return _sfc_setup$l ? _sfc_setup$l(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$l, [["__scopeId", "data-v-34140026"]]);
const _sfc_main$k = {
  __name: "ForeignLanguages",
  __ssrInlineRender: true,
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    useDictionaryStore();
    const selectedLanguages = ref([]);
    watch(selectedLanguages, (newValues) => {
      emit("set", "languages", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SharedComponentsForeignLanguagesWrapper = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><div class="left"><label>\u0412\u043B\u0430\u0434\u0435\u043D\u0438\u0435 \u0438\u043D\u043E\u0441\u0442\u0440\u0430\u043D\u043D\u044B\u043C\u0438 \u044F\u0437\u044B\u043A\u0430\u043C\u0438</label></div><div class="right">`);
      _push(ssrRenderComponent(_component_SharedComponentsForeignLanguagesWrapper, {
        modelValue: unref(selectedLanguages),
        "onUpdate:modelValue": ($event) => isRef(selectedLanguages) ? selectedLanguages.value = $event : null
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$k = _sfc_main$k.setup;
_sfc_main$k.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/ForeignLanguages.vue");
  return _sfc_setup$k ? _sfc_setup$k(props, ctx) : void 0;
};
const __nuxt_component_6$1 = _sfc_main$k;
const _sfc_main$j = {
  __name: "Step02",
  __ssrInlineRender: true,
  emits: ["set", "prev"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const emit = __emit;
    const vacancyStore = useVacancyStore();
    const { getVacancyBillingTypes } = useDictionaryStore();
    const { vacancy_billing_types } = storeToRefs(vacancyStore);
    [__temp, __restore] = withAsyncContext(() => getVacancyBillingTypes()), await __temp, __restore();
    computed(() => vacancy_billing_types.value.map((item) => ({ value: item.id, name: item.name })));
    const vacancy_billing_type = ref(50);
    watch(vacancy_billing_type, (newValues) => {
      emit("set", "billing_type", newValues);
    });
    const updateState = (name, value) => emit("set", name, value);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyOldChildren = __nuxt_component_0$5;
      const _component_CreateVacancyOldExperience2 = __nuxt_component_1$1;
      const _component_CreateVacancyOldPlaceOfWork = __nuxt_component_2$1;
      const _component_CreateVacancyOldLicenses = __nuxt_component_3$2;
      const _component_CreateVacancyOldSkills = __nuxt_component_4$2;
      const _component_CreateVacancyOldAge = __nuxt_component_5$1;
      const _component_CreateVacancyOldForeignLanguages = __nuxt_component_6$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "step d-block" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldChildren, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldExperience2, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldPlaceOfWork, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldLicenses, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldSkills, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldAge, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldForeignLanguages, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div><div class="w-box-foot"><div class="form-footer d-flex"><button type="button" id="prevBtn">\u041D\u0430\u0437\u0430\u0434</button><button type="button" id="nextBtn">\u0414\u0430\u043B\u0435\u0435</button></div></div></div>`);
    };
  }
};
const _sfc_setup$j = _sfc_main$j.setup;
_sfc_main$j.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Step02.vue");
  return _sfc_setup$j ? _sfc_setup$j(props, ctx) : void 0;
};
const __nuxt_component_3$1 = _sfc_main$j;
const _sfc_main$i = {
  __name: "FirmName",
  __ssrInlineRender: true,
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    useVacancyStore();
    const firm_name = ref("");
    watch(firm_name, (newValues) => {
      emit("set", "firm_name", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438</label><div class="input-wrapper"><input class="form-control" placeholder="\u0425\u043E\u043B\u0434\u0438\u043D\u0433 LLC"${ssrRenderAttr("value", unref(firm_name))}></div></div>`);
    };
  }
};
const _sfc_setup$i = _sfc_main$i.setup;
_sfc_main$i.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/FirmName.vue");
  return _sfc_setup$i ? _sfc_setup$i(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$i;
const _sfc_main$h = {
  __name: "FirmActivity",
  __ssrInlineRender: true,
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    useVacancyStore();
    const firm_activity = ref("");
    watch(firm_activity, (newValues) => {
      console.log(newValues);
      emit("set", "firm_activity", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u0414\u0435\u044F\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0444\u0438\u0440\u043C\u044B</label><div class="input-wrapper"><input class="form-control" placeholder="It Products"${ssrRenderAttr("value", unref(firm_activity))}></div></div>`);
    };
  }
};
const _sfc_setup$h = _sfc_main$h.setup;
_sfc_main$h.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/FirmActivity.vue");
  return _sfc_setup$h ? _sfc_setup$h(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$h;
const _sfc_main$g = {
  __name: "Description",
  __ssrInlineRender: true,
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    useVacancyStore();
    const description = ref("");
    watch(description, (newValues) => {
      emit("set", "description", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435</label><div class="input-wrapper"><textarea class="form-control" rows="4">${ssrInterpolate(unref(description))}</textarea></div></div>`);
    };
  }
};
const _sfc_setup$g = _sfc_main$g.setup;
_sfc_main$g.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Description.vue");
  return _sfc_setup$g ? _sfc_setup$g(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$g;
const _sfc_main$f = {
  __name: "AcceptKids",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: true
    }
  },
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const value = ref(props.modelValue);
    watch(value, (newValues) => {
      emit("set", "accept_kids", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "check-block" }, _attrs))}><div class="checkbox"><input type="checkbox" id="accept_kids"${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="accept_kids">\u0423\u043A\u0430\u0437\u0430\u043D\u0438\u0435, \u0447\u0442\u043E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044F \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0434\u043B\u044F \u0441\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u0435\u0439 \u0441\u0442\u0430\u0440\u0448\u0435 14 \u043B\u0435\u0442</label></div>`);
    };
  }
};
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/HH/AcceptKids.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$f;
const _sfc_main$e = {
  __name: "AcceptTemporary",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: true
    }
  },
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const value = ref(props.modelValue);
    watch(value, (newValues) => {
      emit("set", "accept_temporary", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "check-block" }, _attrs))}><div class="checkbox"><input type="checkbox" id="accept_temporary"${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="accept_temporary">\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0435 \u0442\u0440\u0443\u0434\u043E\u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E. \u0443\u043A\u0430\u0437\u0430\u043D\u0438\u0435, \u0447\u0442\u043E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044F \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0441 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u043C \u0442\u0440\u0443\u0434\u043E\u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E\u043C</label></div>`);
    };
  }
};
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/HH/AcceptTemporary.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const __nuxt_component_4$1 = _sfc_main$e;
const _sfc_main$d = {
  __name: "AcceptIncompleteResumes",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: true
    }
  },
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const value = ref(props.modelValue);
    watch(value, (newValues) => {
      emit("set", "accept_incomplete_resumes", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "check-block" }, _attrs))}><div class="checkbox"><input type="checkbox" id="accept_incomplete_resumes"${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="accept_incomplete_resumes">\u041D\u0435\u043F\u043E\u043B\u043D\u043E\u0435 \u0440\u0435\u0437\u044E\u043C\u0435. \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D \u043B\u0438 \u043E\u0442\u043A\u043B\u0438\u043A \u043D\u0430 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E \u043D\u0435\u043F\u043E\u043B\u043D\u044B\u043C \u0440\u0435\u0437\u044E\u043C\u0435</label></div>`);
    };
  }
};
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/HH/AcceptIncompleteResumes.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$d;
const _sfc_main$c = {
  __name: "AcceptHandicapped",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: true
    }
  },
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const value = ref(props.modelValue);
    watch(value, (newValues) => {
      emit("set", "accept_handicapped", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "check-block" }, _attrs))}><div class="checkbox"><input type="checkbox" id="accept_handicapped"${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="accept_handicapped">\u0421\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u044C \u0441 \u0438\u043D\u0432\u0430\u043B\u0438\u0434\u043D\u043E\u0441\u0442\u044C\u044E. \u0423\u043A\u0430\u0437\u0430\u043D\u0438\u0435, \u0447\u0442\u043E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044F \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0434\u043B\u044F \u0441\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u0435\u0439 \u0441 \u0438\u043D\u0432\u0430\u043B\u0438\u0434\u043D\u043E\u0441\u0442\u044C\u044E</label></div>`);
    };
  }
};
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/HH/AcceptHandicapped.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$c;
const _sfc_main$b = {
  __name: "AllowMessages",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: true
    }
  },
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const value = ref(props.modelValue);
    watch(value, (newValues) => {
      emit("set", "allow_messages", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "check-block" }, _attrs))}><div class="checkbox"><input type="checkbox" id="allow_messages"${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="allow_messages">\u0420\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439. \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u044C \u043F\u0435\u0440\u0435\u043F\u0438\u0441\u043A\u0438 \u0441 \u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442\u0430\u043C\u0438 \u043F\u043E \u0434\u0430\u043D\u043D\u043E\u0439 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</label></div>`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/HH/AllowMessages.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main$b;
const _sfc_main$a = {
  __name: "ResponseNotifcation",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: true
    }
  },
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const value = ref(props.modelValue);
    watch(value, (newValues) => {
      emit("set", "response_notifications", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "check-block" }, _attrs))}><div class="checkbox"><input type="checkbox" id="response_notification"${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="response_notification">\u0423\u0432\u0435\u0434\u043E\u043C\u043B\u044F\u0442\u044C \u043B\u0438 \u043C\u0435\u043D\u0435\u0434\u0436\u0435\u0440\u0430 \u043E \u043D\u043E\u0432\u044B\u0445 \u043E\u0442\u043A\u043B\u0438\u043A\u0430\u0445</label></div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/HH/ResponseNotifcation.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_8 = _sfc_main$a;
const _sfc_main$9 = {
  __name: "WithZP",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: false
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const value = ref(props.modelValue);
    watch(value, (newValues) => {
      emit("update:modelValue", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "check-block" }, _attrs))}><div class="checkbox"><input type="checkbox" id="with_zp"${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="with_zp">\u0412\u0430\u0448\u0443 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E \u0443\u0432\u0438\u0434\u044F\u0442 \u0431\u043E\u043B\u044C\u0448\u0435 \u043B\u044E\u0434\u0435\u0439. \u041C\u044B \u0440\u0430\u0437\u043C\u0435\u0441\u0442\u0438\u043C \u0435\u0435 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043D\u0430 \u0441\u0435\u0440\u0432\u0438\u0441\u0435 \u0417\u0430\u0440\u043F\u043B\u0430\u0442\u0430.\u0440\u0443</label></div>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/HH/WithZP.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_9 = _sfc_main$9;
const _sfc_main$8 = {
  __name: "WorkinDays",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: false
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const value = ref(props.modelValue);
    watch(value, (newValues) => {
      if (newValues === true) {
        emit("update:modelValue", 26);
      } else {
        emit("update:modelValue", null);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "check-block" }, _attrs))}><div class="checkbox"><input type="checkbox" id="working_in_days"${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="working_in_days">\u0420\u0430\u0431\u043E\u0442\u0430 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E \u0441\u0431 \u0438 \u0432\u0441</label></div>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/HH/WorkinDays.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_10 = _sfc_main$8;
const _sfc_main$7 = {
  __name: "WorkinTimeIntervals",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: false
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const value = ref(props.modelValue);
    watch(value, (newValues) => {
      if (newValues === true) {
        emit("update:modelValue", 25);
      } else {
        emit("update:modelValue", null);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "check-block" }, _attrs))}><div class="checkbox"><input type="checkbox" id="working_in_time_intervals"${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="working_in_time_intervals">\u041C\u043E\u0436\u043D\u043E \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0441\u043C\u0435\u043D\u0430\u043C\u0438 \u043F\u043E 4\u20136 \u0447\u0430\u0441\u043E\u0432 \u0432 \u0434\u0435\u043D\u044C</label></div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/HH/WorkinTimeIntervals.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_11 = _sfc_main$7;
const _sfc_main$6 = {
  __name: "WorkinTimeModes",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: false
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const value = ref(props.modelValue);
    watch(value, (newValues) => {
      if (newValues === true) {
        emit("update:modelValue", 25);
      } else {
        emit("update:modelValue", null);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "check-block" }, _attrs))}><div class="checkbox"><input type="checkbox" id="working_in_time_modes"${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), null) : unref(value)) ? " checked" : ""}><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="working_in_time_modes">\u041C\u043E\u0436\u043D\u043E \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u043F\u043E\u0441\u043B\u0435 16:00</label></div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/HH/WorkinTimeModes.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_12 = _sfc_main$6;
const _sfc_main$5 = {
  __name: "ResponseUrl",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true,
      default: null
    }
  },
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const value = ref(props.modelValue);
    watch(value, (newValues) => {
      emit("set", "response_url", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><div class="left"><label for="remote-work"> URL \u043E\u0442\u043A\u043B\u0438\u043A\u0430 \u0434\u043B\u044F \u043F\u0440\u044F\u043C\u044B\u0445 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439 </label></div><div class="right"><input class="form-control" type="text"${ssrRenderAttr("value", unref(value))}></div></div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/HH/ResponseUrl.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_13 = _sfc_main$5;
const _sfc_main$4 = {
  __name: "Vacancytype",
  __ssrInlineRender: true,
  emits: ["set"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const emit = __emit;
    const dictionaryStore = useDictionaryStore();
    const { getVacancyTypes } = dictionaryStore;
    const { vacancy_types } = storeToRefs(dictionaryStore);
    [__temp, __restore] = withAsyncContext(() => getVacancyTypes()), await __temp, __restore();
    const vacancyTypeOptions = computed(() => vacancy_types.value.map((item) => ({ value: item.id, name: item.name })));
    const vacancy_type = ref(46);
    watch(vacancy_type, (newValues) => {
      emit("set", "vacancy_type", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u0422\u0438\u043F \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        options: unref(vacancyTypeOptions),
        modelValue: unref(vacancy_type),
        "onUpdate:modelValue": ($event) => isRef(vacancy_type) ? vacancy_type.value = $event : null
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Vacancytype.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_14 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "BillingType",
  __ssrInlineRender: true,
  emits: ["set"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const emit = __emit;
    const dictionaryStore = useDictionaryStore();
    const { getVacancyBillingTypes } = dictionaryStore;
    const { vacancy_billing_types } = storeToRefs(dictionaryStore);
    [__temp, __restore] = withAsyncContext(() => getVacancyBillingTypes()), await __temp, __restore();
    const vacancyTypeOptions = computed(() => vacancy_billing_types.value.map((item) => ({ value: item.id, name: item.name })));
    const vacancy_billing_type = ref(50);
    watch(vacancy_billing_type, (newValues) => {
      emit("set", "billing_type", newValues);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label for="remote-work">\u0422\u0438\u043F \u043E\u043F\u043B\u0430\u0442\u044B(\u0442\u0430\u0440\u0438\u0444)</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        options: unref(vacancyTypeOptions),
        modelValue: unref(vacancy_billing_type),
        "onUpdate:modelValue": ($event) => isRef(vacancy_billing_type) ? vacancy_billing_type.value = $event : null
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/BillingType.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_15 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "Notifications",
  __ssrInlineRender: true,
  emits: ["set"],
  setup(__props, { emit: __emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row input-row--checkboxes" }, _attrs))}><label>\u041A\u0443\u0434\u0430 \u043F\u043E\u043B\u0443\u0447\u0430\u0442\u044C \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F</label><div class="checkboxes-row"><div class="check-block"><div class="checkbox"><input type="checkbox" id="push-notifications"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="push-notifications">Push-\u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F</label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="email-notofocations"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div></div><label for="email-notofocations">E-mail \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F</label></div></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Notifications.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_16 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "Step03",
  __ssrInlineRender: true,
  emits: ["set", "prev"],
  async setup(__props, { emit: __emit }) {
    let __temp, __restore;
    const emit = __emit;
    const dictionaryStore = useDictionaryStore();
    const { getVacancyBillingTypes } = dictionaryStore;
    const { vacancy_billing_types } = storeToRefs(dictionaryStore);
    [__temp, __restore] = withAsyncContext(() => getVacancyBillingTypes()), await __temp, __restore();
    computed(() => vacancy_billing_types.value.map((item) => ({ value: item.id, name: item.name })));
    const hhState = reactive({});
    const vacancy_billing_type = ref(50);
    watch(vacancy_billing_type, (newValues) => {
      emit("set", "billing_type", newValues);
    });
    const updateState = (name, value) => emit("set", name, value);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyOldFirmName = __nuxt_component_0;
      const _component_CreateVacancyOldFirmActivity = __nuxt_component_1;
      const _component_CreateVacancyOldDescription = __nuxt_component_2;
      const _component_CreateVacancyOldHHAcceptKids = __nuxt_component_3;
      const _component_CreateVacancyOldHHAcceptTemporary = __nuxt_component_4$1;
      const _component_CreateVacancyOldHHAcceptIncompleteResumes = __nuxt_component_5;
      const _component_CreateVacancyOldHHAcceptHandicapped = __nuxt_component_6;
      const _component_CreateVacancyOldHHAllowMessages = __nuxt_component_7;
      const _component_CreateVacancyOldHHResponseNotifcation = __nuxt_component_8;
      const _component_CreateVacancyOldHHWithZP = __nuxt_component_9;
      const _component_CreateVacancyOldHHWorkinDays = __nuxt_component_10;
      const _component_CreateVacancyOldHHWorkinTimeIntervals = __nuxt_component_11;
      const _component_CreateVacancyOldHHWorkinTimeModes = __nuxt_component_12;
      const _component_CreateVacancyOldHHResponseUrl = __nuxt_component_13;
      const _component_CreateVacancyOldVacancytype = __nuxt_component_14;
      const _component_CreateVacancyOldBillingType = __nuxt_component_15;
      const _component_CreateVacancyOldNotifications = __nuxt_component_16;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "step step3 pb-3" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldFirmName, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldFirmActivity, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldDescription, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div><div class="c2"><div class="input-wrapper--flex">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldHHAcceptKids, {
        modelValue: unref(hhState).accept_kids,
        "onUpdate:modelValue": ($event) => unref(hhState).accept_kids = $event
      }, null, _parent));
      _push(`</div><div class="input-wrapper--flex">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldHHAcceptTemporary, {
        modelValue: unref(hhState).accept_temporary,
        "onUpdate:modelValue": ($event) => unref(hhState).accept_temporary = $event
      }, null, _parent));
      _push(`</div></div><div class="sep"></div><div class="c2"><div class="input-wrapper--flex">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldHHAcceptIncompleteResumes, {
        modelValue: unref(hhState).accept_incomplete_resumes,
        "onUpdate:modelValue": ($event) => unref(hhState).accept_incomplete_resumes = $event
      }, null, _parent));
      _push(`</div><div class="input-wrapper--flex">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldHHAcceptHandicapped, {
        modelValue: unref(hhState).accept_handicapped,
        "onUpdate:modelValue": ($event) => unref(hhState).accept_handicapped = $event
      }, null, _parent));
      _push(`</div></div><div class="sep"></div><div class="c2"><div class="input-wrapper--flex">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldHHAllowMessages, {
        modelValue: unref(hhState).allow_messages,
        "onUpdate:modelValue": ($event) => unref(hhState).allow_messages = $event
      }, null, _parent));
      _push(`</div><div class="input-wrapper--flex">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldHHResponseNotifcation, {
        modelValue: unref(hhState).response_notification,
        "onUpdate:modelValue": ($event) => unref(hhState).response_notification = $event
      }, null, _parent));
      _push(`</div></div><div class="sep"></div><div class="c2"><div class="input-wrapper--flex">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldHHWithZP, {
        modelValue: unref(hhState).with_zp,
        "onUpdate:modelValue": ($event) => unref(hhState).with_zp = $event
      }, null, _parent));
      _push(`</div><div class="input-wrapper--flex">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldHHWorkinDays, {
        modelValue: unref(hhState).working_days,
        "onUpdate:modelValue": ($event) => unref(hhState).working_days = $event
      }, null, _parent));
      _push(`</div></div><div class="sep"></div><div class="c2"><div class="input-wrapper--flex">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldHHWorkinTimeIntervals, {
        modelValue: unref(hhState).working_time_intervals,
        "onUpdate:modelValue": ($event) => unref(hhState).working_time_intervals = $event
      }, null, _parent));
      _push(`</div><div class="input-wrapper--flex">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldHHWorkinTimeModes, {
        modelValue: unref(hhState).working_time_modes,
        "onUpdate:modelValue": ($event) => unref(hhState).working_time_modes = $event
      }, null, _parent));
      _push(`</div></div><div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldHHResponseUrl, {
        modelValue: unref(hhState).response_url,
        "onUpdate:modelValue": ($event) => unref(hhState).response_url = $event
      }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldVacancytype, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldBillingType, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyOldNotifications, { onSet: updateState }, null, _parent));
      _push(`<div class="sep"></div><div class="w-box-foot"><div class="form-footer d-flex"><button type="button" id="prevBtn">\u041D\u0430\u0437\u0430\u0434</button></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancyOld/Step03.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main$1;
const _sfc_main = {
  __name: "create-vacancy-old",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 - Jobeek"
    });
    const providers = reactive({
      hh: {
        is_connected: true,
        is_valid: true,
        is_checked: true
      },
      superjob: {
        is_connected: false,
        is_valid: false,
        is_checked: false
      }
    });
    reactive({
      accept_kids: false,
      accept_temporary: false,
      accept_incomplete_resumes: false,
      accept_handicapped: false,
      allow_messages: false,
      response_notification: false,
      response_url: "",
      with_zp: false,
      working_days: null,
      working_time_intervals: null,
      working_time_modes: null
    });
    reactive({
      accept_kids: true,
      accept_temporary: true
    });
    const state = reactive({
      providers: {
        val: {
          hh: true,
          superjob: true
        },
        isValid: true
      },
      name: "",
      specializations: [],
      areas: [],
      salary: {},
      contacts: [],
      employment: null,
      education: null,
      gender: null,
      marital_status: null,
      children: [],
      experience: null,
      place_of_work: null,
      vacancy_type: null,
      billing_type: null,
      driver_license_types: null,
      work_type: null,
      key_skills: null,
      age_from: null,
      age_to: null,
      firm_name: "",
      firm_activity: "",
      description: "",
      schedule: ""
    });
    const updateState = (prop, value) => {
      console.log(prop, value);
      state[prop] = value;
    };
    useVacancyStore();
    const isFirstStep = computed(() => currentStep.value === "first");
    const isSecondStep = computed(() => currentStep.value === "second");
    const isThirdStep = computed(() => currentStep.value === "third");
    const currentStep = ref("first");
    const goToPrevStep = () => {
      console.log(2);
      let newStep = currentStep.value;
      if (currentStep.value === "third") {
        newStep = "second";
      }
      if (currentStep.value === "second") {
        newStep = "first";
      }
      currentStep.value = newStep;
    };
    const goToNextStep = () => {
      console.log(currentStep.value);
      let newStep = currentStep.value;
      if (currentStep.value === "second") {
        newStep = "third";
      }
      if (currentStep.value === "first") {
        newStep = "second";
      }
      currentStep.value = newStep;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0$a;
      const _component_CreateVacancyOldProviders = __nuxt_component_1$3;
      const _component_CreateVacancyOldStep01 = __nuxt_component_2$2;
      const _component_CreateVacancyOldStep02 = __nuxt_component_3$1;
      const _component_CreateVacancyOldStep03 = __nuxt_component_4;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet create-subscribe-page bg-wrapper",
        role: "main"
      }, _attrs))}><div class="bg-wrapper pt">`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="wrapper wrapper-1290"><form class="create-vacancy" action="" name="create-subscribe "><div class="w-box w-box--main w-box-subscribe"><div class="w-box-head create-vacancy_head"><h1 class="title col-lg-6">\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</h1><div class="form-header col-lg-6 col-md-6 d-flex mb-4"><span class="${ssrRenderClass([{ "active": unref(isFirstStep), "finish": unref(isThirdStep) || unref(isSecondStep) }, "stepIndicator"])}">1 <span class="tab_name">\u0428\u0430\u0433</span></span><span class="${ssrRenderClass([{ "active": unref(isSecondStep), "finish": unref(isThirdStep) }, "stepIndicator"])}">2 <span class="tab_name">\u0428\u0430\u0433</span></span><span class="${ssrRenderClass([{ "active": unref(isThirdStep) }, "stepIndicator"])}">3 <span class="tab_name">\u0428\u0430\u0433</span></span></div></div><div class="w-box-body"><form id="CreateVacancyOldForm" class="create-vacancy__form">`);
      _push(ssrRenderComponent(_component_CreateVacancyOldProviders, null, null, _parent));
      _push(`<!--[-->`);
      if (unref(isFirstStep)) {
        _push(ssrRenderComponent(_component_CreateVacancyOldStep01, {
          providers: unref(providers),
          class: { "d-block": unref(isFirstStep) },
          onSet: updateState,
          onNext: goToNextStep
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isSecondStep)) {
        _push(ssrRenderComponent(_component_CreateVacancyOldStep02, {
          providers: unref(providers),
          class: { "d-block": unref(isFirstStep) },
          onSet: updateState,
          onNext: goToNextStep,
          onPrev: goToPrevStep
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isThirdStep)) {
        _push(ssrRenderComponent(_component_CreateVacancyOldStep03, {
          providers: unref(providers),
          class: { "d-block": unref(isThirdStep) },
          onSet: updateState,
          onPrev: goToPrevStep
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]--></form></div></div><div class="form-submit-container"><button class="btn btn-outline-primary" type="button">\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043A\u0430\u043A \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A</button><button class="button-accent" type="button">\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C</button></div></form></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/create-vacancy-old.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=create-vacancy-old-CIwDqPJJ.mjs.map
