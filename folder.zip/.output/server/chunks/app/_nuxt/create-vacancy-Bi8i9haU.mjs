import { H as Head, T as Title } from './components-DWwOHCR7.mjs';
import { _ as __nuxt_component_0 } from './SearchMobile-WfXJ1gHL.mjs';
import { _ as __nuxt_component_4 } from './CreateDraft-DS1I7Wix.mjs';
import { ref, computed, watch, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, useSSRContext } from 'vue';
import { e as useRoute, l as useVacancyStore, r as useResumeStore, k as useAuthStore } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { u as useAlert } from './useAlert-CPK6c05f.mjs';
import './search-CNCM2ROA.mjs';
import './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import 'vee-validate';
import './sb-_CyfLtbf.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './dictionary--F10-rgU.mjs';
import './VacancyCheckboxInput-VKg7Lh2Y.mjs';
import './useSort-Dy_x39w5.mjs';
import './useFilter-BmdPUTpE.mjs';
import './useProviders-Ck9yopDY.mjs';
import './check-BGWLIG1L.mjs';
import './VeeMultiSelectWithSearch-Btd5b5Va.mjs';
import './VeeTipTapRichEditor-C3vw1Km2.mjs';
import '@tiptap/pm/state';
import '@tiptap/pm/model';
import '@tiptap/pm/transform';
import '@tiptap/pm/commands';
import '@tiptap/pm/schema-list';
import '@tiptap/pm/dropcursor';
import '@tiptap/pm/gapcursor';
import '@tiptap/pm/history';
import './VeeCustomSelect-BxrAvA7-.mjs';
import './useCurrencyOptions-BsifIVKS.mjs';
import './useFormValidation-BMv_R6aU.mjs';
import '@vee-validate/zod';
import 'zod';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main = {
  __name: "create-vacancy",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useVacancyStore();
    const providers = ref({
      superjob: false,
      hh: false
    });
    useResumeStore();
    const pageTitle = computed(() => {
      return "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438";
    });
    computed(() => {
      return route.query.message;
    });
    const { handleAlert } = useAlert();
    watch(() => route.query.message, handleAlert);
    const authStore = useAuthStore();
    computed(() => authStore.isEmployer);
    computed(() => authStore.user);
    computed(() => authStore.employer);
    computed(() => {
      if (providers.value.hh && providers.value.superjob) {
        return ["hh", "superjob"];
      }
      if (providers.value.hh) {
        return ["hh"];
      }
      if (providers.value.superjob) {
        return ["superjob"];
      }
      return [];
    });
    const draft_el = ref();
    ref(null);
    ref(null);
    ref(null);
    ref([]);
    const isLoading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0;
      const _component_CreateVacancyCreateDraft = __nuxt_component_4;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet create-subscribe-page bg-wrapper",
        role: "main"
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(pageTitle))} - Jobeek`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(pageTitle)) + " - Jobeek", 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(pageTitle)) + " - Jobeek", 1)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="bg-wrapper pt">`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="wrapper wrapper-1290"><form class="create-vacancy" name="create-vacancy">`);
      _push(ssrRenderComponent(_component_CreateVacancyCreateDraft, {
        ref_key: "draft_el",
        ref: draft_el,
        title: unref(pageTitle)
      }, null, _parent));
      _push(`<div class="form-submit-container"><button class="btn btn-outline-primary"> \u0414\u0430\u043B\u0435\u0435 `);
      if (unref(isLoading)) {
        _push(`<div class="ms-2 bg-primary spinner-grow spinner-grow-sm" role="status"><span class="visually-hidden">Loading...</span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</button></div></form></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/create-vacancy.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=create-vacancy-Bi8i9haU.mjs.map
