import { S as SeekerEditForm_vue_vue_type_style_index_1_scoped_25e47d92_lang } from './SeekerEditForm-styles-2.mjs-u0YZBwRF.mjs';

const SeekerEditFormStyles_DGW7XMea = [SeekerEditForm_vue_vue_type_style_index_1_scoped_25e47d92_lang];

export { SeekerEditFormStyles_DGW7XMea as default };
//# sourceMappingURL=SeekerEditForm-styles.DGW7XMea.mjs.map
