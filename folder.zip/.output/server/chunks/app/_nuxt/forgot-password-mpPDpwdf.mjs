import { _ as _imports_0$1, a as __nuxt_component_0 } from './i-XlC_iSFx.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-BdrY0gEc.mjs';
import { _ as __nuxt_component_2 } from './Loader-UZvrxmyZ.mjs';
import { ref, computed, reactive, watch, mergeProps, unref, withCtx, createVNode, toDisplayString, createTextVNode, useSSRContext } from 'vue';
import { u as useHead, k as useAuthStore, a as useRouter } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import { _ as _imports_0 } from './jobeek-dark-BM969tB2.mjs';
import './BaseButton-CWRjb9_h.mjs';
import './_plugin-vue_export-helper-1tPrXgE0.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "forgot-password",
  __ssrInlineRender: true,
  setup(__props) {
    const title = ref("\u0412\u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u0430\u0440\u043E\u043B\u044F");
    useHead({
      title
    });
    const authStore = useAuthStore();
    computed(() => authStore.isAuthed);
    ref(true);
    const isLoading = ref(false);
    ref(null);
    const state = reactive({
      phone: {
        val: "",
        isValid: true
      },
      code: {
        val: null,
        isValid: true
      },
      password: {
        val: null,
        isValid: true
      },
      password_confirmation: {
        val: null,
        isValid: true
      },
      token: null,
      isFormValid: true,
      error: null,
      success: null
    });
    watch(
      () => state.code.val,
      (newValue) => {
        if (newValue && String(newValue).length !== 4) {
          state.code.isValid = false;
          return;
        }
        state.code.isValid = true;
      }
    );
    const isConfirmSMSButton = computed(() => {
      if (isLoading.value)
        return false;
      if (state.code.val) {
        return String(state.code.val).length === 4;
      }
      return false;
    });
    ref();
    ref(null);
    useRouter();
    const tabs = reactive({
      isRegisterTab: true,
      isConfirmTab: false,
      isResetTab: false
    });
    function close() {
      state.error = null;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_base_modal = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Loader = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_base_modal, {
        show: !!unref(state).error,
        title: "Error occured",
        type: "error",
        onClose: close
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<p${_scopeId}>${ssrInterpolate(unref(state).error)}</p>`);
          } else {
            return [
              createVNode("p", null, toDisplayString(unref(state).error), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_base_modal, {
        show: !!unref(state).success,
        title: "Success",
        onClose: close
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<p${_scopeId}>${ssrInterpolate(unref(state).success)}</p>`);
          } else {
            return [
              createVNode("p", null, toDisplayString(unref(state).success), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<main class="main enter-page sign-up" role="main"><div class="enter-page-content">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "logo"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="#"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "#"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      if (unref(tabs).isRegisterTab) {
        _push(`<form class="enter-form"><h1>${ssrInterpolate(unref(title))}</h1><div class="i-wrap"><input type="tel" name="tel" placeholder="\u041D\u043E\u043C\u0435\u0440 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430"></div><button class="btn button-accent" type="submit"> \u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C `);
        if (unref(isLoading)) {
          _push(ssrRenderComponent(_component_Loader, { class: "text-light spinner-border-sm" }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</button></form>`);
      } else if (unref(tabs).isConfirmTab) {
        _push(`<form class="enter-form"><div class="i-wrap"><input type="number" name="code"${ssrRenderAttr("value", unref(state).code.val)} placeholder="\u041A\u043E\u0434 \u043F\u043E\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F">`);
        if (!unref(state).code.isValid) {
          _push(`<span class="text text-danger"> \u0412\u0432\u0435\u0434\u0438\u0442\u0435 4 \u0437\u043D\u0430\u0447\u043D\u044B\u0439 \u043A\u043E\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F </span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div class="note"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"><p> \u041D\u0430 \u043D\u043E\u043C\u0435\u0440 +${ssrInterpolate(unref(state).phone.val)} \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D \u043A\u043E\u0434 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F \u043F\u0430\u0440\u043E\u043B\u044F. </p></div><button class="btn button-accent" type="submit"${ssrIncludeBooleanAttr(!unref(isConfirmSMSButton)) ? " disabled" : ""}> \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C `);
        if (unref(isLoading)) {
          _push(ssrRenderComponent(_component_Loader, { class: "text-light spinner-border-sm" }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</button></form>`);
      } else if (unref(tabs).isResetTab) {
        _push(`<form class="enter-form"><div class="i-wrap"><input type="password" name="password"${ssrRenderAttr("value", unref(state).password.val)} placeholder="\u041F\u0430\u0440\u043E\u043B\u044C"></div><div class="i-wrap"><input type="password" name="password_confirmation"${ssrRenderAttr("value", unref(state).password_confirmation.val)} placeholder="\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0430\u0440\u043E\u043B\u044C"></div><div class="note"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"><p>\u0423\u0441\u0442\u0430\u043D\u043E\u043D\u0438\u0442\u0435 \u043D\u043E\u0432\u044B\u0439 \u043F\u0430\u0440\u043E\u043B\u044C \u0434\u043B\u044F \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430 +${ssrInterpolate(unref(state).phone.val)}</p></div><button class="btn button-accent" type="submit"> \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C `);
        if (unref(isLoading)) {
          _push(ssrRenderComponent(_component_Loader, { class: "text-light spinner-border-sm" }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</button></form>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="f-prompt"> \u0425\u043E\u0442\u0438\u0442\u0435 \u0432\u043E\u0439\u0442\u0438? `);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "sign-in" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0412\u043E\u0439\u0434\u0438\u0442\u0435!`);
          } else {
            return [
              createTextVNode("\u0412\u043E\u0439\u0434\u0438\u0442\u0435!")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></main></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/forgot-password.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=forgot-password-mpPDpwdf.mjs.map
