const VacancyForm_vue_vue_type_style_index_0_scoped_2b77d9e4_lang = ".search-form[data-v-2b77d9e4]{box-shadow:none}";

const VacancyFormStyles_B81ONLFs = [VacancyForm_vue_vue_type_style_index_0_scoped_2b77d9e4_lang];

export { VacancyFormStyles_B81ONLFs as default };
//# sourceMappingURL=VacancyForm-styles.B81ONLFs.mjs.map
