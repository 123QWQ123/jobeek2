import { H as Head, T as Title } from './components-DWwOHCR7.mjs';
import { _ as __nuxt_component_0 } from './SearchMobile-WfXJ1gHL.mjs';
import { _ as __nuxt_component_1 } from './Providers-Bui0vB9a.mjs';
import { _ as __nuxt_component_2 } from './VeeBirthDatePicker-7XRn76OG.mjs';
import { _ as __nuxt_component_0$1 } from './VeeSelectWithSearch-CuZCClCB.mjs';
import { defineAsyncComponent, ref, computed, watch, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, useSSRContext, reactive } from 'vue';
import { _ as __nuxt_component_1$1 } from './VeeMultiSelectWithSearch-Btd5b5Va.mjs';
import { e as useRoute, l as useVacancyStore, r as useResumeStore, m as useProfileStore, s as storeToRefs, d as navigateTo } from '../server.mjs';
import { useForm } from 'vee-validate';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrRenderAttr } from 'vue/server-renderer';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { u as useFormValidation } from './useFormValidation-BMv_R6aU.mjs';
import { u as useWatchStateValues } from './useWatchStateValues-DimKH74z.mjs';
import { u as useResumeHooks } from './useResumeHooks-BM2nRo7f.mjs';
import { R as ResumeCheckboxInput } from './ResumeCheckboxInput-DBsB0Z0m.mjs';
import { R as ResumeTextInput } from './ResumeTextInput-BxTsuw7y.mjs';
import { u as useAlert } from './useAlert-CPK6c05f.mjs';
import './search-CNCM2ROA.mjs';
import './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import './sb-_CyfLtbf.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './useYearOptions--VQWJCm5.mjs';
import 'moment';
import './useSort-Dy_x39w5.mjs';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './check-BGWLIG1L.mjs';

const __nuxt_component_3_lazy = defineAsyncComponent(() => import('./VeeCustomSelect-BxrAvA7-.mjs').then((c) => c.default || c));
const _sfc_main$1 = {
  __name: "DraftCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const props = __props;
    const resumeStore = useResumeStore();
    const profileStore = useProfileStore();
    useRoute();
    storeToRefs(resumeStore);
    const formTitle = computed(() => props.title);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    ref(false);
    const isUpdated = ref(false);
    const schema = computed(() => {
      return {
        providers: "required",
        title: "required|min:1|max:100",
        first_name: "required|min:1|max:100",
        last_name: "required|min:1|max:100",
        middle_name: "required|min:1|max:100",
        email: { required: true, email: true },
        is_preferred_email: { boolean: true },
        birth_date: "required|date",
        city_id: "required|numeric",
        gender_id: "required|numeric",
        business_trip_id: "required|numeric",
        relocation_type_id: "numeric",
        work_types: "required|min:1"
      };
    });
    const {
      values,
      errors,
      defineField,
      meta,
      setTouched,
      setErrors,
      handleSubmit
    } = useForm({
      initialValues: {
        providers: [],
        title: null,
        first_name: null,
        last_name: null,
        middle_name: null,
        email: null,
        is_preferred_email: false,
        birth_date: null,
        city_id: null,
        gender_id: null,
        business_trip_id: null,
        relocation_type_id: null,
        move_able_cities: [],
        work_types: []
      },
      initialTouched: true,
      validationSchema: schema
    });
    const { createResume } = resumeStore;
    const state = reactive({
      title: {
        is_hidden: false
      },
      first_name: {
        is_hidden: false
      },
      last_name: {
        is_hidden: false
      },
      middle_name: {
        is_hidden: false
      },
      email: {
        is_hidden: false
      },
      is_preferred_email: {
        is_hidden: false
      },
      city_id: {
        is_hidden: false
      },
      move_able_cities: {
        is_hidden: true
      },
      metros: {
        is_hidden: true
      },
      professional_roles: {
        is_hidden: true
      },
      birth_date: {
        is_hidden: true
      },
      salary: {
        is_hidden: true
      },
      gender_id: {
        is_hidden: true
      },
      business_trip_id: {
        is_hidden: true
      },
      work_types: {
        is_hidden: true
      },
      relocation_type_id: {
        is_hidden: true
      }
    });
    const isMovableCitiesEnabled = computed(() => {
      const relocation_id = parseInt(values.relocation_type_id);
      return relocation_id === 148 || relocation_id === 149;
    });
    watch(
      () => useWatchStateValues(state, true, true),
      (newState, oldState) => {
        isChanged.value = true;
      }
    );
    const { searchCities, searchProfessionalRoles } = profileStore;
    const dictionaryStore = useDictionaryStore();
    const cityOptions = ref([]);
    const moveableCityOptions = ref([]);
    const genderOptions = computed(() => {
      return dictionaryStore.resume_genders.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const workTypeOptions = computed(() => {
      return dictionaryStore.work_types.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const businessTripOptions = computed(() => {
      return dictionaryStore.business_trips.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const relocationTypeOptions = computed(() => {
      return dictionaryStore.relocation_types.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const { getCityName, getCityNameFromArea2 } = useResumeHooks();
    const updateCityInput = async (newValue = "") => {
      var _a;
      if (newValue.length < 2) {
        return;
      }
      const items = (_a = await searchCities({ search: newValue })) != null ? _a : [];
      cityOptions.value = items.map((item) => ({
        value: item.id,
        name: getCityNameFromArea2(item)
      }));
    };
    const updateMoveableCityInput = async (newValue = "") => {
      var _a;
      const items = (_a = await searchCities({ search: newValue })) != null ? _a : [];
      moveableCityOptions.value = items.map((item) => ({
        value: item.id,
        name: item.name
      }));
    };
    const { errors: serverErrors, handleErrorResponse } = useFormValidation(state);
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    const isLoading = ref(false);
    const errorMessageElement = ref();
    const errorMessage = ref(null);
    const onSubmit = handleSubmit((submittedValues) => {
      save();
    });
    const save = async (is_from_parent = false) => {
      if (!meta.value.valid) {
        setTouched(true);
        errorMessage.value = "\u0412\u0430\u043C \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u0437\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C";
        errorMessageElement.value.scrollIntoView({ behavior: "smooth" });
        return;
      }
      setErrors({});
      errorMessage.value = "";
      isLoading.value = true;
      let resData = await createResume(values);
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        return;
      }
      isLoading.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
      const resume_id = resData.data.data.id;
      setTimeout(() => {
        console.log("redirecting...");
        navigateTo({ name: "my-resume-id", params: { id: resume_id } });
      }, 100);
      isLoading.value = false;
      if (resData.data.hasOwnProperty("errors")) {
        setErrors(resData.data.errors);
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = false;
    };
    __expose({
      onSubmit
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyProviders = __nuxt_component_1;
      const _component_VeeBirthDatePicker = __nuxt_component_2;
      const _component_VeeSelectWithSearch = __nuxt_component_0$1;
      const _component_LazyVeeCustomSelect = __nuxt_component_3_lazy;
      const _component_VeeMultiSelectWithSearch = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box w-box--main w-box-resume pb-4" }, _attrs))}><div class="w-box-head"><h1 class="title">${ssrInterpolate(unref(formTitle))}</h1><div class="descr"> \u041F\u043E\u043B\u0443\u0447\u0430\u0439\u0442\u0435 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u043E \u043D\u043E\u0432\u044B\u0445 \u043F\u043E \u0441\u043E\u0437\u0434\u0430\u043D\u043D\u043E\u043C\u0443 \u0437\u0430\u043F\u0440\u043E\u0441\u0443 </div><span class="arrow"></span></div><div class="${ssrRenderClass([{ disabled: unref(isLoading) }, "w-box-body"])}"><div>`);
      if (unref(errors).message) {
        _push(`<div class="alert alert-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><form${ssrRenderAttr("validation-schema", unref(schema))}>`);
      _push(ssrRenderComponent(_component_CreateVacancyProviders, { name: "providers" }, null, _parent));
      _push(`<div class="input-row"><label for="name">\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438<b>*</b></label><div class="input-wrapper"><div class="c1 mt-1">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "title",
        placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435"
      }, null, _parent));
      _push(`</div></div></div><div class="input-row"><label for="name">\u0418\u043C\u044F \u0438 \u0444\u0430\u043C\u0438\u043B\u0438\u044F <b>*</b></label><div class="input-wrapper"><div class="c2"><div class="input-wrapper">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "first_name",
        placeholder: "\u0418\u043C\u044F"
      }, null, _parent));
      _push(`</div><div class="input-wrapper">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "last_name",
        placeholder: "\u0424\u0430\u043C\u0438\u043B\u0438\u044F"
      }, null, _parent));
      _push(`</div></div><div class="c1 mt-1">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "middle_name",
        placeholder: "\u041E\u0442\u0447\u0435\u0441\u0442\u0432\u043E"
      }, null, _parent));
      _push(`</div></div></div><div class="input-row"><label for="resume_email">\u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0447\u0442\u0430<b>*</b></label><div class="input-wrapper">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "email",
        placeholder: "\u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0447\u0442\u0430"
      }, null, _parent));
      if (!unref(state).is_preferred_email.is_hidden) {
        _push(ssrRenderComponent(ResumeCheckboxInput, {
          class: "mt-2",
          name: "is_preferred_email",
          label: "Email \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043B\u0438 \u043F\u0440\u0435\u0434\u043F\u043E\u0447\u0442\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u043C \u0441\u043F\u043E\u0441\u043E\u0431\u043E\u043C \u0441\u0432\u044F\u0437\u0438"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="input-row"><label>\u0414\u0430\u0442\u0430 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F <b>*</b></label><div class="input-wrapper"><div class="mb-1">`);
      _push(ssrRenderComponent(_component_VeeBirthDatePicker, { name: "birth_date" }, null, _parent));
      _push(`</div></div></div><div class="input-row"><label>\u0413\u043E\u0440\u043E\u0434 \u043F\u0440\u043E\u0436\u0438\u0432\u0430\u043D\u0438\u044F:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_VeeSelectWithSearch, {
        options: unref(cityOptions),
        name: "city_id",
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0433\u043E\u0440\u043E\u0434",
        onInput: updateCityInput
      }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u041F\u043E\u043B\u044C:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_LazyVeeCustomSelect, {
        options: unref(genderOptions),
        name: "gender_id",
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u0413\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C \u043A \u043A\u043E\u043C\u0430\u043D\u0434\u0438\u0440\u043E\u0432\u043A\u0430\u043C:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_LazyVeeCustomSelect, {
        options: unref(businessTripOptions),
        name: "business_trip_id",
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u0413\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C \u043A \u0440\u0435\u043B\u043E\u043A\u0430\u0446\u0438\u044E:</label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_LazyVeeCustomSelect, {
        options: unref(relocationTypeOptions),
        name: "relocation_type_id",
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div>`);
      if (unref(isMovableCitiesEnabled)) {
        _push(`<div class="input-row"><label>\u0413\u043E\u0440\u043E\u0434\u043E\u0432 \u0432 \u043A\u043E\u0442\u043E\u0440\u044B\u043C \u0433\u043E\u0442\u043E\u0432 \u043F\u0435\u0440\u0435\u0435\u0445\u0430\u0442\u044C:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, {
          name: "move_able_cities",
          options: unref(moveableCityOptions),
          placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435",
          onInput: updateMoveableCityInput
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="input-row"><label>\u0422\u0438\u043F \u0440\u0430\u0431\u043E\u0442\u044B:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, {
        name: "work_types",
        options: unref(workTypeOptions),
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div></form></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/DraftCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$1;
const _sfc_main = {
  __name: "create-vacancy2",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useVacancyStore();
    const providers = ref({
      superjob: false,
      hh: false
    });
    const pageTitle = computed(() => {
      return "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438";
    });
    computed(() => {
      return route.query.message;
    });
    const { handleAlert } = useAlert();
    watch(() => route.query.message, handleAlert);
    computed(() => {
      if (providers.value.hh && providers.value.superjob) {
        return ["hh", "superjob"];
      }
      if (providers.value.hh) {
        return ["hh"];
      }
      if (providers.value.superjob) {
        return ["superjob"];
      }
      return [];
    });
    const draft_el = ref();
    ref(null);
    ref(null);
    ref(null);
    ref([]);
    const isLoading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0;
      const _component_CreateVacancyDraftCard = __nuxt_component_3;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet create-subscribe-page bg-wrapper",
        role: "main"
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(pageTitle))} - Jobeek`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(pageTitle)) + " - Jobeek", 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(pageTitle)) + " - Jobeek", 1)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="bg-wrapper pt">`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="wrapper wrapper-1290"><form class="create-vacancy" name="create-vacancy">`);
      _push(ssrRenderComponent(_component_CreateVacancyDraftCard, {
        ref_key: "draft_el",
        ref: draft_el
      }, null, _parent));
      _push(`<div class="form-submit-container"><button class="btn btn-outline-primary"> \u0414\u0430\u043B\u0435\u0435 `);
      if (unref(isLoading)) {
        _push(`<div class="ms-2 bg-primary spinner-grow spinner-grow-sm" role="status"><span class="visually-hidden">Loading...</span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</button></div></form></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/create-vacancy2.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=create-vacancy2-DODWGShb.mjs.map
