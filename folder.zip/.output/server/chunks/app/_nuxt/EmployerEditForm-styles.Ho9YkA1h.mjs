import { E as EmployerEditForm_vue_vue_type_style_index_1_scoped_21aeda6f_lang } from './EmployerEditForm-styles-2.mjs-DQOn_E2F.mjs';

const EmployerEditFormStyles_Ho9YkA1h = [EmployerEditForm_vue_vue_type_style_index_1_scoped_21aeda6f_lang];

export { EmployerEditFormStyles_Ho9YkA1h as default };
//# sourceMappingURL=EmployerEditForm-styles.Ho9YkA1h.mjs.map
