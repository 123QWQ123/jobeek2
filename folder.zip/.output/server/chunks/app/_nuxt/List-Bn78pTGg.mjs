import { _ as __nuxt_component_0 } from './PageLoader-CgN00RaA.mjs';
import { _ as __nuxt_component_0$1 } from './Item-EOkX6xfY.mjs';
import { _ as __nuxt_component_0$2 } from './nuxt-link-BdrY0gEc.mjs';
import { useSSRContext, ref, watch, unref, withCtx, createTextVNode } from 'vue';
import { l as useVacancyStore, s as storeToRefs, e as useRoute } from '../server.mjs';
import { ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { u as useVacancyForm } from './useVacancyForm-UJ-LLtx0.mjs';

const _sfc_main = {
  __name: "List",
  __ssrInlineRender: true,
  setup(__props) {
    const vacancyStore = useVacancyStore();
    const { my_favorite_vacancies, current_page } = storeToRefs(vacancyStore);
    const items = ref([]);
    const isLoading = ref(true);
    const isMore = ref(false);
    useRoute();
    ref(useVacancyForm());
    watch(my_favorite_vacancies, (newValues) => {
      items.value = newValues;
      if (newValues.length > 0) {
        isMore.value = true;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PageLoader = __nuxt_component_0;
      const _component_VacanciesItem = __nuxt_component_0$1;
      const _component_nuxt_link = __nuxt_component_0$2;
      _push(`<!--[--><h2 class="lk-page-title">\u041C\u043E\u0438 \u0418\u0437\u0431\u0440\u0430\u043D\u043D\u044B\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</h2>`);
      if (unref(isLoading)) {
        _push(ssrRenderComponent(_component_PageLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="favorites-list-container"><ul class="favorites-list"><!--[-->`);
      ssrRenderList(unref(items), (item) => {
        _push(ssrRenderComponent(_component_VacanciesItem, {
          key: item.id,
          item
        }, null, _parent));
      });
      _push(`<!--]--></ul>`);
      if (unref(items).length) {
        _push(`<div class="footer mt-3"><button class="btn btn-primary">Prev</button><button class="btn btn-primary ms-2">Next</button></div>`);
      } else {
        _push(`<div class="notification no-ic-bg"><div class="notification-text"><strong class="title">\u0423 \u0432\u0430\u0441 \u043F\u043E\u043A\u0430 \u043D\u0435\u0442 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439 \u0432 \u0438\u0437\u0431\u0440\u0430\u043D\u043D\u043E\u043C</strong><p>\u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0439\u0442\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438, \u043D\u0430\u0436\u0438\u043C\u0430\u044F \u043D\u0430 \u0437\u0432\u0451\u0437\u0434\u043E\u0447\u043A\u0443</p></div>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          class: "notification-button button-accent",
          to: { name: "search-vacancies" }
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u041D\u0430\u0439\u0442\u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E `);
            } else {
              return [
                createTextVNode("\u041D\u0430\u0439\u0442\u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      }
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MyFavoriteVacancies/List.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_2 as _ };
//# sourceMappingURL=List-Bn78pTGg.mjs.map
