import { _ as __nuxt_component_0 } from './ThePersonalCabinetHeader-BrQhEWZm.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-BdrY0gEc.mjs';
import { _ as __nuxt_component_1 } from './page-DRc_CJ9B.mjs';
import { _ as __nuxt_component_2 } from './TheFooter-D-Qn_ABY.mjs';
import { mergeProps, withCtx, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderSlot, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_0 } from './search-CNCM2ROA.mjs';
import { _ as _imports_1 } from './location-6cdwV0kl.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import '../server.mjs';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './TheMainHeader-BNhvozaC.mjs';
import './jobeek-dark-BM969tB2.mjs';
import './ui-DaXXToyC.mjs';

const _sfc_main = {
  computed: {
    hasHeaderSlot() {
      return !!this.$slots.header;
    },
    hasFooterSlot() {
      return !!this.$slots.footer;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_HeaderThePersonalCabinetHeader = __nuxt_component_0;
  const _component_NuxtLink = __nuxt_component_0$1;
  const _component_NuxtPage = __nuxt_component_1;
  const _component_the_footer = __nuxt_component_2;
  _push(`<div${ssrRenderAttrs(mergeProps({ className: "layout" }, _attrs))}>`);
  if ($options.hasHeaderSlot) {
    _push(`<header className="header">`);
    ssrRenderSlot(_ctx.$slots, "header", {}, null, _push, _parent);
    _push(`</header>`);
  } else {
    _push(ssrRenderComponent(_component_HeaderThePersonalCabinetHeader, null, null, _parent));
  }
  _push(`<main class="main cabinet advice-page bg-wrapper" role="main"><div class="tabs tabs-row wrapper wrapper-1290"><ul><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "advice-category", params: { category: "popular" } } }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u041F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u043E\u0435`);
      } else {
        return [
          createTextVNode("\u041F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u043E\u0435")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "advice-category", params: { category: "resume" } } }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u0420\u0435\u0437\u044E\u043C\u0435`);
      } else {
        return [
          createTextVNode("\u0420\u0435\u0437\u044E\u043C\u0435")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "advice-category", params: { category: "seeking-jobs" } } }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u041F\u043E\u0438\u0441\u043A \u0440\u0430\u0431\u043E\u0442\u044B`);
      } else {
        return [
          createTextVNode("\u041F\u043E\u0438\u0441\u043A \u0440\u0430\u0431\u043E\u0442\u044B")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "advice-category", params: { category: "interviews" } } }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u0421\u043E\u0431\u0435\u0441\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F`);
      } else {
        return [
          createTextVNode("\u0421\u043E\u0431\u0435\u0441\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u044F")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "advice-category", params: { category: "about-money" } } }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u041F\u0440\u043E \u0434\u0435\u043D\u044C\u0433\u0438`);
      } else {
        return [
          createTextVNode("\u041F\u0440\u043E \u0434\u0435\u043D\u044C\u0433\u0438")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "advice-category", params: { category: "career" } } }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u041A\u0430\u0440\u044C\u0435\u0440\u0430`);
      } else {
        return [
          createTextVNode("\u041A\u0430\u0440\u044C\u0435\u0440\u0430")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></div><div class="main-section main-section-mob"><div class="wrapper wrapper--xl"><form class="search-form" action="#" role="form" autocomplete="off"><div class="search-row"><div class="input-wrap has-icon has-label"><img class="icon"${ssrRenderAttr("src", _imports_0)} alt="#"><label for="name">\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 </label><input type="text" name="name" id="name" placeholder="\u041A\u0430\u043A\u0443\u044E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E \u0432\u044B \u0438\u0449\u0435\u0442\u0435?" autocomplete="off"></div><div class="input-wrap has-label"><label for="salary">\u0416\u0435\u043B\u0430\u0435\u043C\u0430\u044F \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0430 </label><select class="n-select" name="salary" id="salary"><option data-display="\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0443">Nothing</option><option value="1">Some option</option><option value="2">Another option</option><option value="3" disabled>A disabled option</option><option value="4">Potato</option></select></div><div class="input-wrap has-icon"><img class="icon"${ssrRenderAttr("src", _imports_1)} alt="#"><input type="text" name="city" placeholder="\u0413\u043E\u0440\u043E\u0434" autocomplete="off"></div><div class="input-wrap has-icon"><img class="icon"${ssrRenderAttr("src", _imports_1)} alt="#"><input type="text" name="country" placeholder="\u0421\u0442\u0440\u0430\u043D\u0430" autocomplete="off"></div><button class="button-accent submit-search-form" type="submit">\u041F\u043E\u0438\u0441\u043A </button></div></form></div></div><div class="articles-grid-container wrapper wrapper-1290">`);
  _push(ssrRenderComponent(_component_NuxtPage, null, null, _parent));
  _push(`</div></main>`);
  if ($options.hasFooterSlot) {
    _push(`<footer className="footer">`);
    ssrRenderSlot(_ctx.$slots, "footer", {}, null, _push, _parent);
    _push(`</footer>`);
  } else {
    _push(ssrRenderComponent(_component_the_footer, null, null, _parent));
  }
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/advice.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const advice = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { advice as default };
//# sourceMappingURL=advice-Bu7U6lTW.mjs.map
