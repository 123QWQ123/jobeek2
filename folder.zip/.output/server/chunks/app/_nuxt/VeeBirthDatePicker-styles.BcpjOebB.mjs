const VeeBirthDatePicker_vue_vue_type_style_index_0_scoped_0bf11983_lang = "#date-picker[data-v-0bf11983]{display:flex}#date-picker div[data-v-0bf11983]{margin-right:10px}";

const VeeBirthDatePickerStyles_BcpjOebB = [VeeBirthDatePicker_vue_vue_type_style_index_0_scoped_0bf11983_lang];

export { VeeBirthDatePickerStyles_BcpjOebB as default };
//# sourceMappingURL=VeeBirthDatePicker-styles.BcpjOebB.mjs.map
