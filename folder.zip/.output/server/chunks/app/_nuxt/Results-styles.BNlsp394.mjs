const Results_vue_vue_type_style_index_0_scoped_8920d837_lang = ".sort[data-v-8920d837]{align-items:baseline;justify-content:end}@media (max-width:960px){.sorting_forms[data-v-8920d837]{flex-direction:column}.reversed_forms[data-v-8920d837]{flex-direction:column-reverse}.sort[data-v-8920d837]{justify-content:flex-start!important}}@media (max-width:480px){.sorting_forms[data-v-8920d837]{flex-direction:column}.reversed_forms[data-v-8920d837]{flex-direction:column-reverse}.sort[data-v-8920d837]{flex-direction:column}}";

const ResultsStyles_BNlsp394 = [Results_vue_vue_type_style_index_0_scoped_8920d837_lang];

export { ResultsStyles_BNlsp394 as default };
//# sourceMappingURL=Results-styles.BNlsp394.mjs.map
