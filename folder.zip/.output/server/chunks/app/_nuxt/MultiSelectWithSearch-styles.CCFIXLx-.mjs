import { M as MultiSelectWithSearch_vue_vue_type_style_index_0_lang } from './MultiSelectWithSearch-styles-1.mjs-CmDtrXzg.mjs';
import { M as MultiSelectWithSearch_vue_vue_type_style_index_1_scoped_06d53309_lang } from './MultiSelectWithSearch-styles-2.mjs-BEYiaMHG.mjs';

const MultiSelectWithSearchStyles_CCFIXLx_ = [MultiSelectWithSearch_vue_vue_type_style_index_0_lang, MultiSelectWithSearch_vue_vue_type_style_index_1_scoped_06d53309_lang];

export { MultiSelectWithSearchStyles_CCFIXLx_ as default };
//# sourceMappingURL=MultiSelectWithSearch-styles.CCFIXLx-.mjs.map
