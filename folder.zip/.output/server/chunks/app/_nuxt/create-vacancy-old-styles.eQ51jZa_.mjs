import { c as createVacancyOld_vue_vue_type_style_index_0_lang } from './create-vacancy-old-styles-1.mjs-da2iGGot.mjs';

const createVacancyOldStyles_eQ51jZa_ = [createVacancyOld_vue_vue_type_style_index_0_lang];

export { createVacancyOldStyles_eQ51jZa_ as default };
//# sourceMappingURL=create-vacancy-old-styles.eQ51jZa_.mjs.map
