const DriverLicensesForm_vue_vue_type_style_index_0_scoped_fc17c82a_lang = ".checkboxes-row[data-v-fc17c82a]{width:-webkit-fill-available}";

const DriverLicensesFormStyles_wu2_DKpK = [DriverLicensesForm_vue_vue_type_style_index_0_scoped_fc17c82a_lang];

export { DriverLicensesFormStyles_wu2_DKpK as default };
//# sourceMappingURL=DriverLicensesForm-styles.wu2_DKpK.mjs.map
