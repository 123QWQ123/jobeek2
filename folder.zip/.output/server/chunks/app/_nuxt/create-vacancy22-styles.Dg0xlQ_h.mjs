const createVacancy22_vue_vue_type_style_index_0_scoped_c86ab810_lang = ".button-accent.disabled[data-v-c86ab810]{filter:grayscale(180%)}@media (max-width:768px){.form-submit-container[data-v-c86ab810]{flex-direction:column-reverse}.button-accent[data-v-c86ab810]{margin-bottom:1rem}}";

const createVacancy22Styles_Dg0xlQ_h = [createVacancy22_vue_vue_type_style_index_0_scoped_c86ab810_lang];

export { createVacancy22Styles_Dg0xlQ_h as default };
//# sourceMappingURL=create-vacancy22-styles.Dg0xlQ_h.mjs.map
