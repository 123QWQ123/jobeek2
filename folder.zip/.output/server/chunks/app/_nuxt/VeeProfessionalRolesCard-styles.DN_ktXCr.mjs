const VeeProfessionalRolesCard_vue_vue_type_style_index_0_lang = "";

const VeeProfessionalRolesCardStyles_DN_ktXCr = [VeeProfessionalRolesCard_vue_vue_type_style_index_0_lang];

export { VeeProfessionalRolesCardStyles_DN_ktXCr as default };
//# sourceMappingURL=VeeProfessionalRolesCard-styles.DN_ktXCr.mjs.map
