import { _ as __nuxt_component_0 } from './BlockLoader-RiL0eLJn.mjs';
import { defineAsyncComponent, computed, ref, reactive, watch, unref, mergeProps, useSSRContext, withAsyncContext } from 'vue';
import { r as useResumeStore, m as useProfileStore, e as useRoute, s as storeToRefs, d as navigateTo } from '../server.mjs';
import { useForm, useField } from 'vee-validate';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderClass, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1, b as _imports_2 } from './sb-_CyfLtbf.mjs';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { _ as __nuxt_component_2 } from './VeeBirthDatePicker-7XRn76OG.mjs';
import { _ as __nuxt_component_0$1 } from './VeeSelectWithSearch-CuZCClCB.mjs';
import { _ as __nuxt_component_1$1 } from './VeeMultiSelectWithSearch-Btd5b5Va.mjs';
import { u as useFormValidation } from './useFormValidation-BMv_R6aU.mjs';
import { u as useResumeHooks } from './useResumeHooks-BM2nRo7f.mjs';
import { R as ResumeCheckboxInput } from './ResumeCheckboxInput-DBsB0Z0m.mjs';
import { R as ResumeTextInput } from './ResumeTextInput-BxTsuw7y.mjs';
import { toTypedSchema } from '@vee-validate/zod';
import { z } from 'zod';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import './search-CNCM2ROA.mjs';
import './useYearOptions--VQWJCm5.mjs';
import './useSort-Dy_x39w5.mjs';
import './check-BGWLIG1L.mjs';

const _sfc_main$1 = {
  __name: "ProvidersInput",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: false,
      default: {}
    },
    name: {
      required: true,
      type: String
    },
    errors: {
      required: false,
      default: {}
    }
  },
  emits: ["update:modelValue"],
  async setup(__props, { emit: __emit }) {
    var _a;
    let __temp, __restore;
    const emit = __emit;
    const props = __props;
    const errors = computed(() => props.errors);
    useDictionaryStore();
    const route = useRoute();
    computed(() => route.params.id);
    const resumeStore = useResumeStore();
    const { getConnectedSeekerProviders, getSeekerProvidersAuthEndpoints } = resumeStore;
    [__temp, __restore] = withAsyncContext(() => getConnectedSeekerProviders()), await __temp, __restore();
    const { value, errorMessage } = useField(() => props.name);
    const enabledProviders = ref(resumeStore.providers);
    const isHHEnabled = computed(() => enabledProviders.value.hh);
    const isSuperjobEnabled = computed(() => enabledProviders.value.superjob);
    const resetObject = {
      superjob: false,
      hh: false
    };
    const resumeProviders = computed(() => {
      let selectedProvidersValue = [];
      if (!resumeStore.my_resume) {
        return resetObject;
      }
      const providersNewValues = { ...resetObject };
      if (selectedProvidersValue.includes("hh")) {
        providersNewValues.hh = true;
      } else {
        providersNewValues.superjob = false;
      }
      if (selectedProvidersValue.includes("superjob")) {
        providersNewValues.superjob = true;
      } else {
        providersNewValues.superjob = false;
      }
      return providersNewValues;
    });
    watch(
      () => resumeProviders.value,
      (newValue) => {
        selectedProviders.value = newValue;
      }
    );
    const selectedProviders = ref((_a = props.modelValue) != null ? _a : resetObject);
    watch(
      () => selectedProviders.value,
      (newSelectedItems) => {
        emit("update:modelValue", newSelectedItems);
      }
    );
    const isHHSelected = computed(() => selectedProviders.value.hh);
    const isSuperjobSelected = computed(() => selectedProviders.value.superjob);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "carryover-box" }, _attrs))} data-v-5f246e03><div class="carryover-box-label" data-v-5f246e03> \u0415\u0441\u0442\u044C \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 \u043D\u0430 hh \u0438\u043B\u0438 SuperJob? \u041F\u0440\u043E\u0441\u0442\u043E \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0438\u0442\u0435 \u0435\u0433\u043E! </div><div class="import-grid" data-v-5f246e03><div class="${ssrRenderClass([{
        "import-is-complete": unref(isHHSelected),
        disabled: !unref(isHHEnabled),
        "is-connected": unref(isHHEnabled)
      }, "import-box"])}" data-v-5f246e03><div class="import-box-dvnld" data-v-5f246e03><div class="logo" data-v-5f246e03><img${ssrRenderAttr("src", _imports_0)} alt="#" data-v-5f246e03><div class="check" data-v-5f246e03><img${ssrRenderAttr("src", _imports_1)} alt="#" data-v-5f246e03></div></div><span data-v-5f246e03>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 HeadHunters.ru</span></div><div class="import-complete" data-v-5f246e03><div class="logo logo-fake" data-v-5f246e03></div><span data-v-5f246e03>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 HeadHunters.ru</span><button class="close" type="button" data-v-5f246e03><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-5f246e03><path d="M18.9951 4.99512L5.00586 18.9843" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-5f246e03></path><path d="M19.0009 18.9928L5 4.98901" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-5f246e03></path></svg></button></div>`);
      if (unref(errors).hh) {
        _push(`<div class="text-danger d-block" data-v-5f246e03>${ssrInterpolate(unref(errors).hh)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="${ssrRenderClass([{
        "import-is-complete": unref(isSuperjobSelected),
        disabled: !unref(isSuperjobEnabled),
        "is-connected": unref(isSuperjobEnabled)
      }, "import-box"])}" data-v-5f246e03><div class="import-box-dvnld" data-v-5f246e03><div class="logo" data-v-5f246e03><img${ssrRenderAttr("src", _imports_2)} alt="#" data-v-5f246e03><div class="check" data-v-5f246e03><img${ssrRenderAttr("src", _imports_1)} alt="#" data-v-5f246e03></div></div><span data-v-5f246e03>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 Superjob.ru </span></div><div class="import-complete" data-v-5f246e03><div class="logo logo-fake" data-v-5f246e03></div><span data-v-5f246e03>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 Superjob.ru</span><button class="close" type="button" data-v-5f246e03><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-5f246e03><path d="M18.9951 4.99512L5.00586 18.9843" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-5f246e03></path><path d="M19.0009 18.9928L5 4.98901" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-5f246e03></path></svg></button></div>`);
      if (unref(errors).superjob) {
        _push(`<div class="text-danger d-block" data-v-5f246e03>${ssrInterpolate(unref(errors).superjob)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="text-danger d-block" data-v-5f246e03>${ssrInterpolate(unref(errorMessage))}</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/ProvidersInput.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-5f246e03"]]);
const __nuxt_component_4_lazy = defineAsyncComponent(() => import('./VeeCustomSelect-BxrAvA7-.mjs').then((c) => c.default || c));
const _sfc_main = {
  __name: "DraftCard",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const props = __props;
    const resumeStore = useResumeStore();
    const profileStore = useProfileStore();
    useRoute();
    storeToRefs(resumeStore);
    const formTitle = computed(() => props.title);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    ref(false);
    const isUpdated = ref(false);
    const schema = z.object({
      providers: z.array(z.string()).nonempty("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0445\u043E\u0442\u044F \u0431\u044B 1 \u0441\u0435\u0440\u0432\u0438\u0441"),
      title: z.string(),
      first_name: z.string(),
      last_name: z.string(),
      middle_name: z.string().optional().nullable(),
      email: z.string(),
      is_preferred_email: z.boolean(),
      birth_date: z.string(),
      city_id: z.number(),
      gender_id: z.number(),
      business_trip_id: z.number(),
      relocation_type_id: z.number(),
      work_types: z.array(z.number()).nonempty("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0445\u043E\u0442\u044F \u0431\u044B 1")
    });
    const { values, errors, validate, meta, setTouched, setErrors, handleSubmit } = useForm({
      initialValues: {
        providers: [],
        title: null,
        first_name: null,
        last_name: null,
        middle_name: null,
        email: null,
        is_preferred_email: false,
        birth_date: null,
        city_id: null,
        gender_id: null,
        business_trip_id: null,
        relocation_type_id: null,
        move_able_cities: [],
        work_types: []
      },
      initialTouched: true,
      validationSchema: toTypedSchema(schema)
    });
    const { createResume } = resumeStore;
    const state = reactive({
      title: {
        is_hidden: false
      },
      first_name: {
        is_hidden: false
      },
      last_name: {
        is_hidden: false
      },
      middle_name: {
        is_hidden: false
      },
      email: {
        is_hidden: false
      },
      is_preferred_email: {
        is_hidden: false
      },
      city_id: {
        is_hidden: false
      },
      move_able_cities: {
        is_hidden: true
      },
      metros: {
        is_hidden: true
      },
      professional_roles: {
        is_hidden: true
      },
      birth_date: {
        is_hidden: true
      },
      salary: {
        is_hidden: true
      },
      gender_id: {
        is_hidden: true
      },
      business_trip_id: {
        is_hidden: true
      },
      work_types: {
        is_hidden: true
      },
      relocation_type_id: {
        is_hidden: true
      }
    });
    const isMovableCitiesEnabled = computed(() => {
      const relocation_id = parseInt(values.relocation_type_id);
      return relocation_id === 148 || relocation_id === 149;
    });
    const { searchCities } = profileStore;
    const dictionaryStore = useDictionaryStore();
    const cityOptions = ref([]);
    const moveableCityOptions = ref([]);
    const genderOptions = computed(() => {
      return dictionaryStore.resume_genders.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const businessTripOptions = computed(() => {
      return dictionaryStore.business_trips.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const relocationTypeOptions = computed(() => {
      return dictionaryStore.relocation_types.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const { getCityName, getCityNameFromArea2 } = useResumeHooks();
    const updateCityInput = async (newValue = "") => {
      var _a;
      if (newValue.length < 2) {
        return;
      }
      const items = (_a = await searchCities({ search: newValue })) != null ? _a : [];
      cityOptions.value = items.map((item) => ({
        value: item.id,
        name: getCityNameFromArea2(item)
      }));
    };
    const updateMoveableCityInput = async (newValue = "") => {
      var _a;
      const items = (_a = await searchCities({ search: newValue })) != null ? _a : [];
      moveableCityOptions.value = items.map((item) => ({
        value: item.id,
        name: item.name
      }));
    };
    const { errors: serverErrors, handleErrorResponse } = useFormValidation(state);
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    const isLoading = ref(false);
    const block_loader = ref();
    const errorMessageElement = ref();
    const errorMessage = ref(null);
    const scrollTop = () => {
      (void 0).scrollTo(0, 0);
    };
    const onSubmit = handleSubmit((submittedValues) => {
      save();
    });
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.valid) {
        console.log(1);
        errorMessage.value = "\u0412\u0430\u043C \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u0437\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C";
        scrollTop();
        errorMessageElement.value.scrollIntoView({ behavior: "smooth" });
        return;
      }
      setErrors({});
      errorMessage.value = "";
      isLoading.value = true;
      scrollTop();
      errorMessageElement.value.scrollIntoView({ behavior: "smooth" });
      let resData = await createResume(unref(values));
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        isLoading.value = false;
        return;
      }
      isLoading.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
      const resume_id = resData.data.data.id;
      setTimeout(() => {
        console.log("redirecting...");
        navigateTo({ name: "my-resume-id", params: { id: resume_id } });
      }, 100);
      isLoading.value = false;
      if (resData.data.hasOwnProperty("errors")) {
        setErrors(resData.data.errors);
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = false;
    };
    __expose({
      onSubmit,
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BlockLoader = __nuxt_component_0;
      const _component_CreateResumeProvidersInput = __nuxt_component_1;
      const _component_VeeBirthDatePicker = __nuxt_component_2;
      const _component_VeeSelectWithSearch = __nuxt_component_0$1;
      const _component_LazyVeeCustomSelect = __nuxt_component_4_lazy;
      const _component_VeeMultiSelectWithSearch = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box w-box--main w-box-resume" }, _attrs))}><div class="w-box-head"><h1 class="title">${ssrInterpolate(unref(formTitle))}</h1><div class="descr"> \u041F\u043E\u043B\u0443\u0447\u0430\u0439\u0442\u0435 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u043E \u043D\u043E\u0432\u044B\u0445 \u043F\u043E \u0441\u043E\u0437\u0434\u0430\u043D\u043D\u043E\u043C\u0443 \u0437\u0430\u043F\u0440\u043E\u0441\u0443 </div><span class="arrow"></span></div><div class="${ssrRenderClass([{ disabled: unref(isLoading) }, "w-box-body"])}">`);
      if (unref(isLoading)) {
        _push(ssrRenderComponent(_component_BlockLoader, {
          ref_key: "block_loader",
          ref: block_loader
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div></div><form${ssrRenderAttr("validation-schema", unref(schema))}>`);
      _push(ssrRenderComponent(_component_CreateResumeProvidersInput, { name: "providers" }, null, _parent));
      _push(`<div class="input-row"><label for="name">\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438<b>*</b></label><div class="input-wrapper"><div class="c1 mt-1">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "title",
        placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435"
      }, null, _parent));
      _push(`</div></div></div><div class="input-row"><label for="name">\u0418\u043C\u044F \u0438 \u0444\u0430\u043C\u0438\u043B\u0438\u044F <b>*</b></label><div class="input-wrapper"><div class="c2"><div class="input-wrapper">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "first_name",
        placeholder: "\u0418\u043C\u044F"
      }, null, _parent));
      _push(`</div><div class="input-wrapper">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "last_name",
        placeholder: "\u0424\u0430\u043C\u0438\u043B\u0438\u044F"
      }, null, _parent));
      _push(`</div></div><div class="c1 mt-1">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "middle_name",
        placeholder: "\u041E\u0442\u0447\u0435\u0441\u0442\u0432\u043E"
      }, null, _parent));
      _push(`</div></div></div><div class="input-row"><label for="resume_email">\u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0447\u0442\u0430<b>*</b></label><div class="input-wrapper">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "email",
        type: "email",
        placeholder: "\u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0447\u0442\u0430"
      }, null, _parent));
      if (!unref(state).is_preferred_email.is_hidden) {
        _push(ssrRenderComponent(ResumeCheckboxInput, {
          class: "mt-2",
          name: "is_preferred_email",
          label: "Email \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043B\u0438 \u043F\u0440\u0435\u0434\u043F\u043E\u0447\u0442\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u043C \u0441\u043F\u043E\u0441\u043E\u0431\u043E\u043C \u0441\u0432\u044F\u0437\u0438"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="input-row"><label>\u0414\u0430\u0442\u0430 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F <b>*</b></label><div class="input-wrapper"><div class="mb-1">`);
      _push(ssrRenderComponent(_component_VeeBirthDatePicker, { name: "birth_date" }, null, _parent));
      _push(`</div></div></div><div class="input-row"><label>\u0413\u043E\u0440\u043E\u0434 \u043F\u0440\u043E\u0436\u0438\u0432\u0430\u043D\u0438\u044F:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_VeeSelectWithSearch, {
        options: unref(cityOptions),
        name: "city_id",
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0433\u043E\u0440\u043E\u0434",
        onInput: updateCityInput
      }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u041F\u043E\u043B\u044C:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_LazyVeeCustomSelect, {
        options: unref(genderOptions),
        name: "gender_id",
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u0413\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C \u043A \u043A\u043E\u043C\u0430\u043D\u0434\u0438\u0440\u043E\u0432\u043A\u0430\u043C:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_LazyVeeCustomSelect, {
        options: unref(businessTripOptions),
        name: "business_trip_id",
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u0413\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C \u043A \u0440\u0435\u043B\u043E\u043A\u0430\u0446\u0438\u044E:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_LazyVeeCustomSelect, {
        options: unref(relocationTypeOptions),
        name: "relocation_type_id",
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div>`);
      if (unref(isMovableCitiesEnabled)) {
        _push(`<div class="input-row"><label>\u0413\u043E\u0440\u043E\u0434\u043E\u0432 \u0432 \u043A\u043E\u0442\u043E\u0440\u044B\u043C \u0433\u043E\u0442\u043E\u0432 \u043F\u0435\u0440\u0435\u0435\u0445\u0430\u0442\u044C:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, {
          name: "move_able_cities",
          options: unref(moveableCityOptions),
          placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435",
          onInput: updateMoveableCityInput
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="input-row pb-4"><label>\u0422\u0438\u043F \u0440\u0430\u0431\u043E\u0442\u044B:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, {
        name: "work_types",
        options: unref(dictionaryStore).work_types_formatted,
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div></form></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/DraftCard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=DraftCard-BCGYBUfv.mjs.map
