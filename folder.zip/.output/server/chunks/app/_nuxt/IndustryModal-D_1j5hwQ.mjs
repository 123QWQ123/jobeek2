import { a as __nuxt_component_0$1$1 } from './FilterIcon-Bk66Krbt.mjs';
import { useSSRContext, ref, watch, toRefs, computed, mergeProps, unref, resolveDirective, isRef } from 'vue';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderAttr, ssrIncludeBooleanAttr, ssrInterpolate, ssrRenderList, ssrRenderComponent, ssrGetDirectiveProps } from 'vue/server-renderer';
import { _ as _imports_0 } from './check-BGWLIG1L.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { u as useQueryParams } from './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main$2 = {
  __name: "IndustrySubItem",
  __ssrInlineRender: true,
  props: {
    parent_id: {
      required: true
    },
    id: {
      required: true
    },
    checked: {
      required: false
    },
    label: {
      required: false
    }
  },
  emits: ["toggle"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const toggle = (newValue) => {
      emit("toggle", props.id, newValue);
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesCheckbox = __nuxt_component_0$1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "filter-form-item" }, _attrs))}><div class="filter-tree-selector-content">`);
      _push(ssrRenderComponent(_component_VacanciesCheckbox, {
        onChange: toggle,
        label: props.label,
        checked: props.checked
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/IndustrySubItem.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0$1 = _sfc_main$2;
const _imports_1 = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='16'%20height='16'%20fill='white'%20class='bi%20bi-dash'%20viewBox='0%200%2016%2016'%3e%3cpath%20d='M4%208a.5.5%200%200%201%20.5-.5h7a.5.5%200%200%201%200%201h-7A.5.5%200%200%201%204%208z'/%3e%3c/svg%3e";
const _sfc_main$1 = {
  __name: "IndustryItem",
  __ssrInlineRender: true,
  props: {
    item: {
      required: true,
      default: {}
    },
    items: {
      required: true,
      default: {}
    },
    isOpen: {
      required: false,
      default: false
    },
    checked: {
      required: false,
      default: false
    }
  },
  emits: ["remove", "add", "toggleSubItem"],
  setup(__props, { emit: __emit }) {
    var _a, _b;
    const emit = __emit;
    const props = __props;
    const item = ref((_a = props.item) != null ? _a : {});
    const items = ref((_b = props.item.items) != null ? _b : []);
    watch(
      () => props.items,
      () => {
        items.value = props.items;
      }
    );
    const isOpen = ref(props.isOpen);
    const { checked } = toRefs(props);
    const toggleSubItem = (id, checked2) => {
      if (checked2) {
        emit("add", [id]);
      } else {
        emit("remove", [id, item.value.id]);
      }
    };
    const anyChecked = computed(() => {
      return props.items.some((item2) => item2.checked === true);
    });
    const anyUnchecked = computed(() => {
      return props.items.some((item2) => item2.checked === false);
    });
    const isHalfChecked = computed(() => {
      return anyChecked.value && anyUnchecked.value;
    });
    const allChecked = computed(() => {
      return !anyUnchecked.value;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesFiltersIndustrySubItem = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "filter-tree-selector-item filter-tree-selector-item_has-children-has-action" }, _attrs))} data-v-4200c3c2><div class="filter-form-item" data-v-4200c3c2><div class="filter-tree-selector-content" data-v-4200c3c2><div class="check-block" data-v-4200c3c2><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="${ssrRenderClass([{ expanded: props.isOpen }, "bi bi-caret-right cursor-pointer"])}" viewBox="0 0 16 16" data-v-4200c3c2><path d="M6 12.796V3.204L11.481 8 6 12.796zm.659.753 5.48-4.796a1 1 0 0 0 0-1.506L6.66 2.451C6.011 1.885 5 2.345 5 3.204v9.592a1 1 0 0 0 1.659.753z" data-v-4200c3c2></path></svg><div class="checkbox ms-1"${ssrRenderAttr("title", unref(item).checked + "-" + unref(isHalfChecked))} data-v-4200c3c2><input type="checkbox"${ssrIncludeBooleanAttr(unref(checked)) ? " checked" : ""} class="${ssrRenderClass({ is_half_checked: unref(isHalfChecked) })}" data-v-4200c3c2><div class="checkbox-mask" data-v-4200c3c2>`);
      if (unref(allChecked)) {
        _push(`<img${ssrRenderAttr("src", _imports_0)} alt="#" data-v-4200c3c2>`);
      } else {
        _push(`<img${ssrRenderAttr("src", _imports_1)} alt="#" data-v-4200c3c2>`);
      }
      _push(`</div></div><label${ssrRenderAttr("for", `industry_${unref(item).id}`)} data-v-4200c3c2>${ssrInterpolate(unref(item).title)}</label></div></div></div>`);
      if (unref(isOpen)) {
        _push(`<div class="filter-tree-selector__items" data-v-4200c3c2><!--[-->`);
        ssrRenderList(unref(items), (sub_item) => {
          _push(`<div class="filter-tree-selector-item filter-tree-selector-item_no-children" data-v-4200c3c2>`);
          _push(ssrRenderComponent(_component_VacanciesFiltersIndustrySubItem, {
            onToggle: toggleSubItem,
            id: sub_item.id,
            parent_id: unref(item).id,
            checked: sub_item.checked,
            label: sub_item.title
          }, null, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/IndustryItem.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-4200c3c2"]]);
const _sfc_main = {
  __name: "IndustryModal",
  __ssrInlineRender: true,
  props: {
    items: {
      required: true
    },
    title: {
      required: true
    },
    isOpen: {
      required: false
    },
    modelValue: {
      required: false
    },
    name: {
      required: true
    }
  },
  emits: {
    close: {
      required: true
    },
    "update:modelValue": {
      required: false
    }
  },
  setup(__props, { emit: __emit }) {
    var _a, _b, _c;
    const props = __props;
    const { isOpen, items: industries, modelValue, title } = props;
    const emit = __emit;
    const { updateQueryParam, getQueryParam } = useQueryParams();
    const industry_ids = ref((_a = getQueryParam("industries")) != null ? _a : []);
    watch(
      () => industry_ids.value,
      (newValues) => {
        console.log(newValues);
      }
    );
    ref((_b = props.items) != null ? _b : []);
    const selectedSpecs = ref((_c = industry_ids.value) != null ? _c : []);
    const items = ref([]);
    const isLoading = ref(false);
    const addIds = (new_ids) => {
      let ids = [...selectedSpecs.value];
      ids = new_ids.concat(ids);
      selectedSpecs.value = ids;
      prepare(props.items, false);
    };
    const removeIds = (old_ids) => {
      let ids = [...selectedSpecs.value];
      ids = ids.filter((id) => !old_ids.includes(id));
      selectedSpecs.value = ids;
      prepare(props.items, false);
    };
    const searchInput = ref("");
    const isSearching = computed(() => {
      if (searchInput.value === "") {
        return false;
      }
      return true;
    });
    const prepare = (newValues, is_first = false) => {
      let dynamicItems = [];
      if (isSearching.value) {
        dynamicItems = [
          ...newValues.map((item) => {
            item.items = [...item.items].filter(
              (sub_item) => sub_item.title.toLowerCase().includes(searchInput.value.toLowerCase())
            );
            return item;
          })
        ];
      } else {
        dynamicItems = [...newValues];
      }
      dynamicItems = dynamicItems.map((item) => {
        const is_parent_checked = selectedSpecs.value.includes(item.id);
        item.checked = is_parent_checked;
        const d_items = item.items.map((sub_item) => {
          if (!is_parent_checked) {
            sub_item.checked = selectedSpecs.value.includes(sub_item.id);
          } else {
            if (is_first) {
              sub_item.checked = true;
            } else {
              sub_item.checked = selectedSpecs.value.includes(sub_item.id);
            }
          }
          return sub_item;
        });
        if (!d_items.some((item2) => item2.checked === false)) {
          item.checked = true;
          const ids = d_items.map((item2) => item2.id);
          ids.push(item.id);
          const new_ids = Array.from(new Set([...selectedSpecs.value].concat(ids)));
          selectedSpecs.value = new_ids;
        }
        item.items = d_items;
        return item;
      });
      items.value = dynamicItems;
    };
    watch(
      () => industry_ids.value,
      () => {
        prepare(props.items);
      }
    );
    const onClickOutside = (e) => {
      if (e.target.classList.contains("filter-modal-container")) {
        close();
      }
    };
    const close = () => emit("close");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesFiltersIndustryItem = __nuxt_component_0;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["filter-modal-overlay filter-modal-overlay_visible", { hidden: !props.isOpen }]
      }, _attrs))} data-v-dd026118><div class="filter-modal-container filter-modal-container_visible" data-v-dd026118><div${ssrRenderAttrs(mergeProps({ class: "filter-modal" }, ssrGetDirectiveProps(_ctx, _directive_click_outside, onClickOutside)))} data-v-dd026118><div class="filter-modal-header" data-v-dd026118><span class="filter-modal-title" data-v-dd026118>${ssrInterpolate(unref(title))}</span><br data-v-dd026118><div class="filter-tree-selector-popup-search" data-v-dd026118><fieldset class="input-wrapper" data-v-dd026118><input placeholder="\u0411\u044B\u0441\u0442\u0440\u044B\u0439 \u043F\u043E\u0438\u0441\u043A" type="search" class="filter-input-text"${ssrRenderAttr("value", unref(searchInput))} data-v-dd026118></fieldset></div></div><div class="filter-tree-selector-popup" data-v-dd026118>`);
      if (!unref(isLoading)) {
        _push(`<div class="filter-tree-selector-popup-content" data-v-dd026118>`);
        if (unref(isSearching)) {
          _push(`<!--[-->`);
          ssrRenderList(unref(items), (item) => {
            _push(ssrRenderComponent(_component_VacanciesFiltersIndustryItem, {
              item,
              items: item.items,
              key: item.id,
              onAdd: addIds,
              onRemove: removeIds,
              checked: item.checked,
              "is-open": true
            }, null, _parent));
          });
          _push(`<!--]-->`);
        } else {
          _push(`<!--[-->`);
          ssrRenderList(unref(items), (item) => {
            _push(ssrRenderComponent(_component_VacanciesFiltersIndustryItem, {
              item,
              items: item.items,
              onAdd: addIds,
              onRemove: removeIds,
              key: item.id,
              checked: item.checked,
              modelValue: unref(selectedSpecs),
              "onUpdate:modelValue": ($event) => isRef(selectedSpecs) ? selectedSpecs.value = $event : null
            }, null, _parent));
          });
          _push(`<!--]-->`);
        }
        _push(`</div>`);
      } else {
        _push(`<div class="filter-tree-selector-popup-content" data-v-dd026118><div class="ms-2 spinner-grow spinner-grow-sm" role="status" data-v-dd026118><span class="visually-hidden" data-v-dd026118>Loading...</span></div></div>`);
      }
      _push(`</div><div class="filter-modal-error filter-modal-error_hidden" data-v-dd026118></div><div class="filter-modal-footer mt-3" data-v-dd026118><div class="filter-tree-selector-popup-footer" data-v-dd026118><div class="filter-form-spacer" data-v-dd026118><button class="btn button-xs sign-in-btn" type="button" data-v-dd026118><span data-v-dd026118>\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C</span></button></div><div class="filter-form-spacer" data-v-dd026118><button class="btn button-accent" type="button" data-v-dd026118><span data-v-dd026118>\u0412\u044B\u0431\u0440\u0430\u0442\u044C</span></button></div></div></div></div><div class="filter-modal-close-button" data-v-dd026118><button type="button" class="btn-close btn-close-white" data-v-dd026118></button></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/IndustryModal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const IndustryModal = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-dd026118"]]);

export { IndustryModal as default };
//# sourceMappingURL=IndustryModal-D_1j5hwQ.mjs.map
