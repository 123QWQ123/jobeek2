import { V as VeeSelectWithSearch_vue_vue_type_style_index_0_lang } from './VeeSelectWithSearch-styles-1.mjs-DH5SIHl1.mjs';
import { V as VeeSelectWithSearch_vue_vue_type_style_index_1_scoped_e66e6be6_lang } from './VeeSelectWithSearch-styles-2.mjs-BWLY_ldn.mjs';

const VeeSelectWithSearchStyles_5JnB8xtL = [VeeSelectWithSearch_vue_vue_type_style_index_0_lang, VeeSelectWithSearch_vue_vue_type_style_index_1_scoped_e66e6be6_lang];

export { VeeSelectWithSearchStyles_5JnB8xtL as default };
//# sourceMappingURL=VeeSelectWithSearch-styles.5JnB8xtL.mjs.map
