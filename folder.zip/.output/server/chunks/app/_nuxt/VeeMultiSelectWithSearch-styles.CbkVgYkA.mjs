import { V as VeeMultiSelectWithSearch_vue_vue_type_style_index_1_scoped_5c732ac5_lang } from './VeeMultiSelectWithSearch-styles-2.mjs-DjvyX1JM.mjs';

const VeeMultiSelectWithSearchStyles_CbkVgYkA = [VeeMultiSelectWithSearch_vue_vue_type_style_index_1_scoped_5c732ac5_lang];

export { VeeMultiSelectWithSearchStyles_CbkVgYkA as default };
//# sourceMappingURL=VeeMultiSelectWithSearch-styles.CbkVgYkA.mjs.map
