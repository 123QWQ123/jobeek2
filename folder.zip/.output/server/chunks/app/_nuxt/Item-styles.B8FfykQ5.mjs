const Item_vue_vue_type_style_index_0_scoped_cd1d43bc_lang = ".absoluted_icon[data-v-cd1d43bc]{cursor:pointer;font-size:1rem;left:-.5rem;max-width:3rem;position:absolute;top:.5rem;z-index:1}.absoluted_icon svg[data-v-cd1d43bc]{height:24px;width:24px}";

const ItemStyles_B8FfykQ5 = [Item_vue_vue_type_style_index_0_scoped_cd1d43bc_lang];

export { ItemStyles_B8FfykQ5 as default };
//# sourceMappingURL=Item-styles.B8FfykQ5.mjs.map
