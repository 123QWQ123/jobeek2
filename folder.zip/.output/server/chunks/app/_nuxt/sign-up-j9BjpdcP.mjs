import { _ as _imports_0$2, a as __nuxt_component_0 } from './i-XlC_iSFx.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-BdrY0gEc.mjs';
import { _ as __nuxt_component_2 } from './Loader-UZvrxmyZ.mjs';
import { useSSRContext, computed, ref, reactive, watch, onUpdated, unref, withCtx, createVNode, toDisplayString, createTextVNode } from 'vue';
import { u as useHead, k as useAuthStore, e as useRoute, a as useRouter } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrRenderClass, ssrLooseContain } from 'vue/server-renderer';
import { _ as _imports_0 } from './jobeek-dark-BM969tB2.mjs';
import { _ as _imports_0$1 } from './check-BGWLIG1L.mjs';
import IMask from 'imask';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './BaseButton-CWRjb9_h.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "sign-up",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F"
    });
    const authStore = useAuthStore();
    computed(() => authStore.isAuthed);
    const phoneDisabled = ref(false);
    ref(true);
    const isLoading = ref(false);
    ref(false);
    ref(null);
    useRoute();
    const state = reactive({
      disabled: {
        val: "",
        isValid: true
      },
      phone: {
        val: "",
        isValid: true
      },
      i_agree: {
        val: false,
        isValid: true
      },
      code: {
        val: null,
        isValid: true
      },
      session: null,
      isFormValid: true,
      error: null,
      success: null
    });
    useRouter();
    const isRegisterTab = ref(true);
    const isConfirmTab = ref(false);
    const isFirstTimeCodeSent = ref(true);
    watch(
      () => state.code.val,
      (newValue) => {
        if (newValue && String(newValue).length !== 4) {
          state.code.isValid = false;
          return;
        }
        state.code.isValid = true;
      }
    );
    const isConfirmSMSButton = computed(() => {
      if (isLoading.value)
        return false;
      if (state.code.val) {
        return String(state.code.val).length === 4;
      }
      return false;
    });
    const isRegisterButton = computed(() => {
      if (isLoading.value)
        return false;
      if (state.phone.val) {
        return String(state.phone.val).length === 11;
      }
      return false;
    });
    function close() {
      state.error = null;
    }
    const phoneInputElement = ref();
    onUpdated(() => {
      if (phoneInputElement.value) {
        phoneMask.value = new IMask(phoneInputElement.value, {
          mask: "+{7}(000)000-00-00"
        });
        phoneInputElement.value.addEventListener("input", () => {
          state.phone.val = phoneMask.value.unmaskedValue;
        });
        phoneMask.value.unmaskedValue = state.phone.val;
      }
    });
    const phoneMask = ref(null);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_base_modal = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Loader = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-d1424ce1>`);
      _push(ssrRenderComponent(_component_base_modal, {
        show: !!unref(state).error,
        title: "Error occured",
        type: "error",
        onClose: close
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<p data-v-d1424ce1${_scopeId}>${ssrInterpolate(unref(state).error)}</p>`);
          } else {
            return [
              createVNode("p", null, toDisplayString(unref(state).error), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_base_modal, {
        show: !!unref(state).success,
        title: "Success",
        onClose: close
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<p data-v-d1424ce1${_scopeId}>${ssrInterpolate(unref(state).success)}</p>`);
          } else {
            return [
              createVNode("p", null, toDisplayString(unref(state).success), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<main class="main enter-page sign-up" role="main" data-v-d1424ce1><div class="enter-page-content" data-v-d1424ce1>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "logo"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="#" data-v-d1424ce1${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "#"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      if (isRegisterTab.value) {
        _push(`<form class="enter-form" data-v-d1424ce1><h1 data-v-d1424ce1>\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F</h1><div class="i-wrap" data-v-d1424ce1><input${ssrIncludeBooleanAttr(phoneDisabled.value) ? " disabled" : ""} type="tel" name="tel" placeholder="\u041D\u043E\u043C\u0435\u0440 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430" autofocus data-v-d1424ce1></div><div class="help-box" data-v-d1424ce1><div class="${ssrRenderClass([{ "border-bottom border-danger": !unref(state).i_agree.isValid }, "check-block"])}" data-v-d1424ce1><div class="checkbox" data-v-d1424ce1><input type="checkbox" id="agree"${ssrIncludeBooleanAttr(Array.isArray(unref(state).i_agree.val) ? ssrLooseContain(unref(state).i_agree.val, null) : unref(state).i_agree.val) ? " checked" : ""} autofocus data-v-d1424ce1><div class="checkbox-mask" data-v-d1424ce1><img${ssrRenderAttr("src", _imports_0$1)} alt="#" data-v-d1424ce1></div></div><label for="agree" data-v-d1424ce1>\u0421\u043E\u0433\u043B\u0430\u0441\u0435\u043D \u0441 <a href="#" data-v-d1424ce1>\u043F\u0440\u0430\u0432\u0438\u043B\u0430\u043C\u0438 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445</a></label></div></div><button class="btn button-accent" type="submit"${ssrIncludeBooleanAttr(!unref(isRegisterButton)) ? " disabled" : ""} data-v-d1424ce1> \u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F `);
        if (isLoading.value) {
          _push(ssrRenderComponent(_component_Loader, { class: "text-light spinner-border-sm" }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</button></form>`);
      } else {
        _push(`<!---->`);
      }
      if (isConfirmTab.value) {
        _push(`<form class="enter-form" data-v-d1424ce1><h1 data-v-d1424ce1>\u041F\u043E\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430</h1><div class="i-wrap" data-v-d1424ce1><div class="note" data-v-d1424ce1><img${ssrRenderAttr("src", _imports_0$2)} alt="#" data-v-d1424ce1><p class="" data-v-d1424ce1>`);
        if (isFirstTimeCodeSent.value) {
          _push(`<span data-v-d1424ce1> \u041C\u044B \u0432\u0430\u043C \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u043B\u0438 \u043A\u043E\u0434 \u043F\u043E\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043D\u0430 \u0442\u0435\u043B\u0435\u0444\u043E\u043D </span>`);
        } else {
          _push(`<span data-v-d1424ce1> \u041C\u044B \u0432\u0430\u043C \u0435\u0449\u0435 \u0440\u0430\u0437 \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u043B\u0438 \u043A\u043E\u0434 \u043F\u043E\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043D\u0430 \u0442\u0435\u043B\u0435\u0444\u043E\u043D </span>`);
        }
        _push(`<span class="text-success" data-v-d1424ce1>${ssrInterpolate(unref(state).phone.val)}.</span><a href="#" class="fw-medium" data-v-d1424ce1> \u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043D\u043E\u043C\u0435\u0440 </a></p></div><input class="mt-2" type="number" name="code"${ssrRenderAttr("value", unref(state).code.val)} placeholder="\u041A\u043E\u0434 \u043F\u043E\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F" autofocus data-v-d1424ce1>`);
        if (!unref(state).code.isValid) {
          _push(`<span class="text text-danger" data-v-d1424ce1> \u0412\u0432\u0435\u0434\u0438\u0442\u0435 4 \u0437\u043D\u0430\u0447\u043D\u044B\u0439 \u043A\u043E\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F </span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<span class="col-auto px-3" type="button" disabled data-v-d1424ce1> \u041D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u0438 \u043A\u043E\u0434? <a class="link link-primary" data-v-d1424ce1> \u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435 \u0440\u0430\u0437 </a></span></div><button class="btn button-accent mt-4" type="submit"${ssrIncludeBooleanAttr(!unref(isConfirmSMSButton)) ? " disabled" : ""} data-v-d1424ce1> \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C `);
        if (isLoading.value) {
          _push(ssrRenderComponent(_component_Loader, { class: "text-light spinner-border-sm" }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</button></form>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="f-prompt" data-v-d1424ce1> \u0423\u0436\u0435 \u0435\u0441\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442? `);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "sign-in" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0412\u043E\u0439\u0434\u0438\u0442\u0435!`);
          } else {
            return [
              createTextVNode("\u0412\u043E\u0439\u0434\u0438\u0442\u0435!")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></main></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/sign-up.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const signUp = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-d1424ce1"]]);

export { signUp as default };
//# sourceMappingURL=sign-up-j9BjpdcP.mjs.map
