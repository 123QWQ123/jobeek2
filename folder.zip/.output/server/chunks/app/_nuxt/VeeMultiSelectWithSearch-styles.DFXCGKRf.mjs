import { V as VeeMultiSelectWithSearch_vue_vue_type_style_index_0_lang } from './VeeMultiSelectWithSearch-styles-1.mjs-D1HKKn17.mjs';
import { V as VeeMultiSelectWithSearch_vue_vue_type_style_index_1_scoped_5c732ac5_lang } from './VeeMultiSelectWithSearch-styles-2.mjs-DjvyX1JM.mjs';

const VeeMultiSelectWithSearchStyles_DFXCGKRf = [VeeMultiSelectWithSearch_vue_vue_type_style_index_0_lang, VeeMultiSelectWithSearch_vue_vue_type_style_index_1_scoped_5c732ac5_lang];

export { VeeMultiSelectWithSearchStyles_DFXCGKRf as default };
//# sourceMappingURL=VeeMultiSelectWithSearch-styles.DFXCGKRf.mjs.map
