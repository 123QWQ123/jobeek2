globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './SearchMobile-WfXJ1gHL.mjs';
import { _ as __nuxt_component_1$1 } from './ConnectedProviders-DKmnzzBN.mjs';
import { _ as __nuxt_component_0$2 } from './nuxt-link-BdrY0gEc.mjs';
import { u as useMyVacancySortingOptions, a as useMyVacancyPerPageOptions, b as __nuxt_component_1$1$1, _ as __nuxt_component_1$2 } from './DraftList-BRMHAaUX.mjs';
import { C as CustomSelect } from './search-CNCM2ROA.mjs';
import { computed, watch, mergeProps, useSSRContext, ref, unref, isRef, withAsyncContext, withCtx, createTextVNode, resolveDirective, toDisplayString } from 'vue';
import { u as useCurrencyOptions } from './useCurrencyOptions-BsifIVKS.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderAttr, ssrGetDirectiveProps, ssrRenderStyle } from 'vue/server-renderer';
import { _ as _imports_2, a as _imports_3 } from './sj-CUMJdhcR.mjs';
import { _ as _imports_0$2 } from './check-BGWLIG1L.mjs';
import moment from 'moment';
import { u as useHead, k as useAuthStore, d as navigateTo, l as useVacancyStore, e as useRoute, s as storeToRefs } from '../server.mjs';
import { u as useQueryParams } from './useQueryParams-Bpl0Cf82.mjs';
import { _ as __nuxt_component_0$1 } from './PageLoader-CgN00RaA.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { _ as _imports_0$1 } from './crown2-yZ91oAVe.mjs';
import { P as Premium } from './Premium-A3GoIzm5.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './superjob-DOWPfj1m.mjs';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './state-D1MfAAni.mjs';

const _imports_0 = "data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cg%20clip-path='url(%23clip0_310_5741)'%3e%3cpath%20fill-rule='evenodd'%20clip-rule='evenodd'%20d='M23.8046%2011.8303C23.8046%2014.1708%2023.12%2016.4587%2021.8373%2018.4048C20.5545%2020.3508%2018.7313%2021.8676%2016.5982%2022.7632C14.4651%2023.6589%2012.1179%2023.8932%209.85339%2023.4366C7.5889%2022.98%205.50882%2021.853%203.87621%2020.198C2.2436%2018.543%201.13178%2016.4345%200.681345%2014.1389C0.230909%2011.8434%200.462089%209.46406%201.34565%207.30173C2.22921%205.1394%203.72548%203.29123%205.64522%201.99092C7.56497%200.690616%209.82198%20-0.00341753%2012.1308%20-0.00341753C13.664%20-0.00384118%2015.1822%200.301956%2016.5987%200.896506C18.0152%201.49106%2019.3023%202.36271%2020.3864%203.46165C21.4705%204.5606%2022.3304%205.86531%2022.9169%207.30123C23.5034%208.73716%2023.8051%2010.2762%2023.8046%2011.8303Z'%20fill='%23D20A11'/%3e%3cpath%20fill-rule='evenodd'%20clip-rule='evenodd'%20d='M7.0391%206.10693V10.1665C7.29593%209.82431%207.62676%209.54637%208.00615%209.35408C8.38554%209.16178%208.80338%209.06025%209.22755%209.0573C9.63346%209.05094%2010.0356%209.13688%2010.4045%209.30881C10.7211%209.44729%2010.9948%209.67015%2011.1965%209.9537C11.3748%2010.2137%2011.4993%2010.5077%2011.5623%2010.8179C11.6403%2011.3027%2011.6733%2011.7939%2011.6609%2012.285V16.6251H9.75239V12.7138C9.77877%2012.219%209.7435%2011.7229%209.64742%2011.237C9.57836%2011.033%209.44401%2010.8582%209.26571%2010.7405C9.06169%2010.6094%208.82321%2010.5442%208.58183%2010.5534C8.28507%2010.5493%207.99346%2010.6321%207.74208%2010.7921C7.48986%2010.9625%207.30248%2011.215%207.21087%2011.5079C7.07595%2011.9645%207.01789%2012.4408%207.0391%2012.917V16.6251H5.14648V6.10693H7.05501H7.0391Z'%20fill='white'/%3e%3cpath%20fill-rule='evenodd'%20clip-rule='evenodd'%20d='M14.4984%206.10693V10.1665C14.7552%209.82431%2015.086%209.54637%2015.4654%209.35408C15.8448%209.16178%2016.2626%209.06025%2016.6868%209.0573C17.0937%209.05111%2017.4969%209.13703%2017.8669%209.30881C18.1824%209.44778%2018.455%209.6706%2018.6558%209.9537C18.8341%2010.2137%2018.9585%2010.5077%2019.0216%2010.8179C19.0995%2011.3027%2019.1325%2011.7939%2019.1202%2012.285V16.6251H17.2276V12.7138C17.2535%2012.2189%2017.2172%2011.7226%2017.1194%2011.237C17.0503%2011.033%2016.916%2010.8582%2016.7377%2010.7405C16.5338%2010.6092%2016.2952%2010.5439%2016.0538%2010.5534C15.7571%2010.5493%2015.4654%2010.6321%2015.2141%2010.7921C14.9583%2010.9617%2014.7666%2011.2139%2014.6701%2011.5079C14.5375%2011.9649%2014.4795%2012.4409%2014.4984%2012.917V16.6251H12.5898V6.10693H14.4984V6.10693Z'%20fill='white'/%3e%3c/g%3e%3cdefs%3e%3cclipPath%20id='clip0_310_5741'%3e%3crect%20width='24'%20height='24'%20fill='white'/%3e%3c/clipPath%3e%3c/defs%3e%3c/svg%3e";
const _imports_1 = "" + buildAssetsURL("sb.DWep2xFH.svg");
const _sfc_main$4 = {
  __name: "ActiveItem",
  __ssrInlineRender: true,
  props: ["item"],
  setup(__props) {
    const props = __props;
    const { item } = props;
    const hhIncluded = computed(() => {
      if (props.item.providers.length) {
        return !!props.item.providers.find((item2) => {
          return item2.name === "hh";
        });
      }
      return false;
    });
    const hhTotalCount = computed(() => {
      let total = 0;
      if (props.item.providers.length) {
        total += props.item.providers.reduce((acc, item2) => {
          return item2.name === "hh" ? acc + item2.views_count : acc;
        }, 0);
      }
      return total;
    });
    const superjobTotalCount = computed(() => {
      let total = 0;
      if (props.item.providers.length) {
        total += props.item.providers.reduce((acc, item2) => {
          return item2.name === "superjob" ? acc + item2.views_count : acc;
        }, 0);
      }
      return total;
    });
    const totalViewCount = computed(() => {
      return superjobTotalCount.value + hhTotalCount.value;
    });
    const salary_from = computed(() => {
      if (props.item.salary && props.item.salary.hasOwnProperty("from")) {
        return props.item.salary.from;
      }
      return false;
    });
    const salary_to = computed(() => {
      if (props.item.salary && props.item.salary.hasOwnProperty("to")) {
        return props.item.salary.to;
      }
      return false;
    });
    const currency = computed(() => {
      if (props.item.salary && props.item.salary.hasOwnProperty("currency")) {
        const options = useCurrencyOptions();
        const found = options.find(
          (item2) => item2.value === props.item.salary.currency
        );
        if (found)
          return found.symbol;
        return props.item.salary.currency;
      }
      return "RUB";
    });
    const cityAddress = computed(() => {
      if (item.hasOwnProperty("cities")) {
        if (item.cities.length === 1) {
          return item.cities[0].name;
        } else {
          return item.cities.reduce((acc, item2) => acc + item2.name + ", ", "").replace(/,*\s$/, "");
        }
      }
      return "no city";
    });
    const isContextMenuShown = ref(false);
    const isViewsShown = ref(false);
    const closeContextMenu = (e) => {
      e.preventDefault();
      isContextMenuShown.value = false;
    };
    computed(() => {
      if (item && item.logo) {
        return item.logo;
      } else {
        if (hhIncluded.value) {
          return new URL("~/assets/img/logos/hh.svg", globalThis._importMeta_.url);
        }
        return new URL("~/assets/img/logos/superjob.svg", globalThis._importMeta_.url);
      }
    });
    const published_date = moment(item == null ? void 0 : item.published_date).locale("ru");
    useVacancyStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$2;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<li${ssrRenderAttrs(_attrs)}><div class="resume-card"><div class="resume-card-body"><div class="resume-card-body-col"><div class="resume-card-name">`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: { name: "create-vacancy", query: { vacancy_id: unref(item).id } },
        class: "title"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref(item).name)}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref(item).name), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<span class="location">${ssrInterpolate(unref(cityAddress))}</span>`);
      if (unref(salary_from) && unref(salary_to)) {
        _push(`<span><span class="price">${ssrInterpolate(_ctx.vueNumberFormat(unref(salary_from), {}))}</span> - <span class="price">${ssrInterpolate(_ctx.vueNumberFormat(unref(salary_to), {}))} ${ssrInterpolate(unref(currency))}</span></span>`);
      } else {
        _push(`<span>`);
        if (unref(salary_from)) {
          _push(`<span class="price">\u041E\u0442 ${ssrInterpolate(_ctx.vueNumberFormat(unref(salary_from), {}))} ${ssrInterpolate(unref(currency))}</span>`);
        } else if (unref(salary_to)) {
          _push(`<span class="price">\u041E\u0442 ${ssrInterpolate(_ctx.vueNumberFormat(unref(salary_to), {}))} ${ssrInterpolate(unref(currency))}</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</span>`);
      }
      _push(`</div></div><div class="resume-card-body-col"><div class="date"> \u0432 ${ssrInterpolate(unref(published_date).format("D"))} ${ssrInterpolate(unref(published_date).format("MMMM"))}</div><div class="resume-counts"><div class="count cursor-pointer"><strong class="js-view-stat">${ssrInterpolate(unref(totalViewCount))}</strong><span>\u041F\u043E\u043A\u0430\u0437\u044B</span></div></div></div></div>`);
      if (unref(isViewsShown)) {
        _push(`<div class="resume-card-stats active"><div class="resume-card-stats-head"><div class="name">\u041F\u043E\u043A\u0430\u0437\u044B</div><button class="close close-stats"> \u0421\u043A\u0440\u044B\u0442\u044C </button></div><div class="resume-card-stats-body"><div class="stat"><strong>${ssrInterpolate(unref(totalViewCount))}</strong><a href="#">\u0412\u0441\u0435 </a></div><div class="stat"><strong>${ssrInterpolate(unref(hhTotalCount))}</strong><a href="#"><img${ssrRenderAttr("src", _imports_0)} alt="#">Hh.ru </a></div><div class="stat"><strong>${ssrInterpolate(unref(superjobTotalCount))}</strong><a href="#"><img${ssrRenderAttr("src", _imports_1)} alt="#">Superjob.ru </a></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="resume-card-options"><span class="status">\u041E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u043E \u0432 ${ssrInterpolate(unref(moment)(unref(item).updated_at).format("HH:mm"))}</span><div class="option-group selector-group"><div class="option"><div class="custom-check-wrap"><div class="theme-checker theme-checker--blue"><input type="checkbox" id="sj"${ssrIncludeBooleanAttr(unref(item).can_publish.hh) ? " checked" : ""}><div class="theme-checker-ui"><div class="circle"></div></div></div><label for="sj"><img${ssrRenderAttr("src", _imports_2)} alt="#"><span>HH</span></label></div></div><div class="option"><div class="custom-check-wrap"><div class="theme-checker theme-checker--blue"><input type="checkbox" id="sj"${ssrIncludeBooleanAttr(unref(item).can_publish.superjob) ? " checked" : ""}><div class="theme-checker-ui"><div class="circle"></div></div></div><label for="sj"><img${ssrRenderAttr("src", _imports_3)} alt="#"><span>Superjob</span></label></div></div></div><div class="d-inline-flex ms-0 ms-lg-auto"><div class="d-inline-flex flex-column flex-lg-row mt-4 mt-lg-0 ms-sm-4"><div class="check-block mb-2 mb-md-1 mb-lg-0 me-lg-3"><div class="checkbox"><input type="checkbox" id="enable-push"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$2)} alt="#"></div></div><label for="enable-push">\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C Push-\u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F </label></div><div class="check-block"><div class="checkbox"><input type="checkbox" id="enable-email-notification"><div class="checkbox-mask"><img${ssrRenderAttr("src", _imports_0$2)} alt="#"></div></div><label for="enable-email-notification">\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C E-mail \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F</label></div></div></div><div${ssrRenderAttrs(mergeProps({ class: "params-button-container ms-auto" }, ssrGetDirectiveProps(_ctx, _directive_click_outside, closeContextMenu, void 0, { once: true })))}><button class="resume-action params-button"><svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.0002 10.8204C14.7557 10.8204 13.5622 11.3148 12.6823 12.1948C11.8023 13.0747 11.3079 14.2682 11.3079 15.5127C11.3079 16.7571 11.8023 17.9506 12.6823 18.8306C13.5622 19.7106 14.7557 20.2049 16.0002 20.2049C17.2446 20.2049 18.4381 19.7106 19.3181 18.8306C20.1981 17.9506 20.6924 16.7571 20.6924 15.5127C20.6924 14.2682 20.1981 13.0747 19.3181 12.1948C18.4381 11.3148 17.2446 10.8204 16.0002 10.8204ZM12.872 15.5127C12.872 14.683 13.2016 13.8874 13.7882 13.3007C14.3749 12.7141 15.1705 12.3845 16.0002 12.3845C16.8298 12.3845 17.6255 12.7141 18.2121 13.3007C18.7988 13.8874 19.1284 14.683 19.1284 15.5127C19.1284 16.3423 18.7988 17.138 18.2121 17.7246C17.6255 18.3113 16.8298 18.6408 16.0002 18.6408C15.1705 18.6408 14.3749 18.3113 13.7882 17.7246C13.2016 17.138 12.872 16.3423 12.872 15.5127ZM13.1811 27.6925C14.1064 27.9134 15.0536 28.0247 16.0046 28.0247C16.9535 28.0237 17.899 27.9116 18.8218 27.6906C19.0644 27.6322 19.2831 27.5005 19.4481 27.3133C19.6131 27.1261 19.7164 26.8926 19.744 26.6446L19.9554 24.7233C19.9912 24.3797 20.1484 24.0601 20.3988 23.8221C20.6491 23.5841 20.9762 23.4433 21.3212 23.4251C21.5506 23.4151 21.7791 23.458 21.9894 23.5502L23.7455 24.3203C23.8982 24.389 24.0636 24.425 24.231 24.4261C24.3984 24.4272 24.5642 24.3933 24.7178 24.3266C24.8723 24.2609 25.0106 24.1633 25.1244 24.0401C26.4157 22.6482 27.3797 20.9854 27.946 19.1733C28.0202 18.9329 28.0179 18.6754 27.9394 18.4363C27.861 18.1973 27.7103 17.9885 27.5081 17.8388L25.9478 16.6876C25.7619 16.5526 25.6107 16.3756 25.5064 16.1709C25.4021 15.9663 25.3477 15.7399 25.3477 15.5102C25.3477 15.2805 25.4021 15.0541 25.5064 14.8494C25.6107 14.6448 25.7619 14.4677 25.9478 14.3327L27.5031 13.1841C27.7059 13.0341 27.857 12.8248 27.9355 12.5851C28.0139 12.3455 28.0159 12.0873 27.941 11.8465C27.3745 10.0341 26.4093 8.37152 25.1163 6.98091C24.945 6.79779 24.721 6.67236 24.4754 6.62194C24.2297 6.57151 23.9745 6.59856 23.7449 6.69937L21.9894 7.47266C21.8079 7.55461 21.6102 7.59778 21.41 7.59778C21.0497 7.59707 20.7023 7.46336 20.4344 7.22229C20.1665 6.98122 19.9971 6.64976 19.9586 6.29146L19.7459 4.37702C19.7185 4.12586 19.6133 3.88953 19.4451 3.70108C19.2768 3.51262 19.0539 3.38147 18.8074 3.32596C17.889 3.12051 16.9518 3.01127 16.0108 3C15.0637 3.01093 14.1202 3.11996 13.1955 3.32533C12.9492 3.38056 12.7263 3.51139 12.5581 3.69951C12.3898 3.88763 12.2845 4.12363 12.257 4.37452L12.0443 6.29021C12.0042 6.64908 11.8331 6.98054 11.5638 7.22115C11.2892 7.45451 10.9426 7.58715 10.5822 7.59653C10.3839 7.59653 10.1868 7.55524 10.0047 7.47516L8.25296 6.70187C8.02259 6.60016 7.76626 6.57274 7.51959 6.62342C7.27292 6.6741 7.04817 6.80036 6.87656 6.98466C5.58529 8.37557 4.62125 10.0375 4.05496 11.849C3.98015 12.0897 3.98211 12.3478 4.06059 12.5873C4.13906 12.8269 4.29015 13.0361 4.4929 13.1859L6.04948 14.3346C6.32734 14.5403 6.52369 14.8374 6.60392 15.1737C6.68415 15.51 6.64312 15.8637 6.48804 16.1727C6.38475 16.3776 6.23473 16.5552 6.0501 16.6914L4.49227 17.8425C4.28983 17.9922 4.13893 18.2011 4.06046 18.4403C3.982 18.6795 3.97985 18.9372 4.05433 19.1776C4.6196 20.9908 5.58373 22.6544 6.87594 24.0463C7.0467 24.2305 7.27062 24.3568 7.51653 24.4077C7.76245 24.4586 8.01812 24.4316 8.24795 24.3304L10.011 23.5564C10.193 23.4764 10.3895 23.4351 10.5884 23.4351H10.5935C10.9525 23.4355 11.2988 23.568 11.5664 23.8073C11.8341 24.0466 12.0044 24.3759 12.0449 24.7326L12.2564 26.6452C12.284 26.8935 12.3876 27.1273 12.553 27.3146C12.7183 27.5019 12.9375 27.6337 13.1804 27.6919L13.1811 27.6925ZM18.2262 26.2254C16.7622 26.5382 15.2482 26.5382 13.7842 26.2254L13.594 24.56C13.5113 23.821 13.1595 23.1383 12.6056 22.6421C12.0517 22.1459 11.3346 21.871 10.591 21.8697H10.5847C10.17 21.8681 9.75949 21.9533 9.37972 22.12L7.84942 22.7913C6.8567 21.6716 6.09927 20.3638 5.62217 18.9455L6.97666 17.9445C7.35849 17.6631 7.66886 17.296 7.88275 16.8727C8.09665 16.4493 8.20809 15.9817 8.20809 15.5074C8.20809 15.0331 8.09665 14.5654 7.88275 14.1421C7.66886 13.7187 7.35849 13.3516 6.97666 13.0702L5.62279 12.0692C6.10083 10.6525 6.85843 9.34624 7.85068 8.2278L9.37222 8.89848C9.7526 9.0674 10.1643 9.15373 10.5803 9.15311H10.5866C11.332 9.15156 12.0507 8.87571 12.6057 8.37815C13.1607 7.8806 13.5132 7.19616 13.5959 6.45538L13.7836 4.79119C14.5175 4.64411 15.2636 4.56536 16.0121 4.55595C16.7547 4.56534 17.4948 4.64354 18.2231 4.79056L18.4107 6.45475C18.4912 7.19539 18.8421 7.8803 19.3962 8.37822C19.9504 8.87615 20.6688 9.15207 21.4138 9.15311C21.834 9.16304 22.2508 9.07523 22.6313 8.8966L24.1516 8.22654C25.1444 9.34489 25.9023 10.6515 26.3801 12.0686L25.0306 13.0652C24.6462 13.3454 24.3334 13.7125 24.1177 14.1365C23.9021 14.5605 23.7897 15.0295 23.7897 15.5052C23.7897 15.9809 23.9021 16.4498 24.1177 16.8739C24.3334 17.2979 24.6462 17.6649 25.0306 17.9451L26.3851 18.9462C25.9068 20.3626 25.1495 21.6688 24.1578 22.7875L22.6313 22.1181C22.1967 21.9253 21.7227 21.838 21.2479 21.8633C20.7731 21.8886 20.3111 22.0258 19.8994 22.2637C19.4878 22.5016 19.1383 22.8335 18.8793 23.2322C18.6204 23.631 18.4594 24.0853 18.4095 24.5581L18.2262 26.2254Z" fill="#5375FD"></path></svg></button><div class="params-box" style="${ssrRenderStyle([{ "left": "unset", "right": "0" }, { display: unref(isContextMenuShown) ? "block" : "none" }])}"><div class="group"><button class="b-action"><div class="card-action"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-copy" viewBox="0 0 16 16"><path stroke="#5375FD" fill-rule="evenodd" d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V2Zm2-1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H6ZM2 5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1h1v1a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1v1H2Z"></path></svg></div><span> \u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043A\u043E\u043F\u0438\u044E </span></button><button class="b-action"><div class="card-action"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-archive" viewBox="0 0 16 16"><path stroke="#5375FD" d="M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 1 12.5V5a1 1 0 0 1-1-1V2zm2 3v7.5A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5V5H2zm13-3H1v2h14V2zM5 7.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"></path></svg></div><span>\u0410\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C </span></button></div></div></div></div></div></li>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MyVacancies/ActiveItem.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "ActiveList",
  __ssrInlineRender: true,
  props: {
    items: {
      required: false,
      default: []
    }
  },
  setup(__props) {
    var _a;
    const props = __props;
    const my_vacancies = computed(() => props.items);
    const vacancyStore = useVacancyStore();
    const current_page = ref((_a = vacancyStore.my_current_page) != null ? _a : 1);
    const total_page = computed(() => vacancyStore.my_last_page);
    const isPrevDisabled = computed(() => {
      if (parseInt(current_page.value) === 1)
        return true;
      return false;
    });
    const isNextDisabled = computed(
      () => vacancyStore.my_last_page === vacancyStore.my_current_page
    );
    const isPaginationVisible = computed(() => vacancyStore.my_last_page !== 1);
    const route = useRoute();
    watch(
      () => route.query.page,
      () => {
        var _a2;
        current_page.value = (_a2 = route.query.page) != null ? _a2 : 1;
      }
    );
    watch(
      () => current_page.value,
      async (newPage) => {
        await getMyDrafts({
          page: newPage
        });
      }
    );
    const per_page = ref(10);
    const order_by = ref(null);
    const sortingOptions = ref(useMyVacancySortingOptions());
    const perPageOptions = ref(useMyVacancyPerPageOptions());
    const onChangePerPage = async (per_page2) => {
      isLoading.value = true;
      isLoading.value = false;
      current_page.value = form.value.page;
    };
    const onChangeSorting = async (sorting) => {
      isLoading.value = true;
      isLoading.value = false;
    };
    const listStyles = {
      left: 0,
      right: "unset",
      width: "auto !important"
    };
    const isLoading = ref(false);
    useQueryParams();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      const _component_MyVacanciesActiveItem = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-749e3c88>`);
      if (unref(isLoading)) {
        _push(ssrRenderComponent(__nuxt_component_0$1, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="d-inline-flex" data-v-749e3c88><form class="sort mx-1" action="#" data-v-749e3c88><span data-v-749e3c88>\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C:</span>`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        modelValue: unref(per_page),
        "onUpdate:modelValue": ($event) => isRef(per_page) ? per_page.value = $event : null,
        options: unref(perPageOptions),
        onChange: onChangePerPage,
        class: "bg-white w-auto",
        listStyles
      }, null, _parent));
      _push(`</form><form class="sort mx-1" action="#" data-v-749e3c88><span data-v-749e3c88>\u0421\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C:</span>`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        modelValue: unref(order_by),
        "onUpdate:modelValue": ($event) => isRef(order_by) ? order_by.value = $event : null,
        options: unref(sortingOptions),
        onChange: onChangeSorting,
        class: "bg-white w-auto",
        listStyles
      }, null, _parent));
      _push(`</form></div>`);
      if (unref(my_vacancies).length > 0) {
        _push(`<ul class="resume-list mt-4" data-v-749e3c88><!--[-->`);
        ssrRenderList(unref(my_vacancies), (item) => {
          _push(ssrRenderComponent(_component_MyVacanciesActiveItem, {
            key: item.id,
            item
          }, null, _parent));
        });
        _push(`<!--]--></ul>`);
      } else {
        _push(`<div class="d-flex mt-4 pb-4 justify-content-center" data-v-749e3c88><p data-v-749e3c88>\u041D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E!</p></div>`);
      }
      if (unref(isPaginationVisible)) {
        _push(`<div class="d-flex mt-4 justify-content-between" data-v-749e3c88><button class="${ssrRenderClass([{ disabled: unref(isPrevDisabled) }, "btn btn-primary btn-group-sm"])}" data-v-749e3c88> Prev </button><p data-v-749e3c88>${ssrInterpolate(unref(current_page))}/${ssrInterpolate(unref(total_page))}</p><button class="${ssrRenderClass([{ disabled: unref(isNextDisabled) }, "btn btn-primary btn-group-sm"])}" data-v-749e3c88> Next </button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MyVacancies/ActiveList.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_2$1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-749e3c88"]]);
const _sfc_main$2 = {
  __name: "ArchivedList",
  __ssrInlineRender: true,
  props: {
    items: {
      required: false,
      default: []
    }
  },
  setup(__props) {
    var _a;
    const props = __props;
    const my_vacancies = computed(() => props.items);
    const vacancyStore = useVacancyStore();
    const current_page = ref((_a = vacancyStore.my_archived_vacancies_current_page) != null ? _a : 1);
    const total_page = computed(() => vacancyStore.my_archived_vacancies_last_page);
    const isPrevDisabled = computed(() => {
      if (parseInt(current_page.value) <= 1)
        return true;
      return false;
    });
    const isNextDisabled = computed(
      () => parseInt(current_page.value) === parseInt(total_page.value)
    );
    const isPaginationVisible = computed(
      () => vacancyStore.my_archived_vacancies_last_page !== 1
    );
    const route = useRoute();
    watch(
      () => route.query.page,
      () => {
        var _a2;
        console.log(route.query.page);
        current_page.value = (_a2 = route.query.page) != null ? _a2 : 1;
      }
    );
    watch(
      () => current_page.value,
      async (newPage) => {
        console.log(current_page.value);
        await getArchivedVacancies({
          page: newPage
        });
        isLoading.value = false;
      }
    );
    const per_page = ref(10);
    const order_by = ref(null);
    const sortingOptions = ref(useMyVacancySortingOptions());
    const perPageOptions = ref(useMyVacancyPerPageOptions());
    const { getArchivedVacancies } = vacancyStore;
    const onChangePerPage = async (per_page2) => {
      isLoading.value = true;
      isLoading.value = false;
    };
    const onChangeSorting = async (sorting) => {
      isLoading.value = true;
      isLoading.value = false;
    };
    const listStyles = {
      left: 0,
      right: "unset",
      width: "auto !important"
    };
    const isLoading = ref(false);
    useQueryParams();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      const _component_MyVacanciesDraftItem = __nuxt_component_1$1$1;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-325e4cb2>`);
      if (unref(isLoading)) {
        _push(ssrRenderComponent(__nuxt_component_0$1, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="d-inline-flex" data-v-325e4cb2><form class="sort mx-1" action="#" data-v-325e4cb2><span data-v-325e4cb2>\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C:</span>`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        modelValue: unref(per_page),
        "onUpdate:modelValue": ($event) => isRef(per_page) ? per_page.value = $event : null,
        options: unref(perPageOptions),
        onChange: onChangePerPage,
        class: "bg-white w-auto",
        listStyles
      }, null, _parent));
      _push(`</form><form class="sort mx-1" action="#" data-v-325e4cb2><span data-v-325e4cb2>\u0421\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C:</span>`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        modelValue: unref(order_by),
        "onUpdate:modelValue": ($event) => isRef(order_by) ? order_by.value = $event : null,
        options: unref(sortingOptions),
        onChange: onChangeSorting,
        class: "bg-white w-auto",
        listStyles
      }, null, _parent));
      _push(`</form></div>`);
      if (unref(my_vacancies).length > 0) {
        _push(`<ul class="resume-list mt-4" data-v-325e4cb2><!--[-->`);
        ssrRenderList(unref(my_vacancies), (item) => {
          _push(ssrRenderComponent(_component_MyVacanciesDraftItem, {
            key: item.id,
            item
          }, null, _parent));
        });
        _push(`<!--]--></ul>`);
      } else {
        _push(`<div class="d-flex mt-4 pb-4 justify-content-center" data-v-325e4cb2><p data-v-325e4cb2>\u041D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E!</p></div>`);
      }
      if (unref(isPaginationVisible)) {
        _push(`<div class="d-flex mt-4 justify-content-between pagination" data-v-325e4cb2><button class="${ssrRenderClass([{ disabled: unref(isPrevDisabled) }, "page-item"])}"${ssrIncludeBooleanAttr(unref(isPrevDisabled)) ? " disabled" : ""} data-v-325e4cb2><span class="page-link" data-v-325e4cb2> Prev </span></button><button class="page-item" data-v-325e4cb2><span class="page-link" data-v-325e4cb2>${ssrInterpolate(unref(current_page))}/${ssrInterpolate(unref(total_page))}</span></button><button class="${ssrRenderClass([{ disabled: unref(isNextDisabled) }, "page-item"])}"${ssrIncludeBooleanAttr(unref(isNextDisabled)) ? " disabled" : ""} data-v-325e4cb2><span class="page-link" data-v-325e4cb2> Next </span></button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MyVacancies/ArchivedList.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-325e4cb2"]]);
function useMyVacancyForm(data = null, to_ = "front") {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
  const removeNull = (obj) => {
    Object.keys(obj).forEach(
      (k) => obj[k] && typeof obj[k] === "object" && removeNull(obj[k]) || !obj[k] && obj[k] !== void 0 && delete obj[k]
    );
    return obj;
  };
  const route = useRoute();
  const params = route.query;
  let page = params.page;
  if (to_ === "reset") {
    return {
      name: "",
      page,
      status: "draft",
      provider: "*",
      order_by: null,
      per_page: 10
    };
  }
  const form_data = {
    name: (_a = data == null ? void 0 : data.name) != null ? _a : params == null ? void 0 : params.name,
    page: (_b = data == null ? void 0 : data.page) != null ? _b : 1,
    per_page: (_d = (_c = data == null ? void 0 : data.per_page) != null ? _c : params.per_page) != null ? _d : 10,
    order_by: (_f = (_e = data == null ? void 0 : data.order_by) != null ? _e : params.order_by) != null ? _f : null,
    status: (_h = (_g = data == null ? void 0 : data.status) != null ? _g : params.status) != null ? _h : "draft",
    provider: (_j = (_i = data == null ? void 0 : data.provider) != null ? _i : params.provider) != null ? _j : "*"
  };
  if (data === null) {
    return form_data;
  }
  const back_params = {
    name: (_k = data.name) != null ? _k : null,
    page: (_l = data.page) != null ? _l : 1,
    order_by: null,
    status: "draft",
    provider: "*",
    per_page: 10
  };
  const front_params = {
    name: null,
    page: null,
    order_by: null,
    status: "draft",
    provider: null,
    per_page: 10
  };
  if (to_ === "front") {
    if (data.name) {
      front_params.name = data.name;
    }
    if (data.page) {
      front_params.page = data.page;
    }
    if (data.order_by !== "")
      front_params.order_by = data.order_by;
    if (data.status !== "")
      front_params.status = data.status;
    if (data.provider !== "")
      front_params.provider = data.provider;
    if (data.per_page !== "")
      front_params.per_page = data.per_page;
    return removeNull(front_params);
  }
  if (to_ === "backend") {
    if (data.name) {
      back_params.name = data.name;
    }
    if (data.order_by) {
      back_params.order_by = data.order_by;
    }
    if (data.status) {
      back_params.status = data.status;
    }
    if (data.provider) {
      back_params.provider = data.provider;
    }
    if (data.per_page) {
      back_params.per_page = data.per_page;
    }
    return removeNull(back_params);
  }
}
function useMyVacanciesFilterOptions() {
  return [
    { value: "active", name: "\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0435" },
    { value: "draft", name: "\u0432 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A" },
    { value: "archived", name: "\u0432 \u0430\u0440\u0445\u0438\u0432\u0435" }
  ];
}
const _sfc_main$1 = {
  __name: "List",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useHead({
      title: "Jobeek - \u041C\u043E\u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438"
    });
    const vacancyStore = useVacancyStore();
    const {
      getMyVacancies,
      getMyDrafts: getMyDrafts2,
      getArchivedVacancies,
      getCreateAvailability
    } = vacancyStore;
    ref(useMyVacancySortingOptions());
    ref(useMyVacancyPerPageOptions());
    const filterOptions = ref(useMyVacanciesFilterOptions());
    ref([
      { value: "*", name: "\u0412\u0441\u0435" },
      { value: "hh", name: "HeadHunter" },
      { value: "superjob", name: "Superjob" }
    ]);
    const { my_vacancies, current_page, my_total } = storeToRefs(vacancyStore);
    computed(() => {
      if (parseInt(current_page.value) === 1)
        return true;
      return false;
    });
    const form2 = ref(useMyVacancyForm());
    computed(() => {
      if (form2.value.status === "draft") {
        return vacancyStore.my_drafts.length;
      }
      if (form2.value.status === "active" || form2.value.status === "archived") {
        return vacancyStore.my_vacancies.length;
      }
    });
    const totalDrafts = computed(() => vacancyStore.my_drafts.length);
    const totalActiveVacancies = computed(() => vacancyStore.my_vacancies.length);
    const totalArchivedVacancies = computed(
      () => vacancyStore.my_archived_vacancies.length
    );
    const providers = ref({
      hh: true,
      superjob: true
    });
    const vacancies = ref([]);
    const my_drafts = ref([]);
    const isLoading = ref(true);
    const route = useRoute();
    watch(
      () => route.query,
      async (newQuery) => {
        let newStatus = "draft";
        if (filterOptions.value.map((item) => item.value).includes(route.query.status)) {
          newStatus = route.query.status;
        }
        form2.value.status = newStatus;
        const params = { status: newStatus };
        console.log(params);
        if (newStatus === "draft") {
          await getMyDrafts2(params);
        } else if (newStatus === "active") {
          await getMyVacancies(params);
        } else {
          await getArchivedVacancies(params);
        }
      }
    );
    [__temp, __restore] = withAsyncContext(() => getCreateAvailability()), await __temp, __restore();
    const canCreateVacancy = computed(() => {
      var _a;
      return (_a = vacancyStore.can_create_vacancy) != null ? _a : false;
    });
    const onFilterChange = (filter) => {
      navigateTo({ name: "my-vacancies", query: { status: filter } });
    };
    watch(
      () => vacancyStore.my_vacancies,
      (newMyVacancies) => {
        vacancies.value = newMyVacancies;
      }
    );
    watch(
      () => vacancyStore.my_drafts,
      (newMyDrafts) => {
        my_drafts.value = newMyDrafts;
      }
    );
    const hhFilters = ["active", "archived", "deleted"];
    const superjobFilters = [
      "active",
      "private",
      "published",
      "archived",
      "declined",
      "in_moderation"
    ];
    function getCommon(arr1, arr2) {
      let common = [];
      for (let i = 0; i < arr1.length; ++i) {
        for (let j = 0; j < arr2.length; ++j) {
          if (arr1[i] == arr2[j]) {
            common.push(arr1[i]);
          }
        }
      }
      return common;
    }
    watch(providers.value, (newProviders) => {
      let prevItems = useMyVacanciesFilterOptions();
      const commonStates = getCommon(hhFilters, superjobFilters);
      if (newProviders.superjob === false && newProviders.hh === false) {
        prevItems = [];
      }
      if (newProviders.superjob === false && newProviders.hh === true) {
        prevItems = prevItems.filter(
          (item) => hhFilters.includes(item.value) || commonStates.includes(item.value)
        );
      }
      if (newProviders.superjob === true && newProviders.hh === false) {
        prevItems = prevItems.filter(
          (item) => superjobFilters.includes(item.value) || commonStates.includes(item.value)
        );
      }
      filterOptions.value = prevItems;
    });
    watch(filterOptions, (newFilterOptions) => {
      if (newFilterOptions.length > 0) {
        const findItem = newFilterOptions.some(
          (item) => item.value === form2.value.status
        );
        if (!findItem) {
          onFilterChange(newFilterOptions[0].value);
        }
      }
    });
    ref();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_MyVacanciesDraftList = __nuxt_component_1$2;
      const _component_MyVacanciesActiveList = __nuxt_component_2$1;
      const _component_MyVacanciesArchivedList = __nuxt_component_3;
      _push(`<!--[-->`);
      if (unref(isLoading)) {
        _push(ssrRenderComponent(__nuxt_component_0$1, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="" data-v-72c59c3c><div class="notification mt-0" data-v-72c59c3c><div class="ic" data-v-72c59c3c><img${ssrRenderAttr("src", _imports_0$1)} alt="#" data-v-72c59c3c></div><div class="notification-text" data-v-72c59c3c><strong class="title" data-v-72c59c3c>\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u043F\u0440\u0435\u043C\u0438\u0443\u043C</strong><p data-v-72c59c3c> \u0423 \u0432\u0430\u0441 \u0435\u0441\u0442\u044C \u043B\u0438\u043C\u0438\u0442 \u043D\u0430 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439: ${ssrInterpolate(unref(vacancyStore).can_create_vacancy_count)} \u0448\u0442\u0443\u043A. \u0427\u0442\u043E\u0431\u044B \u0441\u043E\u0437\u0434\u0430\u0432\u0430\u0442\u044C \u043D\u0435\u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u043D\u043E\u0435 \u043A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439, \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u043F\u0440\u0435\u043C\u0438\u0443\u043C-\u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443 </p></div></div>`);
      if (unref(canCreateVacancy)) {
        _push(ssrRenderComponent(_component_NuxtLink, {
          class: "create-button",
          type: "link",
          to: { name: "create-vacancy" }
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E `);
            } else {
              return [
                createTextVNode("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E ")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<div data-v-72c59c3c></div>`);
      }
      _push(`<div class="col d-flex justify-content-between mt-4" data-v-72c59c3c><h1 class="lk-page-title mt-4" data-v-72c59c3c>\u0412\u0430\u0448\u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</h1></div><div class="col d-flex justify-content-between align-items-center py-4" data-v-72c59c3c><ul class="nav nav-tabs vacancy_tabs w-100" data-v-72c59c3c><li class="${ssrRenderClass([{ active: unref(form2).status === "draft" }, "nav-item"])}" data-v-72c59c3c><a${ssrRenderAttr("to", { name: "my-vacancies", query: { status: "draft" } })} class="${ssrRenderClass([{ active: unref(form2).status === "draft" }, "nav-link"])}" data-v-72c59c3c>\u0427\u0435\u0440\u043D\u043E\u0432\u0435\u043A(${ssrInterpolate(unref(totalDrafts))})</a></li><li class="${ssrRenderClass([{ active: unref(form2).status === "active" }, "nav-item"])}" data-v-72c59c3c><a${ssrRenderAttr("to", { name: "my-vacancies", query: { status: "active" } })} class="${ssrRenderClass([{ active: unref(form2).status === "active" }, "nav-link"])}" data-v-72c59c3c>\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435(${ssrInterpolate(unref(totalActiveVacancies))})</a></li><li class="${ssrRenderClass([{ active: unref(form2).status === "archived" }, "nav-item"])}" data-v-72c59c3c><a${ssrRenderAttr("to", { name: "my-vacancies", query: { status: "archived" } })} class="${ssrRenderClass([{ active: unref(form2).status === "archived" }, "nav-link"])}" data-v-72c59c3c>\u0412 \u0430\u0440\u0445\u0438\u0432\u0435(${ssrInterpolate(unref(totalArchivedVacancies))})</a></li></ul><div class="d-inline-flex" data-v-72c59c3c></div></div>`);
      if (unref(form2).status === "draft") {
        _push(ssrRenderComponent(_component_MyVacanciesDraftList, {
          items: unref(vacancyStore).my_drafts
        }, null, _parent));
      } else if (unref(form2).status === "active") {
        _push(ssrRenderComponent(_component_MyVacanciesActiveList, {
          items: unref(vacancyStore).my_vacancies
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(_component_MyVacanciesArchivedList, {
          items: unref(vacancyStore).my_archived_vacancies
        }, null, _parent));
      }
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MyVacancies/List.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-72c59c3c"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u041C\u043E\u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 - Jobeek"
    });
    const authStore = useAuthStore();
    const isEmployer = computed(() => authStore.isEmployer);
    computed(() => authStore.user);
    computed(() => authStore.employer);
    watch(isEmployer, (new_value) => {
      if (new_value === false) {
        navigateTo({ name: "my-resumes" });
      }
    });
    const vacancyStore = useVacancyStore();
    computed(() => {
      if (vacancyStore.providers.hh === true && vacancyStore.providers.superjob === true) {
        return true;
      }
      return false;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0;
      const _component_MyVacanciesConnectedProviders = __nuxt_component_1$1;
      const _component_MyVacanciesList = __nuxt_component_2;
      const _component_MyVacanciesPremium = Premium;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet my-vacancies-page",
        role: "main"
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="bg-wrapper position-relative pt-4"><div class="has-sidebar has-sidebar--v2 wrapper wrapper-1290"><div class="content mb-4">`);
      _push(ssrRenderComponent(_component_MyVacanciesConnectedProviders, null, null, _parent));
      _push(ssrRenderComponent(_component_MyVacanciesList, null, null, _parent));
      _push(`</div><aside class="sidebar">`);
      _push(ssrRenderComponent(_component_MyVacanciesPremium, null, null, _parent));
      _push(`</aside></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/my-vacancies/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-B2lKJMB9.mjs.map
