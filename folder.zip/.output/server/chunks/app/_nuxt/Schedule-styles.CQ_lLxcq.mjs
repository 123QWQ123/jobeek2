const Schedule_vue_vue_type_style_index_0_scoped_dbabdf13_lang = ".check-block label[data-v-dbabdf13]{white-space:pre-wrap}.with_scroll[data-v-dbabdf13]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-dbabdf13]{font-weight:700}.is_header .radio-mask[data-v-dbabdf13],.is_header input[data-v-dbabdf13]{display:none}input[type=search][data-v-dbabdf13]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const ScheduleStyles_CQ_lLxcq = [Schedule_vue_vue_type_style_index_0_scoped_dbabdf13_lang];

export { ScheduleStyles_CQ_lLxcq as default };
//# sourceMappingURL=Schedule-styles.CQ_lLxcq.mjs.map
