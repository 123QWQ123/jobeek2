import { M as MultiSelectWithSearch_vue_vue_type_style_index_1_scoped_06d53309_lang } from './MultiSelectWithSearch-styles-2.mjs-BEYiaMHG.mjs';

const MultiSelectWithSearchStyles_BT1qXcpU = [MultiSelectWithSearch_vue_vue_type_style_index_1_scoped_06d53309_lang];

export { MultiSelectWithSearchStyles_BT1qXcpU as default };
//# sourceMappingURL=MultiSelectWithSearch-styles.BT1qXcpU.mjs.map
