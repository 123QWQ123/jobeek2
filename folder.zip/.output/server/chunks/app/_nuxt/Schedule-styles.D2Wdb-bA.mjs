const Schedule_vue_vue_type_style_index_0_scoped_7003843b_lang = ".check-block label[data-v-7003843b]{white-space:pre-wrap}.with_scroll[data-v-7003843b]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-7003843b]{font-weight:700}.is_header .radio-mask[data-v-7003843b],.is_header input[data-v-7003843b]{display:none}input[type=search][data-v-7003843b]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const ScheduleStyles_D2WdbBA = [Schedule_vue_vue_type_style_index_0_scoped_7003843b_lang];

export { ScheduleStyles_D2WdbBA as default };
//# sourceMappingURL=Schedule-styles.D2Wdb-bA.mjs.map
