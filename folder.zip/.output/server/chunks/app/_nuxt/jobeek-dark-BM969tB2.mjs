import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + buildAssetsURL("jobeek-dark.Do_KXeWm.svg");

export { _imports_0 as _ };
//# sourceMappingURL=jobeek-dark-BM969tB2.mjs.map
