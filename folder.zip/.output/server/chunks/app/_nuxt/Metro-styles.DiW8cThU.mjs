const Metro_vue_vue_type_style_index_0_scoped_680feddc_lang = ".check-block label[data-v-680feddc]{white-space:pre-wrap}.with_scroll[data-v-680feddc]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-680feddc]{font-weight:700}.is_header .radio-mask[data-v-680feddc],.is_header input[data-v-680feddc]{display:none}input[type=search][data-v-680feddc]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const MetroStyles_DiW8cThU = [Metro_vue_vue_type_style_index_0_scoped_680feddc_lang];

export { MetroStyles_DiW8cThU as default };
//# sourceMappingURL=Metro-styles.DiW8cThU.mjs.map
