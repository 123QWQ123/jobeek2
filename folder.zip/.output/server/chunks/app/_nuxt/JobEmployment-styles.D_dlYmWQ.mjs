const JobEmployment_vue_vue_type_style_index_0_scoped_06f5998e_lang = "@media (min-width:960px){.checkboxes-row.job_employment_types[data-v-06f5998e]{grid-template-columns:1fr 1fr}}";

const JobEmploymentStyles_D_dlYmWQ = [JobEmployment_vue_vue_type_style_index_0_scoped_06f5998e_lang];

export { JobEmploymentStyles_D_dlYmWQ as default };
//# sourceMappingURL=JobEmployment-styles.D_dlYmWQ.mjs.map
