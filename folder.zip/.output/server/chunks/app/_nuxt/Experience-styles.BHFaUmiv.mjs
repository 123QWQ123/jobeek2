const Experience_vue_vue_type_style_index_0_scoped_abf4b4e3_lang = ".check-block label[data-v-abf4b4e3]{white-space:pre-wrap}.with_scroll[data-v-abf4b4e3]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-abf4b4e3]{font-weight:700}.is_header .radio-mask[data-v-abf4b4e3],.is_header input[data-v-abf4b4e3]{display:none}input[type=search][data-v-abf4b4e3]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const ExperienceStyles_BHFaUmiv = [Experience_vue_vue_type_style_index_0_scoped_abf4b4e3_lang];

export { ExperienceStyles_BHFaUmiv as default };
//# sourceMappingURL=Experience-styles.BHFaUmiv.mjs.map
