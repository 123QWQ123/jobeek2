import { M as MultiSelectWithSearch_vue_vue_type_style_index_0_lang } from './MultiSelectWithSearch-styles-1.mjs-CmDtrXzg.mjs';

const MultiSelectWithSearchStyles_DtPNTQ0e = [MultiSelectWithSearch_vue_vue_type_style_index_0_lang];

export { MultiSelectWithSearchStyles_DtPNTQ0e as default };
//# sourceMappingURL=MultiSelectWithSearch-styles.DtPNTQ0e.mjs.map
