const City_vue_vue_type_style_index_0_scoped_08343c95_lang = ".check-block label[data-v-08343c95]{white-space:pre-wrap}.with_scroll[data-v-08343c95]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-08343c95]{font-weight:700}.is_header .radio-mask[data-v-08343c95],.is_header input[data-v-08343c95]{display:none}input[type=search][data-v-08343c95]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const CityStyles_ilSVOs2U = [City_vue_vue_type_style_index_0_scoped_08343c95_lang];

export { CityStyles_ilSVOs2U as default };
//# sourceMappingURL=City-styles.ilSVOs2U.mjs.map
