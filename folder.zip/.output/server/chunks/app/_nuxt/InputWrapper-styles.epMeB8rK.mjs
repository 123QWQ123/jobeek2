const InputWrapper_vue_vue_type_style_index_0_scoped_26f8214a_lang = ".absoluted_icon svg[data-v-26f8214a]{height:24px;width:24px}";

const InputWrapperStyles_epMeB8rK = [InputWrapper_vue_vue_type_style_index_0_scoped_26f8214a_lang];

export { InputWrapperStyles_epMeB8rK as default };
//# sourceMappingURL=InputWrapper-styles.epMeB8rK.mjs.map
