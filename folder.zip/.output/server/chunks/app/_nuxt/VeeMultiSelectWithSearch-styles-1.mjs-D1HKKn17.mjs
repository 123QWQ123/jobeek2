const VeeMultiSelectWithSearch_vue_vue_type_style_index_0_lang = ".select2-container .select2-selection--multiple .select2-selection__rendered{flex-wrap:wrap!important}";

export { VeeMultiSelectWithSearch_vue_vue_type_style_index_0_lang as V };
//# sourceMappingURL=VeeMultiSelectWithSearch-styles-1.mjs-D1HKKn17.mjs.map
