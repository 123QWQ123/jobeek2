const VeeDriverLicensesCard_vue_vue_type_style_index_0_lang = "";

const VeeDriverLicensesCardStyles_C3yUfeBK = [VeeDriverLicensesCard_vue_vue_type_style_index_0_lang];

export { VeeDriverLicensesCardStyles_C3yUfeBK as default };
//# sourceMappingURL=VeeDriverLicensesCard-styles.C3yUfeBK.mjs.map
