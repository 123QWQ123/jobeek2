import { E as EmployerEditForm_vue_vue_type_style_index_0_lang } from './EmployerEditForm-styles-1.mjs-LUqCgKGD.mjs';

const EmployerEditFormStyles_BVD0s9t0 = [EmployerEditForm_vue_vue_type_style_index_0_lang];

export { EmployerEditFormStyles_BVD0s9t0 as default };
//# sourceMappingURL=EmployerEditForm-styles.BVD0s9t0.mjs.map
