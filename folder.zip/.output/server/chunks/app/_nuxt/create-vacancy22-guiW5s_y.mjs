import { H as Head, T as Title } from './components-DWwOHCR7.mjs';
import { _ as __nuxt_component_0 } from './SearchMobile-WfXJ1gHL.mjs';
import { _ as __nuxt_component_1 } from './Providers-Bui0vB9a.mjs';
import { _ as __nuxt_component_4 } from './CreateDraft-DS1I7Wix.mjs';
import { useSSRContext, computed, ref, watch, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, isRef } from 'vue';
import { e as useRoute, l as useVacancyStore, k as useAuthStore, d as navigateTo } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';
import { u as useAlert } from './useAlert-CPK6c05f.mjs';
import { u as useProviders } from './useProviders-Ck9yopDY.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './search-CNCM2ROA.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import './sb-_CyfLtbf.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './dictionary--F10-rgU.mjs';
import 'vee-validate';
import './VacancyCheckboxInput-VKg7Lh2Y.mjs';
import './useSort-Dy_x39w5.mjs';
import './useFilter-BmdPUTpE.mjs';
import './check-BGWLIG1L.mjs';
import './VeeMultiSelectWithSearch-Btd5b5Va.mjs';
import './VeeTipTapRichEditor-C3vw1Km2.mjs';
import '@tiptap/pm/state';
import '@tiptap/pm/model';
import '@tiptap/pm/transform';
import '@tiptap/pm/commands';
import '@tiptap/pm/schema-list';
import '@tiptap/pm/dropcursor';
import '@tiptap/pm/gapcursor';
import '@tiptap/pm/history';
import './VeeCustomSelect-BxrAvA7-.mjs';
import './useCurrencyOptions-BsifIVKS.mjs';
import './useFormValidation-BMv_R6aU.mjs';
import '@vee-validate/zod';
import 'zod';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main = {
  __name: "create-vacancy22",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const vacancyStore = useVacancyStore();
    const my_vacancy = computed(() => vacancyStore.my_vacancy);
    const providers = ref({
      superjob: false,
      hh: false
    });
    const { setProviders } = useProviders();
    setProviders(providers.value);
    watch(
      () => providers.value,
      (newValues) => {
        setProviders(newValues);
      }
    );
    computed(() => {
      if (providers.value.hh && providers.value.superjob) {
        return ["hh", "superjob"];
      }
      if (providers.value.hh) {
        return ["hh"];
      }
      if (providers.value.superjob) {
        return ["superjob"];
      }
      return [];
    });
    const { getMyVacancy, getMyDraft } = vacancyStore;
    const draftID = computed(() => route.query.draft_id);
    const vacancyID = computed(() => route.query.vacancy_id);
    const pageTitle = computed(() => {
      if (draftID == null ? void 0 : draftID.value) {
        return "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438";
      }
      return "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438";
    });
    watch(
      () => route.query.draft_id,
      (newDraftId) => {
        console.log(newDraftId);
        if (newDraftId) {
          getMyDraft(draftID.value);
        }
      }
    );
    computed(() => {
      return route.query.message;
    });
    const { handleAlert } = useAlert();
    watch(() => route.query.message, handleAlert);
    const authStore = useAuthStore();
    const isEmployer = computed(() => authStore.isEmployer);
    computed(() => authStore.user);
    computed(() => authStore.employer);
    watch(
      () => isEmployer.value,
      (new_value) => {
        console.log(new_value);
        if (new_value === false) {
          navigateTo({ name: "create-resume" });
        }
      }
    );
    const canBePublished = computed(() => {
      var _a, _b, _c, _d;
      if (my_vacancy.value) {
        if (!providers.value.hh && !providers.value.superjob) {
          return false;
        }
        if (!providers.value.hh && providers.value.superjob) {
          if ((_a = my_vacancy.value.can_publish) == null ? void 0 : _a.superjob)
            return true;
          return false;
        }
        if (providers.value.hh && !providers.value.superjob) {
          if ((_b = my_vacancy.value.can_publish) == null ? void 0 : _b.hh)
            return true;
          return false;
        }
        if (providers.value.hh && providers.value.superjob) {
          if (((_c = my_vacancy.value.can_publish) == null ? void 0 : _c.hh) || ((_d = my_vacancy.value.can_publish) == null ? void 0 : _d.superjob)) {
            return true;
          }
        }
        return false;
      }
      return false;
    });
    ref();
    ref();
    ref();
    ref();
    ref();
    ref();
    ref();
    ref();
    ref();
    ref();
    ref();
    ref();
    ref(null);
    ref(null);
    ref(null);
    const errors = ref([]);
    const isLoading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0;
      const _component_CreateVacancyProviders = __nuxt_component_1;
      const _component_CreateVacancyCreateDraft = __nuxt_component_4;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet create-subscribe-page bg-wrapper",
        role: "main"
      }, _attrs))} data-v-c86ab810>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(pageTitle))} - Jobeek`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(pageTitle)) + " - Jobeek", 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(pageTitle)) + " - Jobeek", 1)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="bg-wrapper pt" data-v-c86ab810>`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="wrapper wrapper-1290" data-v-c86ab810>`);
      if (!unref(draftID) && !unref(vacancyID)) {
        _push(`<form class="create-vacancy" action="" name="create-vacancy " data-v-c86ab810>`);
        _push(ssrRenderComponent(_component_CreateVacancyProviders, {
          modelValue: unref(providers),
          "onUpdate:modelValue": ($event) => isRef(providers) ? providers.value = $event : null
        }, null, _parent));
        _push(ssrRenderComponent(_component_CreateVacancyCreateDraft, {
          title: unref(pageTitle),
          providers: unref(providers)
        }, null, _parent));
        _push(`<div class="form-submit-container mt-2" data-v-c86ab810><button class="btn btn-outline-primary" type="button" data-v-c86ab810> \u0414\u0430\u043B\u0435\u0435 </button></div></form>`);
      } else {
        _push(`<form class="update-vacancy" data-v-c86ab810>${ssrInterpolate(unref(errors))} `);
        if (unref(errors).length) {
          _push(`<div class="errors" data-v-c86ab810><h4 data-v-c86ab810>\u041A \u0441\u043E\u0436\u0430\u043B\u0435\u043D\u0438\u044E \u0432\u043E\u0437\u043D\u0438\u043A\u043B\u0438 \u043E\u0448\u0438\u0431\u043A\u0438 \u043F\u0440\u0438 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0438 \u0412\u0430\u043A\u0430\u043D\u0441\u0438\u0438:</h4><!--[-->`);
          ssrRenderList(unref(errors), (item) => {
            _push(`<p class="alert alert-info" data-v-c86ab810>${ssrInterpolate(item)}</p>`);
          });
          _push(`<!--]--></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<p class="text-lg-end" data-v-c86ab810> \u041F\u0440\u0438 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0438 \u0432\u0430\u043A\u0430\u043D\u0446\u0438\u0438 \u0432\u044B \u0441\u043E\u0433\u043B\u0430\u0448\u0430\u0435\u0442\u0435\u0441\u044C \u0441 <a href="#" data-v-c86ab810>\u043F\u0440\u0430\u0432\u0438\u043B\u0430\u043C\u0438 \u0440\u0430\u0431\u043E\u0442\u044B \u0441\u0435\u0440\u0432\u0438\u0441\u0430</a> \u0438 \u0434\u0430\u0435\u0442\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u0435 \u043D\u0430 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445, \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u0440\u0430\u0441\u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0435\u043D\u0438\u044F </p><div class="form-submit-container mt-2" data-v-c86ab810><button class="btn btn-outline-primary" type="button" data-v-c86ab810> \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043A\u0430\u043A \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A </button><button class="${ssrRenderClass([{ disabled: !unref(canBePublished) }, "button-accent"])}" type="submit" data-v-c86ab810>`);
        if (unref(isLoading)) {
          _push(`<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true" data-v-c86ab810></span>`);
        } else {
          _push(`<!---->`);
        }
        _push(` \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0438 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C </button></div></form>`);
      }
      _push(`</div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/create-vacancy22.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const createVacancy22 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-c86ab810"]]);

export { createVacancy22 as default };
//# sourceMappingURL=create-vacancy22-guiW5s_y.mjs.map
