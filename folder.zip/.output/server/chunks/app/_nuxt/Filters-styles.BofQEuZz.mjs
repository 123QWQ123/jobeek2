const Filters_vue_vue_type_style_index_0_scoped_e0fdc38f_lang = ".check-block label[data-v-e0fdc38f]{white-space:pre-wrap}";

const FiltersStyles_BofQEuZz = [Filters_vue_vue_type_style_index_0_scoped_e0fdc38f_lang];

export { FiltersStyles_BofQEuZz as default };
//# sourceMappingURL=Filters-styles.BofQEuZz.mjs.map
