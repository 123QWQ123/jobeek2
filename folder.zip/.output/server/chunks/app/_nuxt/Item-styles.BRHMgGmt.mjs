const Item_vue_vue_type_style_index_0_scoped_3b60c612_lang = ".push_and_context_wrapper[data-v-3b60c612]{align-items:center;display:flex;justify-content:flex-end;width:100%}@media (max-width:768px){.option-group[data-v-3b60c612]{flex-direction:row;justify-content:space-between;width:100%}.selector-group .option+.option[data-v-3b60c612]{margin-top:unset}}.theme-checker.disabled *[data-v-3b60c612]{filter:grayscale(100%)}@keyframes placeHolderShimmer-3b60c612{0%{background-position:0 0}to{background-position:100em 0}}.animated[data-v-3b60c612]{animation-duration:20s;animation-fill-mode:forwards;animation-iteration-count:infinite;animation-name:placeHolderShimmer-3b60c612;animation-timing-function:linear;background:#fff;background:linear-gradient(90deg,#eee 8%,#ddd 18%,#eee 33%);border-radius:43px;height:calc(100% + 2px);padding:3px;position:absolute;width:calc(100% + 2px);z-index:9999;//padding-top:50px;-webkit-backface-visibility:hidden;bottom:0;left:-1px;right:0;top:-1px}";

const ItemStyles_BRHMgGmt = [Item_vue_vue_type_style_index_0_scoped_3b60c612_lang];

export { ItemStyles_BRHMgGmt as default };
//# sourceMappingURL=Item-styles.BRHMgGmt.mjs.map
