const app_vue_vue_type_style_index_0_lang = ".modal{background:rgba(0,0,0,.15);display:flex}.layout-enter-from{opacity:0;transform:translateY(-30px)}.layout-leave-to{opacity:0;transform:translateY(30px)}.layout-enter-active{transition:all .3s ease-out}.layout-leave-active{transition:all .3s ease-in}.layout-enter-to,.layout-leave-from{opacity:1;transform:translateY(0)}:root{--vh:9.32px}";

export { app_vue_vue_type_style_index_0_lang as a };
//# sourceMappingURL=entry-styles-25.mjs-BYJ35Ser.mjs.map
