const LkNavbar_vue_vue_type_style_index_0_scoped_63963270_lang = ".router-link-active[data-v-63963270]:after{background:#5375fd}";

const LkNavbarStyles_ClnlWxFQ = [LkNavbar_vue_vue_type_style_index_0_scoped_63963270_lang];

export { LkNavbarStyles_ClnlWxFQ as default };
//# sourceMappingURL=LkNavbar-styles.ClnlWxFQ.mjs.map
