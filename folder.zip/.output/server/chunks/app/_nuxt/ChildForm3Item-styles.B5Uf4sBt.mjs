const ChildForm3Item_vue_vue_type_style_index_0_lang = "input,span{display:block}span{margin-bottom:20px}label{margin-top:20px}button,label{display:block}button[type=submit]{margin-top:10px}.InputGroup{border:2px dotted #000;margin-bottom:30px;padding:10px;position:relative}.InputGroup button{position:absolute;right:10px;top:10px}";

const ChildForm3ItemStyles_B5Uf4sBt = [ChildForm3Item_vue_vue_type_style_index_0_lang];

export { ChildForm3ItemStyles_B5Uf4sBt as default };
//# sourceMappingURL=ChildForm3Item-styles.B5Uf4sBt.mjs.map
