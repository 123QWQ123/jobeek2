const VeeSalaryCard_vue_vue_type_style_index_0_lang = "";

const VeeSalaryCardStyles_BrnToqez = [VeeSalaryCard_vue_vue_type_style_index_0_lang];

export { VeeSalaryCardStyles_BrnToqez as default };
//# sourceMappingURL=VeeSalaryCard-styles.BrnToqez.mjs.map
