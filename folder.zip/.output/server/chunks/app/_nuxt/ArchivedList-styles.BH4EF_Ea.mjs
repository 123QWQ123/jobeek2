const ArchivedList_vue_vue_type_style_index_0_scoped_325e4cb2_lang = ".theme-checker input~.theme-checker-ui .circle.left[data-v-325e4cb2]{transform:translate(3px,-50%)}.theme-checker input~.theme-checker-ui .circle.right[data-v-325e4cb2]{transform:translate(30px,-50%)}.sort .d-select[data-v-325e4cb2]{background:#f5f8fa!important}";

const ArchivedListStyles_BH4EF_Ea = [ArchivedList_vue_vue_type_style_index_0_scoped_325e4cb2_lang];

export { ArchivedListStyles_BH4EF_Ea as default };
//# sourceMappingURL=ArchivedList-styles.BH4EF_Ea.mjs.map
