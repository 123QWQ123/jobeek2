const Wrapper_vue_vue_type_style_index_0_scoped_34140026_lang = ".language_margin[data-v-34140026]{margin-bottom:1rem}@media (max-width:768px){.language_margin[data-v-34140026]{margin-bottom:2rem}}";

const WrapperStyles_DL2gs1QB = [Wrapper_vue_vue_type_style_index_0_scoped_34140026_lang];

export { WrapperStyles_DL2gs1QB as default };
//# sourceMappingURL=Wrapper-styles.DL2gs1QB.mjs.map
