const Region_vue_vue_type_style_index_0_scoped_c6f16caf_lang = ".check-block label[data-v-c6f16caf]{white-space:pre-wrap}.with_scroll[data-v-c6f16caf]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-c6f16caf]{font-weight:700}.is_header .radio-mask[data-v-c6f16caf],.is_header input[data-v-c6f16caf]{display:none}input[type=search][data-v-c6f16caf]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const RegionStyles_Bth29VX = [Region_vue_vue_type_style_index_0_scoped_c6f16caf_lang];

export { RegionStyles_Bth29VX as default };
//# sourceMappingURL=Region-styles.Bth-29VX.mjs.map
