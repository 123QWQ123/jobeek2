const advice_vue_vue_type_style_index_0_lang = "";

const adviceStyles_CgseKype = [advice_vue_vue_type_style_index_0_lang];

export { adviceStyles_CgseKype as default };
//# sourceMappingURL=advice-styles.CgseKype.mjs.map
