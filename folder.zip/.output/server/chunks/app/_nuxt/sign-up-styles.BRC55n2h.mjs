const signUp_vue_vue_type_style_index_0_scoped_d1424ce1_lang = "input[data-v-d1424ce1]:disabled{background-color:#e5e5e5}";

const signUpStyles_BRC55n2h = [signUp_vue_vue_type_style_index_0_scoped_d1424ce1_lang];

export { signUpStyles_BRC55n2h as default };
//# sourceMappingURL=sign-up-styles.BRC55n2h.mjs.map
