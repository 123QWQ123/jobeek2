import { _ as __nuxt_component_0 } from './VuePhoneInput-C5R34atv.mjs';
import { ref, mergeProps, unref, isRef, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import 'vue3-tel-input';

const _sfc_main = {
  __name: "component",
  __ssrInlineRender: true,
  setup(__props) {
    const phone = ref("+77777777778");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VuePhoneInput = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "component" }, _attrs))}>${ssrInterpolate(unref(phone))} `);
      _push(ssrRenderComponent(_component_VuePhoneInput, {
        modelValue: unref(phone),
        "onUpdate:modelValue": ($event) => isRef(phone) ? phone.value = $event : null
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/component.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=component-CgM5zabi.mjs.map
