import { useForm, Field, ErrorMessage, useFieldArray, useField } from 'vee-validate';
import { mergeProps, unref, useSSRContext, toRefs } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import { R as ResumeTextInput } from './ResumeTextInput-BxTsuw7y.mjs';
import * as yup from 'yup';

const _sfc_main$2 = {
  __name: "ChildForm3Item",
  __ssrInlineRender: true,
  props: ["idx"],
  emits: ["remove"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const { idx } = toRefs(props);
    useField(`users[${props.idx}].email`);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><legend>User #${ssrInterpolate(unref(idx))}</legend><label${ssrRenderAttr("for", `name_${unref(idx)}`)}>Name</label>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `users[${unref(idx)}].name`,
        placeholder: "Enter your name"
      }, null, _parent));
      _push(`<label${ssrRenderAttr("for", `email_${unref(idx)}`)}>Email</label>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `users[${unref(idx)}].email`,
        placeholder: "Enter your email"
      }, null, _parent));
      _push(`<button class="btn btn-primary btn-sm" type="button"> X </button><br><button type="button" class="btn btn-light"> Confirm Email </button></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ChildForm3Item.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const ChildForm3Item = _sfc_main$2;
const _sfc_main$1 = {
  __name: "ChildForm3",
  __ssrInlineRender: true,
  props: ["name"],
  setup(__props) {
    const props = __props;
    const { push, fields, remove } = useFieldArray(() => props.name);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><!--[-->`);
      ssrRenderList(unref(fields), (field, idx) => {
        _push(`<fieldset>`);
        _push(ssrRenderComponent(ChildForm3Item, {
          onRemove: unref(remove),
          idx
        }, null, _parent));
        _push(`</fieldset>`);
      });
      _push(`<!--]--><button type="button"> Add User + </button></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ChildForm3.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const _sfc_main = {
  __name: "vee3",
  __ssrInlineRender: true,
  setup(__props) {
    const initialData = {
      users: [
        {
          name: "",
          email: "te@domain.uz"
        }
      ],
      email: ""
    };
    const schema = yup.object().shape({
      users: yup.array().of(
        yup.object().shape({
          name: yup.string().required().label("Name"),
          email: yup.string().email().required().label("Email")
        })
      ).strict(),
      email: yup.string().email().required()
    });
    const { values, setValues, errors, handleSubmit, validate } = useForm({
      initialValues: initialData,
      validationSchema: schema
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Field = Field;
      const _component_ErrorMessage = ErrorMessage;
      const _component_ChildForm3 = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="p-5"><h1>vee-validate array fields</h1><form><div class="input-group"><label for="email">Parent Email</label>`);
      _push(ssrRenderComponent(_component_Field, {
        id: "email",
        name: "email",
        type: "email"
      }, null, _parent));
      _push(ssrRenderComponent(_component_ErrorMessage, { name: "email" }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_ChildForm3, { name: "users" }, null, _parent));
      _push(`<button class="btn btn-primary" type="submit">Submit</button></form></div> ${ssrInterpolate(unref(errors))}</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vee3.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=vee3-Doppn02j.mjs.map
