import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + buildAssetsURL("megafon.CRFUFZpu.svg");

export { _imports_0 as _ };
//# sourceMappingURL=megafon-UViF3Tze.mjs.map
