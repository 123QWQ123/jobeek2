const PhoneInputWithConfirmationAndCaptcha_vue_vue_type_style_index_0_scoped_9b5c4f9f_lang = ".absoluted_icon[data-v-9b5c4f9f]{cursor:pointer;font-size:1rem;left:-1.8rem;max-width:3rem;position:absolute;top:.5rem;z-index:1}.absoluted_icon.right-0[data-v-9b5c4f9f]{left:unset;right:.5rem;top:.9rem}.absoluted_icon svg[data-v-9b5c4f9f]{height:24px;width:24px}";

const PhoneInputWithConfirmationAndCaptchaStyles_BVhGe7C = [PhoneInputWithConfirmationAndCaptcha_vue_vue_type_style_index_0_scoped_9b5c4f9f_lang];

export { PhoneInputWithConfirmationAndCaptchaStyles_BVhGe7C as default };
//# sourceMappingURL=PhoneInputWithConfirmationAndCaptcha-styles.BVhGe7-C.mjs.map
