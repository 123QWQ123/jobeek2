const CabinetHeaderSearchForm_vue_vue_type_style_index_0_scoped_0a15ff14_lang = ".search-form--widget[data-v-0a15ff14]{display:block}.search-form--widget .search-row[data-v-0a15ff14]{grid-template-columns:1fr 20% 20% 130px}@media only screen and (max-width:1280px){.search-form-desktop[data-v-0a15ff14]{display:none}}";

const CabinetHeaderSearchFormStyles_BufwJISV = [CabinetHeaderSearchForm_vue_vue_type_style_index_0_scoped_0a15ff14_lang];

export { CabinetHeaderSearchFormStyles_BufwJISV as default };
//# sourceMappingURL=CabinetHeaderSearchForm-styles.BufwJISV.mjs.map
