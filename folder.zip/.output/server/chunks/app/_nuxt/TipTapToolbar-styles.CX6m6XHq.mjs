const TipTapToolbar_vue_vue_type_style_index_0_lang = ".tiptap-toolbar{background-color:#f6f6f6;border-radius:10%}.tiptap-toolbar button.is-active{border:1px solid #7f8b99}.tiptap-toolbar button{border:1px solid transparent;border-radius:10%;margin-right:.5rem;padding:2px 6px}.tiptap-toolbar button:hover{background-color:#7f8b99}";

const TipTapToolbarStyles_CX6m6XHq = [TipTapToolbar_vue_vue_type_style_index_0_lang];

export { TipTapToolbarStyles_CX6m6XHq as default };
//# sourceMappingURL=TipTapToolbar-styles.CX6m6XHq.mjs.map
