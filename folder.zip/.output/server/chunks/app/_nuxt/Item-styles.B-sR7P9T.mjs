const Item_vue_vue_type_style_index_0_scoped_1449cedf_lang = ".absoluted_icon[data-v-1449cedf]{cursor:pointer;font-size:1rem;left:-.5rem;max-width:3rem;position:absolute;top:.5rem;z-index:1}.absoluted_icon svg[data-v-1449cedf]{height:24px;width:24px}";

const ItemStyles_BSR7P9T = [Item_vue_vue_type_style_index_0_scoped_1449cedf_lang];

export { ItemStyles_BSR7P9T as default };
//# sourceMappingURL=Item-styles.B-sR7P9T.mjs.map
