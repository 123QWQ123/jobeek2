import { a as app_vue_vue_type_style_index_0_lang } from './entry-styles-25.mjs-BYJ35Ser.mjs';

const appStyles_i4I9MQKU = [app_vue_vue_type_style_index_0_lang];

export { appStyles_i4I9MQKU as default };
//# sourceMappingURL=app-styles.i4I9MQKU.mjs.map
