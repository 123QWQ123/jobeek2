import { H as Head, T as Title } from './components-DWwOHCR7.mjs';
import { _ as __nuxt_component_0 } from './SearchMobile-WfXJ1gHL.mjs';
import { defineAsyncComponent, ref, computed, watch, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, useSSRContext } from 'vue';
import { e as useRoute, l as useVacancyStore, r as useResumeStore, k as useAuthStore, d as navigateTo } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { u as useAlert } from './useAlert-CPK6c05f.mjs';
import './search-CNCM2ROA.mjs';
import './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const __nuxt_component_3_lazy = defineAsyncComponent(() => import('./DraftCard-BCGYBUfv.mjs').then((c) => c.default || c));
const _sfc_main = {
  __name: "create-resume",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useVacancyStore();
    const providers = ref({
      superjob: false,
      hh: false
    });
    useResumeStore();
    const pageTitle = computed(() => {
      return "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0440\u0435\u0437\u044E\u043C\u0435";
    });
    computed(() => {
      return route.query.message;
    });
    const { handleAlert } = useAlert();
    watch(() => route.query.message, handleAlert);
    const authStore = useAuthStore();
    const isEmployer = computed(() => authStore.isEmployer);
    computed(() => authStore.user);
    computed(() => authStore.employer);
    watch(
      () => isEmployer.value,
      (new_value) => {
        console.log(new_value);
        if (new_value === true) {
          navigateTo({ name: "create-vacancy" });
        }
      }
    );
    computed(() => {
      if (providers.value.hh && providers.value.superjob) {
        return ["hh", "superjob"];
      }
      if (providers.value.hh) {
        return ["hh"];
      }
      if (providers.value.superjob) {
        return ["superjob"];
      }
      return [];
    });
    const draft_el = ref();
    ref(null);
    ref(null);
    ref(null);
    ref([]);
    const isLoading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0;
      const _component_LazyCreateResumeDraftCard = __nuxt_component_3_lazy;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet create-subscribe-page bg-wrapper",
        role: "main"
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(pageTitle))} - Jobeek`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(pageTitle)) + " - Jobeek", 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(pageTitle)) + " - Jobeek", 1)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="bg-wrapper pt">`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="wrapper wrapper-1290"><form class="create-vacancy" name="create-vacancy">`);
      _push(ssrRenderComponent(_component_LazyCreateResumeDraftCard, {
        ref_key: "draft_el",
        ref: draft_el,
        title: unref(pageTitle)
      }, null, _parent));
      _push(`<div class="form-submit-container"><button class="btn btn-outline-primary"> \u0414\u0430\u043B\u0435\u0435 `);
      if (unref(isLoading)) {
        _push(`<div class="ms-2 bg-primary spinner-grow spinner-grow-sm" role="status"><span class="visually-hidden">Loading...</span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</button></div></form></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/create-resume.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=create-resume-B-FTvy04.mjs.map
