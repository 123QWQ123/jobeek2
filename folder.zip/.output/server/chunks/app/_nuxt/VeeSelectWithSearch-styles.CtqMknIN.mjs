import { V as VeeSelectWithSearch_vue_vue_type_style_index_0_lang } from './VeeSelectWithSearch-styles-1.mjs-DH5SIHl1.mjs';

const VeeSelectWithSearchStyles_CtqMknIN = [VeeSelectWithSearch_vue_vue_type_style_index_0_lang];

export { VeeSelectWithSearchStyles_CtqMknIN as default };
//# sourceMappingURL=VeeSelectWithSearch-styles.CtqMknIN.mjs.map
