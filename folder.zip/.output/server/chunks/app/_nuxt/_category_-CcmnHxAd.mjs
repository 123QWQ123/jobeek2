import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-BdrY0gEc.mjs';
import { _ as __nuxt_component_1 } from './page-DRc_CJ9B.mjs';
import { ref, mergeProps, unref, withCtx, createVNode, useSSRContext } from 'vue';
import { e as useRoute } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderList, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_1 } from './eye-BBGyqhm9.mjs';
import { P as Paginate } from '../../vuejs-paginate-next.es.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _imports_0 = "" + buildAssetsURL("unsplash_jrh5lAq-mIs.Ppa4kFkv.jpg");
const _sfc_main = {
  __name: "[category]",
  __ssrInlineRender: true,
  setup(__props) {
    const onPageChange = () => {
    };
    const route = useRoute();
    console.log(route.params.category);
    const quantity = ref(3);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_NuxtPage = __nuxt_component_1;
      if (_ctx.$route.name == "advice-category") {
        _push(`<ul${ssrRenderAttrs(mergeProps({ class: "articles-grid" }, _attrs))}><!--[-->`);
        ssrRenderList(unref(quantity), (i) => {
          _push(`<li>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            class: "article-card",
            "active-class": "advice",
            to: { name: "advice-category-slug", params: { category: unref(route).params.category, slug: i } }
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<div class="article-card-photo"${_scopeId}><img${ssrRenderAttr("src", _imports_0)} alt="#"${_scopeId}></div><div class="article-card-body"${_scopeId}><span class="cat"${_scopeId}>\u0420\u0435\u0437\u044E\u043C\u0435</span><span class="title"${_scopeId}>Adipiscing volutpat porttitor urna ac sed vitae dolor, massa sem ac sed vitae dolor, massa sem dapibus.</span><p class="descr"${_scopeId}>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eu in gravida orci, ac sed vitae dolor, massa sem.</p><div class="views a-count"${_scopeId}><img${ssrRenderAttr("src", _imports_1)} alt="#"${_scopeId}><span${_scopeId}>1 234</span></div></div>`);
              } else {
                return [
                  createVNode("div", { class: "article-card-photo" }, [
                    createVNode("img", {
                      src: _imports_0,
                      alt: "#"
                    })
                  ]),
                  createVNode("div", { class: "article-card-body" }, [
                    createVNode("span", { class: "cat" }, "\u0420\u0435\u0437\u044E\u043C\u0435"),
                    createVNode("span", { class: "title" }, "Adipiscing volutpat porttitor urna ac sed vitae dolor, massa sem ac sed vitae dolor, massa sem dapibus."),
                    createVNode("p", { class: "descr" }, "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eu in gravida orci, ac sed vitae dolor, massa sem."),
                    createVNode("div", { class: "views a-count" }, [
                      createVNode("img", {
                        src: _imports_1,
                        alt: "#"
                      }),
                      createVNode("span", null, "1 234")
                    ])
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]-->`);
        _push(ssrRenderComponent(unref(Paginate), {
          "page-count": 20,
          "click-handler": onPageChange,
          "prev-text": "Prev",
          "next-text": "Next",
          "container-class": "pagination"
        }, null, _parent));
        _push(`</ul>`);
      } else {
        _push(`<div${ssrRenderAttrs(_attrs)}>`);
        _push(ssrRenderComponent(_component_NuxtPage, null, null, _parent));
        _push(`</div>`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/advice/[category].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_category_-CcmnHxAd.mjs.map
