const VeeMultiSelectWithSearchWithSelectedOptions_vue_vue_type_style_index_0_lang = ".select2-container .select2-selection--multiple .select2-selection__rendered{flex-wrap:wrap!important}";

export { VeeMultiSelectWithSearchWithSelectedOptions_vue_vue_type_style_index_0_lang as V };
//# sourceMappingURL=VeeMultiSelectWithSearchWithSelectedOptions-styles-1.mjs-D9Qj2nIm.mjs.map
