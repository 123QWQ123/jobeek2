const DraftCard_vue_vue_type_style_index_0_lang = ".w-box-body.disabled{position:relative}";

const DraftCardStyles_BIjTrIXE = [DraftCard_vue_vue_type_style_index_0_lang];

export { DraftCardStyles_BIjTrIXE as default };
//# sourceMappingURL=DraftCard-styles.BIjTrIXE.mjs.map
