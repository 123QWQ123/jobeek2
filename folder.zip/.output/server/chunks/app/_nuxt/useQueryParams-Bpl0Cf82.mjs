import { useSSRContext, ref, watch, computed, resolveDirective, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrGetDirectiveProps, ssrRenderAttr, ssrRenderClass, ssrRenderStyle, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { u as useState } from './state-D1MfAAni.mjs';
import { useRouter } from 'vue-router';

const __default__ = {
  name: "SelectWithSearch"
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    options: {
      required: true
    },
    label: {
      required: false
    },
    placeholder: {
      required: false
    },
    listStyles: {
      required: false
    },
    listItemStyles: {
      required: false
    },
    modelValue: {
      required: true,
      default: null
    },
    selected: {
      required: false
    },
    not_found: {
      required: false,
      type: String,
      default: "\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E"
    },
    hint: {
      required: false,
      type: String,
      default: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435..."
    }
  },
  emits: ["change", "update:modelValue", "input"],
  setup(__props, { emit: __emit }) {
    var _a;
    const props = __props;
    const isFirst = ref(false);
    const isFirstOpen = ref(true);
    const isOpen = ref(false);
    const options = ref(props.options);
    const searchInput = ref((_a = props.placeholder) != null ? _a : "");
    watch(
      () => props.placeholder,
      () => searchInput.value = props.placeholder
    );
    watch(
      () => props.options,
      (newOptions) => {
        options.value = newOptions;
        if (props.modelValue) {
          selectedOption.value = options.value.find(
            (item) => String(item.value) === String(props.modelValue)
          );
        }
      }
    );
    watch(
      () => props.modelValue,
      (newValue) => {
        selectedOption.value = options.value.find(
          (item) => String(item.value) === String(newValue)
        );
      }
    );
    const selectedOption = ref({});
    watch(
      () => selectedOption.value,
      () => {
        var _a2;
        return searchInput.value = (_a2 = selectedOption.value) == null ? void 0 : _a2.name;
      }
    );
    ref("");
    const placeholderClass = computed(() => {
      return isFirst.value || !selectedOption.value;
    });
    ref();
    watch(
      () => isOpen.value,
      (newOpen) => {
        if (!newOpen) {
          if (searchInput.value === "") {
            searchInput.value = props.placeholder;
          }
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["nice-select n-select d-select", { open: unref(isOpen) }],
        tabindex: "0"
      }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, () => isOpen.value = false)))} data-v-75e232fb><input${ssrRenderAttr("placeholder", props.placeholder)} class="${ssrRenderClass([{ placeholder: unref(placeholderClass) }, "current"])}" data-v-75e232fb><span class="select_arrow" data-v-75e232fb></span>`);
      if (unref(isOpen)) {
        _push(`<ul class="list" style="${ssrRenderStyle(__props.listStyles)}" data-v-75e232fb><!--[-->`);
        ssrRenderList(unref(options), (item) => {
          _push(`<li${ssrRenderAttr("data-value", item.value)} class="option" style="${ssrRenderStyle(__props.listItemStyles)}" data-v-75e232fb>${ssrInterpolate(item.name)}</li>`);
        });
        _push(`<!--]-->`);
        if (unref(options).length === 0) {
          _push(`<li data-v-75e232fb>`);
          if (unref(isFirstOpen)) {
            _push(`<span data-v-75e232fb>${ssrInterpolate(props.hint)}</span>`);
          } else {
            _push(`<span data-v-75e232fb>${ssrInterpolate(props.not_found)}</span>`);
          }
          _push(`</li>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</ul>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/SelectWithSearch.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-75e232fb"]]);
function useQueryParams(initialValues) {
  const router = useRouter();
  useState("search_vacancy_params", () => ({ countries: [1] }));
  function updateQueryParam(key, value) {
    const currentQuery = { ...router.currentRoute.value.query };
    if (Array.isArray(value) || typeof value === "object") {
      value = JSON.stringify(value);
    }
    currentQuery[key] = value;
    router.push({ path: router.currentRoute.value.path, query: currentQuery });
  }
  function removeQueryParam(key) {
    const currentQuery = { ...router.currentRoute.value.query };
    delete currentQuery[key];
    router.push({ path: router.currentRoute.value.path, query: currentQuery });
  }
  function getQueryParam(key) {
    const currentQuery = { ...router.currentRoute.value.query };
    try {
      return JSON.parse(currentQuery[key]);
    } catch (error) {
      return currentQuery[key];
    }
  }
  function getCurrentQueryParams(to_ = "back") {
    const query = { ...router.currentRoute.value.query };
    for (const key in query) {
      try {
        query[key] = JSON.parse(query[key]);
      } catch (error) {
        query[key] = query[key];
      }
    }
    return { ...initialValues, ...query };
  }
  return {
    updateQueryParam,
    removeQueryParam,
    getCurrentQueryParams,
    getQueryParam
  };
}

export { __nuxt_component_1 as _, useQueryParams as u };
//# sourceMappingURL=useQueryParams-Bpl0Cf82.mjs.map
