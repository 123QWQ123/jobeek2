import { V as VeeMultiSelectWithSearch_vue_vue_type_style_index_0_lang } from './VeeMultiSelectWithSearch-styles-1.mjs-D1HKKn17.mjs';

const VeeMultiSelectWithSearchStyles_DtrAVLMR = [VeeMultiSelectWithSearch_vue_vue_type_style_index_0_lang];

export { VeeMultiSelectWithSearchStyles_DtrAVLMR as default };
//# sourceMappingURL=VeeMultiSelectWithSearch-styles.DtrAVLMR.mjs.map
