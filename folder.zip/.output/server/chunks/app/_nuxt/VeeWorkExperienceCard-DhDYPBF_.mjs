import { _ as __nuxt_component_0$2 } from './VeeSelectWithSearch-CuZCClCB.mjs';
import { _ as __nuxt_component_1 } from './VeeMultiSelectWithSearch-Btd5b5Va.mjs';
import __nuxt_component_2 from './VeeCustomSelect-BxrAvA7-.mjs';
import { useForm, ErrorMessage, useField, useFieldArray } from 'vee-validate';
import { ref, computed, watch, resolveDirective, mergeProps, unref, useSSRContext, reactive } from 'vue';
import { u as useYearOptions } from './useYearOptions--VQWJCm5.mjs';
import { u as useMonthOptions } from './VeeBirthDatePicker-7XRn76OG.mjs';
import { u as useFormData } from './useFormData-CRA6LhaU.mjs';
import { ssrRenderAttrs, ssrGetDirectiveProps, ssrRenderClass, ssrInterpolate, ssrRenderComponent, ssrRenderStyle, ssrRenderList } from 'vue/server-renderer';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { u as useWatchStateValues } from './useWatchStateValues-DimKH74z.mjs';
import { e as useRoute, r as useResumeStore, l as useVacancyStore, m as useProfileStore } from '../server.mjs';
import { R as ResumeTextInput } from './ResumeTextInput-BxTsuw7y.mjs';
import { R as ResumeTextarea } from './Form-Bl6z4ElR.mjs';
import { R as ResumeCheckboxInput } from './ResumeCheckboxInput-DBsB0Z0m.mjs';
import { u as useProviderFields } from './useProviderFields-B2EuWWWy.mjs';
import { u as useProviders } from './useProviders-Ck9yopDY.mjs';
import { u as useResumeHooks } from './useResumeHooks-BM2nRo7f.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { u as useFormValidation } from './useFormValidation-BMv_R6aU.mjs';
import { u as useDiff } from './useDiff-Chx28f43.mjs';
import { toTypedSchema } from '@vee-validate/zod';
import { z } from 'zod';
import './useSort-Dy_x39w5.mjs';
import './search-CNCM2ROA.mjs';
import 'moment';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './VuePhoneInput-C5R34atv.mjs';
import './check-BGWLIG1L.mjs';
import './state-D1MfAAni.mjs';

const _sfc_main$2 = {
  __name: "Item",
  __ssrInlineRender: true,
  props: ["idx", "name"],
  emits: ["delete", "update"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    useField(
      () => `${props.name}[${props.idx}].city_id`
    );
    const errors = ref(props.errors);
    watch(
      () => props.errors,
      (newErrors) => {
        errors.value = newErrors;
      }
    );
    useDictionaryStore();
    const vacancyStore = useVacancyStore();
    const { getIndustries } = vacancyStore;
    const { value: until_today } = useField(
      () => `${props.name}[${props.idx}].until_today`
    );
    useField(
      () => `${props.name}[${props.idx}].industries`
    );
    const updateIndustryInput = async (newValue = "") => {
      let items = await getIndustries();
      items = items.filter((item) => item.title.includes(newValue));
      industryOptions.value = items.map((item) => ({
        value: item.id,
        name: item.title
      }));
    };
    const profileStore = useProfileStore();
    const { getCityName, getCityNameFromArea2 } = useResumeHooks();
    const { searchCities } = profileStore;
    const industryOptions = ref([]);
    const cityOptions = ref([]);
    const updateCityInput = async (newValue = "") => {
      var _a;
      if (newValue.length < 2) {
        return;
      }
      const items = (_a = await searchCities({ search: newValue })) != null ? _a : [];
      cityOptions.value = items.map((item) => ({
        value: item.id,
        name: getCityNameFromArea2(item)
      }));
    };
    useResumeStore();
    ref(props.isNew);
    const { providers } = useProviders();
    const state = reactive({
      profession: {
        is_hidden: false
      },
      city_id: {
        is_hidden: false
      },
      city_name: {
        is_hidden: false
      },
      company: {
        is_hidden: false
      },
      company_url: {
        is_hidden: false
      },
      industries: {
        is_hidden: false
      },
      start_month: {
        is_hidden: false
      },
      end_month: {
        is_hidden: false
      },
      start_year: {
        is_hidden: false
      },
      until_today: {
        is_hidden: false
      },
      end_year: {
        is_hidden: false
      },
      responsibilities: {
        is_hidden: false
      },
      achievements: {
        is_hidden: false
      },
      company_scope: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        profession: true,
        responsibilities: true,
        company: true,
        achievements: true,
        company_scope: null,
        company_url: false,
        city_id: false,
        city_name: false,
        industries: false,
        start_year: true,
        start_month: true,
        end_month: false,
        end_year: false,
        until_today: false
      },
      superjob: {
        profession: false,
        responsibilities: true,
        company: false,
        achievements: false,
        company_scope: null,
        company_url: false,
        city_id: false,
        city_name: false,
        industries: null,
        start_year: true,
        start_month: true,
        end_month: false,
        end_year: false,
        until_today: false
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    watch(
      () => providers.value,
      () => {
        walkThroughFields(providers.value);
      }
    );
    const yearOptions = computed(() => useYearOptions());
    const monthOptions = computed(() => useMonthOptions());
    const save = () => {
      emit("update", props.id, useFormData(state));
    };
    watch(() => useWatchStateValues(state), save);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeSelectWithSearch = __nuxt_component_0$2;
      const _component_VeeMultiSelectWithSearch = __nuxt_component_1;
      const _component_VeeCustomSelect = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row position-relative empty-area" }, _attrs))} data-v-c98a61b2><span class="position-absolute absoluted_icon" data-v-c98a61b2><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" data-v-c98a61b2><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-c98a61b2></path></svg></span><div class="col-12" data-v-c98a61b2><div class="row" data-v-c98a61b2><div class="input-row" style="${ssrRenderStyle(!unref(state).profession.is_hidden ? null : { display: "none" })}" data-v-c98a61b2><label for="position" data-v-c98a61b2>\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C<b data-v-c98a61b2>*</b></label><div class="input-wrapper" data-v-c98a61b2>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${__props.name}[${__props.idx}].profession`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).company_url.is_hidden ? null : { display: "none" })}" data-v-c98a61b2><label for="position" data-v-c98a61b2>\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u0441\u0430\u0439\u0442 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438<b data-v-c98a61b2>*</b></label><div class="input-wrapper" data-v-c98a61b2>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${__props.name}[${__props.idx}].company_url`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).company.is_hidden ? null : { display: "none" })}" data-v-c98a61b2><label for="position" data-v-c98a61b2>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438<b data-v-c98a61b2>*</b></label><div class="input-wrapper" data-v-c98a61b2>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${__props.name}[${__props.idx}].company`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-c98a61b2><label data-v-c98a61b2>\u0413\u043E\u0440\u043E\u0434:</label><div class="input-wrapper mt-2" data-v-c98a61b2>`);
      _push(ssrRenderComponent(_component_VeeSelectWithSearch, {
        options: unref(cityOptions),
        name: `${props.name}[${props.idx}].city_id`,
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0433\u043E\u0440\u043E\u0434",
        onInput: updateCityInput
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).company_scope.is_hidden ? null : { display: "none" })}" data-v-c98a61b2><label for="position" data-v-c98a61b2>\u0414\u0435\u044F\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438</label><div class="input-wrapper" data-v-c98a61b2>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${props.name}[${props.idx}].company_scope`,
        placeholder: "\u041E\u043F\u0438\u0448\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).industries.is_hidden ? null : { display: "none" })}" data-v-c98a61b2><label for="position" data-v-c98a61b2>\u041E\u0442\u0440\u0430\u0441\u043B\u0435\u0439 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438<b data-v-c98a61b2>*</b></label><div class="input-wrapper" data-v-c98a61b2>`);
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, {
        options: unref(industryOptions),
        onInput: updateIndustryInput,
        name: `${props.name}[${props.idx}].industries`,
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-c98a61b2><label for="position" data-v-c98a61b2>\u0414\u0430\u0442\u044B<b data-v-c98a61b2>*</b></label><div class="input-wrapper" data-v-c98a61b2><div class="c2" data-v-c98a61b2><div style="${ssrRenderStyle(!unref(state).start_year.is_hidden ? null : { display: "none" })}" data-v-c98a61b2>`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        options: unref(yearOptions),
        name: `${props.name}[${props.idx}].start_year`,
        label: "\u041D\u0430\u0447\u0430\u043B\u043E \u0433\u043E\u0434\u0430"
      }, null, _parent));
      if (unref(state).start_year.isValid) {
        _push(`<div class="alert alert-warning" data-v-c98a61b2> \u041D\u0430\u0447\u0430\u043B\u043E \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043C\u0435\u043D\u044C\u0448\u0435 \u0447\u0435\u043C \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044F </div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div style="${ssrRenderStyle(!unref(state).start_month.is_hidden ? null : { display: "none" })}" data-v-c98a61b2>`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        options: unref(monthOptions),
        name: `${props.name}[${props.idx}].start_month`,
        label: "\u041D\u0430\u0447\u0430\u043B\u043E \u043C\u0435\u0441\u044F\u0446\u0430"
      }, null, _parent));
      _push(`</div></div>`);
      if (!unref(until_today) === true) {
        _push(`<div class="c2 mt-2" data-v-c98a61b2><div style="${ssrRenderStyle(!unref(state).end_year.is_hidden ? null : { display: "none" })}" data-v-c98a61b2>`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(yearOptions),
          name: `${__props.name}[${__props.idx}].end_year`,
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div><div style="${ssrRenderStyle(!unref(state).end_month.is_hidden ? null : { display: "none" })}" data-v-c98a61b2>`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(monthOptions),
          name: `${props.name}[${props.idx}].end_month`,
          label: "\u041E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 \u043C\u0435\u0441\u044F\u0446\u0430"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="check-block mt-2" style="${ssrRenderStyle(!unref(state).until_today.is_hidden ? null : { display: "none" })}" data-v-c98a61b2><div class="checkbox" data-v-c98a61b2>`);
      _push(ssrRenderComponent(ResumeCheckboxInput, {
        label: "\u0420\u0430\u0431\u043E\u0442\u0430\u044E \u043F\u043E \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0435\u0435 \u0432\u0440\u0435\u043C\u044F",
        name: `${props.name}[${props.idx}].until_today`
      }, null, _parent));
      _push(`</div></div></div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).responsibilities.is_hidden ? null : { display: "none" })}" data-v-c98a61b2><label for="position" data-v-c98a61b2>\u041E\u0431\u044F\u0437\u0430\u043D\u043D\u043E\u0441\u0442\u0438<b data-v-c98a61b2>*</b></label><div class="input-wrapper" data-v-c98a61b2>`);
      _push(ssrRenderComponent(ResumeTextarea, {
        name: `${props.name}[${props.idx}].responsibilities`,
        placeholder: "\u041E\u043F\u0438\u0448\u0438\u0442\u0435, \u043A\u0430\u043A\u0438\u0435 \u043E\u0431\u044F\u0437\u0430\u043D\u043D\u043E\u0441\u0442\u0438 \u0443 \u0432\u0430\u0441 \u0431\u044B\u043B\u0438 \u0432 \u044D\u0442\u043E\u0439 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438, \u0447\u0442\u043E \u0438\u043C\u0435\u043D\u043D\u043E \u0432\u044B \u0434\u0435\u043B\u0430\u043B\u0438"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).achievements.is_hidden ? null : { display: "none" })}" data-v-c98a61b2><label for="position" data-v-c98a61b2>\u0414\u043E\u0441\u0442\u0438\u0436\u0435\u043D\u0438\u044F<b data-v-c98a61b2>*</b></label><div class="input-wrapper" data-v-c98a61b2>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${props.name}[${props.idx}].achievements`,
        placeholder: "\u041E\u043F\u0438\u0448\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeWorkExperience/Item.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-c98a61b2"]]);
const _sfc_main$1 = {
  __name: "Form",
  __ssrInlineRender: true,
  props: ["name", "parent_type_id", "providers"],
  setup(__props) {
    const props = __props;
    const { push, fields, remove } = useFieldArray(() => props.name);
    useDictionaryStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeVeeWorkExperienceItem = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><!--[-->`);
      ssrRenderList(unref(fields), (field, idx) => {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_CreateResumeVeeWorkExperienceItem, {
          onRemove: unref(remove),
          name: props.name,
          providers: props.providers,
          idx
        }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]-->`);
      if (unref(fields).length === 0) {
        _push(`<button type="button" class="btn btn-primary btn-sm mt-1"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(fields).length > 0) {
        _push(`<button type="button" class="btn btn-primary mt-1 btn-sm"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435 </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeWorkExperience/Form.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$1;
const _sfc_main = {
  __name: "VeeWorkExperienceCard",
  __ssrInlineRender: true,
  setup(__props, { expose: __expose }) {
    var _a2;
    var _a;
    ref(false);
    const route = useRoute();
    const resumeStore = useResumeStore();
    const resumeID = computed(() => route.params.id);
    const experience = ref((_a2 = (_a = resumeStore.my_resume) == null ? void 0 : _a.experience) != null ? _a2 : []);
    const isShown = ref(false);
    const isChanged = ref(false);
    const isSaved = ref(false);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const { providers } = useProviders();
    const schema = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false) {
        const experienceScheme2 = z.object({
          profession: z.string(),
          responsibilities: z.string(),
          company: z.string(),
          achievements: z.string(),
          start_year: z.number(),
          start_month: z.string(),
          end_year: z.number(),
          end_month: z.string(),
          until_today: z.boolean().nullable().optional(),
          city_id: z.number(),
          // city_name: z.boolean().nullable().optional(),
          company_url: z.string().nullish().optional(),
          industries: z.number().array().nonempty(),
          company_scope: z.string().nullish().optional()
        });
        return z.object({
          experience: z.array(experienceScheme2).nonempty()
        });
      }
      if (providers.value.hh === false && providers.value.superjob === true) {
        const experienceScheme2 = z.object({
          profession: z.string(),
          responsibilities: z.string(),
          company: z.string(),
          achievements: z.string().nullable(),
          start_year: z.number(),
          start_month: z.string(),
          end_year: z.number().nullish().optional(),
          end_month: z.string().nullish().optional(),
          until_today: z.boolean().nullable().optional(),
          city_id: z.number(),
          // city_name: z.boolean().nullable().optional(),
          company_url: z.string().nullish().optional(),
          industries: z.number().array().nullable(),
          company_scope: z.string().nullish().optional()
        });
        return z.object({
          experience: z.array(experienceScheme2).optional()
        });
      }
      const experienceScheme = z.object({
        profession: z.string(),
        responsibilities: z.string(),
        company: z.string(),
        achievements: z.string(),
        start_year: z.number(),
        start_month: z.string(),
        end_year: z.number(),
        end_month: z.string(),
        until_today: z.boolean().nullable().optional(),
        city_id: z.number(),
        // city_name: z.boolean().nullable().optional(),
        company_url: z.string(),
        industries: z.number().array().nonempty(),
        company_scope: z.string()
      });
      return z.object({
        experience: z.array(experienceScheme).nonempty()
      });
    });
    const initialValues = ref({
      experience: []
    });
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const sectionData = ref({
      experience: []
    });
    const getFields = (newObject) => {
      return {
        experience: newObject.experience.map((item) => {
          var _a3;
          var _a22;
          return {
            industries: (_a3 = item.industries.map((sub_item) => sub_item.id)) != null ? _a3 : [],
            city_id: (_a22 = item.city) == null ? void 0 : _a22.id,
            end_month: String(item.end_month).padStart(2, 0),
            start_month: String(item.start_month).padStart(2, 0),
            profession: item.profession,
            company: item.company,
            company_url: item.company_url,
            company_scope: item.company_scope,
            start_year: item.start_year,
            end_year: item.end_year,
            until_today: item.until_today,
            responsibilities: item.responsibilities,
            achievements: item.achievements
          };
        })
      };
    };
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
          if (experience.value.length) {
            isShown.value = true;
          }
        }
      }
    );
    watch(
      () => resumeStore.my_resume,
      (newResume) => {
        if (newResume) {
          sectionData.value = getFields(newResume);
        }
      }
    );
    watch(
      () => isCollapsed.value,
      (newData) => {
        if (!newData) {
          isShown.value = true;
        }
      }
    );
    const { getResume, updateResume } = resumeStore;
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    ref(false);
    const errorMessage = ref(null);
    ref(false);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435!";
        return false;
      }
      setErrors({});
      const payload = {
        form_data: "EXPERIENCE_DATA",
        ...values
      };
      console.log(values);
      const resData = await updateResume(resumeID.value, payload);
      console.log(resData);
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = true;
      setErrors({});
      resetForm({ values });
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      var _a22, _b;
      return ((_b = (_a22 = resumeStore.resume) == null ? void 0 : _a22.work_histories) == null ? void 0 : _b.length) > 0;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeVeeWorkExperienceForm = __nuxt_component_0;
      const _component_ErrorMessage = ErrorMessage;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u041E\u043F\u044B\u0442 \u0440\u0430\u0431\u043E\u0442\u044B</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div><div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div><div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      if (unref(isShown)) {
        _push(`<div class="form_content"><div class="row">`);
        _push(ssrRenderComponent(_component_CreateResumeVeeWorkExperienceForm, {
          name: "experience",
          ref: "workExperienceElement"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<div class="empty-area"><span>\u0417\u0434\u0435\u0441\u044C \u0432\u044B \u043C\u043E\u0436\u0435\u0442\u0435 \u0443\u043A\u0430\u0437\u0430\u0442\u044C</span><button class="add" type="button"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button></div>`);
      }
      _push(`<div class="text-danger">`);
      _push(ssrRenderComponent(_component_ErrorMessage, { name: "experience" }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeWorkExperienceCard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=VeeWorkExperienceCard-DhDYPBF_.mjs.map
