import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { mergeProps, useSSRContext, computed, unref, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList } from 'vue/server-renderer';
import { _ as _imports_1$1 } from './eye-BBGyqhm9.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { _ as __nuxt_component_0$2 } from './nuxt-link-BdrY0gEc.mjs';
import { e as useRoute } from '../server.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _imports_0$1 = "" + buildAssetsURL("unsplash_jrh5lAq-mIs-art.Ctb5UCVJ.jpg");
const _imports_1 = "data:image/svg+xml,%3csvg%20width='20'%20height='20'%20viewBox='0%200%2020%2020'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M10%2018.75C8.26942%2018.75%206.57769%2018.2368%205.13876%2017.2754C3.69983%2016.3139%202.57832%2014.9473%201.91606%2013.3485C1.25379%2011.7496%201.08051%209.9903%201.41813%208.29296C1.75575%206.59563%202.58911%205.03653%203.81282%203.81282C5.03653%202.58911%206.59563%201.75575%208.29296%201.41813C9.9903%201.08051%2011.7496%201.25379%2013.3485%201.91606C14.9473%202.57832%2016.3139%203.69983%2017.2754%205.13876C18.2368%206.57769%2018.75%208.26942%2018.75%2010C18.75%2012.3206%2017.8281%2014.5462%2016.1872%2016.1872C14.5462%2017.8281%2012.3206%2018.75%2010%2018.75ZM10%202.5C8.51664%202.5%207.0666%202.93987%205.83323%203.76398C4.59986%204.58809%203.63856%205.75943%203.07091%207.12988C2.50325%208.50032%202.35473%2010.0083%202.64411%2011.4632C2.9335%2012.918%203.64781%2014.2544%204.6967%2015.3033C5.7456%2016.3522%207.08197%2017.0665%208.53683%2017.3559C9.99168%2017.6453%2011.4997%2017.4968%2012.8701%2016.9291C14.2406%2016.3614%2015.4119%2015.4001%2016.236%2014.1668C17.0601%2012.9334%2017.5%2011.4834%2017.5%2010C17.5%208.01088%2016.7098%206.10323%2015.3033%204.6967C13.8968%203.29018%2011.9891%202.5%2010%202.5Z'%20fill='%2378757E'/%3e%3cpath%20d='M12.8688%2013.75L9.375%2010.2562V4.375H10.625V9.7375L13.75%2012.8687L12.8688%2013.75Z'%20fill='%2378757E'/%3e%3c/svg%3e";
const _imports_3 = "" + buildAssetsURL("unsplash_Imc-IoZDMXc.BV30FlaL.jpg");
const _imports_4 = "data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M24%2012C24%205.37075%2018.6248%200%2012%200C5.37075%200%200%205.37075%200%2012C0%2017.988%204.38675%2022.953%2010.125%2023.8522V15.4695H7.07775V12.0007H10.125V9.3555C10.125%206.34875%2011.9138%204.68825%2014.6558%204.68825C15.969%204.68825%2017.3438%204.92225%2017.3438%204.92225V7.875H15.828C14.34%207.875%2013.875%208.80125%2013.875%209.75V12H17.2028L16.668%2015.4688H13.875V23.8515C19.6087%2022.9522%2024%2017.9872%2024%2011.9992V12Z'%20fill='%233759E1'/%3e%3c/svg%3e";
const _imports_5 = "data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M12%200C5.37253%200%200%205.37253%200%2012C0%2018.6275%205.37253%2024%2012%2024C18.6275%2024%2024%2018.6275%2024%2012C24%205.37253%2018.6275%200%2012%200Z'%20fill='%2340B3E0'/%3e%3cpath%20d='M17.8408%206.90302L15.6974%2017.7095C15.6974%2017.7095%2015.3977%2018.4589%2014.5733%2018.0992L9.62728%2014.3072L7.82878%2013.438L4.80122%2012.4187C4.80122%2012.4187%204.33659%2012.2539%204.29159%2011.8942C4.24659%2011.5345%204.81622%2011.3396%204.81622%2011.3396L16.8515%206.6184C16.8515%206.6184%2017.8407%206.18377%2017.8407%206.90321'%20fill='white'/%3e%3cpath%20d='M9.24656%2017.5877C9.24656%2017.5877%209.10219%2017.5742%208.92219%2017.0046C8.74247%2016.4351%207.82812%2013.4375%207.82812%2013.4375L15.0973%208.82126C15.0973%208.82126%2015.517%208.56645%2015.502%208.82126C15.502%208.82126%2015.5769%208.86626%2015.352%209.07607C15.1273%209.28598%209.64172%2014.2169%209.64172%2014.2169'%20fill='%23D2E5F1'/%3e%3cpath%20d='M11.5226%2015.7605L9.56634%2017.5442C9.56634%2017.5442%209.41334%2017.6603%209.24609%2017.5875L9.62072%2014.2744'%20fill='%23B5CFE4'/%3e%3c/svg%3e";
const _imports_6 = "data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3ccircle%20cx='12'%20cy='12'%20r='12'%20fill='%235665EA'/%3e%3cg%20clip-path='url(%23clip0_170_3703)'%3e%3cpath%20fill-rule='evenodd'%20clip-rule='evenodd'%20d='M19.063%208.53679C19.1737%208.17279%2019.063%207.90479%2018.533%207.90479H16.783C16.3377%207.90479%2016.1324%208.13612%2016.021%208.39145C16.021%208.39145%2015.131%2010.5221%2013.8704%2011.9061C13.4624%2012.3075%2013.277%2012.4348%2013.0544%2012.4348C12.943%2012.4348%2012.7757%2012.3075%2012.7757%2011.9428V8.53679C12.7757%208.09945%2012.653%207.90479%2012.2824%207.90479H9.53035C9.25235%207.90479%209.08502%208.10745%209.08502%208.30012C9.08502%208.71412%209.71569%208.81012%209.78035%209.97545V12.5075C9.78035%2013.0628%209.67835%2013.1635%209.45569%2013.1635C8.86235%2013.1635%207.41902%2011.0228%206.56235%208.57345C6.39635%208.09679%206.22835%207.90479%205.78102%207.90479H4.02969C3.52969%207.90479%203.42969%208.13612%203.42969%208.39145C3.42969%208.84612%204.02302%2011.1048%206.19302%2014.0921C7.63969%2016.1321%209.67635%2017.2381%2011.5317%2017.2381C12.6444%2017.2381%2012.7817%2016.9928%2012.7817%2016.5695V15.0275C12.7817%2014.5361%2012.887%2014.4381%2013.2397%2014.4381C13.4997%2014.4381%2013.9444%2014.5661%2014.983%2015.5495C16.1697%2016.7155%2016.365%2017.2381%2017.033%2017.2381H18.783C19.283%2017.2381%2019.5337%2016.9928%2019.3897%2016.5075C19.231%2016.0248%2018.6644%2015.3241%2017.913%2014.4928C17.505%2014.0195%2016.893%2013.5095%2016.707%2013.2541C16.4477%2012.9268%2016.5217%2012.7808%2016.707%2012.4895C16.707%2012.4895%2018.8404%209.53879%2019.0624%208.53679H19.063Z'%20fill='white'/%3e%3c/g%3e%3cdefs%3e%3cclipPath%20id='clip0_170_3703'%3e%3crect%20width='16'%20height='16'%20fill='white'%20transform='translate(3.42969%204.57129)'/%3e%3c/clipPath%3e%3c/defs%3e%3c/svg%3e";
const _imports_7 = "data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3ccircle%20cx='12'%20cy='12'%20r='12'%20fill='%23FF9533'/%3e%3cpath%20d='M11.9877%2012.2761C9.70082%2012.2761%207.80006%2010.3769%207.80006%208.12969C7.80006%205.80474%209.70082%203.90479%2011.9885%203.90479C14.354%203.90479%2016.1762%205.80393%2016.1762%208.12969C16.1721%209.23311%2015.7301%2010.2898%2014.9473%2011.0674C14.1645%2011.8451%2013.1049%2012.2801%2012.0015%2012.2769L11.9877%2012.2761ZM11.9877%206.34712C11.0195%206.34712%2010.2829%207.16069%2010.2829%208.1305C10.2829%209.09869%2011.0195%209.83536%2011.9885%209.83536C12.9964%209.83536%2013.6942%209.09869%2013.6942%208.1305C13.695%207.15988%2012.9964%206.34712%2011.9877%206.34712ZM13.6553%2015.7263L16.0216%2018.0132C16.4871%2018.5159%2016.4871%2019.2525%2016.0216%2019.718C15.5181%2020.2207%2014.7417%2020.2207%2014.354%2019.718L11.9885%2017.3923L9.70082%2019.718C9.46849%2019.9504%209.15763%2020.0661%208.80792%2020.0661C8.53673%2020.0661%208.22668%2019.9495%207.95468%2019.718C7.4892%2019.2525%207.4892%2018.5159%207.95468%2018.0124L10.359%2015.7255C9.4907%2015.4683%208.65778%2015.1042%207.87939%2014.6415C7.29735%2014.3315%207.18158%2013.5567%207.49163%2012.9747C7.87939%2012.3935%208.5772%2012.2388%209.19811%2012.6266C10.0389%2013.1397%2011.0048%2013.4111%2011.9898%2013.4111C12.9747%2013.4111%2013.9406%2013.1397%2014.7814%2012.6266C15.4023%2012.2388%2016.1382%2012.3935%2016.4871%2012.9747C16.8368%2013.5567%2016.6805%2014.3306%2016.1373%2014.6415C15.4015%2015.107%2014.5483%2015.4559%2013.6562%2015.7271L13.6553%2015.7263Z'%20fill='white'/%3e%3c/svg%3e";
const _sfc_main$3 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<article${ssrRenderAttrs(mergeProps({ class: "article" }, _attrs))}><div class="cat">\u041F\u0440\u043E \u0434\u0435\u043D\u044C\u0433\u0438</div><div class="article-image"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div><div class="article-info-row"><div class="time a-count"><img${ssrRenderAttr("src", _imports_1)} alt="#"><span>1 234</span></div><div class="views a-count"><img${ssrRenderAttr("src", _imports_1$1)} alt="#"><span>1 234 </span></div></div><h1>Adipiscing volutpat porttitor urna ac sed vitae dolor, massa sem ac sed vitae dolor, massa sem dapibus. </h1><p>According to sitefy.com, there are approximately 10,500 new websites every hour. It\u2019s a monstrous number, right? But among all these websites, only a few stand out enough to win the Webby Awards.</p><p>Ever heard about them?</p><p>Regarding the digital world, these awards are some of the most important internationally speaking. The main categories are websites, mobile sites, videos, advertising, apps and software, podcasts, among others.</p><p>In every edition, there are two prizes for each category.</p><p>On one hand, \u201CThe Webby Award\u201D. The winners of this recognition are selected by the \u201CInternational Academy of Digital Arts and Sciences\u201D. The jury consists of digital experts, famous entrepreneurs, creative minds, and creators.</p><p>On the other hand, \u201CThe Webby People\u2019s Voice Award\u201D. This award is given by popular vote. However, the nominated works are chosen by the academy.</p><img${ssrRenderAttr("src", _imports_3)} alt="#"><h2>The jury consists of digital experts, famous entrepreneurs</h2><p>On one hand, \u201CThe Webby Award\u201D. The winners of this recognition are selected by the \u201CInternational Academy of Digital Arts and Sciences\u201D. The jury consists of digital experts, famous entrepreneurs, creative minds, and creators.</p><p>On the other hand, \u201CThe Webby People\u2019s Voice Award\u201D. This award is given by popular vote. However, the nominated works are chosen by the academy.</p><div class="article-footer"><div class="socials-widget"><span>\u041F\u043E\u0434\u0435\u043B\u0438\u0442\u044C\u0441\u044F:</span><ul><li><a href="#"><img${ssrRenderAttr("src", _imports_4)} alt="#"></a></li><li><a href="#"><img${ssrRenderAttr("src", _imports_5)} alt="#"></a></li><li><a href="#"><img${ssrRenderAttr("src", _imports_6)} alt="#"></a></li><li><a href="#"><img${ssrRenderAttr("src", _imports_7)} alt="#"></a></li></ul></div></div></article>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Advice/Category/Post/Content.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$1]]);
const _imports_0 = "" + buildAssetsURL("unsplash_QBpZGqEMsKgmini.CLa7Zxh0.jpg");
const _sfc_main$2 = {
  __name: "LatestListItem",
  __ssrInlineRender: true,
  props: ["id"],
  setup(__props) {
    const props = __props;
    const url = computed(() => "http://localhost:3033/advice/popular/" + props.id);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$2;
      _push(`<li${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: unref(url),
        class: "publication-card-mini",
        href: "#"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="publication-card-mini-img"${_scopeId}><img${ssrRenderAttr("src", _imports_0)} alt="#"${_scopeId}></div><div class="publication-card-mini-text"${_scopeId}><h5 class="title"${_scopeId}>Adipiscing volutpat porttitor urna ac sed vitae dolor, massa sem ac sed </h5><div class="views a-count"${_scopeId}><img${ssrRenderAttr("src", _imports_1$1)} alt="#"${_scopeId}><span${_scopeId}>1 234</span></div></div>`);
          } else {
            return [
              createVNode("div", { class: "publication-card-mini-img" }, [
                createVNode("img", {
                  src: _imports_0,
                  alt: "#"
                })
              ]),
              createVNode("div", { class: "publication-card-mini-text" }, [
                createVNode("h5", { class: "title" }, "Adipiscing volutpat porttitor urna ac sed vitae dolor, massa sem ac sed "),
                createVNode("div", { class: "views a-count" }, [
                  createVNode("img", {
                    src: _imports_1$1,
                    alt: "#"
                  }),
                  createVNode("span", null, "1 234")
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Advice/Category/Post/LatestListItem.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$2;
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_AdviceCategoryPostLatestListItem = __nuxt_component_0;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "publications-col sticky-item" }, _attrs))}><h4 class="publications-col-title">\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0435 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438</h4><ul class="publications-col-list"><!--[-->`);
  ssrRenderList(4, (i) => {
    _push(ssrRenderComponent(_component_AdviceCategoryPostLatestListItem, {
      key: i,
      id: i
    }, null, _parent));
  });
  _push(`<!--]--></ul></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Advice/Category/Post/LatestList.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    console.log(route);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AdviceCategoryPostContent = __nuxt_component_0$1;
      const _component_AdviceCategoryPostLatestList = __nuxt_component_1;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet advice-single-page bg-wrapper",
        role: "main"
      }, _attrs))}><div class="has-sidebar wrapper wrapper-1290"><div class="content">`);
      _push(ssrRenderComponent(_component_AdviceCategoryPostContent, null, null, _parent));
      _push(`</div><aside class="sidebar">`);
      _push(ssrRenderComponent(_component_AdviceCategoryPostLatestList, null, null, _parent));
      _push(`</aside></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/advice/[category]/[slug]/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-BMZKoR-E.mjs.map
