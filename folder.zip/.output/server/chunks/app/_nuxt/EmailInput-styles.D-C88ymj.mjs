const EmailInput_vue_vue_type_style_index_0_scoped_6f01572e_lang = "input[type=email][data-v-6f01572e]:disabled{background:#ccc}.absolute_button[data-v-6f01572e]{position:absolute;right:.3rem;top:.25rem}";

const EmailInputStyles_DC88ymj = [EmailInput_vue_vue_type_style_index_0_scoped_6f01572e_lang];

export { EmailInputStyles_DC88ymj as default };
//# sourceMappingURL=EmailInput-styles.D-C88ymj.mjs.map
