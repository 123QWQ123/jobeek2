import { useSSRContext, ref, computed, watch, resolveDirective, mergeProps, unref, getCurrentInstance } from 'vue';
import { j as useNuxtApp } from '../server.mjs';
import { ssrRenderAttrs, ssrGetDirectiveProps, ssrInterpolate, ssrRenderClass, ssrRenderList, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseEqual } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const ATTR_KEY = "data-n-ids";
function useId(key) {
  var _a;
  if (typeof key !== "string") {
    throw new TypeError("[nuxt] [useId] key must be a string.");
  }
  key = key.slice(1);
  const nuxtApp = useNuxtApp();
  const instance = getCurrentInstance();
  if (!instance) {
    throw new TypeError("[nuxt] `useId` must be called within a component setup function.");
  }
  nuxtApp._id || (nuxtApp._id = 0);
  instance._nuxtIdIndex || (instance._nuxtIdIndex = {});
  (_a = instance._nuxtIdIndex)[key] || (_a[key] = 0);
  const instanceIndex = key + ":" + instance._nuxtIdIndex[key]++;
  {
    const ids = JSON.parse(instance.attrs[ATTR_KEY] || "{}");
    ids[instanceIndex] = key + ":" + nuxtApp._id++;
    instance.attrs[ATTR_KEY] = JSON.stringify(ids);
    return ids[instanceIndex];
  }
}
const __default__ = {
  name: "CustomSelectWithRadio"
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: ["options", "modelValue", "label"],
  emits: ["change", "update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const isOpen = ref(false);
    const options = computed(() => props.options);
    useId("$7S0EfMMXRO");
    const label = computed(() => {
      if (selectedOption.value) {
        return selectedOption.value.name;
      }
      return props.label;
    });
    const selectedValue = ref(null);
    watch(
      () => selectedValue.value,
      (newValue) => {
        emit("update:modelValue", newValue);
        emit("change", newValue);
      }
    );
    const selectedOption = ref(null);
    const reApply = (newValue) => {
    };
    watch(() => props.modelValue, reApply);
    watch(() => props.options, reApply);
    function close() {
      isOpen.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["custom-select", { open: unref(isOpen) }]
      }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, close)))} data-v-cf885613><div class="custom-select__trigger" data-v-cf885613><span data-v-cf885613>${ssrInterpolate(unref(label))}</span><div class="${ssrRenderClass([{ open: unref(isOpen) }, "radio_arrow"])}" data-v-cf885613></div></div><div class="custom-options" data-v-cf885613><!--[-->`);
      ssrRenderList(unref(options), (item) => {
        _push(`<div class="custom-option" data-v-cf885613><input type="radio"${ssrRenderAttr("id", item.value)}${ssrIncludeBooleanAttr(ssrLooseEqual(unref(selectedValue), item.value)) ? " checked" : ""}${ssrRenderAttr("value", item.value)} name="random_radio_" data-v-cf885613><label${ssrRenderAttr("for", item.value)} data-v-cf885613>${ssrInterpolate(item.name)}</label></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/CustomSelectWithRadio.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-cf885613"]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=CustomSelectWithRadio-CUSovK5B.mjs.map
