const Industry_vue_vue_type_style_index_0_scoped_332efe31_lang = ".check-block label[data-v-332efe31]{white-space:pre-wrap}";

const IndustryStyles_DduabFGb = [Industry_vue_vue_type_style_index_0_scoped_332efe31_lang];

export { IndustryStyles_DduabFGb as default };
//# sourceMappingURL=Industry-styles.DduabFGb.mjs.map
