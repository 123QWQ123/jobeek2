const VeeForm_vue_vue_type_style_index_0_scoped_3f4bdef7_lang = ".absoluted_icon[data-v-3f4bdef7]{cursor:pointer;font-size:1rem;left:-1.8rem;max-width:3rem;position:absolute;top:.5rem;z-index:1}.absoluted_icon svg[data-v-3f4bdef7]{height:24px;width:24px}";

export { VeeForm_vue_vue_type_style_index_0_scoped_3f4bdef7_lang as V };
//# sourceMappingURL=VeeForm-styles-1.mjs-BBheLIjb.mjs.map
