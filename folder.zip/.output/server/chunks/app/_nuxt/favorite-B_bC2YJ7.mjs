import { _ as __nuxt_component_0 } from './SearchMobile-WfXJ1gHL.mjs';
import { _ as __nuxt_component_1 } from './ConnectedProviders-HekmsW6F.mjs';
import { _ as __nuxt_component_2 } from './List-Bn78pTGg.mjs';
import { computed, watch, mergeProps, useSSRContext } from 'vue';
import { u as useHead, k as useAuthStore, d as navigateTo } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './search-CNCM2ROA.mjs';
import './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import './superjob-DOWPfj1m.mjs';
import 'moment';
import './PageLoader-CgN00RaA.mjs';
import './Item-EOkX6xfY.mjs';
import './nuxt-link-BdrY0gEc.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import './CustomSelectWithRadio-CUSovK5B.mjs';
import './useVacancyForm-UJ-LLtx0.mjs';
import 'unhead';
import '@unhead/shared';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main = {
  __name: "favorite",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u041C\u043E\u0438 \u0438\u0437\u0431\u0440\u0430\u043D\u043D\u0438\u0435 \u0440\u0435\u0437\u044E\u043C\u0435 - Jobeek"
    });
    const authStore = useAuthStore();
    const isEmployer = computed(() => authStore.isEmployer);
    computed(() => authStore.user);
    computed(() => authStore.employer);
    watch(
      () => isEmployer.value,
      (new_value) => {
        if (!new_value) {
          navigateTo({ name: "my-vacancies-favorite" });
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0;
      const _component_MyResumesConnectedProviders = __nuxt_component_1;
      const _component_MyFavoriteVacanciesList = __nuxt_component_2;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet my-vacancies-page",
        role: "main"
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="bg-wrapper position-relative pt-4"><div class="has-sidebar has-sidebar--v2 wrapper wrapper-1290"><div class="content mb-4">`);
      _push(ssrRenderComponent(_component_MyResumesConnectedProviders, null, null, _parent));
      _push(ssrRenderComponent(_component_MyFavoriteVacanciesList, null, null, _parent));
      _push(`</div></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vacancies/favorite.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=favorite-B_bC2YJ7.mjs.map
