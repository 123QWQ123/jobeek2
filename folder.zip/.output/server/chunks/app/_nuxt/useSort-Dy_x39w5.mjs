function useSort(defaultOptions = null) {
  const items = [];
  const sort = (items2 = [], options = null) => {
    if (options) {
      const { by } = options;
      if (by === "alpha") {
        return items2.sort(function(a, b) {
          if (a.name < b.name) {
            return -1;
          }
          if (a.name > b.name) {
            return 1;
          }
          return 0;
        });
      }
    }
  };
  return { items, sort };
}

export { useSort as u };
//# sourceMappingURL=useSort-Dy_x39w5.mjs.map
