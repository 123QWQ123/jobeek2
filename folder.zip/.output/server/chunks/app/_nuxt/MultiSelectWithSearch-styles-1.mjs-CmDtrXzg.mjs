const MultiSelectWithSearch_vue_vue_type_style_index_0_lang = ".select2-container .select2-selection--multiple .select2-selection__rendered{flex-wrap:wrap!important}";

export { MultiSelectWithSearch_vue_vue_type_style_index_0_lang as M };
//# sourceMappingURL=MultiSelectWithSearch-styles-1.mjs-CmDtrXzg.mjs.map
