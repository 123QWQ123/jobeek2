const VeeSkillsCard_vue_vue_type_style_index_0_lang = "";

const VeeSkillsCardStyles_B50nOAtB = [VeeSkillsCard_vue_vue_type_style_index_0_lang];

export { VeeSkillsCardStyles_B50nOAtB as default };
//# sourceMappingURL=VeeSkillsCard-styles.B50nOAtB.mjs.map
