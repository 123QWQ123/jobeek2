const index_vue_vue_type_style_index_0_scoped_c1eda587_lang = ".content-enter-active[data-v-c1eda587],.content-leave-active[data-v-c1eda587]{transition:opacity .5s ease}.content-enter-from[data-v-c1eda587],.content-leave-to[data-v-c1eda587]{opacity:0}@media (max-width:768px){.content[data-v-c1eda587]{order:2}.sidebar[data-v-c1eda587]{order:1}}";

const indexStyles_CtmHLMse = [index_vue_vue_type_style_index_0_scoped_c1eda587_lang];

export { indexStyles_CtmHLMse as default };
//# sourceMappingURL=index-styles.CtmHLMse.mjs.map
