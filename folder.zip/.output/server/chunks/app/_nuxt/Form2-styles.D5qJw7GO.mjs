const Form2_vue_vue_type_style_index_0_scoped_79b81ab5_lang = ".search-form[data-v-79b81ab5]{box-shadow:none}";

const Form2Styles_D5qJw7GO = [Form2_vue_vue_type_style_index_0_scoped_79b81ab5_lang];

export { Form2Styles_D5qJw7GO as default };
//# sourceMappingURL=Form2-styles.D5qJw7GO.mjs.map
