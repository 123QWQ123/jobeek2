import { V as VeeForm_vue_vue_type_style_index_0_scoped_3f4bdef7_lang } from './VeeForm-styles-1.mjs-BBheLIjb.mjs';

const VeeFormStyles_B1NlQ69Q = [VeeForm_vue_vue_type_style_index_0_scoped_3f4bdef7_lang];

export { VeeFormStyles_B1NlQ69Q as default };
//# sourceMappingURL=VeeForm-styles.B1NlQ69Q.mjs.map
