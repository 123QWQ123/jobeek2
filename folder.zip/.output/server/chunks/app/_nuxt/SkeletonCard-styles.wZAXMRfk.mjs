const SkeletonCard_vue_vue_type_style_index_0_scoped_bb22c79e_lang = '.skeleton-card .img[data-v-bb22c79e]{background-color:#ddd;border-radius:50%;padding-top:10%;width:10%}.skeleton-card span[data-v-bb22c79e]{background-color:#ddd;display:inline-block;height:16px;min-width:100px}.skeleton-card h3[data-v-bb22c79e]{background-color:#ddd;content:" ";height:24px;margin:10px 0;width:250px}.skeleton-card p[data-v-bb22c79e]{background-color:#ddd;height:16px;line-height:140%;width:80%}';

const SkeletonCardStyles_wZAXMRfk = [SkeletonCard_vue_vue_type_style_index_0_scoped_bb22c79e_lang];

export { SkeletonCardStyles_wZAXMRfk as default };
//# sourceMappingURL=SkeletonCard-styles.wZAXMRfk.mjs.map
