import { S as SelectWithSearchWithIcon_vue_vue_type_style_index_0_lang } from './SelectWithSearchWithIcon-styles-1.mjs-BLrFJS4M.mjs';

const SelectWithSearchWithIconStyles_DkIF7nu3 = [SelectWithSearchWithIcon_vue_vue_type_style_index_0_lang];

export { SelectWithSearchWithIconStyles_DkIF7nu3 as default };
//# sourceMappingURL=SelectWithSearchWithIcon-styles.DkIF7nu3.mjs.map
