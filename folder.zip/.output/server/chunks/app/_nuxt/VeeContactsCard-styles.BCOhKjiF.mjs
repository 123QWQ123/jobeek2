const VeeContactsCard_vue_vue_type_style_index_0_lang = "";

const VeeContactsCardStyles_BCOhKjiF = [VeeContactsCard_vue_vue_type_style_index_0_lang];

export { VeeContactsCardStyles_BCOhKjiF as default };
//# sourceMappingURL=VeeContactsCard-styles.BCOhKjiF.mjs.map
