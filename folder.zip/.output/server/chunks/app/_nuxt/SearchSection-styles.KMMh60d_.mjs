const SearchSection_vue_vue_type_style_index_0_scoped_b7a385ee_lang = ".labels-list-box[data-v-b7a385ee]{height:auto;max-height:20vh;overflow:hidden}.labels-list-box.expanded[data-v-b7a385ee]{height:auto;max-height:unset;overflow:visible}";

const SearchSectionStyles_KMMh60d_ = [SearchSection_vue_vue_type_style_index_0_scoped_b7a385ee_lang];

export { SearchSectionStyles_KMMh60d_ as default };
//# sourceMappingURL=SearchSection-styles.KMMh60d_.mjs.map
