const ResumeForm_vue_vue_type_style_index_0_scoped_4b7f38f9_lang = ".search-form[data-v-4b7f38f9]{box-shadow:none}";

const ResumeFormStyles_TNNPvEOt = [ResumeForm_vue_vue_type_style_index_0_scoped_4b7f38f9_lang];

export { ResumeFormStyles_TNNPvEOt as default };
//# sourceMappingURL=ResumeForm-styles.TNNPvEOt.mjs.map
