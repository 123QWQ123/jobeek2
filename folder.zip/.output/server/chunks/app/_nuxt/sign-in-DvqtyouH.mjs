import { _ as _imports_0$1, a as __nuxt_component_0 } from './i-XlC_iSFx.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-BdrY0gEc.mjs';
import { _ as __nuxt_component_2 } from './Loader-UZvrxmyZ.mjs';
import { useSSRContext, computed, reactive, ref, watch, unref, withCtx, createVNode, toDisplayString, createTextVNode } from 'vue';
import { u as useHead, k as useAuthStore, l as useVacancyStore, r as useResumeStore, a as useRouter, e as useRoute, j as useNuxtApp } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderStyle, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseContain } from 'vue/server-renderer';
import { _ as _imports_0 } from './jobeek-dark-BM969tB2.mjs';
import { _ as _imports_0$2 } from './check-BGWLIG1L.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './BaseButton-CWRjb9_h.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "sign-in",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u0410\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u044F"
    });
    const auth = useAuthStore();
    useVacancyStore();
    useResumeStore();
    computed(() => auth.isAuthed);
    useRouter();
    const state = reactive({
      phone: {
        val: "",
        isValid: true
      },
      password: {
        val: "",
        isValid: true
      },
      remember_me: {
        val: false,
        isValid: true
      },
      isFormValid: true,
      isLoading: true,
      error: null,
      success: null
    });
    const route = useRoute();
    const isLoading = ref(false);
    ref();
    ref(null);
    function close() {
      state.error = null;
      state.success = null;
    }
    watch(
      () => route.query.message,
      () => {
        if (route.query.message) {
          useNuxtApp().$toast.info(route.query.message, { autoClose: 3e3 });
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_base_modal = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Loader = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-eab0dd40>`);
      _push(ssrRenderComponent(_component_base_modal, {
        show: !!unref(state).success,
        title: "Success",
        onClose: close
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<p data-v-eab0dd40${_scopeId}>${ssrInterpolate(unref(state).success)}</p>`);
          } else {
            return [
              createVNode("p", null, toDisplayString(unref(state).success), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<main class="main enter-page sign-in" role="main" data-v-eab0dd40><div class="enter-page-content" data-v-eab0dd40>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "logo"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="#" data-v-eab0dd40${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "#"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<form class="enter-form" data-v-eab0dd40><h1 data-v-eab0dd40>\u0412\u0445\u043E\u0434</h1><div class="i-wrap has-validation" data-v-eab0dd40><input type="tel" name="tel" placeholder="\u041D\u043E\u043C\u0435\u0440 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430" data-v-eab0dd40><div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(state).phone.isValid }, "text-danger"])}" data-v-eab0dd40> \u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430 </div></div><div class="i-wrap" data-v-eab0dd40><input type="password" name="pass" placeholder="\u041F\u0430\u0440\u043E\u043B\u044C"${ssrRenderAttr("value", unref(state).password.val)} data-v-eab0dd40><div style="${ssrRenderStyle({ display: "none" })}" class="${ssrRenderClass([{ "d-block": !unref(state).password.isValid }, "text-danger"])}" data-v-eab0dd40> \u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u044B\u0439 \u043F\u0430\u0440\u043E\u043B\u044C </div></div><div class="note" data-v-eab0dd40><img${ssrRenderAttr("src", _imports_0$1)} alt="#" data-v-eab0dd40><p class="" data-v-eab0dd40> \u0415\u0441\u043B\u0438 \u0432\u044B \u043D\u0435 \u0443\u0441\u0442\u0430\u043D\u0430\u0432\u043B\u0438\u0432\u0430\u043B\u0438 \u043F\u0430\u0440\u043E\u043B\u044C, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 SMS \u043A\u043E\u0434 \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u0438 \u043D\u0430 \u0442\u0435\u043B\u0435\u0444\u043E\u043D \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0430\u043A\u0442\u0438\u0432\u0430\u0446\u0438\u0438. </p></div><div class="help-box" data-v-eab0dd40><div class="check-block" data-v-eab0dd40><div class="checkbox" data-v-eab0dd40><input type="checkbox" id="remember_me"${ssrIncludeBooleanAttr(Array.isArray(unref(state).remember_me.val) ? ssrLooseContain(unref(state).remember_me.val, null) : unref(state).remember_me.val) ? " checked" : ""} data-v-eab0dd40><div class="checkbox-mask" data-v-eab0dd40><img${ssrRenderAttr("src", _imports_0$2)} alt="#" data-v-eab0dd40></div></div><label for="remember_me" data-v-eab0dd40>\u0417\u0430\u043F\u043E\u043C\u043D\u0438\u0442\u044C \u043C\u0435\u043D\u044F</label></div>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "forgot-password" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0417\u0430\u0431\u044B\u043B\u0438 \u043F\u0430\u0440\u043E\u043B\u044C? `);
          } else {
            return [
              createTextVNode("\u0417\u0430\u0431\u044B\u043B\u0438 \u043F\u0430\u0440\u043E\u043B\u044C? ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><button class="btn button-accent" type="submit"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} data-v-eab0dd40> \u0412\u043E\u0439\u0442\u0438 `);
      if (isLoading.value) {
        _push(ssrRenderComponent(_component_Loader, { class: "text-light spinner-border-sm" }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</button></form><div class="f-prompt" data-v-eab0dd40> \u0415\u0449\u0435 \u043D\u0435\u0442 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430? `);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "sign-up" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0439\u0442\u0435\u0441\u044C!`);
          } else {
            return [
              createTextVNode("\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0439\u0442\u0435\u0441\u044C!")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></main></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/sign-in.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const signIn = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-eab0dd40"]]);

export { signIn as default };
//# sourceMappingURL=sign-in-DvqtyouH.mjs.map
