const ContactsPhonesItem_vue_vue_type_style_index_0_scoped_0521d25c_lang = ".absoluted_icon[data-v-0521d25c]{cursor:pointer;font-size:1rem;left:-2rem;max-width:3rem;position:absolute;top:.5rem;z-index:1}.absoluted_icon svg[data-v-0521d25c]{height:24px;width:24px}";

const ContactsPhonesItemStyles_DBjaY7yv = [ContactsPhonesItem_vue_vue_type_style_index_0_scoped_0521d25c_lang];

export { ContactsPhonesItemStyles_DBjaY7yv as default };
//# sourceMappingURL=ContactsPhonesItem-styles.DBjaY7yv.mjs.map
