const TheMainHeader_vue_vue_type_style_index_0_scoped_0c411f7e_lang = ".nav-link[data-v-0c411f7e]{color:#fff!important}.router-link-exact-active[data-v-0c411f7e]{color:#6c757d!important}.header-wrapper--fxstart .header-actions[data-v-0c411f7e]{margin-left:unset}@media (max-width:1025px){.header-wrapper--fxstart .header-actions[data-v-0c411f7e]{margin-left:auto}.header-wrapper--fxstart .header-actions .btn[data-v-0c411f7e]{margin-right:.5rem}}";

const TheMainHeaderStyles_DIwj7yZx = [TheMainHeader_vue_vue_type_style_index_0_scoped_0c411f7e_lang];

export { TheMainHeaderStyles_DIwj7yZx as default };
//# sourceMappingURL=TheMainHeader-styles.DIwj7yZx.mjs.map
