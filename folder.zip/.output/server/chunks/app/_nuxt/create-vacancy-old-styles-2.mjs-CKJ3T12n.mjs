const createVacancyOld_vue_vue_type_style_index_1_lang = ".input-row input.checkbox-mask{height:24px;width:24px}";

export { createVacancyOld_vue_vue_type_style_index_1_lang as c };
//# sourceMappingURL=create-vacancy-old-styles-2.mjs-CKJ3T12n.mjs.map
