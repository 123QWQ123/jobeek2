const SeekerEditForm_vue_vue_type_style_index_0_lang = "input[type=text]:disabled{background:#ccc}";

export { SeekerEditForm_vue_vue_type_style_index_0_lang as S };
//# sourceMappingURL=SeekerEditForm-styles-1.mjs-D7IIqgMQ.mjs.map
