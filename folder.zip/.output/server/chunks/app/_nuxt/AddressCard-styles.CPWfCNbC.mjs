const AddressCard_vue_vue_type_style_index_0_lang = "";

const AddressCardStyles_CPWfCNbC = [AddressCard_vue_vue_type_style_index_0_lang];

export { AddressCardStyles_CPWfCNbC as default };
//# sourceMappingURL=AddressCard-styles.CPWfCNbC.mjs.map
