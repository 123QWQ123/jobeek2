const VeeContactsPhones_vue_vue_type_style_index_0_lang = "";

const VeeContactsPhonesStyles_B6FrXJMu = [VeeContactsPhones_vue_vue_type_style_index_0_lang];

export { VeeContactsPhonesStyles_B6FrXJMu as default };
//# sourceMappingURL=VeeContactsPhones-styles.B6FrXJMu.mjs.map
