import { _ as __nuxt_component_0 } from './ThePersonalCabinetHeader-BrQhEWZm.mjs';
import { _ as __nuxt_component_1 } from './page-DRc_CJ9B.mjs';
import { _ as __nuxt_component_2 } from './TheFooter-D-Qn_ABY.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './nuxt-link-BdrY0gEc.mjs';
import '../server.mjs';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './search-CNCM2ROA.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import './TheMainHeader-BNhvozaC.mjs';
import './jobeek-dark-BM969tB2.mjs';
import './ui-DaXXToyC.mjs';

const _sfc_main = {
  computed: {
    hasHeaderSlot() {
      return !!this.$slots.header;
    },
    hasFooterSlot() {
      return !!this.$slots.footer;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_HeaderThePersonalCabinetHeader = __nuxt_component_0;
  const _component_NuxtPage = __nuxt_component_1;
  const _component_the_footer = __nuxt_component_2;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "layout" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_HeaderThePersonalCabinetHeader, null, null, _parent));
  _push(`<div>`);
  _push(ssrRenderComponent(_component_NuxtPage, null, null, _parent));
  _push(`</div>`);
  if ($options.hasFooterSlot) {
    _push(`<footer class="footer">`);
    ssrRenderSlot(_ctx.$slots, "footer", {}, null, _push, _parent);
    _push(`</footer>`);
  } else {
    _push(ssrRenderComponent(_component_the_footer, null, null, _parent));
  }
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/cabinet.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const cabinet = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { cabinet as default };
//# sourceMappingURL=cabinet-LyybTwjJ.mjs.map
