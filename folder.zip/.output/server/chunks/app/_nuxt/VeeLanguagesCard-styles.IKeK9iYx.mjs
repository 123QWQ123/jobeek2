const VeeLanguagesCard_vue_vue_type_style_index_0_lang = "";

const VeeLanguagesCardStyles_IKeK9iYx = [VeeLanguagesCard_vue_vue_type_style_index_0_lang];

export { VeeLanguagesCardStyles_IKeK9iYx as default };
//# sourceMappingURL=VeeLanguagesCard-styles.IKeK9iYx.mjs.map
