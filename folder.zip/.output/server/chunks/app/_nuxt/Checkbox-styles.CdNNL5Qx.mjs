const Checkbox_vue_vue_type_style_index_0_scoped_74998b69_lang = ".checked .checkbox-mask img[data-v-74998b69]{opacity:1}";

const CheckboxStyles_CdNNL5Qx = [Checkbox_vue_vue_type_style_index_0_scoped_74998b69_lang];

export { CheckboxStyles_CdNNL5Qx as default };
//# sourceMappingURL=Checkbox-styles.CdNNL5Qx.mjs.map
