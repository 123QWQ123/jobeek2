import { useSSRContext, watch, computed, ref, reactive, unref, mergeProps, isRef, withAsyncContext } from 'vue';
import { l as useVacancyStore, m as useProfileStore, e as useRoute, s as storeToRefs, d as navigateTo } from '../server.mjs';
import { useForm, useField } from 'vee-validate';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderClass, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1, b as _imports_2 } from './sb-_CyfLtbf.mjs';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { _ as __nuxt_component_0$2, a as __nuxt_component_0$1, b as __nuxt_component_2$1 } from './VacancyCheckboxInput-VKg7Lh2Y.mjs';
import { _ as __nuxt_component_1 } from './VeeMultiSelectWithSearch-Btd5b5Va.mjs';
import { u as useFilter } from './useFilter-BmdPUTpE.mjs';
import { u as useProviders } from './useProviders-Ck9yopDY.mjs';
import { _ as __nuxt_component_0$3 } from './VeeTipTapRichEditor-C3vw1Km2.mjs';
import __nuxt_component_2 from './VeeCustomSelect-BxrAvA7-.mjs';
import { u as useCurrencyOptions } from './useCurrencyOptions-BsifIVKS.mjs';
import { u as useFormValidation } from './useFormValidation-BMv_R6aU.mjs';
import { toTypedSchema } from '@vee-validate/zod';
import { z } from 'zod';

const _sfc_main$2 = {
  __name: "ProvidersInput",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: false,
      default: {}
    },
    name: {
      required: true,
      type: String
    },
    errors: {
      required: false,
      default: {}
    }
  },
  emits: ["update:modelValue"],
  async setup(__props, { emit: __emit }) {
    var _a;
    let __temp, __restore;
    const emit = __emit;
    const props = __props;
    const errors = computed(() => props.errors);
    useDictionaryStore();
    const route = useRoute();
    computed(() => route.params.id);
    const vacancyStore = useVacancyStore();
    const { getConnectedEmployerProviders, getEmployerProvidersAuthEndpoints } = vacancyStore;
    [__temp, __restore] = withAsyncContext(() => getConnectedEmployerProviders()), await __temp, __restore();
    const { value, errorMessage } = useField(() => props.name);
    const enabledProviders = ref(vacancyStore.providers);
    const isHHEnabled = computed(() => enabledProviders.value.hh);
    const isSuperjobEnabled = computed(() => enabledProviders.value.superjob);
    const resetObject = {
      superjob: false,
      hh: false
    };
    const vacancyProviders = computed(() => {
      let selectedProvidersValue = [];
      if (!vacancyStore.my_resume) {
        return resetObject;
      }
      const providersNewValues = { ...resetObject };
      if (selectedProvidersValue.includes("hh")) {
        providersNewValues.hh = true;
      } else {
        providersNewValues.superjob = false;
      }
      if (selectedProvidersValue.includes("superjob")) {
        providersNewValues.superjob = true;
      } else {
        providersNewValues.superjob = false;
      }
      return providersNewValues;
    });
    watch(
      () => vacancyProviders.value,
      (newValue) => {
        selectedProviders.value = newValue;
      }
    );
    const selectedProviders = ref((_a = props.modelValue) != null ? _a : resetObject);
    watch(
      () => selectedProviders.value,
      (newSelectedItems) => {
        console.log(newSelectedItems);
        emit("update:modelValue", newSelectedItems);
      }
    );
    const isHHSelected = computed(() => selectedProviders.value.hh);
    const isSuperjobSelected = computed(() => selectedProviders.value.superjob);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "carryover-box" }, _attrs))} data-v-82fe56ff><div class="carryover-box-label" data-v-82fe56ff> \u0415\u0441\u0442\u044C \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 \u043D\u0430 hh \u0438\u043B\u0438 SuperJob? \u041F\u0440\u043E\u0441\u0442\u043E \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0438\u0442\u0435 \u0435\u0433\u043E! </div><div class="import-grid" data-v-82fe56ff><div class="${ssrRenderClass([{
        "import-is-complete": unref(isHHSelected),
        disabled: !unref(isHHEnabled),
        "is-connected": unref(isHHEnabled)
      }, "import-box"])}" data-v-82fe56ff><div class="import-box-dvnld" data-v-82fe56ff><div class="logo" data-v-82fe56ff><img${ssrRenderAttr("src", _imports_0)} alt="#" data-v-82fe56ff><div class="check" data-v-82fe56ff><img${ssrRenderAttr("src", _imports_1)} alt="#" data-v-82fe56ff></div></div><span data-v-82fe56ff>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 HeadHunters.ru</span></div><div class="import-complete" data-v-82fe56ff><div class="logo logo-fake" data-v-82fe56ff></div><span data-v-82fe56ff>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 HeadHunters.ru</span><button class="close" type="button" data-v-82fe56ff><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-82fe56ff><path d="M18.9951 4.99512L5.00586 18.9843" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-82fe56ff></path><path d="M19.0009 18.9928L5 4.98901" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-82fe56ff></path></svg></button></div>`);
      if (unref(errors).hh) {
        _push(`<div class="text-danger d-block" data-v-82fe56ff>${ssrInterpolate(unref(errors).hh)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="${ssrRenderClass([{
        "import-is-complete": unref(isSuperjobSelected),
        disabled: !unref(isSuperjobEnabled),
        "is-connected": unref(isSuperjobEnabled)
      }, "import-box"])}" data-v-82fe56ff><div class="import-box-dvnld" data-v-82fe56ff><div class="logo" data-v-82fe56ff><img${ssrRenderAttr("src", _imports_2)} alt="#" data-v-82fe56ff><div class="check" data-v-82fe56ff><img${ssrRenderAttr("src", _imports_1)} alt="#" data-v-82fe56ff></div></div><span data-v-82fe56ff>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 Superjob.ru </span></div><div class="import-complete" data-v-82fe56ff><div class="logo logo-fake" data-v-82fe56ff></div><span data-v-82fe56ff>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 Superjob.ru</span><button class="close" type="button" data-v-82fe56ff><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-82fe56ff><path d="M18.9951 4.99512L5.00586 18.9843" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-82fe56ff></path><path d="M19.0009 18.9928L5 4.98901" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-82fe56ff></path></svg></button></div>`);
      if (unref(errors).superjob) {
        _push(`<div class="text-danger d-block" data-v-82fe56ff>${ssrInterpolate(unref(errors).superjob)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="text-danger d-block text-center mt-1" data-v-82fe56ff>${ssrInterpolate(unref(errorMessage))}</div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/ProvidersInput.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-82fe56ff"]]);
const _sfc_main$1 = {
  __name: "ProfessionalRoles",
  __ssrInlineRender: true,
  props: ["name"],
  setup(__props) {
    const props = __props;
    const profileStore = useProfileStore();
    const { providers } = useProviders();
    const selectedProviders = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false)
        return ["hh"];
      if (providers.value.hh === false && providers.value.superjob === true)
        return ["superjob"];
      return ["hh", "superjob"];
    });
    const isHHSelected = computed(() => selectedProviders.value.includes("hh"));
    const isSuperjobSelected = computed(
      () => selectedProviders.value.includes("superjob")
    );
    const professionalRoleOptions = ref([]);
    const {
      searchProfessionalRoles,
      searchHHProfessionalRoles,
      searchSuperjobProfessionalRoles
    } = profileStore;
    const { uniq } = useFilter();
    const { value: prof_role_ids } = useField(() => props.name);
    watch(
      () => prof_role_ids.value,
      async () => {
        let items = [];
        if (isHHProfRolesNeeded.value) {
          const new_h = profileStore.hh_professional_roles_with_parent;
          items = items.concat(new_h);
        }
        if (isSuperjobProfRolesNeeded.value) {
          const new_s = profileStore.superjob_professional_roles_with_parent;
          items = items.concat(new_s);
        }
        if (isHHProfRolesNeeded.value || isSuperjobProfRolesNeeded.value) {
          items = items.concat(profileStore.professional_roles_with_parent);
          items = uniq(items, "value");
          professionalRoleOptions.value = items;
        } else {
          professionalRoleOptions.value = profileStore.professional_roles_with_parent;
        }
      }
    );
    const updateProfessionalInput = async (newValue = "", providers2 = []) => {
      let items = await searchProfessionalRoles();
      if (newValue) {
        items = items.filter((item) => item.parent_id !== 0).filter((item) => item.name.includes(newValue));
      } else {
        items = items.filter((item) => item.parent_id !== 0);
      }
      professionalRoleOptions.value = items.map((item) => ({
        value: item.id,
        name: item.name
      }));
    };
    const isHHProfRolesNeeded = computed(() => {
      if (!isHHSelected.value)
        return false;
      if (prof_role_ids.value.length < 1)
        return true;
      const selected_fields_values = [...prof_role_ids.value];
      return !selected_fields_values.some(
        (item) => profileStore.hh_professional_roles_with_parent_ids.includes(item)
      );
    });
    const isSuperjobProfRolesNeeded = computed(() => {
      if (!isSuperjobSelected.value)
        return false;
      if (prof_role_ids.value.length < 1)
        return true;
      const selected_fields_values = [...prof_role_ids.value];
      return !selected_fields_values.some(
        (item) => profileStore.superjob_professional_roles_with_parent_ids.includes(item)
      );
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeMultiSelectWithSearch = __nuxt_component_1;
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, mergeProps({
        name: "professional_roles",
        sort_by: "none",
        options: unref(professionalRoleOptions),
        onInput: updateProfessionalInput,
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/ProfessionalRoles.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$1;
const _sfc_main = {
  __name: "CreateDraft",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props, { expose: __expose }) {
    const props = __props;
    const { providers } = useProviders();
    watch(
      () => providers.value,
      () => {
        console.log(1);
      }
    );
    const vacancyStore = useVacancyStore();
    const dictionaryStore = useDictionaryStore();
    useProfileStore();
    useRoute();
    storeToRefs(vacancyStore);
    const formTitle = computed(() => props.title);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    ref(false);
    const isUpdated = ref(false);
    const currencyOptions = ref(useCurrencyOptions());
    const schema = z.object({
      providers: z.array(z.string()).nonempty("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0445\u043E\u0442\u044F \u0431\u044B 1 \u0441\u0435\u0440\u0432\u0438\u0441"),
      name: z.string(),
      cities: z.array(z.number()).nonempty("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0445\u043E\u0442\u044F \u0431\u044B 1"),
      description: z.string(),
      professional_roles: z.array(z.number()).nonempty("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0445\u043E\u0442\u044F \u0431\u044B 1"),
      salary: z.object({
        currency: z.string(),
        from: z.number(),
        to: z.number(),
        gross: z.boolean(),
        period: z.number()
      })
    });
    const initialValues = {
      providers: [],
      name: null,
      cities: [],
      professional_roles: [],
      salary: {
        currency: "RUB",
        from: null,
        to: null,
        gross: false,
        period: null
      }
    };
    const { values, errors, meta, setErrors, handleSubmit, validate } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema)
    });
    const { createDraft } = vacancyStore;
    const state = reactive({
      name: {
        is_hidden: false
      },
      cities: {
        is_hidden: false
      },
      professional_roles: {
        is_hidden: false
      },
      description: {
        is_hidden: false
      },
      salary: {
        currency: {
          is_hidden: false
        },
        from: {
          is_hidden: false
        },
        to: {
          is_hidden: false
        },
        gross: {
          is_hidden: false
        },
        period: {
          is_hidden: false
        },
        is_hidden: true
      }
    });
    const { errors: serverErrors, handleErrorResponse } = useFormValidation(state);
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    const isLoading = ref(false);
    const errorMessageElement = ref();
    const errorMessage = ref(null);
    const scrollTop = () => {
      (void 0).scrollTo(0, 0);
    };
    const onSubmit = handleSubmit((submittedValues) => {
      save();
    });
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.valid) {
        console.log(1);
        errorMessage.value = "\u0412\u0430\u043C \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E \u0437\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C";
        scrollTop();
        errorMessageElement.value.scrollIntoView({ behavior: "smooth" });
        return;
      }
      setErrors({});
      errorMessage.value = "";
      isLoading.value = true;
      console.log(values);
      let resData = await createDraft(unref(values));
      console.log(resData);
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        isLoading.value = false;
        return;
      }
      isLoading.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
      const vacancy_id = resData.data.data.id;
      setTimeout(() => {
        console.log("redirecting...");
        navigateTo({
          name: "my-vacancy-id",
          params: { id: vacancy_id },
          query: { type: "draft" }
        });
      }, 100);
      isLoading.value = false;
      if (resData.data.hasOwnProperty("errors")) {
        setErrors(resData.data.errors);
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = false;
    };
    __expose({
      onSubmit,
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateVacancyProvidersInput = __nuxt_component_0;
      const _component_CreateVacancyTextInput = __nuxt_component_0$2;
      const _component_CreateVacancyCities = __nuxt_component_0$1;
      const _component_CreateVacancyProfessionalRoles = __nuxt_component_3;
      const _component_VeeTipTapRichEditor = __nuxt_component_0$3;
      const _component_VeeCustomSelect = __nuxt_component_2;
      const _component_CreateVacancyCheckboxInput = __nuxt_component_2$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box w-box--main w-box-resume pb-4" }, _attrs))}><div class="w-box-head"><h1 class="title">${ssrInterpolate(unref(formTitle))}</h1><div class="descr"> \u041F\u043E\u043B\u0443\u0447\u0430\u0439\u0442\u0435 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u043E \u043D\u043E\u0432\u044B\u0445 \u043F\u043E \u0441\u043E\u0437\u0434\u0430\u043D\u043D\u043E\u043C\u0443 \u0437\u0430\u043F\u0440\u043E\u0441\u0443 </div><span class="arrow"></span></div><div class="${ssrRenderClass([{ disabled: unref(isLoading) }, "w-box-body"])}"><div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div></div>`);
      _push(ssrRenderComponent(_component_CreateVacancyProvidersInput, {
        name: "providers",
        modelValue: unref(providers),
        "onUpdate:modelValue": ($event) => isRef(providers) ? providers.value = $event : null
      }, null, _parent));
      _push(`<div class="input-row"><label for="name">\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438<b>*</b></label><div class="input-wrapper"><div class="c1 mt-1">`);
      _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
        name: "name",
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div></div><div class="input-row"><label>\u0421\u043F\u0438\u0441\u043E\u043A \u0433\u043E\u0440\u043E\u0434\u043E\u0432:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_CreateVacancyCities, { name: "cities" }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_CreateVacancyProfessionalRoles, { name: "professional_roles" }, null, _parent));
      _push(`</div></div><div class="input-row"><label for="description">\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435:</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_VeeTipTapRichEditor, { name: "description" }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u0417\u0430\u0440\u043F\u043B\u0430\u0442\u0430:</label><div class="row-container"><div class="row mb-2"><div class="col-6"><div class="input-wrapper w-100">`);
      _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
        type: "number",
        name: "salary.from",
        placeholder: "\u041E\u0442"
      }, null, _parent));
      _push(`</div></div><div class="col-6"><div class="input-wrapper w-100">`);
      _push(ssrRenderComponent(_component_CreateVacancyTextInput, {
        type: "number",
        name: "salary.to",
        placeholder: "\u0414\u043E"
      }, null, _parent));
      _push(`</div></div></div><div class="row"><div class="col-6">`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        label: "\u041F\u0435\u0440\u0438\u043E\u0434",
        options: unref(dictionaryStore).payment_period_formatted,
        name: "salary.period"
      }, null, _parent));
      _push(`</div><div class="col-6">`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        label: "\u0412\u0430\u043B\u044E\u0442\u0430",
        options: unref(currencyOptions),
        name: "salary.currency"
      }, null, _parent));
      _push(`</div></div><div class="row mt-2">`);
      _push(ssrRenderComponent(_component_CreateVacancyCheckboxInput, {
        name: "salary.gross",
        label: "\u0434\u043E \u0432\u044B\u0447\u0435\u0442\u0430 \u043D\u0430\u043B\u043E\u0433\u043E\u0432"
      }, null, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/CreateDraft.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main;

export { __nuxt_component_4 as _ };
//# sourceMappingURL=CreateDraft-DS1I7Wix.mjs.map
