import { S as SelectWithSearchWithIcon_vue_vue_type_style_index_1_scoped_e1188478_lang } from './SelectWithSearchWithIcon-styles-2.mjs-CZHC0-HD.mjs';

const SelectWithSearchWithIconStyles_B0hlrunX = [SelectWithSearchWithIcon_vue_vue_type_style_index_1_scoped_e1188478_lang];

export { SelectWithSearchWithIconStyles_B0hlrunX as default };
//# sourceMappingURL=SelectWithSearchWithIcon-styles.B0hlrunX.mjs.map
