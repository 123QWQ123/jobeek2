const Region_vue_vue_type_style_index_0_scoped_16e528f7_lang = ".check-block label[data-v-16e528f7]{white-space:pre-wrap}.with_scroll[data-v-16e528f7]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-16e528f7]{font-weight:700}.is_header .radio-mask[data-v-16e528f7],.is_header input[data-v-16e528f7]{display:none}input[type=search][data-v-16e528f7]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const RegionStyles_BsUwn8bd = [Region_vue_vue_type_style_index_0_scoped_16e528f7_lang];

export { RegionStyles_BsUwn8bd as default };
//# sourceMappingURL=Region-styles.BsUwn8bd.mjs.map
