const Skills_vue_vue_type_style_index_0_scoped_6255a5e1_lang = ".selection[data-v-6255a5e1]{border-radius:4px;left:0}.selected-options[data-v-6255a5e1]{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.5rem;padding:0 .1rem .2rem}.multi-select_selected-item[data-v-6255a5e1]{border:1px solid;border-radius:4px;padding:2px}";

const SkillsStyles_DRDNFOqO = [Skills_vue_vue_type_style_index_0_scoped_6255a5e1_lang];

export { SkillsStyles_DRDNFOqO as default };
//# sourceMappingURL=Skills-styles.DRDNFOqO.mjs.map
