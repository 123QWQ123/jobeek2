import { _ as __nuxt_component_0 } from './SearchMobile-WfXJ1gHL.mjs';
import { _ as __nuxt_component_1 } from './ConnectedProviders-DKmnzzBN.mjs';
import { _ as __nuxt_component_0$1 } from './PageLoader-CgN00RaA.mjs';
import { _ as __nuxt_component_0$2 } from './Item-BZivtBWi.mjs';
import { computed, watch, mergeProps, useSSRContext, ref, unref } from 'vue';
import { u as useHead, k as useAuthStore, d as navigateTo, r as useResumeStore, s as storeToRefs, e as useRoute } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { u as useVacancyForm } from './useVacancyForm-UJ-LLtx0.mjs';
import './search-CNCM2ROA.mjs';
import './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import './superjob-DOWPfj1m.mjs';
import 'moment';
import './nuxt-link-BdrY0gEc.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main$1 = {
  __name: "List",
  __ssrInlineRender: true,
  setup(__props) {
    const resumeStore = useResumeStore();
    const { my_favorite_resumes, current_page } = storeToRefs(resumeStore);
    const items = ref([]);
    const isLoading = ref(true);
    const isMore = ref(false);
    useRoute();
    ref(useVacancyForm());
    watch(my_favorite_resumes, (newValues) => {
      items.value = newValues;
      if (newValues.length > 0) {
        isMore.value = true;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PageLoader = __nuxt_component_0$1;
      const _component_ResumesItem = __nuxt_component_0$2;
      _push(`<!--[--><h2 class="lk-page-title mb-4">\u0418\u0437\u0431\u0440\u0430\u043D\u043D\u044B\u0435</h2>`);
      if (unref(isLoading)) {
        _push(ssrRenderComponent(_component_PageLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="favorites-list-container"><ul class="favorites-list"><!--[-->`);
      ssrRenderList(unref(items), (item) => {
        _push(ssrRenderComponent(_component_ResumesItem, {
          key: item.id,
          item
        }, null, _parent));
      });
      _push(`<!--]--></ul>`);
      if (unref(items).length) {
        _push(`<div class="footer mt-3"><button class="btn btn-primary">Prev</button><button class="btn btn-primary ms-2">Next</button></div>`);
      } else {
        _push(`<h3>\u041A \u0441\u043E\u0436\u0430\u043B\u0435\u043D\u0438\u044E \u0431\u043E\u043B\u044C\u0448\u0435 \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043D\u0430\u0448\u043B\u0438.</h3>`);
      }
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MyFavoriteResumes/List.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const _sfc_main = {
  __name: "resumes",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u041C\u043E\u0438 \u0438\u0437\u0431\u0440\u0430\u043D\u043D\u0438\u0435 \u0440\u0435\u0437\u044E\u043C\u0435 - Jobeek"
    });
    const authStore = useAuthStore();
    const isEmployer = computed(() => authStore.isEmployer);
    computed(() => authStore.user);
    computed(() => authStore.employer);
    watch(
      () => isEmployer.value,
      (new_value) => {
        if (!new_value) {
          navigateTo({ name: "my-vacancies-favorite" });
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0;
      const _component_MyVacanciesConnectedProviders = __nuxt_component_1;
      const _component_MyFavoriteResumesList = __nuxt_component_2;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet my-vacancies-page",
        role: "main"
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="bg-wrapper position-relative pt-4"><div class="wrapper wrapper-1290"><div class="content mb-4">`);
      _push(ssrRenderComponent(_component_MyVacanciesConnectedProviders, null, null, _parent));
      _push(ssrRenderComponent(_component_MyFavoriteResumesList, null, null, _parent));
      _push(`</div></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/favorite/resumes.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=resumes-CBxSYxX2.mjs.map
