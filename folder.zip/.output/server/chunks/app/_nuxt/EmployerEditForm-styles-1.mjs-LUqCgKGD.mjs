const EmployerEditForm_vue_vue_type_style_index_0_lang = "input[type=text]:disabled{background:#ccc}";

export { EmployerEditForm_vue_vue_type_style_index_0_lang as E };
//# sourceMappingURL=EmployerEditForm-styles-1.mjs-LUqCgKGD.mjs.map
