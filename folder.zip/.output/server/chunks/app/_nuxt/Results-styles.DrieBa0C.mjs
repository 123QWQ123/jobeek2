const Results_vue_vue_type_style_index_0_scoped_37c99b22_lang = ".sort[data-v-37c99b22]{align-items:baseline;justify-content:end}@media (max-width:960px){.sorting_forms[data-v-37c99b22]{flex-direction:column}.reversed_forms[data-v-37c99b22]{flex-direction:column-reverse}.sort[data-v-37c99b22]{justify-content:flex-start!important}}@media (max-width:480px){.sorting_forms[data-v-37c99b22]{flex-direction:column}.reversed_forms[data-v-37c99b22]{flex-direction:column-reverse}.sort[data-v-37c99b22]{flex-direction:column}}";

const ResultsStyles_DrieBa0C = [Results_vue_vue_type_style_index_0_scoped_37c99b22_lang];

export { ResultsStyles_DrieBa0C as default };
//# sourceMappingURL=Results-styles.DrieBa0C.mjs.map
