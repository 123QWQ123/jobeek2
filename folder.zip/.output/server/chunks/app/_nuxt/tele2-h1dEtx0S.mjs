import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_5 = "" + buildAssetsURL("tele2.BJT7ig5a.svg");

export { _imports_5 as _ };
//# sourceMappingURL=tele2-h1dEtx0S.mjs.map
