import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';

const _sfc_main = {
  __name: "about",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main about-page",
        role: "main"
      }, _attrs))}><div class="about-page-main wrapper"><div class="about-page-main-text"><h1>\u041E \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438 Jobeek</h1><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed consectetur ipsum sit maecenas condimentum in aliquam. A, a sagittis facilisi euismod donec mauris. Lacus feugiat massa, egestas at lectus bibendum in enim. Sodales turpis eu sit mollis luctus suspendisse duis. Pharetra aliquam feugiat venenatis urna.</p><p>Arcu nec at volutpat sapien non. Eget quam pharetra rhoncus euismod arcu adipiscing sagittis, dui in. Consequat ornare praesent placerat arcu, arcu elit in in lobortis. Eu bibendum mi, aliquam mattis non. Vitae pretium augue ipsum quisque. Lacus, volutpat volutpat senectus dignissim turpis hendrerit. Pretium sit pharetra aliquam tempus leo faucibus proin in aliquam. Pulvinar sagittis, vitae scelerisque viverra faucibus tempus eu congue vel.</p><p>Arcu malesuada scelerisque adipiscing et, cursus interdum. Tincidunt ut donec magna euismod posuere. Maecenas ut mauris erat sed sed sit quam </p></div><div class="about-page-main-image half-screen-block"></div></div><ul class="features wrapper"><li class="features-card"><h2><span>\u0420</span>\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u043D\u044B\u0439 \u043F\u043E\u0438\u0441\u043A </h2><p>\u041D\u0430\u0448\u0430 \u0431\u0430\u0437\u0430 \u043F\u043E\u0438\u0441\u043A\u0430 \u043E\u0431\u044A\u0435\u0434\u0438\u043D\u044F\u0435\u0442 \u0432 \u0441\u0435\u0431\u0435 \u0441\u0440\u0430\u0437\u0443 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043F\u043B\u043E\u0449\u0430\u0434\u043E\u043A - \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439 \u0445\u0432\u0430\u0442\u0438\u0442 \u043D\u0430 \u0432\u0441\u0435\u0445!</p></li><li class="features-card"><h2><span>\u041E</span>\u0434\u0438\u043D \u043F\u0440\u043E\u0444\u0438\u043B\u044C \u0434\u043B\u044F \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u0438\u0445 \u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C </h2><p>\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0430\u0439\u0442\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u044B \u043F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u044B\u0445 \u0440\u0435\u043A\u0440\u0443\u0442\u0438\u043D\u0433-\u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C \u0438 \u0443\u043F\u0440\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u0438\u043C\u0438 \u0438\u0437 \u043E\u0434\u043D\u043E\u0433\u043E \u043F\u0440\u043E\u0444\u0438\u043B\u044F</p></li><li class="features-card"><h2><span>\u0423</span>\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u043E\u0431 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F\u0445</h2><p>\u041F\u043E\u0434\u043F\u0438\u0441\u044B\u0432\u0430\u0439\u0442\u0435\u0441\u044C \u043D\u0430 \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u0443\u044E\u0449\u0438\u0435 \u0432\u0430\u0441 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 \u0438 \u043E\u0442\u0441\u043B\u0435\u0436\u0438\u0432\u0430\u0439\u0442\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0441 \u043F\u043E\u043C\u043E\u0449\u044C\u044E \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439</p></li><li class="features-card"><h2><span>\u0420</span>\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</h2><p>\u041C\u044B \u043F\u043E\u0434\u0431\u0438\u0440\u0430\u0435\u043C \u0434\u043B\u044F \u0432\u0430\u0441 \u043D\u0430\u0438\u0431\u043E\u043B\u0435\u0435 \u043F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438, \u0447\u0442\u043E\u0431\u044B \u0432\u0430\u043C \u0431\u044B\u043B\u043E \u043F\u0440\u043E\u0449\u0435 \u0438\u0441\u043A\u0430\u0442\u044C </p></li></ul></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/about.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=about-D1cyxAQF.mjs.map
