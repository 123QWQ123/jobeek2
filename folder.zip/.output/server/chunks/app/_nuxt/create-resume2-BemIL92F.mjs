import { H as Head, T as Title } from './components-DWwOHCR7.mjs';
import { _ as __nuxt_component_0$5 } from './SearchMobile-WfXJ1gHL.mjs';
import { C as CustomSelect } from './search-CNCM2ROA.mjs';
import { computed, watch, resolveComponent, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, useSSRContext, withAsyncContext, ref, reactive, nextTick, resolveDirective, isRef, watchEffect } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrGetDirectiveProps, ssrRenderClass, ssrRenderAttr, ssrRenderList, ssrRenderStyle } from 'vue/server-renderer';
import { u as useCurrencyOptions } from './useCurrencyOptions-BsifIVKS.mjs';
import { e as useRoute, r as useResumeStore, s as storeToRefs, m as useProfileStore } from '../server.mjs';
import { u as useFormValidation } from './useFormValidation-BMv_R6aU.mjs';
import { u as useWatchStateValues } from './useWatchStateValues-DimKH74z.mjs';
import { u as useDiff } from './useDiff-Chx28f43.mjs';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { u as useFormData } from './useFormData-CRA6LhaU.mjs';
import { u as useYearOptions } from './useYearOptions--VQWJCm5.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main$8 = {
  __name: "Salary",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: true
    },
    errors: {
      required: true,
      default: {}
    },
    fields_visibility: {
      required: false,
      default: {}
    }
  },
  emits: ["update:modelValue", "clearError"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const currencyOptions = ref(useCurrencyOptions(false));
    const salary = reactive({
      amount: {
        val: null,
        isChecked: false,
        isValid: false
      },
      currency: {
        val: null,
        isChecked: false,
        isValid: false,
        is_hidden: false
      }
    });
    watch(
      () => props.modelValue,
      (newValue) => {
        salary.amount.val = newValue.amount;
        salary.currency.val = newValue.currency;
      }
    );
    watch(
      () => props.fields_visibility,
      (newValue) => {
        salary.currency.is_hidden = newValue.currency;
      }
    );
    const validate = () => {
      salary.amount.isChecked = true;
      if (parseInt(salary.amount.val) > 0) {
        salary.amount.isValid = true;
      } else {
        salary.amount.isValid = false;
      }
      salary.currency.isChecked = true;
      if (currencyOptions.value.includes(salary.currency.val)) {
        salary.currency.isValid = true;
      } else {
        salary.currency.isValid = false;
      }
      emit("update:modelValue", {
        amount: salary.amount.val,
        currency: salary.currency.val
      });
    };
    watch(salary, validate);
    const skyBlueBG = {
      background: "#F5F8FA"
    };
    const errors = ref({});
    watch(
      () => props.errors,
      (newErrors) => {
        errors.value = newErrors;
      }
    );
    const clear = (input) => emit("clearError", input);
    __expose({ validate });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label>\u041A\u0430\u043A\u043E\u0439 \u0434\u043E\u0445\u043E\u0434 \u0432\u044B \u0440\u0430\u0441\u0441\u043C\u0430\u0442\u0440\u0438\u0432\u0430\u0435\u0442\u0435?</label><div class="row-container"><div class="row"><div class="col-8"><div class="input-wrapper w-100"><div class="input-group mb-3"><input class="form-control" id="salary_from" type="number"${ssrRenderAttr("value", unref(salary).amount.val)} placeholder="\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0441\u0443\u043C\u043C\u0443">`);
      if (props.fields_visibility.currency) {
        _push(`<span class="input-group-text">\u20BD</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (unref(errors).amount) {
        _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errors).amount)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (!unref(salary).currency.is_hidden) {
        _push(`<div class="col-4">`);
        _push(ssrRenderComponent(_component_CustomSelect, {
          class: "skyBlueBG",
          label: "\u0412\u0430\u043B\u044E\u0442\u0430",
          options: unref(currencyOptions),
          style: skyBlueBG,
          modelValue: unref(salary).currency.val,
          "onUpdate:modelValue": ($event) => unref(salary).currency.val = $event,
          onFocusin: ($event) => clear("currency")
        }, null, _parent));
        if (unref(errors).currency) {
          _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errors).currency)}</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/Salary.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_0$4 = _sfc_main$8;
const _sfc_main$7 = {
  __name: "PositionAndIncome",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const resumeStore = useResumeStore();
    useProfileStore();
    const dictionaryStore = useDictionaryStore();
    const { getWorkTypes } = dictionaryStore;
    [__temp, __restore] = withAsyncContext(() => getWorkTypes()), await __temp, __restore();
    const employmentOptions = computed(() => {
      return dictionaryStore.work_types.map((item) => ({ name: item.name, value: item.id }));
    });
    const route = useRoute();
    const draftID = computed(() => route.query.draft_id);
    computed(() => route.query.vacancy_id);
    const resume = computed(() => resumeStore.resume);
    const isShown = ref(false);
    const isSaved = ref(false);
    const isChanged = ref(false);
    const isFirst = ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    const { getResume } = resumeStore;
    const state = reactive({
      title: {
        val: resume.title,
        isValid: true
      },
      salary: {
        val: {
          amount: resume.value.salary_from,
          currency: resume.value.salary_currency
        },
        isValid: true
      },
      employment_id: {
        val: resume.value.employment_id,
        isValid: true
      },
      isFormValid: true,
      isNew: true,
      isLoading: false,
      error: null,
      success: null
    });
    watch(() => useWatchStateValues(state, true, true), () => {
      if (!isFirst.value) {
        isChanged.value = true;
      } else {
        isFirst.value = false;
      }
    });
    const sectionData = ref({});
    watch(() => sectionData.value, (newData, oldData) => {
      const diffData = useDiff(newData, oldData, ["id", "created_at", "updated_at"]);
      if (Object.keys(diffData).length) {
        state["title"].val = newData["title"];
        state["salary"].val.amount = newData["salary_from"];
        state["salary"].val.currency = newData["salary_currency"];
        state["employment_id"].val = newData["employment_id"];
        if (isUpdated.value) {
          isUpdated.value = false;
          return;
        }
      }
    });
    watch(() => resumeStore.resume, (newResume) => {
      var _a, _b, _c, _d;
      if (newResume) {
        sectionData.value = {
          title: (_a = resumeStore.resume) == null ? void 0 : _a.title,
          salary_from: (_b = resumeStore.resume) == null ? void 0 : _b.salary_from,
          salary_currency: (_c = resumeStore.resume) == null ? void 0 : _c.salary_currency,
          employment_id: (_d = resumeStore.resume) == null ? void 0 : _d.employment_id
        };
        nextTick(() => {
          isChanged.value = false;
        });
      }
    });
    watch(() => isCollapsed.value, (newData) => {
      if (!newData) {
        isShown.value = true;
      }
    });
    const { updateResume } = resumeStore;
    const { errors, handleErrorResponse, clearInputError } = useFormValidation();
    const save = async () => {
      if (isChanged.value) {
        state.isLoading = true;
        errors.value = {};
        state.errorMessage = "";
        const jsonData = {
          salary_currency: state.salary.val.currency,
          title: state.title.val,
          salary_from: state.salary.val.amount,
          employment_id: state.employment_id.val,
          form_data: "PROFESSION_DETAILS_DATA"
        };
        state.isLoading = true;
        errors.value = {};
        state.errorMessage = "";
        const resData = await updateResume(draftID.value, jsonData);
        if (resData.status !== "success") {
          return handleErrorResponse(resData.data);
        }
        isChanged.value = false;
        isSaved.value = false;
        isUpdated.value = false;
        await getResume(draftID.value);
      }
    };
    const isCompleted = computed(() => {
      const myResume = resume.value;
      if (myResume) {
        return myResume.title && myResume.salary_from && myResume.salary_currency && myResume.salary_from && myResume.employment_id;
      }
      return false;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeSalary = __nuxt_component_0$4;
      const _component_CustomSelect = CustomSelect;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box w-box--main w-box-position" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C \u0438 \u0434\u043E\u0445\u043E\u0434</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label>\u041A\u0430\u043A\u0443\u044E \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C \u0432\u044B \u0445\u043E\u0442\u0438\u0442\u0435 \u0437\u0430\u043D\u0438\u043C\u0430\u0442\u044C? <b>*</b></label><div class="input-wrapper"><input type="text" placeholder="\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C" id="title"${ssrRenderAttr("value", unref(state).title.val)}>`);
      if (unref(errors).title) {
        _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errors).title)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_CreateResumeSalary, {
        modelValue: unref(state).salary.val,
        "onUpdate:modelValue": ($event) => unref(state).salary.val = $event,
        onClearError: unref(clearInputError),
        errors: unref(errors)
      }, null, _parent));
      _push(`<div class="input-row"><label>\u0417\u0430\u043D\u044F\u0442\u043E\u0441\u0442\u044C <b>*</b></label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        options: unref(employmentOptions),
        modelValue: unref(state).employment_id.val,
        "onUpdate:modelValue": ($event) => unref(state).employment_id.val = $event,
        onFocusin: () => unref(errors).employment_id = ""
      }, null, _parent));
      if (unref(errors).employment_id) {
        _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errors).employment_id)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/PositionAndIncome.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$7;
const _sfc_main$6 = {
  __name: "Item",
  __ssrInlineRender: true,
  props: {
    isNew: {
      required: false,
      default: false
    },
    id: {
      required: true,
      default: null
    },
    title: {
      required: true,
      default: null
    },
    organization: {
      required: true,
      default: null
    },
    url: {
      required: true,
      default: null
    },
    end_year: {
      required: true,
      default: null
    },
    errors: {
      required: true,
      default: {}
    }
  },
  emits: ["delete", "update"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const errors = ref(props.errors);
    watch(() => props.errors, (newErrors) => {
      errors.value = newErrors;
    });
    useDictionaryStore();
    ref(props.isNew);
    const state = reactive({
      id: {
        val: props.id,
        isValid: null
      },
      title: {
        val: props.title,
        isValid: null
      },
      organization: {
        val: props.organization,
        isValid: null
      },
      url: {
        val: props.url,
        isValid: null
      },
      end_year: {
        val: props.end_year,
        isValid: null
      }
    });
    const save = () => {
      emit("update", props.id, useFormData(state));
    };
    watch(() => useWatchStateValues(state), save);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row position-relative empty-area" }, _attrs))} data-v-20a2eee9><span class="position-absolute absoluted_icon" data-v-20a2eee9><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" data-v-20a2eee9><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-20a2eee9></path></svg></span><div class="col-12" data-v-20a2eee9><div class="row" data-v-20a2eee9><div class="input-row" data-v-20a2eee9><label for="position" data-v-20a2eee9>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435<b data-v-20a2eee9>*</b></label><div class="input-wrapper" data-v-20a2eee9><input type="text" placeholder="\u0412\u0432\u0435\u0434\u0438\u0442\u0435"${ssrRenderAttr("value", unref(state).title.val)} data-v-20a2eee9>`);
      if (unref(errors).title) {
        _push(`<div class="text-danger d-block" data-v-20a2eee9>${ssrInterpolate(unref(errors).title)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="input-row" data-v-20a2eee9><label for="position" data-v-20a2eee9>\u041E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F, \u043F\u0440\u043E\u0432\u043E\u0434\u0438\u0432\u0448\u0430\u044F \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435<b data-v-20a2eee9>*</b></label><div class="input-wrapper" data-v-20a2eee9><input type="text" placeholder="\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0437\u0430\u0432\u0435\u0434\u0435\u043D\u0438\u044F"${ssrRenderAttr("value", unref(state).organization.val)} data-v-20a2eee9>`);
      if (unref(errors).organization) {
        _push(`<div class="text-danger d-block" data-v-20a2eee9>${ssrInterpolate(unref(errors).organization)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="input-row" data-v-20a2eee9><label for="position" data-v-20a2eee9>\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u044D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u044B\u0439 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442<b data-v-20a2eee9>*</b></label><div class="input-wrapper" data-v-20a2eee9><input type="text" placeholder="\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0441\u0441\u044B\u043B\u043A\u0443"${ssrRenderAttr("value", unref(state).url.val)} data-v-20a2eee9>`);
      if (unref(errors).url) {
        _push(`<div class="text-danger d-block" data-v-20a2eee9>${ssrInterpolate(unref(errors).url)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="input-row" data-v-20a2eee9><label for="position" data-v-20a2eee9>\u0413\u043E\u0434 \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044F<b data-v-20a2eee9>*</b></label><div class="input-wrapper" data-v-20a2eee9><div data-v-20a2eee9>`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        options: ("useYearOptions" in _ctx ? _ctx.useYearOptions : unref(useYearOptions))(),
        modelValue: unref(state).end_year.val,
        "onUpdate:modelValue": ($event) => unref(state).end_year.val = $event,
        label: "\u0412\u044B\u0431\u0440\u0430\u0442\u044C",
        onFocusin: () => unref(errors).end_year = ""
      }, null, _parent));
      if (unref(errors).end_year) {
        _push(`<div class="text-danger d-block" data-v-20a2eee9>${ssrInterpolate(unref(errors).end_year)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/EducationDocuments/Item.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_0$3 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-20a2eee9"]]);
const _sfc_main$5 = {
  __name: "History",
  __ssrInlineRender: true,
  props: ["modelValue", "errors"],
  emits: ["update:modelValue"],
  async setup(__props, { emit: __emit }) {
    var _a, _b;
    let __temp, __restore;
    const emit = __emit;
    const props = __props;
    const dictionaryStore = useDictionaryStore();
    const { getEducations } = dictionaryStore;
    storeToRefs(dictionaryStore);
    [__temp, __restore] = withAsyncContext(() => getEducations()), await __temp, __restore();
    const selectedEducationDocs = ref((_a = props.modelValue) != null ? _a : []);
    watch(() => selectedEducationDocs.value, (newSelectedEducations) => {
      emit("update:modelValue", newSelectedEducations);
    });
    const errors = ref((_b = props.errors) != null ? _b : []);
    watch(() => props.errors, (newData) => {
      const newItems = selectedEducationDocs.value;
      selectedEducationDocs.value.map((item, index) => {
        newData == null ? void 0 : newData.map((error, errorIndex) => {
          if (errorIndex === index) {
            if (!newItems[index]) {
              newItems[index] = {};
            }
            if (!newItems[index].errors) {
              newItems[index].errors = {};
            }
            Object.keys(error).map((errorKey) => {
              newItems[index].errors[errorKey] = error[errorKey];
            });
          }
        });
      });
      errors.value = newItems;
    });
    const updateItem = (id, newItem) => {
      const newItems = selectedEducationDocs.value.map((item) => {
        if (item.id === id) {
          return newItem;
        }
        return item;
      });
      selectedEducationDocs.value = newItems;
    };
    const deleteItem = (deleteItem2) => {
      const newItems = selectedEducationDocs.value.filter((item) => item.id !== deleteItem2);
      selectedEducationDocs.value = newItems;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeEducationDocumentsItem = __nuxt_component_0$3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "education_item" }, _attrs))} data-v-83d38e7d>`);
      if (unref(selectedEducationDocs).length) {
        _push(`<!--[-->`);
        ssrRenderList(unref(selectedEducationDocs), (item, index) => {
          _push(ssrRenderComponent(_component_CreateResumeEducationDocumentsItem, {
            class: "mb-2",
            item,
            key: item.id,
            id: item.id,
            title: item.title,
            organization: item.organization,
            url: item.url,
            end_year: item.end_year,
            errors: item.errors,
            onUpdate: updateItem,
            onDelete: deleteItem
          }, null, _parent));
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      if (unref(selectedEducationDocs).length === 0) {
        _push(`<button type="button" class="btn btn-primary" data-v-83d38e7d>\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C</button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(selectedEducationDocs).length !== 0) {
        _push(`<button type="button" class="btn btn-primary" data-v-83d38e7d>\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435</button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/EducationDocuments/History.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_0$2 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-83d38e7d"]]);
const _sfc_main$4 = {
  __name: "Content",
  __ssrInlineRender: true,
  setup(__props) {
    var _a2;
    var _a;
    ref(false);
    const route = useRoute();
    const resumeStore = useResumeStore();
    const draftID = computed(() => route.query.draft_id);
    computed(() => route.query.vacancy_id);
    const education_documents = ref((_a2 = (_a = resumeStore.resume) == null ? void 0 : _a.education_documents) != null ? _a2 : []);
    const isShown = ref(false);
    const isChanged = ref(false);
    const isSaved = ref(false);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const sectionData = ref({
      education_documents: []
    });
    watch(() => sectionData.value, (newData, oldData) => {
      const diffData = useDiff(newData, oldData, ["id", "created_at", "updated_at"]);
      if (Object.keys(diffData).length) {
        education_documents.value = newData.education_documents;
        if (isUpdated.value) {
          isUpdated.value = false;
          return;
        }
      }
    });
    watch(() => resumeStore.resume, (newResume) => {
      if (newResume) {
        sectionData.value = {
          education_documents: newResume.education_documents
        };
        nextTick(() => {
          isChanged.value = false;
        });
      }
    });
    watch(() => isCollapsed.value, (newData) => {
      if (!newData) {
        isShown.value = true;
      }
    });
    watch(() => education_documents.value, (newData) => {
      isChanged.value = true;
    });
    const { getResume, updateResume } = resumeStore;
    const { errors, handleErrorResponse } = useFormValidation();
    const save = async () => {
      if (isChanged.value) {
        const resData = await updateResume(draftID.value, {
          form_data: "EDUCATION_DOCUMENTS_DATA",
          education_documents: education_documents.value
        });
        if (resData.status !== "success") {
          return handleErrorResponse(resData.data);
        }
        isChanged.value = false;
        isSaved.value = false;
        isUpdated.value = true;
        await getResume(draftID.value);
      }
    };
    const isCompleted = computed(() => {
      var _a22, _b;
      return ((_b = (_a22 = resumeStore.resume) == null ? void 0 : _a22.education_documents) == null ? void 0 : _b.length) > 0;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeEducationDocumentsHistory = __nuxt_component_0$2;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B, \u043A\u0443\u0440\u0441\u044B</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      if (unref(isShown)) {
        _push(`<div class=""><div class="row">`);
        _push(ssrRenderComponent(_component_CreateResumeEducationDocumentsHistory, {
          ref: "educationDocumentElement",
          modelValue: unref(education_documents),
          "onUpdate:modelValue": ($event) => isRef(education_documents) ? education_documents.value = $event : null,
          errors: unref(errors)["education_documents"]
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<div class="empty-area"><span>\u0417\u0434\u0435\u0441\u044C \u0432\u044B \u043C\u043E\u0436\u0435\u0442\u0435 \u0443\u043A\u0430\u0437\u0430\u0442\u044C</span><button class="add" type="button">\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button></div>`);
      }
      if (unref(isSaved)) {
        _push(`<span class="p-3 d-inline-flex justify-content-center align-items-center" style="${ssrRenderStyle({ "color": "#0c0" })}"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="me-2"><path fill="#0c0" d="M10.041 17l-4.5-4.319 1.395-1.435 3.08 2.937 7.021-7.183 1.422 1.409-8.418 8.591zm5.959 7v-2h-8v2h8zm0-24v2h-8v-2h8zm2 0h1c2.762 0 5 2.239 5 5v1h-2v-1c0-1.654-1.346-3-3-3h-1v-2zm6 16h-2v-8h2v8zm-18 8h-1c-2.762 0-5-2.239-5-5v-1h2v1c0 1.654 1.346 3 3 3h1v2zm18-6v1c0 2.761-2.238 5-5 5h-1v-2h1c1.654 0 3-1.346 3-3v-1h2zm-24-12v-1c0-2.761 2.238-5 5-5h1v2h-1c-1.654 0-3 1.346-3 3v1h-2zm0 2h2v8h-2v-8z"></path></svg> \u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D </span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/EducationDocuments/Content.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "SkillsForm",
  __ssrInlineRender: true,
  props: {
    isNew: {
      required: false,
      default: true
    },
    skill: {
      required: true
    },
    id: {
      required: true
    }
  },
  emits: ["add", "delete", "update"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const isNew = ref(props.isNew);
    const skill = ref(props.skill);
    watchEffect(() => {
      skill.value = props.skill;
      isNew.value = props.isNew;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row" }, _attrs))} data-v-b785f731><div class="col-10" data-v-b785f731><div class="input-wrapper" data-v-b785f731><input type="text"${ssrRenderAttr("value", unref(skill))} data-v-b785f731></div></div><div class="col-2" data-v-b785f731><div class="input-wrapper" data-v-b785f731>`);
      if (props.isNew) {
        _push(`<button class="btn btn-primary" type="button" data-v-b785f731>\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C</button>`);
      } else {
        _push(`<button class="btn btn-primary" type="button" data-v-b785f731>\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C</button>`);
      }
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/Skills/SkillsForm.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-b785f731"]]);
const _sfc_main$2 = {
  __name: "Content",
  __ssrInlineRender: true,
  props: ["modelValue", "errors"],
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    useDictionaryStore();
    const selectedSkills = ref([...props.modelValue]);
    const currentSkillId = ref(null);
    const currentSkill = ref(null);
    const isNew = computed(() => {
      if (currentSkill.value) {
        return false;
      }
      return true;
    });
    const computedSelectedSkills = computed(() => {
      return selectedSkills.value.filter((item) => item);
    });
    const addItem = (newItem) => {
      const newItems = selectedSkills.value.filter((item) => item);
      newItems.push(newItem);
      newItems.push(null);
      selectedSkills.value = newItems;
    };
    const updateItem = (id, newItem) => {
      const newItems = selectedSkills.value.map((item, index) => {
        if (index === id) {
          return newItem;
        }
        return item;
      });
      selectedSkills.value = newItems;
      currentSkillId.value = null;
      currentSkill.value = null;
    };
    const deleteItem = (deleteItem2) => {
      const newItems = selectedSkills.value.filter((item) => item !== deleteItem2);
      selectedSkills.value = newItems;
    };
    watch(selectedSkills, (newValues) => {
      emit(
        "update:modelValue",
        newValues.filter((item) => item)
      );
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeSkillsForm = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-100" }, _attrs))} data-v-6eebcc62>`);
      if (props.message) {
        _push(`<div class="text-danger d-block p-4" data-v-6eebcc62>${ssrInterpolate(props.message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(selectedSkills).length) {
        _push(ssrRenderComponent(_component_CreateResumeSkillsForm, {
          "is-new": unref(isNew),
          id: unref(currentSkillId),
          skill: unref(currentSkill),
          onAdd: addItem,
          onUpdate: updateItem,
          onDelete: deleteItem
        }, null, _parent));
      } else {
        _push(`<button class="btn btn-primary" data-v-6eebcc62>\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C</button>`);
      }
      if (unref(computedSelectedSkills).length > 0) {
        _push(`<div class="selection selected-options" data-v-6eebcc62><ul class="selected-options" id="select2--container" data-v-6eebcc62><!--[-->`);
        ssrRenderList(unref(computedSelectedSkills), (item, index) => {
          _push(`<li class="multi-select_selected-item" data-v-6eebcc62><button type="button" class="select2-selection__choice__remove" data-v-6eebcc62><span aria-hidden="true" data-v-6eebcc62>\xD7</span></button><span class="select2-selection__choice__display" data-v-6eebcc62>${ssrInterpolate(item)}</span></li>`);
        });
        _push(`<!--]--></ul></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/Skills/Content.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-6eebcc62"]]);
const _sfc_main$1 = {
  __name: "KnowledgeAndSkills",
  __ssrInlineRender: true,
  setup(__props) {
    var _a2;
    var _a;
    const route = useRoute();
    const resumeStore = useResumeStore();
    useDictionaryStore();
    const draftID = computed(() => route.query.draft_id);
    computed(() => route.query.vacancy_id);
    const skills = ref((_a2 = (_a = resumeStore.resume) == null ? void 0 : _a.skills) != null ? _a2 : []);
    const isShown = ref(false);
    const isChanged = ref(false);
    const isSaved = ref(false);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const sectionData = ref({
      skills: []
    });
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData, [
          "id",
          "created_at",
          "updated_at"
        ]);
        if (Object.keys(diffData).length) {
          skills.value = newData.skills;
          if (isUpdated.value) {
            isUpdated.value = false;
            return;
          }
        }
      }
    );
    watch(
      () => resumeStore.resume,
      (newResume) => {
        if (newResume) {
          sectionData.value = {
            skills: newResume == null ? void 0 : newResume.skills
          };
          nextTick(() => {
            isChanged.value = false;
          });
        }
      }
    );
    watch(
      () => skills.value,
      (newData) => {
        isChanged.value = true;
      }
    );
    watch(
      () => isCollapsed.value,
      (newData) => {
        if (!newData) {
          isShown.value = true;
        }
      }
    );
    const { getResume, updateResume } = resumeStore;
    const { errors, handleErrorResponse } = useFormValidation();
    const save = async () => {
      if (isChanged.value) {
        const resData = await updateResume(draftID.value, {
          form_data: "KNOWLEDGE_AND_SKILLS_DATA",
          skills: skills.value
        });
        if (resData.status !== "success") {
          return handleErrorResponse(resData.data);
        }
        isChanged.value = false;
        isSaved.value = false;
        isUpdated.value = true;
        await getResume(draftID.value);
      }
    };
    const isCompleted = computed(() => {
      var _a22, _b;
      return ((_b = (_a22 = resumeStore.resume) == null ? void 0 : _a22.skills) == null ? void 0 : _b.length) > 0;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeSkillsContent = __nuxt_component_0;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0417\u043D\u0430\u043D\u0438\u044F \u0438 \u043D\u0430\u0432\u044B\u043A\u0438</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      if (unref(isShown)) {
        _push(`<div class="form_content">`);
        _push(ssrRenderComponent(_component_CreateResumeSkillsContent, {
          modelValue: unref(skills),
          "onUpdate:modelValue": ($event) => isRef(skills) ? skills.value = $event : null,
          errors: unref(errors).skills
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<div class="empty-area"><span>\u0417\u0434\u0435\u0441\u044C \u0432\u044B \u043C\u043E\u0436\u0435\u0442\u0435 \u0443\u043A\u0430\u0437\u0430\u0442\u044C \u0440\u0435\u043B\u0435\u0432\u0430\u043D\u0442\u043D\u044B\u0439 \u043E\u043F\u044B\u0442 \u0432 \u0441\u0444\u0435\u0440\u0435 \u043A\u043E\u0442\u043E\u0440\u0443\u044E \u0432\u044B \u0432\u044B\u0431\u0430\u0440\u043B\u0438</span><button class="add" type="button">\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C</button></div>`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/KnowledgeAndSkills.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$1;
const _sfc_main = {
  __name: "create-resume2",
  __ssrInlineRender: true,
  setup(__props) {
    const pageTitle = computed(() => {
      if (draftId.value) {
        return "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0440\u0435\u0437\u044E\u043C\u0435 - Jobeek";
      }
      return "\u0421\u043E\u0437\u0434\u0430\u043D\u0438\u0435 \u0440\u0435\u0437\u044E\u043C\u0435 - Jobeek";
    });
    const route = useRoute();
    const draftId = computed(() => route.query.draft_id);
    computed(() => route.query.vacancy_id);
    watch(() => route.query.draft_id, (newDraftId) => {
      console.log(newDraftId);
      if (newDraftId) {
        getResume(draftId.value);
      }
    });
    const resumeStore = useResumeStore();
    const { resume } = storeToRefs(resumeStore);
    const isEditable = computed(() => {
      if (resume.value) {
        return true;
      }
      return false;
    });
    const { getResume } = resumeStore;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0$5;
      const _component_CreateResumePersonalDataCard = resolveComponent("CreateResumePersonalDataCard");
      const _component_CreateResumePositionAndIncome = __nuxt_component_3;
      const _component_CreateResumeEducationContent = resolveComponent("CreateResumeEducationContent");
      const _component_CreateResumeEducationDocumentsContent = __nuxt_component_4;
      const _component_CreateResumeWorkExperienceContent = resolveComponent("CreateResumeWorkExperienceContent");
      const _component_CreateResumeDriverLicenses = resolveComponent("CreateResumeDriverLicenses");
      const _component_CreateResumeKnowledgeAndSkills = __nuxt_component_5;
      const _component_CreateResumeForeignLanguagesContent = resolveComponent("CreateResumeForeignLanguagesContent");
      const _component_CreateResumeCitizenshipAndFamily = resolveComponent("CreateResumeCitizenshipAndFamily");
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet create-subscribe-page bg-wrapper",
        role: "main"
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(pageTitle))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(pageTitle)), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(pageTitle)), 1)
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="bg-wrapper pt">`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="wrapper wrapper-1290"><form class="create-resume" action="" name="create-resume ">`);
      _push(ssrRenderComponent(_component_CreateResumePersonalDataCard, null, null, _parent));
      if (unref(isEditable)) {
        _push(ssrRenderComponent(_component_CreateResumePositionAndIncome, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isEditable)) {
        _push(ssrRenderComponent(_component_CreateResumeEducationContent, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isEditable)) {
        _push(ssrRenderComponent(_component_CreateResumeEducationDocumentsContent, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isEditable)) {
        _push(ssrRenderComponent(_component_CreateResumeWorkExperienceContent, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isEditable)) {
        _push(ssrRenderComponent(_component_CreateResumeDriverLicenses, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isEditable)) {
        _push(ssrRenderComponent(_component_CreateResumeKnowledgeAndSkills, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isEditable)) {
        _push(ssrRenderComponent(_component_CreateResumeForeignLanguagesContent, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isEditable)) {
        _push(ssrRenderComponent(_component_CreateResumeCitizenshipAndFamily, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<p class="text-lg-end">\u041F\u0440\u0438 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0438 \u0440\u0435\u0437\u044E\u043C\u0435 \u0432\u044B \u0441\u043E\u0433\u043B\u0430\u0448\u0430\u0435\u0442\u0435\u0441\u044C \u0441 <a href="#">\u043F\u0440\u0430\u0432\u0438\u043B\u0430\u043C\u0438 \u0440\u0430\u0431\u043E\u0442\u044B \u0441\u0435\u0440\u0432\u0438\u0441\u0430</a> \u0438 \u0434\u0430\u0435\u0442\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u0435 \u043D\u0430 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445, \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u0440\u0430\u0441\u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0435\u043D\u0438\u044F</p><div class="form-submit-container mt-2"><button class="btn btn-outline-primary" type="button">\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043A\u0430\u043A \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A</button><button class="button-accent" type="submit">\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0438 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C</button></div></form></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/create-resume2.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=create-resume2-BemIL92F.mjs.map
