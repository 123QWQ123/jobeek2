const Providers_vue_vue_type_style_index_0_scoped_bd0b1e1a_lang = ".import-box[data-v-bd0b1e1a]{cursor:pointer}.is-connected .import-box-dvnld .logo .check[data-v-bd0b1e1a]{display:block}.import-box.disabled[data-v-bd0b1e1a]{background:#fff;border-radius:12px;box-shadow:0 0 20px rgb(0 0 0/4%)}.import-box.disabled .import-box-dvnld[data-v-bd0b1e1a]{border:1px dashed #8c8c8c;color:#8c8c8c}.import-box.disabled .import-box-dvnld .logo[data-v-bd0b1e1a]{filter:grayscale(100%)}.import-box.disabled .import-box-dvnld span[data-v-bd0b1e1a]{color:#8c8c8c}";

const ProvidersStyles_Cip7uu89 = [Providers_vue_vue_type_style_index_0_scoped_bd0b1e1a_lang];

export { ProvidersStyles_Cip7uu89 as default };
//# sourceMappingURL=Providers-styles.Cip7uu89.mjs.map
