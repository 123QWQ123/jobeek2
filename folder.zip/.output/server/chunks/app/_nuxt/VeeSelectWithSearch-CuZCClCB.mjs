import { useField } from 'vee-validate';
import { useSSRContext, ref, computed, watch, resolveDirective, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrGetDirectiveProps, ssrRenderAttr, ssrRenderClass, ssrRenderStyle, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const __default__ = {
  name: "SelectWithSearch"
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    options: {
      required: true
    },
    label: {
      required: false
    },
    name: {
      required: false
    },
    placeholder: {
      required: false
    },
    listStyles: {
      required: false
    },
    listItemStyles: {
      required: false
    },
    selected: {
      required: false
    },
    not_found: {
      required: false,
      type: String,
      default: "\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E"
    }
  },
  emits: ["change", "update:modelValue", "input"],
  setup(__props, { emit: __emit }) {
    var _a;
    const props = __props;
    const { value, errorMessage } = useField(() => props.name);
    const isFirst = ref(false);
    const isOpen = ref(false);
    const options = ref(props.options);
    const placeholder = computed(() => props.placeholder);
    const searchInput = ref((_a = props.placeholder) != null ? _a : "");
    watch(
      () => props.placeholder,
      () => placeholder.value = props.placeholder
    );
    watch(
      () => props.options,
      (newOptions) => {
        options.value = newOptions;
        if (selectedOption.value && value.value !== selectedOption.value.value) {
          const found = options.value.find(
            (item) => String(item.value) === String(value.value)
          );
          if (!found)
            return;
          searchInput.value = found.name;
          selectedOption.value = found;
        }
      }
    );
    watch(
      () => value.value,
      (newValue) => {
        const found = options.value.find(
          (item) => String(item.value) === String(newValue)
        );
        if (!found)
          return;
        selectedOption.value = found;
        searchInput.value = found.name;
      }
    );
    const selectedOption = ref({});
    ref("");
    const placeholderClass = computed(() => {
      return isFirst.value || !selectedOption.value;
    });
    watch(
      () => isOpen.value,
      (newOpen) => {
        if (!newOpen) {
          if (searchInput.value === "") {
            searchInput.value = props.placeholder;
          }
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<!--[--><div${ssrRenderAttrs(mergeProps({
        class: ["nice-select n-select d-select", { open: unref(isOpen) }],
        tabindex: "0"
      }, ssrGetDirectiveProps(_ctx, _directive_click_outside, () => isOpen.value = false)))} data-v-e66e6be6><input${ssrRenderAttr("value", unref(searchInput))} role="presentation" autocomplete="off" autofill="off" class="${ssrRenderClass([{ placeholder: unref(placeholderClass) }, "current"])}" data-v-e66e6be6><span class="select_arrow" data-v-e66e6be6></span>`);
      if (unref(isOpen)) {
        _push(`<ul class="list" style="${ssrRenderStyle(__props.listStyles)}" data-v-e66e6be6><!--[-->`);
        ssrRenderList(unref(options), (item) => {
          _push(`<li${ssrRenderAttr("data-value", item.value)} class="option" style="${ssrRenderStyle(__props.listItemStyles)}" data-v-e66e6be6>${ssrInterpolate(item.name)}</li>`);
        });
        _push(`<!--]-->`);
        if (unref(options).length === 0) {
          _push(`<li data-v-e66e6be6>${ssrInterpolate(props.not_found)}</li>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</ul>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="text-danger d-block" data-v-e66e6be6>${ssrInterpolate(unref(errorMessage))}</div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/VeeSelectWithSearch.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-e66e6be6"]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=VeeSelectWithSearch-CuZCClCB.mjs.map
