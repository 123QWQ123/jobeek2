const DraftList_vue_vue_type_style_index_0_scoped_9f9a20ec_lang = ".theme-checker input~.theme-checker-ui .circle.left[data-v-9f9a20ec]{transform:translate(3px,-50%)}.theme-checker input~.theme-checker-ui .circle.right[data-v-9f9a20ec]{transform:translate(30px,-50%)}.sort .d-select[data-v-9f9a20ec]{background:#f5f8fa!important}";

const DraftListStyles_3KnpK6Zi = [DraftList_vue_vue_type_style_index_0_scoped_9f9a20ec_lang];

export { DraftListStyles_3KnpK6Zi as default };
//# sourceMappingURL=DraftList-styles.3KnpK6Zi.mjs.map
