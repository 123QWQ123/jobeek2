globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { _ as __nuxt_component_0$1, a as __nuxt_component_2 } from './LikeList-D7jOt6wI.mjs';
import { useSSRContext, computed, mergeProps, unref, ref } from 'vue';
import { u as useHead, e as useRoute, r as useResumeStore, s as storeToRefs, j as useNuxtApp } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrRenderList, ssrRenderAttr, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import { _ as _imports_1 } from './akar-icons_whatsapp-fill-DXuWDQDi.mjs';
import moment from 'moment';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './search-CNCM2ROA.mjs';
import './location-6cdwV0kl.mjs';
import './megafon-UViF3Tze.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main$1 = {
  __name: "Content",
  __ssrInlineRender: true,
  props: {
    item: {
      required: true
    }
  },
  setup(__props) {
    var _a;
    const { item } = __props;
    const isFavorite = ref((_a = item.is_favorite) != null ? _a : false);
    useResumeStore();
    const { $format_number } = useNuxtApp();
    const salaryText = computed(() => {
      if (item.salary) {
        return `\u041E\u0442 ${$format_number(item.salary)} ${item.currency}`;
      }
      return "\u041F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0443";
    });
    const isContactsShown = ref("none");
    const vacancyPhones = computed(() => {
      return item.contacts.phones;
    });
    const getPhoneHref = (phone) => {
      return "href: +" + phone;
    };
    const employerLogo = computed(() => {
      if (item && item.logo) {
        return item.logo;
      } else
        return new URL("/assets/img/logos/superjob.svg", globalThis._importMeta_.url);
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a3;
      var _a2;
      _push(`<!--[--><div class="favorites-card favorites-card--footer-only"><div class="favorites-card-footer"><div class="favorites-card-footer-row telephones-row" style="${ssrRenderStyle({ display: unref(isContactsShown) })}">`);
      if (unref(vacancyPhones).length > 0) {
        _push(`<ul><!--[-->`);
        ssrRenderList(unref(vacancyPhones), (phone) => {
          _push(`<li><a class="tel"${ssrRenderAttr("href", getPhoneHref(phone))}><img${ssrRenderAttr("src", _imports_1)} alt="#">+7 ${ssrInterpolate(phone)}</a></li>`);
        });
        _push(`<!--]--></ul>`);
      } else {
        _push(`<p>\u041D\u0435\u0442 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043E\u0432</p>`);
      }
      _push(`</div><div class="favorites-card-footer-row"><div class="group"><button class="group-action btn button-md">\u041E\u0442\u043A\u043B\u0438\u043A\u043D\u0443\u0442\u044C\u0441\u044F</button>`);
      if (unref(isContactsShown) === "none") {
        _push(`<button class="group-action btn button-md js-show-contacts"> \u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u044B </button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isContactsShown) !== "none") {
        _push(`<button class="group-action btn button-md js-show-contacts"> \u0421\u043A\u0440\u044B\u0442\u044C \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u044B </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="group"><button class="${ssrRenderClass([{ active: unref(isFavorite) }, "group-action ic-btn fav-btn"])}"><svg width="23" height="21" viewBox="0 0 23 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.0641 0.796788C11.2552 0.45665 11.7448 0.456649 11.9359 0.796789L14.7993 5.89364C15.0135 6.27499 15.3835 6.54383 15.8124 6.62973L21.5446 7.77794C21.9272 7.85457 22.0785 8.32027 21.8141 8.60711L17.8515 12.9053C17.555 13.2269 17.4137 13.6619 17.4645 14.0964L18.1439 19.9029C18.1892 20.2903 17.793 20.5782 17.4385 20.4153L12.1262 17.9749C11.7287 17.7923 11.2713 17.7923 10.8738 17.9749L5.56148 20.4153C5.20696 20.5782 4.81081 20.2903 4.85614 19.9029L5.53549 14.0964C5.58632 13.6619 5.44498 13.2269 5.1485 12.9053L1.18593 8.60711C0.921493 8.32027 1.07281 7.85457 1.45535 7.77794L7.18757 6.62973C7.61645 6.54383 7.98648 6.27499 8.20072 5.89364L11.0641 0.796788Z" stroke="#C8C8C8"></path></svg></button></div></div></div></div><div class="has-sidebar has-sidebar--v3"><div class="content"><div class="vacancy-single"><div class="vacancy-single-head"><h1 class="title">${ssrInterpolate((_a2 = __props.item) == null ? void 0 : _a2.name)}</h1><div class="adress"><span>${ssrInterpolate(__props.item.address)}</span></div><div class="requirements">${ssrInterpolate(__props.item.experience && __props.item.experience + ",")} ${ssrInterpolate(__props.item.education && __props.item.education + ",")} ${ssrInterpolate(__props.item.work_type)}, ${ssrInterpolate(unref(moment).unix(__props.item.published_date).format("YYYY.MM.DD"))}</div><div class="salary">${ssrInterpolate(unref(salaryText))}</div></div><div class="vacancy-single-body">${__props.item.description}</div><div class="vacancy-single-footer"><button class="btn button-accent button-accent--ts-bigger"> \u041E\u0442\u043A\u043B\u0438\u043A\u043D\u0443\u0442\u044C\u0441\u044F </button></div></div></div><aside class="sidebar"><div class="company-col sticky-item"><div class="company-logo"><img class="w-100"${ssrRenderAttr("src", unref(employerLogo))}${ssrRenderAttr("alt", __props.item.company)}></div><h3 class="title">${ssrInterpolate(__props.item.company)}</h3><div class="count">${ssrInterpolate((_a3 = __props.item.open_vacancies) != null ? _a3 : 0)} \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</div></div></aside></div><!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Resumes/Single/Content.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$1;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    var _a;
    const pageTitle = computed(() => {
      var _a2;
      return ((_a2 = resume[provider]) == null ? void 0 : _a2.name) + " - Jobeek";
    });
    useHead({
      title: (_a = pageTitle.value) != null ? _a : "Loading"
    });
    const route = useRoute();
    const resumeStore = useResumeStore();
    const { resume } = storeToRefs(resumeStore);
    const { slug } = route.params;
    console.log(slug);
    const { provider } = route.query;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SearchForm = __nuxt_component_0$1;
      const _component_ResumesSingleContent = __nuxt_component_1;
      const _component_VacanciesSingleLikeList = __nuxt_component_2;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet vacansy-page",
        role: "main"
      }, _attrs))} data-v-79ebb9f2><div class="bg-wrapper pt" data-v-79ebb9f2><div class="main-section main-section-mob" data-v-79ebb9f2><div class="wrapper wrapper--xl" data-v-79ebb9f2>`);
      _push(ssrRenderComponent(_component_SearchForm, null, null, _parent));
      _push(`</div></div>`);
      if (unref(resume)) {
        _push(`<div class="wrapper wrapper-1290" data-v-79ebb9f2>`);
        _push(ssrRenderComponent(_component_ResumesSingleContent, {
          data: unref(resume)[unref(provider)]
        }, null, _parent));
        _push(`<h2 class="lk-page-title" data-v-79ebb9f2>\u041F\u043E\u0445\u043E\u0436\u0438\u0435 \u0440\u0435\u0437\u044E\u043C\u0435</h2><div class="favorites-list-container" data-v-79ebb9f2>`);
        _push(ssrRenderComponent(_component_VacanciesSingleLikeList, null, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/resumes/[slug]/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-79ebb9f2"]]);

export { index as default };
//# sourceMappingURL=index-DAsK5cYC.mjs.map
