const CreateDraft_vue_vue_type_style_index_0_lang = '.w-box-body.disabled{position:relative}.w-box-body.disabled:before{background:rgba(0,0,0,.5);content:"";height:100%;left:0;position:absolute;top:0;width:100%;z-index:999}';

const CreateDraftStyles_D_7opqcS = [CreateDraft_vue_vue_type_style_index_0_lang];

export { CreateDraftStyles_D_7opqcS as default };
//# sourceMappingURL=CreateDraft-styles.D_7opqcS.mjs.map
