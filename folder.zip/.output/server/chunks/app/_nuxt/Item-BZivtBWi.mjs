globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { _ as __nuxt_component_0$1 } from './nuxt-link-BdrY0gEc.mjs';
import { useSSRContext, computed, ref, watch, unref, withCtx, createTextVNode, toDisplayString } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrInterpolate, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';
import moment from 'moment';
import { r as useResumeStore, j as useNuxtApp } from '../server.mjs';

const _sfc_main = {
  __name: "Item",
  __ssrInlineRender: true,
  props: ["item"],
  setup(__props) {
    var _a;
    const props = __props;
    const { item } = props;
    const {
      $format_number,
      $format_years,
      $format_months,
      $convert_month_to_text
    } = useNuxtApp();
    const viewedText = computed(() => {
      if (!item.date_view)
        return item.viewed ? "\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043D\u043E" : "";
      return "\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043D\u043E" + moment(item.date_view).format("hh:mm");
    });
    const salaryText = computed(() => {
      if (!item.agreement) {
        return `\u041E\u0442 ${$format_number(item.salary)} ${item.currency}`;
      }
      return "\u041F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0443";
    });
    const educationLevelText = computed(() => {
      const { education_level } = props.item.educations;
      const { primary } = props.item.educations;
      let level = "\u0421\u0440\u0435\u0434\u043D\u0435\u0435";
      if (education_level) {
        level = education_level.name;
      }
      let instituteText = void 0;
      if (primary && primary.length > 0) {
        const edu = primary[0];
        const institute = edu.institute ? ", " + edu.institute : "";
        const profession = edu.profession ? ", " + edu.profession : "";
        const end_year = edu.end_year ? ", " + edu.end_year : "";
        instituteText = `${institute}${profession}${end_year}`;
      }
      if (instituteText)
        return level + `${instituteText ? ", " : ""} ${instituteText}`;
      else
        return level;
    });
    computed(() => {
      const { education_level } = props.item.educations;
      let level = "\u0421\u0440\u0435\u0434\u043D\u0435\u0435";
      if (education_level) {
        level = education_level.name;
      }
      return level + "-";
    });
    const experienceText = computed(() => {
      if (item && item.experience_month_count) {
        const years = $format_years(
          parseInt($format_years(item.experience_month_count / 12))
        );
        const months = $format_months(parseInt(item.experience_month_count % 12));
        return `${years} ${months}`;
      }
      return "\u041D\u0435\u0442 \u043E\u043F\u044B\u0442 \u0440\u0430\u0431\u043E\u0442\u044B";
    });
    const formatEndDate = (end_year = null, end_month = null) => {
      if (!end_year || !end_month)
        return "\u043F\u043E \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0435\u0435";
      return $convert_month_to_text(end_month) + " " + end_year;
    };
    const lastWorkplace = computed(() => {
      if (item && item.experience) {
        const lastExperience = item.experience[0];
        if (lastExperience) {
          const { company, profession, start_year, start_month } = lastExperience;
          return `${company} * ${profession} | ${$convert_month_to_text(start_month)} ${start_year} - ` + formatEndDate(lastExperience.end_year, lastExperience.end_month);
        }
      }
      return "\u041D\u0435\u0442 \u043E\u043F\u044B\u0442 \u0440\u0430\u0431\u043E\u0442\u044B";
    });
    computed(() => {
      if (item.description) {
        let text = item.description.slice(0, 150);
        if (item.description.length > 150) {
          text += "...";
        }
        return text;
      }
      return item.description;
    });
    const experienceItems = ref([]);
    const prepareExperienceItems = (newExperience) => {
      const items = newExperience.map((ex_item) => {
        let text = "-";
        text = `${$convert_month_to_text(ex_item.start_month)} ${ex_item.start_year} - ` + formatEndDate(ex_item.end_year, ex_item.end_month);
        return { ...ex_item, dateText: text };
      });
      experienceItems.value = items;
    };
    watch(() => props.item.experience, prepareExperienceItems);
    prepareExperienceItems(item.experience);
    const isFavorite = ref((_a = item.is_favorite) != null ? _a : false);
    useResumeStore();
    const photo = computed(() => {
      if (item.photo) {
        return item.photo;
      } else
        return new URL("/assets/img/avatar.png", globalThis._importMeta_.url);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<li${ssrRenderAttrs(_attrs)}><div class="favorites-card resume-card-t2"><div class="resume-card-t2__head"><div class="resume-card-t2__head-info"><div class="status-list"><span style="${ssrRenderStyle({ "color": "#0dc267" })}"> \u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043E ${ssrInterpolate(unref(moment)(unref(item).updated_at).format("hh:mm"))}</span><span style="${ssrRenderStyle({ "color": "#0dc267" })}">${ssrInterpolate(unref(viewedText))}</span></div><a href="#" class="resume-title">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: {
          name: "resumes-slug",
          params: { slug: unref(item).id },
          query: { provider: unref(item).provider }
        }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref(item).title)}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref(item).title), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</a><div class="salary">${ssrInterpolate(unref(salaryText))}</div><div class="resume-tag">\u0420\u0430\u0441\u0441\u043C\u0430\u0442\u0440\u0438\u0432\u0430\u0435\u0442 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F</div></div><div class="resume-card-t2__head-img"><img${ssrRenderAttr("src", unref(photo))}${ssrRenderAttr("alt", unref(item).profession)}></div></div><div class="resume-card-t2__body"><ul><li><div>\u041E\u043F\u044B\u0442 \u0440\u0430\u0431\u043E\u0442\u044B</div><div>${ssrInterpolate(unref(experienceText))}</div></li><li><div>\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0440\u0430\u0431\u043E\u0442\u044B</div><div><div class="rrow">${ssrInterpolate(unref(lastWorkplace))}</div></div></li><li><div>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0439, \u0432 \u043A\u043E\u0442\u043E\u0440\u044B\u0445 \u0440\u0430\u0431\u043E\u0442\u0430\u043B \u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442</div><div><!--[-->`);
      ssrRenderList(unref(experienceItems), (ex_item) => {
        _push(`<div class="rrow"><strong>${ssrInterpolate(ex_item.company)}</strong> \u2022 ${ssrInterpolate(ex_item.profession)} \u2022 ${ssrInterpolate(ex_item.dateText)}</div>`);
      });
      _push(`<!--]--></div></li><li><div>\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438</div><div>\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0438\u0441\u0442, \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A</div></li><li><div>\u041E\u0441\u043D\u043E\u0432\u043D\u043E\u0435 \u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435</div><div>${ssrInterpolate(unref(educationLevelText))}</div></li></ul></div><div class="favorites-card-footer"><div class="favorites-card-footer-row"><div class="group" style="${ssrRenderStyle({ "margin-left": "auto" })}"><button class="${ssrRenderClass([{ active: unref(isFavorite) }, "group-action ic-btn fav-btn"])}"><svg width="23" height="21" viewBox="0 0 23 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.0641 0.796788C11.2552 0.45665 11.7448 0.456649 11.9359 0.796789L14.7993 5.89364C15.0135 6.27499 15.3835 6.54383 15.8124 6.62973L21.5446 7.77794C21.9272 7.85457 22.0785 8.32027 21.8141 8.60711L17.8515 12.9053C17.555 13.2269 17.4137 13.6619 17.4645 14.0964L18.1439 19.9029C18.1892 20.2903 17.793 20.5782 17.4385 20.4153L12.1262 17.9749C11.7287 17.7923 11.2713 17.7923 10.8738 17.9749L5.56148 20.4153C5.20696 20.5782 4.81081 20.2903 4.85614 19.9029L5.53549 14.0964C5.58632 13.6619 5.44498 13.2269 5.1485 12.9053L1.18593 8.60711C0.921493 8.32027 1.07281 7.85457 1.45535 7.77794L7.18757 6.62973C7.61645 6.54383 7.98648 6.27499 8.20072 5.89364L11.0641 0.796788Z" stroke="#C8C8C8"></path></svg></button></div></div></div></div></li>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Resumes/Item.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=Item-BZivtBWi.mjs.map
