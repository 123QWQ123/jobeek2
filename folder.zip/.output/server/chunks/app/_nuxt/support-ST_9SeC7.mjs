import { _ as _imports_0, a as __nuxt_component_0 } from './i-XlC_iSFx.mjs';
import { computed, reactive, ref, mergeProps, unref, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { u as useHead, k as useAuthStore, a as useRouter, e as useRoute, m as useProfileStore } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import './BaseButton-CWRjb9_h.mjs';
import './nuxt-link-BdrY0gEc.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import './_plugin-vue_export-helper-1tPrXgE0.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main = {
  __name: "support",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C"
    });
    const auth = useAuthStore();
    computed(() => auth.isAuthed);
    useRouter();
    const initialState = {
      phone: {
        val: "",
        isValid: true
      },
      email: {
        val: "",
        isValid: true
      },
      message: {
        val: "",
        isValid: true
      },
      isFormValid: true,
      isLoading: true,
      error: null,
      success: null
    };
    const state = reactive(initialState);
    useRoute();
    useProfileStore();
    ref();
    ref(null);
    function close() {
      state.error = null;
      state.success = null;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_base_modal = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_base_modal, {
        show: !!unref(state).success,
        title: "Success",
        onClose: close
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<p${_scopeId}>${ssrInterpolate(unref(state).success)}</p>`);
          } else {
            return [
              createVNode("p", null, toDisplayString(unref(state).success), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<main class="main enter-page sign-in" role="main"><div class="support-page"><img alt="#" src="https://jobeek.me/assets/img/Frame2.svg" class="auth-bg-1"><img alt="#" src="https://jobeek.me/assets/img/ft-bg-img.png" class="auth-bg-2"><div class="wrapper"><form class="support-form enter-form"><h1>\u041E\u0431\u0440\u0430\u0442\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C</h1><p>\u041F\u043E \u0432\u0441\u0435\u043C \u0432\u043E\u043F\u0440\u043E\u0441\u0430\u043C \u043E\u0431\u0440\u0430\u0449\u0430\u0439\u0442\u0435\u0441\u044C \u043D\u0430 <a href="#">support@hphelp.me</a>, \u0438\u043B\u0438 \u0432\u043E\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435\u0441\u044C \u0444\u043E\u0440\u043C\u043E\u0439</p><div class="i-wrap"><input type="text" name="email"${ssrRenderAttr("value", unref(state).email.val)} placeholder="Email"></div><div class="note"><img${ssrRenderAttr("src", _imports_0)} alt="#"><p>\u041D\u0443\u0436\u0435\u043D \u0434\u043B\u044F \u0442\u043E\u0433\u043E \u0447\u0442\u043E-\u0431\u044B \u043C\u044B \u0441\u043C\u043E\u0433\u043B\u0438 \u043E\u0442\u0432\u0435\u0442\u0438\u0442\u044C \u0432\u0430\u043C.</p></div><div class="i-wrap"><input type="tel" name="tel" placeholder="\u041D\u043E\u043C\u0435\u0440 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430"></div><div class="i-wrap"><textarea name="problem" placeholder="\u041E\u043F\u0438\u0448\u0438\u0442\u0435 \u0441\u0443\u0442\u044C \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B:">${ssrInterpolate(unref(state).message.val)}</textarea></div><button class="btn button-accent" type="submit">\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C</button></form></div></div></main></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/support.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=support-ST_9SeC7.mjs.map
