const BaseModal_vue_vue_type_style_index_0_scoped_868d9d13_lang = ".backdrop[data-v-868d9d13]{background-color:rgba(0,0,0,.4);height:100vh;left:0;position:fixed;top:0;width:100vw}.backdrop[data-v-868d9d13],.show[data-v-868d9d13]{display:block}.modal-content[data-v-868d9d13]{width:100%}.error.modal[data-v-868d9d13]{color:red}.success.modal[data-v-868d9d13]{color:green}.modal-dialog-centered[data-v-868d9d13]{align-items:center;display:flex;min-height:calc(100% - 1rem)}@media (min-width:576px){.modal-dialog-centered[data-v-868d9d13]{min-height:calc(100% - 3.5rem)}}";

const BaseModalStyles_BHdE9v_w = [BaseModal_vue_vue_type_style_index_0_scoped_868d9d13_lang];

export { BaseModalStyles_BHdE9v_w as default };
//# sourceMappingURL=BaseModal-styles.BHdE9v_w.mjs.map
