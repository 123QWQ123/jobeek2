import { _ as _imports_0, a as __nuxt_component_0$2 } from './search-CNCM2ROA.mjs';
import { useSSRContext, ref, computed, watch, resolveDirective, mergeProps, unref, isRef } from 'vue';
import { ssrRenderAttrs, ssrGetDirectiveProps, ssrRenderAttr, ssrRenderClass, ssrRenderStyle, ssrRenderList, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _imports_1 } from './location-6cdwV0kl.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { l as useVacancyStore, e as useRoute, a as useRouter, k as useAuthStore, m as useProfileStore } from '../server.mjs';
import { _ as _imports_0$1 } from './megafon-UViF3Tze.mjs';
import { _ as _imports_1$1, a as _imports_2 } from './akar-icons_whatsapp-fill-DXuWDQDi.mjs';

const __default__ = {
  name: "SelectWithSearchWithIcon"
};
const _sfc_main$3 = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    options: {
      required: true
    },
    label: {
      required: false
    },
    placeholder: {
      required: false
    },
    listStyles: {
      required: false
    },
    listItemStyles: {
      required: false
    },
    modelValue: {
      required: true,
      default: null
    },
    selected: {
      required: false
    },
    not_found: {
      required: false,
      type: String,
      default: "\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E"
    }
  },
  emits: ["change", "update:modelValue", "input"],
  setup(__props, { emit: __emit }) {
    var _a;
    const props = __props;
    const isFirst = ref(false);
    const isOpen = ref(false);
    const options = ref(props.options);
    const placeholder = computed(() => props.placeholder);
    const searchInput = ref((_a = props.placeholder) != null ? _a : "");
    watch(
      () => props.placeholder,
      () => searchInput.value = props.placeholder
    );
    watch(
      () => props.options,
      (newOptions) => {
        options.value = newOptions;
        if (props.modelValue) {
          selectedOption.value = options.value.find(
            (item) => String(item.value) === String(props.modelValue)
          );
        }
      }
    );
    watch(
      () => props.modelValue,
      (newValue) => {
        selectedOption.value = options.value.find(
          (item) => String(item.value) === String(newValue)
        );
      }
    );
    const selectedOption = ref({});
    watch(
      () => selectedOption.value,
      () => {
        var _a2;
        return searchInput.value = (_a2 = selectedOption.value) == null ? void 0 : _a2.name;
      }
    );
    computed(() => {
      if (!isOpen.value) {
        if (selectedOption.value) {
          return selectedOption.value.name;
        } else {
          if (isFirst.value || !selectedOption.value) {
            return placeholder.value;
          }
          return searchInput.value;
        }
      } else {
        return searchInput.value;
      }
    });
    ref("");
    const placeholderClass = computed(() => {
      return isFirst.value || !selectedOption.value;
    });
    ref();
    watch(
      () => isOpen.value,
      (newOpen) => {
        if (!newOpen) {
          if (searchInput.value === "") {
            searchInput.value = props.placeholder;
          }
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["nice-select n-select d-select", { open: unref(isOpen) }],
        tabindex: "0"
      }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, () => isOpen.value = false)))} data-v-e1188478><div class="custom_input-wrap has-icon" data-v-e1188478><span class="d-inline-flex ps-2" data-v-e1188478><img class="icon"${ssrRenderAttr("src", _imports_1)} alt="#" data-v-e1188478></span><input${ssrRenderAttr("placeholder", props.placeholder)} class="${ssrRenderClass([{ placeholder: unref(placeholderClass) }, "current"])}" data-v-e1188478><span class="select_arrow" data-v-e1188478></span></div>`);
      if (unref(isOpen)) {
        _push(`<ul class="list" style="${ssrRenderStyle(__props.listStyles)}" data-v-e1188478><!--[-->`);
        ssrRenderList(unref(options), (item) => {
          _push(`<li${ssrRenderAttr("data-value", item.value)} class="option" style="${ssrRenderStyle(__props.listItemStyles)}" data-v-e1188478>${ssrInterpolate(item.name)}</li>`);
        });
        _push(`<!--]-->`);
        if (unref(options).length === 0) {
          _push(`<li data-v-e1188478>${ssrInterpolate(props.not_found)}</li>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</ul>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/SelectWithSearchWithIcon.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-e1188478"]]);
const _sfc_main$2 = {
  __name: "Form",
  __ssrInlineRender: true,
  setup(__props) {
    const vacancyStore = useVacancyStore();
    useRoute();
    useRouter();
    const auth = useAuthStore();
    const search = ref(null);
    const salary = ref(null);
    ref(null);
    const city = ref("*");
    const profileStore = useProfileStore();
    const { searchCities } = profileStore;
    const updateCityInput = async (newValue = "") => {
      var _a;
      const items = (_a = await searchCities({ search: newValue })) != null ? _a : [];
      cityOptions.value = items.map((item) => ({
        value: item.id,
        name: item.name
      }));
    };
    ref("");
    computed(() => vacancyStore.vacancies);
    const searchSelectItemStyles = {
      width: "auto !important",
      whiteSpace: "pre-wrap"
    };
    computed(() => vacancyStore.cities);
    computed(() => vacancyStore.regions);
    const cityOptions = ref([]);
    useRoute();
    ref(false);
    const searchPlaceHolder = computed(
      () => auth.isEmployer ? "\u041A\u0430\u043A\u043E\u0439 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0441\u0442 \u0432\u044B \u0438\u0449\u0435\u0442\u0435?" : "\u041A\u0430\u043A\u0443\u044E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E \u0432\u044B \u0438\u0449\u0435\u0442\u0435?"
    );
    const searchSelectStyles = {
      left: "unset",
      right: "0px",
      width: "auto !important",
      maxWidth: "20rem",
      minWidth: "8rem"
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderSalarySelectInForm = __nuxt_component_0$2;
      const _component_SelectWithSearchWithIcon = __nuxt_component_1;
      _push(`<form${ssrRenderAttrs(mergeProps({
        class: "search-form",
        role: "form",
        autocomplete: "off"
      }, _attrs))}><div class="wrapper"><div class="search-row"><div class="input-wrap has-icon has-label"><img class="icon"${ssrRenderAttr("src", _imports_0)} alt="#"><label for="name">\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435</label><input${ssrRenderAttr("value", unref(search))} type="text" name="name" id="name"${ssrRenderAttr("placeholder", unref(searchPlaceHolder))} autocomplete="off"></div><div class="input-wrap has-label"><label for="salary placeholder">\u0417\u0430\u0440\u043F\u043B\u0430\u0442\u0430</label>`);
      _push(ssrRenderComponent(_component_HeaderSalarySelectInForm, {
        modelValue: unref(salary),
        "onUpdate:modelValue": ($event) => isRef(salary) ? salary.value = $event : null
      }, null, _parent));
      _push(`</div><div class="input-wrap has-label"><label for="city">\u0413\u043E\u0440\u043E\u0434</label>`);
      _push(ssrRenderComponent(_component_SelectWithSearchWithIcon, {
        options: unref(cityOptions),
        modelValue: unref(city),
        "onUpdate:modelValue": ($event) => isRef(city) ? city.value = $event : null,
        listStyles: searchSelectStyles,
        onInput: updateCityInput,
        listItemStyles: searchSelectItemStyles,
        not_found: "\u0413\u043E\u0440\u043E\u0434 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E"
      }, null, _parent));
      _push(`</div><button class="button-accent submit-search-form" type="button"> \u041F\u043E\u0438\u0441\u043A </button></div></div></form>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Search/Form.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0$1 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "LikeItem",
  __ssrInlineRender: true,
  setup(__props) {
    const isFavoured = ref(true);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<li${ssrRenderAttrs(_attrs)}><div class="favorites-card"><div class="favorites-card-head"><div class="company"><div class="company-logo"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div><div class="company-name"><a href="#"> \u041F\u0440\u043E\u0434\u0430\u0432\u0435\u0446-\u043A\u043E\u043D\u0441\u0443\u043B\u044C\u0442\u0430\u043D\u0442 \u0438 \u0440\u0430\u0431\u043E\u043D\u0438\u043A \u0437\u0430\u043B\u0430</a><span class="count">\u041C\u0435\u0433\u0430\u0444\u043E\u043D</span></div></div><div class="salary">\u041E\u0442 1 000 000 \u20BD</div></div><div class="favorites-card-body"><div class="time-location"><span>9:55</span><strong>\u041C\u043E\u0441\u043A\u0432\u0430</strong></div><p> \u0422\u043E\u0440\u0433\u043E\u0432\u0430\u044F \u0441\u0435\u0442\u044C \xAB\u041F\u0435\u0440\u0435\u043A\u0440\u0451\u0441\u0442\u043E\u043A\xBB \u2013 \u043E\u0431\u044A\u0435\u0434\u0438\u043D\u044F\u0435\u043C \u043B\u0443\u0447\u0448\u0438\u0445! <br>\xAB\u041F\u0435\u0440\u0435\u043A\u0440\u0451\u0441\u0442\u043E\u043A\xBB \u043F\u0440\u0435\u0434\u043B\u0430\u0433\u0430\u0435\u0442 \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u044F\u043C \u0442\u043E\u043B\u044C\u043A\u043E \u043B\u0443\u0447\u0448\u0435\u0435, \u043F\u043E\u0442\u043E\u043C\u0443 \u0447\u0442\u043E \u0443 \u043D\u0430\u0441 \u0441\u0438\u043B\u044C\u043D\u0430\u044F \u043A\u043E\u043C\u0430\u043D\u0434\u0430 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u043E\u043D\u0430\u043B\u043E\u0432!\u041D\u0430\u0448\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438 - \u0441\u0430\u043C\u0430\u044F \u0431\u043E\u043B\u044C\u0448\u0430\u044F \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438. \u041C\u044B \u043F\u0440\u0435\u0434\u043B\u0430\u0433\u0430\u0435\u043C \u0441\u0442\u0430\u0431\u0438\u043B\u044C\u043D\u0443\u044E \u0440\u0430\u0431\u043E\u0442\u0443 \u0438 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u043C \u0432\u0441\u0435 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0438, \u0447\u0442\u043E\u0431\u044B \u0432\u043C\u0435\u0441\u0442\u0435 \u0440\u0430\u0437\u0432\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u0438 \u0434\u0432\u0438\u0433\u0430\u0442\u044C\u0441\u044F \u0432\u043F\u0435\u0440\u0451\u0434. </p></div><div class="favorites-card-footer"><div class="favorites-card-footer-row telephones-row"><ul><li><a class="tel" href="tel: +7 800 550 11 00"><img${ssrRenderAttr("src", _imports_1$1)} alt="#">+7 800 550 11 00 </a></li><li><a class="tel" href="tel: +7 800 550 11 00"><img${ssrRenderAttr("src", _imports_1$1)} alt="#">+7 800 550 11 00 </a></li><li><a class="tel" href="tel: +7 800 550 11 00"><img${ssrRenderAttr("src", _imports_2)} alt="#">+7 800 550 11 00 </a></li></ul></div><div class="favorites-card-footer-row"><div class="group"><button class="group-action btn button-md">\u041E\u0442\u043A\u043B\u0438\u043A\u043D\u0443\u0442\u044C\u0441\u044F</button></div><div class="group"><button class="${ssrRenderClass([{ active: unref(isFavoured) }, "group-action ic-btn fav-btn"])}"><svg width="23" height="21" viewBox="0 0 23 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.0641 0.796788C11.2552 0.45665 11.7448 0.456649 11.9359 0.796789L14.7993 5.89364C15.0135 6.27499 15.3835 6.54383 15.8124 6.62973L21.5446 7.77794C21.9272 7.85457 22.0785 8.32027 21.8141 8.60711L17.8515 12.9053C17.555 13.2269 17.4137 13.6619 17.4645 14.0964L18.1439 19.9029C18.1892 20.2903 17.793 20.5782 17.4385 20.4153L12.1262 17.9749C11.7287 17.7923 11.2713 17.7923 10.8738 17.9749L5.56148 20.4153C5.20696 20.5782 4.81081 20.2903 4.85614 19.9029L5.53549 14.0964C5.58632 13.6619 5.44498 13.2269 5.1485 12.9053L1.18593 8.60711C0.921493 8.32027 1.07281 7.85457 1.45535 7.77794L7.18757 6.62973C7.61645 6.54383 7.98648 6.27499 8.20072 5.89364L11.0641 0.796788Z" stroke="#C8C8C8"></path></svg></button></div></div></div></div></li>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Single/LikeItem.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$1;
const _sfc_main = {
  __name: "LikeList",
  __ssrInlineRender: true,
  setup(__props) {
    const { slug } = route.params;
    console.log(slug);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesSingleLikeItem = __nuxt_component_0;
      _push(`<ul${ssrRenderAttrs(mergeProps({ class: "favorites-list" }, _attrs))}><!--[-->`);
      ssrRenderList(2, (i) => {
        _push(ssrRenderComponent(_component_VacanciesSingleLikeItem, {
          key: i,
          id: i
        }, null, _parent));
      });
      _push(`<!--]--></ul>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Single/LikeList.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_0$1 as _, __nuxt_component_2 as a };
//# sourceMappingURL=LikeList-D7jOt6wI.mjs.map
