import { C as CustomSelect } from './search-CNCM2ROA.mjs';
import { useSSRContext, ref, reactive, computed, watch, unref } from 'vue';
import { u as useYearOptions } from './useYearOptions--VQWJCm5.mjs';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import moment from 'moment';
import { useField } from 'vee-validate';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

function useMonthOptions() {
  const items = [
    {
      name: "\u044F\u043D\u0432\u0430\u0440\u044C",
      value: "01"
    },
    {
      name: "\u0444\u0435\u0432\u0440\u0430\u043B\u044C",
      value: "02"
    },
    {
      name: "\u043C\u0430\u0440\u0442",
      value: "03"
    },
    {
      name: "\u0430\u043F\u0440\u0435\u043B\u044C",
      value: "04"
    },
    {
      name: "\u043C\u0430\u0439",
      value: "05"
    },
    {
      name: "\u0438\u044E\u043D\u044C",
      value: "06"
    },
    {
      name: "\u0438\u044E\u043B\u044C",
      value: "07"
    },
    {
      name: "\u0430\u0432\u0433\u0443\u0441\u0442",
      value: "08"
    },
    {
      name: "\u0441\u0435\u043D\u0442\u044F\u0431\u0440\u044C",
      value: "09"
    },
    {
      name: "\u043E\u043A\u0442\u044F\u0431\u0440\u044C",
      value: "10"
    },
    {
      name: "\u043D\u043E\u044F\u0431\u0440\u044C",
      value: "11"
    },
    {
      name: "\u0434\u0435\u043A\u0430\u0431\u0440\u044C",
      value: "12"
    }
  ];
  return items;
}
const __default__ = {
  name: "BirthDatePicker"
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    name: String,
    label: String,
    max: {
      default: 2009
    }
  },
  emits: {
    "update:modelValue": {
      required: true
    }
  },
  setup(__props, { emit: __emit }) {
    const props = __props;
    const { value, errorMessage } = useField(() => props.name);
    ref([]);
    const date = reactive({
      year: null,
      month: null,
      day: null
    });
    const isFirst = ref(true);
    const update = (newDate) => {
      value.value = getModelValue(newDate);
    };
    const getModelValue = (newDate = null) => {
      if (newDate) {
        date.month = newDate.month;
        date.year = newDate.year;
        date.day = newDate.day;
      }
      const monthString = String(parseInt(date.month));
      const dayString = String(parseInt(date.day));
      return moment(
        `${date.year}-${monthString.padStart(2, "0")}-${dayString.padStart(
          2,
          "0"
        )}`,
        "YYYY-MM-DD"
      ).format("YYYY-MM-DD");
    };
    const maxDate = computed(() => {
      if ([1, 2, 4, 6, 7, 9, 11].includes(date.month)) {
        return 31;
      } else if ([3, 5, 8, 10].includes(date.month)) {
        return 30;
      }
      return 28;
    });
    const yearItems = computed(() => {
      return useYearOptions(1950, (/* @__PURE__ */ new Date()).getUTCFullYear() - 16);
    });
    const monthItems = useMonthOptions();
    const dayItems = computed(() => {
      const items = Array.from({ length: maxDate.value }, (value2, index) => {
        return { name: index + 1, value: index + 1 };
      });
      return items;
    });
    watch(
      () => value.value,
      (newDate) => {
        if (isFirst.value && newDate) {
          const d = moment(newDate, "YYYY-MM-DD");
          const year = d.format("YYYY");
          const month = d.format("MM");
          const day = parseInt(d.format("DD"));
          if (newDate) {
            date.month = month;
            date.year = year;
            date.day = day;
          }
          isFirst.value = false;
        }
      }
    );
    watch(
      () => ({ ...date }),
      (newDate) => {
        update(newDate);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CustomSelect = CustomSelect;
      _push(`<!--[--><div class="c3 w-100" data-v-0bf11983>`);
      _push(ssrRenderComponent(_component_CustomSelect, {
        label: "\u0413\u043E\u0434",
        options: unref(yearItems),
        modelValue: unref(date).year,
        "onUpdate:modelValue": ($event) => unref(date).year = $event
      }, null, _parent));
      _push(ssrRenderComponent(_component_CustomSelect, {
        label: "\u041C\u0435\u0441\u044F\u0446",
        options: unref(monthItems),
        modelValue: unref(date).month,
        "onUpdate:modelValue": ($event) => unref(date).month = $event
      }, null, _parent));
      _push(ssrRenderComponent(_component_CustomSelect, {
        label: "\u0414\u0435\u043D\u044C",
        options: unref(dayItems),
        modelValue: unref(date).day,
        "onUpdate:modelValue": ($event) => unref(date).day = $event
      }, null, _parent));
      _push(`</div>`);
      if (unref(errorMessage)) {
        _push(`<div class="text-danger d-block" data-v-0bf11983>${ssrInterpolate(unref(errorMessage))}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/VeeBirthDatePicker.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-0bf11983"]]);

export { __nuxt_component_2 as _, useMonthOptions as u };
//# sourceMappingURL=VeeBirthDatePicker-7XRn76OG.mjs.map
