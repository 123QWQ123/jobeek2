import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + buildAssetsURL("crown2.C009jjv_.svg");

export { _imports_0 as _ };
//# sourceMappingURL=crown2-yZ91oAVe.mjs.map
