import __nuxt_component_2$1 from './VeeCustomSelect-BxrAvA7-.mjs';
import { useSSRContext, toRefs, ref, watch, reactive, computed, unref, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import { useField, useFieldArray } from 'vee-validate';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { u as useProviderFields } from './useProviderFields-B2EuWWWy.mjs';
import { u as useProviders } from './useProviders-Ck9yopDY.mjs';
import { _ as __nuxt_component_0$1 } from './VuePhoneInput-C5R34atv.mjs';
import { r as useResumeStore } from '../server.mjs';
import { u as useResumeHooks } from './useResumeHooks-BM2nRo7f.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { R as ResumeCheckboxInput } from './ResumeCheckboxInput-DBsB0Z0m.mjs';

function useHourOptions() {
  const items = [];
  for (let i = 0; i <= 23; i++) {
    items.push({ name: `${i}`.padStart(2, "0") + ":00", value: `${i}`.padStart(2, "0") + ":00" });
  }
  return items;
}
const __default__$1 = {
  name: "PhoneInputWithCaptchaAndConfirmation"
};
const _sfc_main$3 = /* @__PURE__ */ Object.assign(__default__$1, {
  __ssrInlineRender: true,
  props: {
    name: {
      required: true,
      default: "phone"
    },
    required: {
      required: false,
      default: true
    }
  },
  emits: ["remove"],
  setup(__props, { emit: __emit }) {
    var _a;
    const props = __props;
    toRefs(props);
    const { value, setValue, errorMessage } = useField(() => props.name);
    const resumeStore = useResumeStore();
    const { getPhoneConfirmationCode, confirmPhoneConfirmationCode, getPhoneInfo } = resumeStore;
    const errors = ref({});
    watch(
      () => props.errors,
      (newErrors) => {
        errors.value = newErrors;
      }
    );
    const isPhoneChanged = ref(false);
    const isConfirmationButtonShown = ref(false);
    const isConfirmationCodeButtonShown = ref(false);
    const isConfirmationCodeInputShown = ref(false);
    const isConfirmationButtonClicked = ref(false);
    const isCaptchaUrlShown = ref(false);
    const isPhoneConfirmed = ref(true);
    const isPhoneChecking = ref(false);
    ref(null);
    ref();
    const seconds = ref(0);
    const phoneMessage = ref(null);
    const confirmationCodeMessage = ref(null);
    const phoneElement = ref();
    const phone = reactive({
      val: (_a = value.value) != null ? _a : "",
      disabled: false,
      country_code: "RU"
    });
    const confirmation_code = reactive({
      val: null
    });
    const onChangeCountryCode = async (newCountryCode) => {
      if (typeof newCountryCode === "string") {
        phone.val.country_code = newCountryCode;
      }
    };
    const onStartEditing = () => {
      isConfirmationButtonClicked.value = false;
      phone.disabled = false;
      isCaptchaUrlShown.value = false;
      isConfirmationButtonShown.value = false;
      phoneMessage.value = null;
      phoneElement.value.focus();
    };
    const onPhoneChange = async (e) => {
      isPhoneChecking.value = true;
      const phoneInput = phone.val.replace("+", "");
      if (props.required) {
        const phoneInfo = await getPhoneInfo({ phone: phoneInput });
        if (phoneInfo.status !== "success") {
          phoneMessage.value = phoneInfo.message;
          phone.disabled = true;
          isPhoneChecking.value = false;
          return;
        }
        const { phone: phoneObject } = phoneInfo.data.hh;
        if (!phoneObject) {
          isPhoneChecking.value = false;
          value.value = phoneInput;
          return;
        }
        if (!phoneObject.need_verification) {
          isPhoneChecking.value = false;
          phoneMessage.value = null;
          value.value = phoneInput;
          return;
        }
        const country_code = phone.country_code;
        if (["UZ", "RU", "KZ", "BY"].includes(country_code)) {
          phone.disabled = true;
          isPhoneChanged.value = true;
          isConfirmationButtonShown.value = true;
          isPhoneConfirmed.value = false;
          isPhoneChecking.value = false;
          return;
        }
      }
      setValue(phoneInput);
      isPhoneChecking.value = false;
    };
    const { convertSecondsToHoursAndMinutes } = useResumeHooks();
    const formattedLeftTime = computed(() => {
      if (seconds.value < 60) {
        return seconds.value + " c";
      }
      return convertSecondsToHoursAndMinutes(seconds.value) + " c";
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VuePhoneInput = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-9b5c4f9f><div class="input-wrapper mt-2" data-v-9b5c4f9f><div class="position-relative" data-v-9b5c4f9f><span class="position-absolute absoluted_icon right-0 top-2" data-v-9b5c4f9f><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" data-v-9b5c4f9f><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-9b5c4f9f></path></svg></span>`);
      if (unref(isPhoneConfirmed)) {
        _push(`<span class="h-100 fs-6 position-absolute end-0 top-0 p-0 px-0 mt-0 me-5 pb-2" data-v-9b5c4f9f><svg xmlns="http://www.w3.org/2000/svg" style="${ssrRenderStyle({ "transform": "scale(0.5)" })}" viewBox="0 0 48 48" width="48px" height="48px" data-v-9b5c4f9f><path fill="green" d="M40.6 12.1L17 35.7 7.4 26.1 4.6 29 17 41.3 43.4 14.9z" data-v-9b5c4f9f></path></svg></span>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_VuePhoneInput, {
        ref_key: "phoneElement",
        ref: phoneElement,
        modelValue: unref(phone).val,
        "onUpdate:modelValue": ($event) => unref(phone).val = $event,
        onFocusout: onPhoneChange,
        onFocus: onStartEditing,
        onChangeCountryCode,
        disabled: unref(phone).disabled
      }, null, _parent));
      _push(`</div>`);
      if (unref(isCaptchaUrlShown)) {
        _push(`<div class="captcha_url mt-2" data-v-9b5c4f9f><p class="alert alert-info" data-v-9b5c4f9f> \u041F\u0440\u043E\u0439\u0434\u0438\u0442\u0435 \u043A\u0430\u043F\u0447\u0443 \u043F\u043E\u0442\u043E\u043C \u043E\u0431\u0440\u0430\u0442\u043D\u043E \u0432\u0435\u0440\u043D\u0438\u0442\u0435\u0441\u044C, \u043A \u0442\u0435\u043A\u0443\u0449\u0435\u043C\u0443 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044E. </p><button class="btn btn-primary" data-v-9b5c4f9f> \u0420\u0435\u0448\u0438\u0442\u044C \u043A\u0430\u043F\u0447\u0443 </button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="mt-2 c2 align-items-start" data-v-9b5c4f9f>`);
      if (unref(isConfirmationCodeInputShown)) {
        _push(`<div class="input-wrapper" data-v-9b5c4f9f><input type="text" placeholder="\u041A\u043E\u0434 \u043F\u043E\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F"${ssrRenderAttr("value", unref(confirmation_code).val)} data-v-9b5c4f9f>`);
        if (unref(confirmationCodeMessage)) {
          _push(`<div class="text-danger d-block" data-v-9b5c4f9f>${ssrInterpolate(unref(confirmationCodeMessage))}</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="input-wrapper p-0" data-v-9b5c4f9f>`);
      if (unref(isConfirmationButtonShown)) {
        _push(`<button type="button" class="btn btn-outline-primary mt-1" data-v-9b5c4f9f> \u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043A\u043E\u0434 </button>`);
      } else if (unref(isConfirmationCodeButtonShown)) {
        _push(`<button type="button" class="btn btn-outline-primary" data-v-9b5c4f9f> \u041F\u043E\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u0442\u0435\u043B\u0435\u0444\u043E\u043D </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (unref(isPhoneChecking)) {
        _push(`<div class="spinner-border text-primary mt-1" role="status" data-v-9b5c4f9f><span class="visually-hidden" data-v-9b5c4f9f>Loading...</span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="text-danger d-block" data-v-9b5c4f9f>${ssrInterpolate(unref(phoneMessage))}</div><div class="text-danger d-block" data-v-9b5c4f9f>${ssrInterpolate(unref(errorMessage))}</div><br data-v-9b5c4f9f>`);
      if (unref(seconds)) {
        _push(`<div class="alert alert-info" data-v-9b5c4f9f> \u041D\u0430 \u0442\u0435\u043B\u0435\u0444\u043E\u043D \u0432\u044B\u0441\u043B\u0430\u043D \u043A\u043E\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F. \u0412\u044B\u0441\u043B\u0430\u0442\u044C \u043A\u043E\u0434 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E \u043C\u043E\u0436\u043D\u043E \u0447\u0435\u0440\u0435\u0437 ${ssrInterpolate(unref(formattedLeftTime))}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeePhoneFields/PhoneInputWithConfirmationAndCaptcha.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const PhoneInputWithCaptchaAndConfirmation = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-9b5c4f9f"]]);
const __default__ = {
  name: "ResumeTextarea"
};
const _sfc_main$2 = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    name: String,
    placeholder: String
  },
  setup(__props) {
    const props = __props;
    const { value, errorMessage } = useField(() => props.name);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><textarea class="form-control"${ssrRenderAttr("placeholder", props.placeholder)}>${ssrInterpolate(unref(value))}</textarea>`);
      if (unref(errorMessage)) {
        _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/ResumeTextarea.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const ResumeTextarea = _sfc_main$2;
const _sfc_main$1 = {
  __name: "VeeItem",
  __ssrInlineRender: true,
  props: ["idx", "name"],
  emits: ["remove"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const { idx, name } = toRefs(props);
    useField(
      () => props.name + "[" + props.idx + "].phone"
    );
    const dictionaryStore = useDictionaryStore();
    const preferredContactTypeOptions = computed(() => {
      return dictionaryStore.preferred_contact_types.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const { providers } = useProviders();
    const state = reactive({
      type_id: {
        is_hidden: false
      },
      phone: {
        is_hidden: false
      },
      is_preferred: {
        is_hidden: false
      },
      start_available_time_phone: {
        is_hidden: false
      },
      end_available_time_phone: {
        is_hidden: false
      },
      comment: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        type_id: true,
        phone: true,
        comment: false,
        is_preferred: false,
        start_available_time_phone: null,
        end_available_time_phone: null
      },
      superjob: {
        type_id: null,
        phone: true,
        comment: null,
        is_preferred: null,
        start_available_time_phone: false,
        end_available_time_phone: false
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    watch(
      () => providers.value,
      () => {
        walkThroughFields(providers.value);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeCustomSelect = __nuxt_component_2$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row position-relative" }, _attrs))} data-v-600cc5bf><div data-v-600cc5bf><span class="position-absolute absoluted_icon" data-v-600cc5bf><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" data-v-600cc5bf><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-600cc5bf></path></svg></span></div><div class="input-wrapper mt-2" style="${ssrRenderStyle(!unref(state).type_id.is_hidden ? null : { display: "none" })}" data-v-600cc5bf>`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        options: unref(preferredContactTypeOptions),
        name: `${unref(name)}[${unref(idx)}].type_id`,
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(PhoneInputWithCaptchaAndConfirmation, {
        style: !unref(state).phone.is_hidden ? null : { display: "none" },
        name: `${props.name}[${unref(idx)}].phone`,
        required: unref(providers).hh
      }, null, _parent));
      _push(`<div class="row" style="${ssrRenderStyle(!unref(state).is_preferred.is_hidden ? null : { display: "none" })}" data-v-600cc5bf>`);
      _push(ssrRenderComponent(ResumeCheckboxInput, {
        name: `${props.name}[${unref(idx)}].is_preferred`,
        label: "\u043F\u0440\u0435\u0434\u043F\u043E\u0447\u0442\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u043C \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F"
      }, null, _parent));
      _push(`</div>`);
      if (!unref(state).end_available_time_phone.is_hidden && !unref(state).start_available_time_phone.is_hidden) {
        _push(`<div class="input-row mt-2" data-v-600cc5bf><label data-v-600cc5bf>\u041E\u0442\u0432\u0435\u0447\u0443 \u043D\u0430 \u0437\u0432\u043E\u043D\u043A\u0438</label><div class="start-to-end" data-v-600cc5bf><div class="hour_c2" style="${ssrRenderStyle(!unref(state).start_available_time_phone.is_hidden ? null : { display: "none" })}" data-v-600cc5bf>`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: ("useHourOptions" in _ctx ? _ctx.useHourOptions : unref(useHourOptions))(),
          name: `${props.name}[${unref(idx)}].start_available_time_phone`,
          label: "\u041E\u0442"
        }, null, _parent));
        _push(`</div><div class="hour_c2" style="${ssrRenderStyle(!unref(state).end_available_time_phone.is_hidden ? null : { display: "none" })}" data-v-600cc5bf>`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: ("useHourOptions" in _ctx ? _ctx.useHourOptions : unref(useHourOptions))(),
          name: `${props.name}[${unref(idx)}].end_available_time_phone`,
          label: "\u0414\u043E"
        }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="input-wrapper mt-2" style="${ssrRenderStyle(!unref(state).comment.is_hidden ? null : { display: "none" })}" data-v-600cc5bf>`);
      _push(ssrRenderComponent(ResumeTextarea, {
        name: `${props.name}[${unref(idx)}].comment`
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeePhoneFields/VeeItem.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-600cc5bf"]]);
const _sfc_main = {
  __name: "Form",
  __ssrInlineRender: true,
  props: ["name", "providers"],
  setup(__props) {
    const props = __props;
    const { push, fields, remove } = useFieldArray(() => props.name);
    useDictionaryStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeVeePhoneFieldsVeeItem = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))}><label>\u0422\u0435\u043B\u0435\u0444\u043E\u043D\u044B</label><div class="input-wrapper mt-2"><div class="phone_network_form"><!--[-->`);
      ssrRenderList(unref(fields), (field, idx) => {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_CreateResumeVeePhoneFieldsVeeItem, {
          onRemove: unref(remove),
          name: props.name,
          providers: props.providers,
          idx
        }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]-->`);
      if (unref(fields).length === 0) {
        _push(`<button type="button" class="btn btn-primary btn-sm mt-1"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(fields).length > 0) {
        _push(`<button type="button" class="btn btn-primary mt-1 btn-sm"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435 </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeePhoneFields/Form.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { ResumeTextarea as R, __nuxt_component_2 as _ };
//# sourceMappingURL=Form-Bl6z4ElR.mjs.map
