import { V as VeeSelectWithSearch_vue_vue_type_style_index_1_scoped_e66e6be6_lang } from './VeeSelectWithSearch-styles-2.mjs-BWLY_ldn.mjs';

const VeeSelectWithSearchStyles_ChA168Eb = [VeeSelectWithSearch_vue_vue_type_style_index_1_scoped_e66e6be6_lang];

export { VeeSelectWithSearchStyles_ChA168Eb as default };
//# sourceMappingURL=VeeSelectWithSearch-styles.ChA168Eb.mjs.map
