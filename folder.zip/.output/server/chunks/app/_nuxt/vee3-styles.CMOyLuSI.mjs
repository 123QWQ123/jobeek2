const vee3_vue_vue_type_style_index_0_lang = "#app{font-family:Arial,Helvetica,sans-serif;max-width:500px}form{border:1px solid #000;padding:20px}form+form{margin-top:20px}";

const vee3Styles_CMOyLuSI = [vee3_vue_vue_type_style_index_0_lang];

export { vee3Styles_CMOyLuSI as default };
//# sourceMappingURL=vee3-styles.CMOyLuSI.mjs.map
