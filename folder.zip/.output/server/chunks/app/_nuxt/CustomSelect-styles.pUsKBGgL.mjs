const CustomSelect_vue_vue_type_style_index_0_scoped_765ad150_lang = ".current[data-v-765ad150]{color:#0a2540}.d-select[data-v-765ad150]{padding-right:3.125rem;width:auto}";

const CustomSelectStyles_pUsKBGgL = [CustomSelect_vue_vue_type_style_index_0_scoped_765ad150_lang];

export { CustomSelectStyles_pUsKBGgL as default };
//# sourceMappingURL=CustomSelect-styles.pUsKBGgL.mjs.map
