const VeeBillingTypeCard_vue_vue_type_style_index_0_lang = "";

const VeeBillingTypeCardStyles_BrfGOBZE = [VeeBillingTypeCard_vue_vue_type_style_index_0_lang];

export { VeeBillingTypeCardStyles_BrfGOBZE as default };
//# sourceMappingURL=VeeBillingTypeCard-styles.BrfGOBZE.mjs.map
