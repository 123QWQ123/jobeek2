const _category__vue_vue_type_style_index_0_lang = ".router-link-active{color:var(--bs-link-hover-color)!important}";

const _category_Styles_DuX_IWO = [_category__vue_vue_type_style_index_0_lang];

export { _category_Styles_DuX_IWO as default };
//# sourceMappingURL=_category_-styles.DuX_IW-O.mjs.map
