import { ref, watchEffect, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const _sfc_main = {
  __name: "InputWrapper",
  __ssrInlineRender: true,
  props: {
    isNew: {
      required: false,
      default: true
    },
    skill: {
      required: true
    },
    id: {
      required: true
    }
  },
  emits: ["add", "delete", "update"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const isNew = ref(props.isNew);
    const skill = ref(props.skill);
    watchEffect(() => {
      skill.value = props.skill;
      isNew.value = props.isNew;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "col-lg-12 col-xs-12" }, _attrs))} data-v-26f8214a><div class="input-wrapper" data-v-26f8214a><input type="text"${ssrRenderAttr("value", unref(skill))} placeholder="\u0412\u0432\u0435\u0434\u0438\u0442\u0435" data-v-26f8214a>`);
      if (props.isNew) {
        _push(`<button class="btn btn-primary mt-2" type="button" data-v-26f8214a> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button>`);
      } else {
        _push(`<button class="btn btn-primary mt-2" type="button" data-v-26f8214a> \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C </button>`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/KnowledgeAndSkills/InputWrapper.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const InputWrapper = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-26f8214a"]]);

export { InputWrapper as default };
//# sourceMappingURL=InputWrapper-DzB22z5L.mjs.map
