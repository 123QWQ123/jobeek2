const History_vue_vue_type_style_index_0_scoped_83d38e7d_lang = ".education_item[data-v-83d38e7d]{margin-bottom:2.5rem}";

const HistoryStyles_pm4L7e9t = [History_vue_vue_type_style_index_0_scoped_83d38e7d_lang];

export { HistoryStyles_pm4L7e9t as default };
//# sourceMappingURL=History-styles.pm4L7e9t.mjs.map
