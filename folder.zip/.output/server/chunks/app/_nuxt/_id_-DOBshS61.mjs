import { _ as __nuxt_component_0$7 } from './SearchMobile-WfXJ1gHL.mjs';
import { _ as __nuxt_component_0$6 } from './BlockLoader-RiL0eLJn.mjs';
import { e as useRoute, r as useResumeStore, p as useRequestURL, u as useHead, m as useProfileStore, l as useVacancyStore, b as useRuntimeConfig } from '../server.mjs';
import { defineAsyncComponent, useSSRContext, computed, withAsyncContext, ref, watch, mergeProps, unref, toRefs, reactive, isRef, resolveDirective } from 'vue';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderStyle, ssrGetDirectiveProps } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1, b as _imports_2 } from './sb-_CyfLtbf.mjs';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { u as useFormData } from './useFormData-CRA6LhaU.mjs';
import { u as useFormValidation } from './useFormValidation-BMv_R6aU.mjs';
import { u as useWatchStateValues } from './useWatchStateValues-DimKH74z.mjs';
import { u as useDiff } from './useDiff-Chx28f43.mjs';
import { _ as __nuxt_component_2$2 } from './VeeBirthDatePicker-7XRn76OG.mjs';
import { _ as __nuxt_component_0$8 } from './VeeSelectWithSearch-CuZCClCB.mjs';
import __nuxt_component_2$1 from './VeeCustomSelect-BxrAvA7-.mjs';
import { _ as __nuxt_component_1$1 } from './VeeMultiSelectWithSearch-Btd5b5Va.mjs';
import { useField, useFieldArray, Field, useForm, ErrorMessage } from 'vee-validate';
import { R as ResumeTextarea, _ as __nuxt_component_2$3 } from './Form-Bl6z4ElR.mjs';
import { u as useProviderFields } from './useProviderFields-B2EuWWWy.mjs';
import { u as useResumeHooks } from './useResumeHooks-BM2nRo7f.mjs';
import { R as ResumeTextInput } from './ResumeTextInput-BxTsuw7y.mjs';
import { R as ResumeCheckboxInput } from './ResumeCheckboxInput-DBsB0Z0m.mjs';
import { useI18n } from 'vue-i18n';
import { toTypedSchema } from '@vee-validate/zod';
import { u as useProviders } from './useProviders-Ck9yopDY.mjs';
import { zodToJsonSchema } from 'zod-to-json-schema';
import { z } from 'zod';
import { u as useFilter } from './useFilter-BmdPUTpE.mjs';
import { u as useCurrencyOptions } from './useCurrencyOptions-BsifIVKS.mjs';
import { _ as __nuxt_component_0$2$1, a as __nuxt_component_0$1$1, b as __nuxt_component_0$9 } from './VeeForm-DN2tnu-9.mjs';
import { u as useYearOptions } from './useYearOptions--VQWJCm5.mjs';
import { u as useAlert } from './useAlert-CPK6c05f.mjs';
import './search-CNCM2ROA.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import './useSort-Dy_x39w5.mjs';
import './VuePhoneInput-C5R34atv.mjs';
import './check-BGWLIG1L.mjs';

const _sfc_main$k = {
  __name: "Providers",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: false,
      default: {}
    }
  },
  emits: ["update:modelValue"],
  async setup(__props, { emit: __emit }) {
    var _a;
    let __temp, __restore;
    const emit = __emit;
    const props = __props;
    useDictionaryStore();
    const route = useRoute();
    computed(() => route.params.id);
    const resumeStore = useResumeStore();
    const {
      getConnectedSeekerProviders,
      getSeekerProvidersAuthEndpoints,
      getMyResume
    } = resumeStore;
    [__temp, __restore] = withAsyncContext(() => getConnectedSeekerProviders()), await __temp, __restore();
    const enabledProviders = ref(resumeStore.providers);
    const isHHEnabled = computed(() => enabledProviders.value.hh);
    const isSuperjobEnabled = computed(() => enabledProviders.value.superjob);
    const resetObject = {
      superjob: false,
      hh: false
    };
    const resumeProviders = computed(() => {
      let selectedProvidersValue = [];
      if (!resumeStore.my_resume) {
        return resetObject;
      }
      const providersNewValues = { ...resetObject };
      if (!resumeStore.my_resume.hasOwnProperty("providers")) {
        return providersNewValues;
      }
      if (resumeStore.my_resume.providers.length > 0) {
        selectedProvidersValue = resumeStore.my_resume.providers.map(
          (item) => item.name
        );
      }
      if (selectedProvidersValue.includes("hh")) {
        providersNewValues.hh = true;
      } else {
        providersNewValues.superjob = false;
      }
      if (selectedProvidersValue.includes("superjob")) {
        providersNewValues.superjob = true;
      } else {
        providersNewValues.superjob = false;
      }
      return providersNewValues;
    });
    watch(
      () => resumeProviders.value,
      (newValue) => {
        selectedProviders.value = newValue;
      }
    );
    const selectedProviders = ref((_a = props.modelValue) != null ? _a : resetObject);
    watch(
      () => selectedProviders.value,
      (newSelectedItems) => {
        emit("update:modelValue", newSelectedItems);
      }
    );
    computed(() => props.errors);
    const isHHSelected = computed(() => selectedProviders.value.hh);
    const isSuperjobSelected = computed(() => selectedProviders.value.superjob);
    const isHHLoading = ref(false);
    const isSuperjobLoading = ref(false);
    useRequestURL();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BlockLoader = __nuxt_component_0$6;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "carryover-box" }, _attrs))} data-v-d45aaadf><div class="carryover-box-label" data-v-d45aaadf> \u0415\u0441\u0442\u044C \u0440\u0435\u0437\u044E\u043C\u0435 \u043D\u0430 HH \u0438\u043B\u0438 SuperJob? \u041F\u0440\u043E\u0441\u0442\u043E \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0438\u0442\u0435 \u0435\u0433\u043E. </div><div class="import-grid" data-v-d45aaadf><div class="${ssrRenderClass([{
        "import-is-complete": unref(isHHSelected),
        disabled: !unref(isHHEnabled),
        "is-connected": unref(isHHEnabled),
        "is-loading": unref(isHHLoading)
      }, "import-box"])}" data-v-d45aaadf>`);
      if (unref(isHHLoading)) {
        _push(ssrRenderComponent(_component_BlockLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="import-box-dvnld" data-v-d45aaadf><div class="logo" data-v-d45aaadf><img${ssrRenderAttr("src", _imports_0)} alt="#" data-v-d45aaadf><div class="check" data-v-d45aaadf><img${ssrRenderAttr("src", _imports_1)} alt="#" data-v-d45aaadf></div></div><span data-v-d45aaadf>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 HeadHunters.ru</span></div><div class="import-complete" data-v-d45aaadf><div class="logo logo-fake" data-v-d45aaadf></div><span data-v-d45aaadf>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 HeadHunters.ru</span><button class="close" type="button" data-v-d45aaadf><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-d45aaadf><path d="M18.9951 4.99512L5.00586 18.9843" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-d45aaadf></path><path d="M19.0009 18.9928L5 4.98901" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-d45aaadf></path></svg></button></div></div><div class="${ssrRenderClass([{
        "import-is-complete": unref(isSuperjobSelected),
        disabled: !unref(isSuperjobEnabled),
        "is-connected": unref(isSuperjobEnabled),
        "is-loading": unref(isSuperjobLoading)
      }, "import-box"])}" data-v-d45aaadf>`);
      if (unref(isSuperjobLoading)) {
        _push(ssrRenderComponent(_component_BlockLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="import-box-dvnld" data-v-d45aaadf><div class="logo" data-v-d45aaadf><img${ssrRenderAttr("src", _imports_2)} alt="#" data-v-d45aaadf><div class="check" data-v-d45aaadf><img${ssrRenderAttr("src", _imports_1)} alt="#" data-v-d45aaadf></div></div><span data-v-d45aaadf>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 Superjob.ru </span></div><div class="import-complete" data-v-d45aaadf><div class="logo logo-fake" data-v-d45aaadf></div><span data-v-d45aaadf>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 Superjob.ru</span><button class="close" type="button" data-v-d45aaadf><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-d45aaadf><path d="M18.9951 4.99512L5.00586 18.9843" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-d45aaadf></path><path d="M19.0009 18.9928L5 4.98901" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-d45aaadf></path></svg></button></div></div></div></div>`);
    };
  }
};
const _sfc_setup$k = _sfc_main$k.setup;
_sfc_main$k.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/Providers.vue");
  return _sfc_setup$k ? _sfc_setup$k(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$k, [["__scopeId", "data-v-d45aaadf"]]);
const _sfc_main$j = {
  __name: "PhotoInput",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: false,
      default: null
    },
    errors: {
      required: true,
      default: {}
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    computed(() => props.errors);
    useDictionaryStore();
    const route = useRoute();
    computed(() => route.params.id);
    useResumeStore();
    const profileStore = useProfileStore();
    const my_artifact = ref(null);
    watch(
      () => profileStore.my_resume_photo_artifact,
      () => {
        var _a;
        my_artifact.value = (_a = profileStore.my_resume_photo_artifact) != null ? _a : null;
      }
    );
    const state = reactive({
      photo: {
        val: "",
        isValid: true,
        base64: ""
      }
    });
    const CONFIG = useRuntimeConfig();
    const photoUrl = computed(() => {
      if (state.photo.base64) {
        return state.photo.base64;
      } else if (my_artifact.value) {
        return my_artifact.value.url;
      } else {
        return CONFIG.public.base + "/assets/images/avatar.png";
      }
    });
    ref();
    const isLoading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BlockLoader = __nuxt_component_0$6;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "photo position-relative" }, _attrs))}>`);
      if (unref(isLoading)) {
        _push(ssrRenderComponent(_component_BlockLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<input type="file" name="photo"><img${ssrRenderAttr("src", unref(photoUrl))} alt="#"><div class="photo-actions"><button class="photo-action redact" type="button"><svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 24.5H24.5" stroke="#D2D2D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M14.2583 6.79933L20.0333 12.5743M14.2583 6.79933L17.5577 3.5L23.3327 9.275L20.0333 12.5743L14.2583 6.79933ZM14.2583 6.79933L7.71683 13.3408C7.49803 13.5596 7.37507 13.8563 7.375 14.1657V19.4577H12.667C12.9764 19.4576 13.2731 19.3346 13.4918 19.1158L20.0333 12.5743L14.2583 6.79933Z" stroke="#D2D2D2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></button><button class="photo-action delete" type="button"><svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14.0007 2.04175C14.9691 2.04168 15.901 2.41223 16.6049 3.07737C17.3089 3.7425 17.7317 4.65181 17.7865 5.61875L17.7923 5.83342H23.9173C24.139 5.83348 24.3524 5.9177 24.5144 6.06905C24.6764 6.2204 24.7749 6.4276 24.79 6.64878C24.8051 6.86995 24.7357 7.08862 24.5958 7.2606C24.4559 7.43257 24.2559 7.54503 24.0363 7.57525L23.9173 7.58342H22.9887L21.4953 22.7734C21.4205 23.5307 21.0789 24.2367 20.5316 24.7655C19.9843 25.2942 19.2669 25.6111 18.5075 25.6597L18.3022 25.6667H9.69915C8.93786 25.6667 8.20138 25.396 7.62132 24.9029C7.04127 24.4099 6.65546 23.7266 6.53282 22.9753L6.50598 22.7722L5.01148 7.58342H4.08398C3.87254 7.58341 3.66825 7.50683 3.5089 7.36785C3.34955 7.22887 3.24591 7.03689 3.21715 6.82742L3.20898 6.70842C3.20899 6.49697 3.28557 6.29268 3.42455 6.13333C3.56352 5.97398 3.75551 5.87034 3.96498 5.84158L4.08398 5.83342H10.209C10.209 4.8278 10.6085 3.86338 11.3195 3.1523C12.0306 2.44123 12.995 2.04175 14.0007 2.04175ZM21.2305 7.58342H6.76965L8.24782 22.6007C8.28055 22.9358 8.42821 23.2493 8.66575 23.4879C8.90328 23.7265 9.21605 23.8755 9.55098 23.9097L9.69915 23.9167H18.3022C19.0022 23.9167 19.596 23.4209 19.7313 22.7477L19.7547 22.6007L21.2293 7.58342H21.2305ZM16.0423 10.7917C16.2538 10.7918 16.4581 10.8683 16.6174 11.0073C16.7768 11.1463 16.8804 11.3383 16.9092 11.5477L16.9173 11.6667V19.8334C16.9173 20.0551 16.833 20.2685 16.6817 20.4305C16.5303 20.5925 16.3231 20.691 16.102 20.7061C15.8808 20.7212 15.6621 20.6518 15.4901 20.5119C15.3182 20.372 15.2057 20.172 15.1755 19.9524L15.1673 19.8334V11.6667C15.1673 11.4347 15.2595 11.2121 15.4236 11.048C15.5877 10.8839 15.8103 10.7917 16.0423 10.7917ZM11.959 10.7917C12.1704 10.7918 12.3747 10.8683 12.5341 11.0073C12.6934 11.1463 12.7971 11.3383 12.8258 11.5477L12.834 11.6667V19.8334C12.8339 20.0551 12.7497 20.2685 12.5983 20.4305C12.447 20.5925 12.2398 20.691 12.0186 20.7061C11.7974 20.7212 11.5788 20.6518 11.4068 20.5119C11.2348 20.372 11.1224 20.172 11.0922 19.9524L11.084 19.8334V11.6667C11.084 11.4347 11.1762 11.2121 11.3403 11.048C11.5044 10.8839 11.7269 10.7917 11.959 10.7917ZM14.0007 3.79175C13.4883 3.79177 12.9946 3.98445 12.6177 4.33154C12.2408 4.67864 12.0081 5.15476 11.966 5.66541L11.959 5.83342H16.0423C16.0423 5.29193 15.8272 4.77263 15.4443 4.38974C15.0614 4.00685 14.5421 3.79175 14.0007 3.79175Z" fill="#D2D2D2"></path></svg></button></div></div>`);
    };
  }
};
const _sfc_setup$j = _sfc_main$j.setup;
_sfc_main$j.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/PhotoInput.vue");
  return _sfc_setup$j ? _sfc_setup$j(props, ctx) : void 0;
};
const __nuxt_component_0$5 = _sfc_main$j;
const _sfc_main$i = {
  __name: "PhotoCard",
  __ssrInlineRender: true,
  props: ["title", "providers"],
  async setup(__props, { expose: __expose }) {
    var _a;
    let __temp, __restore;
    const props = __props;
    const resumeStore = useResumeStore();
    const profileStore = useProfileStore();
    const route = useRoute();
    const resumeID = computed(() => route.params.id);
    const { updateResume, getMyResume } = resumeStore;
    const { getArtifacts } = profileStore;
    [__temp, __restore] = withAsyncContext(() => getArtifacts({ type: 1 })), await __temp, __restore();
    const artifacts = computed(() => profileStore.artifacts);
    const isPhotosShown = ref(false);
    const toggleButtonText = computed(() => {
      if (isPhotosShown.value) {
        return "\u0421\u043A\u0440\u044B\u0442\u044C";
      } else {
        return "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0438\u0437 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u044B\u0445";
      }
    });
    const my_resume = computed(() => resumeStore.my_resume);
    const isSaved = ref(false);
    const isChanged = ref(false);
    const isFirst = ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    computed(() => props.providers);
    const isHidden = ref((_a = props.providers.hh) != null ? _a : false);
    watch(
      () => props.providers,
      (newProviders) => {
        isHidden.value = newProviders.hh;
      }
    );
    const state = reactive({
      photo_id: {
        val: null,
        isValid: true
      },
      isFormValid: true,
      isNew: true,
      isLoading: false,
      error: null,
      success: null
    });
    watch(
      () => useWatchStateValues(state, true, true),
      (newState, oldState) => {
        if (!isFirst.value) {
          isChanged.value = true;
        } else {
          isFirst.value = false;
        }
      }
    );
    const sectionData = ref({});
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          state.photo_id.val = newData.photo_id;
        }
      }
    );
    watch(
      () => resumeStore.my_resume,
      (newData) => {
        var _a2;
        if (isUpdated.value) {
          isUpdated.value = false;
          return;
        }
        if (newData) {
          sectionData.value = {
            photo_id: (_a2 = newData.photo) == null ? void 0 : _a2.id
          };
        }
      }
    );
    useDictionaryStore();
    const { errors, handleErrorResponse } = useFormValidation();
    const isFocused = ref(false);
    const save = async (is_from_parent = false) => {
      if (is_from_parent === true) {
        isFocused.value = true;
      }
      if (!isFocused.value) {
        return true;
      }
      if (isChanged.value) {
        state.isLoading = true;
        errors.value = {};
        state.errorMessage = "";
        let resData = {};
        const jsonData = useFormData(state);
        jsonData.form_data = "UPDATE_PHOTO_DATA";
        resData = await updateResume(resumeID.value, jsonData);
        isUpdated.value = true;
        if (resData.status !== "success") {
          return handleErrorResponse(resData.data);
        }
        isChanged.value = false;
        isSaved.value = false;
        isUpdated.value = false;
        isFocused.value = false;
        if (is_from_parent) {
          return new Promise((resolve, reject) => {
            resolve(true);
          });
        }
      } else {
        return true;
      }
    };
    const isCompleted = computed(() => {
      const newData = my_resume.value;
      if (newData && !isCollapsed.value) {
        return newData.type && newData.type.id;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumePhotoInput = __nuxt_component_0$5;
      const _directive_click_outside = resolveDirective("click-outside");
      if (unref(isHidden)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0424\u043E\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u0438</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
        if (unref(errors).message) {
          _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label for="photo">\u0424\u043E\u0442\u043E(${ssrInterpolate(unref(state).photo_id.val)})</label><div class="dwld-photo">`);
        _push(ssrRenderComponent(_component_CreateResumePhotoInput, {
          modelValue: unref(state).photo_id.val,
          "onUpdate:modelValue": ($event) => unref(state).photo_id.val = $event,
          errors: unref(errors)
        }, null, _parent));
        _push(`<div class="mt-4"><button class="btn btn-primary">${ssrInterpolate(unref(toggleButtonText))}</button>`);
        if (unref(isPhotosShown)) {
          _push(`<div class="row mt-2">`);
          if (unref(artifacts).length > 0) {
            _push(`<!--[-->`);
            ssrRenderList(unref(artifacts), (item) => {
              _push(`<div class="col-sm-4 mb-2 cursor-pointer"><div class="photo position-relative"><img${ssrRenderAttr("src", item.url)} alt="#"><div class="photo-actions"><button class="photo-action delete" type="button"><svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14.0007 2.04175C14.9691 2.04168 15.901 2.41223 16.6049 3.07737C17.3089 3.7425 17.7317 4.65181 17.7865 5.61875L17.7923 5.83342H23.9173C24.139 5.83348 24.3524 5.9177 24.5144 6.06905C24.6764 6.2204 24.7749 6.4276 24.79 6.64878C24.8051 6.86995 24.7357 7.08862 24.5958 7.2606C24.4559 7.43257 24.2559 7.54503 24.0363 7.57525L23.9173 7.58342H22.9887L21.4953 22.7734C21.4205 23.5307 21.0789 24.2367 20.5316 24.7655C19.9843 25.2942 19.2669 25.6111 18.5075 25.6597L18.3022 25.6667H9.69915C8.93786 25.6667 8.20138 25.396 7.62132 24.9029C7.04127 24.4099 6.65546 23.7266 6.53282 22.9753L6.50598 22.7722L5.01148 7.58342H4.08398C3.87254 7.58341 3.66825 7.50683 3.5089 7.36785C3.34955 7.22887 3.24591 7.03689 3.21715 6.82742L3.20898 6.70842C3.20899 6.49697 3.28557 6.29268 3.42455 6.13333C3.56352 5.97398 3.75551 5.87034 3.96498 5.84158L4.08398 5.83342H10.209C10.209 4.8278 10.6085 3.86338 11.3195 3.1523C12.0306 2.44123 12.995 2.04175 14.0007 2.04175ZM21.2305 7.58342H6.76965L8.24782 22.6007C8.28055 22.9358 8.42821 23.2493 8.66575 23.4879C8.90328 23.7265 9.21605 23.8755 9.55098 23.9097L9.69915 23.9167H18.3022C19.0022 23.9167 19.596 23.4209 19.7313 22.7477L19.7547 22.6007L21.2293 7.58342H21.2305ZM16.0423 10.7917C16.2538 10.7918 16.4581 10.8683 16.6174 11.0073C16.7768 11.1463 16.8804 11.3383 16.9092 11.5477L16.9173 11.6667V19.8334C16.9173 20.0551 16.833 20.2685 16.6817 20.4305C16.5303 20.5925 16.3231 20.691 16.102 20.7061C15.8808 20.7212 15.6621 20.6518 15.4901 20.5119C15.3182 20.372 15.2057 20.172 15.1755 19.9524L15.1673 19.8334V11.6667C15.1673 11.4347 15.2595 11.2121 15.4236 11.048C15.5877 10.8839 15.8103 10.7917 16.0423 10.7917ZM11.959 10.7917C12.1704 10.7918 12.3747 10.8683 12.5341 11.0073C12.6934 11.1463 12.7971 11.3383 12.8258 11.5477L12.834 11.6667V19.8334C12.8339 20.0551 12.7497 20.2685 12.5983 20.4305C12.447 20.5925 12.2398 20.691 12.0186 20.7061C11.7974 20.7212 11.5788 20.6518 11.4068 20.5119C11.2348 20.372 11.1224 20.172 11.0922 19.9524L11.084 19.8334V11.6667C11.084 11.4347 11.1762 11.2121 11.3403 11.048C11.5044 10.8839 11.7269 10.7917 11.959 10.7917ZM14.0007 3.79175C13.4883 3.79177 12.9946 3.98445 12.6177 4.33154C12.2408 4.67864 12.0081 5.15476 11.966 5.66541L11.959 5.83342H16.0423C16.0423 5.29193 15.8272 4.77263 15.4443 4.38974C15.0614 4.00685 14.5421 3.79175 14.0007 3.79175Z" fill="#D2D2D2"></path></svg></button></div></div></div>`);
            });
            _push(`<!--]-->`);
          } else {
            _push(`<div class="col mb-2"> \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u044B\u0435 \u0444\u043E\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u0438 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B </div>`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$i = _sfc_main$i.setup;
_sfc_main$i.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/PhotoCard.vue");
  return _sfc_setup$i ? _sfc_setup$i(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$i;
const _sfc_main$h = {
  __name: "Form",
  __ssrInlineRender: true,
  props: {
    name: {
      required: true,
      default: "name"
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const { errorMessage } = useField(() => props.name);
    const { remove, push, fields } = useFieldArray(() => props.name);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Field = Field;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "input-row" }, _attrs))} data-v-e495bc1c><label data-v-e495bc1c>\u0421\u043E\u0446\u0438\u0430\u043B\u043D\u044B\u0435 \u0441\u0435\u0442\u0438</label><div class="input-wrapper mt-2" data-v-e495bc1c><div class="social_network_form" data-v-e495bc1c><!--[-->`);
      ssrRenderList(unref(fields), (field, idx) => {
        _push(`<div class="row position-relative mt-2" data-v-e495bc1c><span class="position-absolute absoluted_icon cursor-pointer" data-v-e495bc1c><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" data-v-e495bc1c><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-e495bc1c></path></svg></span><div data-v-e495bc1c>`);
        _push(ssrRenderComponent(_component_Field, {
          name: props.name + "[" + [idx] + "]",
          rules: { url: true }
        }, null, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]-->`);
      if (unref(fields).length === 0) {
        _push(`<button type="button" class="btn btn-primary btn-sm mt-1" data-v-e495bc1c> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(fields).length > 0) {
        _push(`<button type="button" class="btn btn-primary mt-1 btn-sm" data-v-e495bc1c> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435 </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (unref(errorMessage)) {
        _push(`<div class="text-danger d-block" data-v-e495bc1c>${ssrInterpolate(unref(errorMessage))}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$h = _sfc_main$h.setup;
_sfc_main$h.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeSocialNetworks/Form.vue");
  return _sfc_setup$h ? _sfc_setup$h(props, ctx) : void 0;
};
const __nuxt_component_4$1 = /* @__PURE__ */ _export_sfc(_sfc_main$h, [["__scopeId", "data-v-e495bc1c"]]);
const __nuxt_component_2_lazy = defineAsyncComponent(() => import('./VeeCustomSelect-BxrAvA7-.mjs').then((c) => c.default || c));
const _sfc_main$g = {
  __name: "VeePersonalFieldsCard",
  __ssrInlineRender: true,
  props: {
    title: {
      default: "-",
      required: false
    }
  },
  setup(__props, { expose: __expose }) {
    useVacancyStore();
    const profileStore = useProfileStore();
    const route = useRoute();
    const resumeID = computed(() => route.params.id);
    const resumeStore = useResumeStore();
    const { updateResume } = resumeStore;
    const my_resume = computed(() => resumeStore.my_resume);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    useI18n();
    const { providers } = useProviders();
    watch(
      () => providers.value,
      () => {
        walkThroughFields(providers.value);
      }
    );
    const isHHSelected = computed(() => {
      if (providers.value.hh === true)
        return true;
      else
        return false;
    });
    const schema = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false) {
        let phoneScheme2 = z.object({
          type_id: z.number(),
          comment: z.string().optional().nullable(),
          phone: z.string(),
          is_preferred: z.boolean().optional().nullable()
        });
        return z.object({
          first_name: z.string().min(2),
          last_name: z.string().min(2),
          middle_name: z.string().nullable().optional(),
          email: z.string().email(),
          is_preferred_email: z.boolean().nullable(),
          birth_date: z.string().nullable().optional(),
          additional_information: z.string().nullable().optional(),
          other_contacts: z.string().nullable().optional(),
          gender_id: z.number(),
          city_id: z.number(),
          address: z.string().nullable().optional(),
          business_trip_id: z.number(),
          relocation_type_id: z.number().nullable().optional(),
          social_networks: z.number().array().optional(),
          phones: z.array(phoneScheme2).nonempty()
        });
      }
      if (providers.value.hh === false && providers.value.superjob === true) {
        const phoneScheme2 = z.object({
          start_available_time_phone: z.string().optional().nullable(),
          end_available_time_phone: z.string().optional().nullable(),
          phone: z.string()
        });
        return z.object({
          first_name: z.string().min(2),
          last_name: z.string().nullable().optional(),
          middle_name: z.string().nullable().optional(),
          email: z.string().email().nullable().optional(),
          is_preferred_email: z.boolean().nullable().optional(),
          birth_date: z.string(),
          additional_information: z.string().nullable().optional(),
          other_contacts: z.string().nullable().optional(),
          gender_id: z.number(),
          city_id: z.number(),
          address: z.string().nullable().optional(),
          business_trip_id: z.number().nullable(),
          relocation_type_id: z.number().nullable().optional(),
          social_networks: z.number().array().optional(),
          phones: z.array(phoneScheme2).optional()
        });
      }
      let phoneScheme = z.object({
        type_id: z.number(),
        comment: z.string().optional().nullable(),
        start_available_time_phone: z.string().optional().nullable(),
        end_available_time_phone: z.string().optional().nullable(),
        phone: z.string(),
        is_preferred: z.boolean()
      });
      return z.object({
        first_name: z.string().min(2),
        last_name: z.string().min(2),
        middle_name: z.string().nullable().optional(),
        email: z.string().email(),
        is_preferred_email: z.boolean().nullable(),
        birth_date: z.string(),
        additional_information: z.string().nullable().optional(),
        other_contacts: z.string().nullable().optional(),
        gender_id: z.number(),
        city_id: z.number(),
        address: z.string().nullable().optional(),
        business_trip_id: z.number(),
        relocation_type_id: z.number().nullable().optional(),
        social_networks: z.number().array().optional(),
        phones: z.array(phoneScheme).nonempty()
      });
    });
    zodToJsonSchema(schema.value, { errorMessages: true });
    computed(
      () => zodToJsonSchema(schema.value, { errorMessages: true })
    );
    const initialValues = ref({
      first_name: null,
      last_name: null,
      middle_name: null,
      email: null,
      is_preferred_email: false,
      birth_date: null,
      city_id: null,
      gender_id: null,
      relocation_type_id: null,
      move_able_cities: [],
      social_networks: ["https://"],
      phones: [],
      business_trip_id: null,
      address: null
    });
    const {
      errors,
      values,
      setErrors,
      meta,
      handleSubmit,
      setValues,
      resetForm,
      validate
    } = useForm({
      initialValues,
      validationSchema: toTypedSchema(schema.value)
    });
    const dictionaryStore = useDictionaryStore();
    const genderOptions = computed(() => {
      return dictionaryStore.resume_genders.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const relocationTypeOptions = computed(() => {
      return dictionaryStore.relocation_types.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const businessTripOptions = computed(() => {
      return dictionaryStore.business_trips.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const state = reactive({
      first_name: {
        is_hidden: false
      },
      last_name: {
        is_hidden: false
      },
      middle_name: {
        is_hidden: false
      },
      email: {
        is_hidden: false
      },
      is_preferred_email: {
        is_hidden: false
      },
      birth_date: {
        is_hidden: false
      },
      city_id: {
        is_hidden: false
      },
      additional_information: {
        is_hidden: false
      },
      other_contacts: {
        is_hidden: false
      },
      gender_id: {
        is_hidden: false
      },
      relocation_type_id: {
        is_hidden: false
      },
      move_able_cities: {
        is_hidden: false
      },
      metros: {
        is_hidden: false
      },
      business_trip_id: {
        is_hidden: false
      },
      address: {
        is_hidden: false
      },
      social_networks: {
        is_hidden: false
      },
      phones: {
        is_hidden: false
      },
      is_relocatable: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        first_name: true,
        last_name: true,
        middle_name: false,
        email: true,
        is_preferred_email: false,
        birth_date: false,
        city_id: true,
        additional_information: null,
        other_contacts: null,
        gender_id: true,
        relocation_type_id: false,
        move_able_cities: false,
        metros: false,
        business_trip_id: true,
        address: null,
        social_networks: false,
        phones: true
      },
      superjob: {
        first_name: true,
        last_name: false,
        middle_name: false,
        email: false,
        is_preferred_email: null,
        birth_date: true,
        city_id: true,
        additional_information: false,
        other_contacts: false,
        gender_id: true,
        relocation_type_id: false,
        move_able_cities: false,
        metros: false,
        business_trip_id: false,
        address: false,
        social_networks: false,
        phones: false
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    const canBeRelocated = computed(() => {
      return parseInt(values.relocation_type_id) === 148 || parseInt(values.relocation_type_id) === 149;
    });
    computed(() => {
      return true;
    });
    const { getCityNameFromArea, getCityNameFromArea2 } = useResumeHooks();
    const cityOptions = ref([]);
    const selectedProviders = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false)
        return ["hh"];
      if (providers.value.hh === false && providers.value.superjob === true)
        return ["superjob"];
      return ["hh", "superjob"];
    });
    const updateCityInput = async (newValue = "") => {
      if (newValue) {
        const items = await searchCities({
          search: newValue,
          providers: selectedProviders.value
        });
        cityOptions.value = items.map((item) => ({
          value: item.id,
          name: getCityNameFromArea2(item)
        }));
      }
    };
    const moveableCityOptions = ref([]);
    const updateMoveableCityInput = async (newValue = "") => {
      var _a;
      const items = (_a = await searchCities({ search: newValue })) != null ? _a : [];
      moveableCityOptions.value = items.map((item) => ({
        value: item.id,
        name: item.name
      }));
    };
    const sectionData = ref({});
    const getFields = (newObject) => {
      var _a, _b, _c, _d;
      return {
        first_name: newObject.first_name,
        last_name: newObject.last_name,
        middle_name: newObject.middle_name,
        email: newObject.email,
        is_preferred_email: newObject.is_preferred_email,
        birth_date: newObject.birth_date,
        city_id: (_a = newObject.city) == null ? void 0 : _a.id,
        additional_information: newObject.additional_information,
        other_contacts: newObject.other_contacts,
        gender_id: (_b = newObject.gender) == null ? void 0 : _b.id,
        relocation_type_id: (_c = newObject.relocation_type) == null ? void 0 : _c.id,
        move_able_cities: newObject.move_able_cities,
        metros: newObject.metros,
        business_trip_id: (_d = newObject.business_trip) == null ? void 0 : _d.id,
        address: newObject.address,
        social_networks: newObject.social_networks,
        phones: newObject.phones.map((item, index) => {
          var _a2;
          return {
            id: index,
            type_id: (_a2 = item.type) == null ? void 0 : _a2.id,
            phone: String(item.phone),
            comment: item.comment,
            is_preferred: item.is_preferred,
            start_available_time_phone: item.start_available_time_phone,
            end_available_time_phone: item.end_available_time_phone
          };
        }),
        is_relocatable: newObject.is_relocatable
      };
    };
    watch(
      () => resumeStore.my_resume,
      (newResume) => {
        if (newResume) {
          sectionData.value = getFields(newResume);
          newResume.city;
          if (newResume.city.hasOwnProperty("country_id")) {
            const city2 = newResume.city;
            onSearchCitiesByCountryId(city2.country_id, city2.name);
          }
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    const { searchCities } = profileStore;
    const onSearchCitiesByCountryId = async (country_id, name) => {
      const items = await searchCities({ search: name });
      cityOptions.value = items.map((item) => ({
        value: item.id,
        name: getCityNameFromArea2(item)
      }));
    };
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    ref(false);
    const onSubmit = () => {
      save();
    };
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      isLoading.value = true;
      errorMessage.value = "";
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        return false;
      }
      setErrors({});
      let resData = {};
      const jsonData = { ...JSON.parse(JSON.stringify(values)) };
      jsonData.form_data = "PERSONAL_DATA";
      jsonData.phones = jsonData.phones.map((item) => {
        var _a;
        return {
          ...item,
          phone: (_a = item.phone) == null ? void 0 : _a.replace("+", "")
        };
      });
      resData = await updateResume(resumeID.value, jsonData);
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = false;
      setErrors({});
      resetForm({ values });
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
      return true;
    };
    const isCompleted = computed(() => {
      const myResume = my_resume.value;
      if (myResume && !isCollapsed.value) {
        return myResume.address && myResume.address.address;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeBirthDatePicker = __nuxt_component_2$2;
      const _component_VeeSelectWithSearch = __nuxt_component_0$8;
      const _component_VeeCustomSelect = __nuxt_component_2$1;
      const _component_VeeMultiSelectWithSearch = __nuxt_component_1$1;
      const _component_LazyVeeCustomSelect = __nuxt_component_2_lazy;
      const _component_CreateResumeVeeSocialNetworksForm = __nuxt_component_4$1;
      const _component_CreateResumeVeePhoneFieldsForm = __nuxt_component_2$3;
      const _component_ErrorMessage = ErrorMessage;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, onSubmit)))}><div class="w-box-head"><h3 class="title">\u041B\u0438\u0447\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label for="name">\u0418\u043C\u044F \u0438 \u0444\u0430\u043C\u0438\u043B\u0438\u044F <b>*</b></label><div class="input-wrapper"><div class="c2"><div class="input-wrapper">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "first_name",
        placeholder: "\u0418\u043C\u044F"
      }, null, _parent));
      _push(`</div><div class="input-wrapper">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "last_name",
        placeholder: "\u0424\u0430\u043C\u0438\u043B\u0438\u044F"
      }, null, _parent));
      _push(`</div></div><div class="c1 mt-1">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "middle_name",
        placeholder: "\u041E\u0442\u0447\u0435\u0441\u0442\u0432\u043E"
      }, null, _parent));
      _push(`</div></div></div><div class="input-row"><label>\u0414\u0430\u0442\u0430 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F <b>*</b></label><div class="input-wrapper"><div class="mb-1">`);
      _push(ssrRenderComponent(_component_VeeBirthDatePicker, { name: "birth_date" }, null, _parent));
      _push(`</div></div></div><div class="input-row"><label for="resume_email">\u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0447\u0442\u0430 `);
      if (unref(isHHSelected)) {
        _push(`<b>*</b>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "email",
        placeholder: "\u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0447\u0442\u0430"
      }, null, _parent));
      if (!unref(state).is_preferred_email.is_hidden) {
        _push(ssrRenderComponent(ResumeCheckboxInput, {
          class: "mt-2",
          name: "is_preferred_email",
          type: "checkbox",
          label: "e-mail \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043B\u0438 \u043F\u0440\u0435\u0434\u043F\u043E\u0447\u0442\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u043C \u0441\u043F\u043E\u0441\u043E\u0431\u043E\u043C \u0441\u0432\u044F\u0437\u0438"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (!unref(state).additional_information.is_hidden) {
        _push(`<div class="input-row"><label>\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(ResumeTextInput, {
          name: "additional_information",
          placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="input-row"><label>\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u044B</label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: "other_contacts",
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u0413\u043E\u0440\u043E\u0434 \u043F\u0440\u043E\u0436\u0438\u0432\u0430\u043D\u0438\u044F:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_VeeSelectWithSearch, {
        options: unref(cityOptions),
        name: "city_id",
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0433\u043E\u0440\u043E\u0434",
        onInput: updateCityInput
      }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u0420\u0435\u043B\u043E\u043A\u0430\u0446\u0438\u044F:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        options: unref(relocationTypeOptions),
        name: "relocation_type_id",
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div>`);
      if (unref(canBeRelocated)) {
        _push(`<div class="input-row"><label>\u0413\u043E\u0440\u043E\u0434\u043E\u0432 \u0432 \u043A\u043E\u0442\u043E\u0440\u044B\u043C \u0433\u043E\u0442\u043E\u0432 \u043F\u0435\u0440\u0435\u0435\u0445\u0430\u0442\u044C:</label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, {
          name: "move_able_cities",
          options: unref(moveableCityOptions),
          placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435",
          onInput: updateMoveableCityInput
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="input-row"><label>\u0413\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C \u043A \u043A\u043E\u043C\u0430\u043D\u0434\u0438\u0440\u043E\u0432\u043A\u0430\u043C:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_LazyVeeCustomSelect, {
        options: unref(businessTripOptions),
        name: "business_trip_id",
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u041F\u043E\u043B\u044C:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_LazyVeeCustomSelect, {
        options: unref(genderOptions),
        name: "gender_id",
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div>`);
      if (!unref(state).address.is_hidden) {
        _push(`<div class="input-row"><label>\u0410\u0434\u0440\u0435\u0441: </label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(ResumeTextInput, {
          name: "address",
          placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_CreateResumeVeeSocialNetworksForm, {
        style: !unref(state).social_networks.is_hidden ? null : { display: "none" },
        name: "social_networks"
      }, null, _parent));
      _push(ssrRenderComponent(_component_CreateResumeVeePhoneFieldsForm, {
        style: !unref(state).phones.is_hidden ? null : { display: "none" },
        name: "phones"
      }, null, _parent));
      _push(`<div class="text-danger d-block">`);
      _push(ssrRenderComponent(_component_ErrorMessage, { name: "phones" }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$g = _sfc_main$g.setup;
_sfc_main$g.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeePersonalFieldsCard.vue");
  return _sfc_setup$g ? _sfc_setup$g(props, ctx) : void 0;
};
const __nuxt_component_3$1 = _sfc_main$g;
const _sfc_main$f = {
  __name: "ProfessionalRoles",
  __ssrInlineRender: true,
  setup(__props) {
    const profileStore = useProfileStore();
    const { providers } = useProviders();
    const selectedProviders = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false)
        return ["hh"];
      if (providers.value.hh === false && providers.value.superjob === true)
        return ["superjob"];
      return ["hh", "superjob"];
    });
    const isHHSelected = computed(() => selectedProviders.value.includes("hh"));
    const isSuperjobSelected = computed(
      () => selectedProviders.value.includes("superjob")
    );
    const professionalRoleOptions = ref([]);
    const {
      searchProfessionalRoles,
      searchHHProfessionalRoles,
      searchSuperjobProfessionalRoles
    } = profileStore;
    const { uniq } = useFilter();
    const { value: prof_role_ids } = useField("professional_roles");
    watch(
      () => prof_role_ids.value,
      async () => {
        let items = [];
        if (isHHProfRolesNeeded.value) {
          const new_h = profileStore.hh_professional_roles_with_parent;
          items = items.concat(new_h);
        }
        if (isSuperjobProfRolesNeeded.value) {
          const new_s = profileStore.superjob_professional_roles_with_parent;
          items = items.concat(new_s);
        }
        if (isHHProfRolesNeeded.value || isSuperjobProfRolesNeeded.value) {
          items = items.concat(profileStore.professional_roles_with_parent);
          items = uniq(items, "value");
          professionalRoleOptions.value = items;
        } else {
          professionalRoleOptions.value = profileStore.professional_roles_with_parent;
        }
      }
    );
    const updateProfessionalInput = async (newValue = "", providers2 = []) => {
      let items = await searchProfessionalRoles();
      if (newValue) {
        items = items.filter((item) => item.parent_id !== 0).filter((item) => item.name.includes(newValue));
      } else {
        items = items.filter((item) => item.parent_id !== 0);
      }
      professionalRoleOptions.value = items.map((item) => ({
        value: item.id,
        name: item.name
      }));
    };
    const isHHProfRolesNeeded = computed(() => {
      if (!isHHSelected.value)
        return false;
      if (prof_role_ids.value.length < 1)
        return true;
      const selected_fields_values = [...prof_role_ids.value];
      return !selected_fields_values.some(
        (item) => profileStore.hh_professional_roles_with_parent_ids.includes(item)
      );
    });
    const isSuperjobProfRolesNeeded = computed(() => {
      if (!isSuperjobSelected.value)
        return false;
      if (prof_role_ids.value.length < 1)
        return true;
      const selected_fields_values = [...prof_role_ids.value];
      return !selected_fields_values.some(
        (item) => profileStore.superjob_professional_roles_with_parent_ids.includes(item)
      );
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeMultiSelectWithSearch = __nuxt_component_1$1;
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, mergeProps({
        name: "professional_roles",
        sort_by: "none",
        options: unref(professionalRoleOptions),
        onInput: updateProfessionalInput,
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeProfessionalDetails/ProfessionalRoles.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const __nuxt_component_0$4 = _sfc_main$f;
const _sfc_main$e = {
  __name: "WorkTypes",
  __ssrInlineRender: true,
  setup(__props) {
    useProfileStore();
    const dictionaryStore = useDictionaryStore();
    const { providers } = useProviders();
    const selectedProviders = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false)
        return ["hh"];
      if (providers.value.hh === false && providers.value.superjob === true)
        return ["superjob"];
      return ["hh", "superjob"];
    });
    ref([]);
    const isHHSelected = computed(() => selectedProviders.value.includes("hh"));
    const isSuperjobSelected = computed(
      () => selectedProviders.value.includes("superjob")
    );
    computed(() => {
      if (!isHHSelected.value)
        return false;
      if (work_type_ids.value.length < 1)
        return true;
      const selected_fields_values = [...work_type_ids.value];
      return !selected_fields_values.some(
        (item) => hhWorkTypes.value.includes(item)
      );
    });
    computed(() => {
      if (!isSuperjobSelected.value)
        return false;
      if (work_type_ids.value.length < 1)
        return true;
      const selected_fields_values = [...work_type_ids.value];
      return !selected_fields_values.some(
        (item) => superjobWorkTypes.value.includes(item)
      );
    });
    ref([]);
    const { value: work_type_ids } = useField("work_types");
    watch(
      () => work_type_ids.value,
      async () => {
      }
    );
    useResumeStore();
    const hhWorkTypes = ref([]);
    const superjobWorkTypes = ref([]);
    watch(
      () => dictionaryStore.hh_work_types,
      () => {
        hhWorkTypes.value = dictionaryStore.hh_work_types.map((item) => item.id);
      }
    );
    watch(
      () => dictionaryStore.superjob_work_types,
      () => {
        superjobWorkTypes.value = dictionaryStore.superjob_work_types.map(
          (item) => item.id
        );
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeMultiSelectWithSearch = __nuxt_component_1$1;
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, mergeProps({
        name: "work_types",
        sort_by: "none",
        options: unref(dictionaryStore).work_types_formatted,
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeProfessionalDetails/WorkTypes.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$e;
const _sfc_main$d = {
  __name: "VeeProfessionDetailsCard",
  __ssrInlineRender: true,
  props: {
    providers: {
      default: {
        hh: false,
        superjob: false
      },
      required: true
    }
  },
  setup(__props, { expose: __expose }) {
    const dictionaryStore = useDictionaryStore();
    useProfileStore();
    const route = useRoute();
    const resumeID = computed(() => route.params.id);
    const resumeStore = useResumeStore();
    const { updateResume } = resumeStore;
    const my_resume = computed(() => resumeStore.my_resume);
    const isSaved = ref(false);
    ref(false);
    ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    const { providers } = useProviders();
    const currencyOptions = useCurrencyOptions();
    const schema = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false) {
        return z.object({
          title: z.string().min(2),
          salary: z.number(),
          currency: z.string().nullable().optional(),
          place_of_work_id: z.number().nullable(),
          professional_roles: z.array(z.number()).nonempty(),
          work_types: z.array(z.number()).nonempty(),
          schedules: z.array(z.number()).nonempty()
        });
      }
      if (providers.value.hh === false && providers.value.superjob === true) {
        return z.object({
          title: z.string().nullable().optional(),
          salary: z.number().min(2),
          currency: z.string().nullable().optional(),
          place_of_work_id: z.number().nullable(),
          professional_roles: z.array(z.number()).nonempty(),
          work_types: z.array(z.number()).nonempty(),
          schedules: z.array(z.number()).nonempty()
        });
      }
      return z.object({
        title: z.string().min(2),
        professional_roles: z.array(z.number()).nonempty(),
        work_types: z.array(z.number()).nonempty(),
        schedules: z.array(z.number()).nonempty(),
        salary: z.number().nullable(),
        currency: z.string(),
        place_of_work_id: z.number().nullable()
      });
    });
    const initialValues = {
      title: null,
      professional_roles: [],
      work_types: [],
      schedules: [],
      place_of_work_id: null,
      salary: null,
      currency: "RUB"
    };
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      title: {
        is_hidden: false
      },
      professional_roles: {
        is_hidden: false
      },
      salary: {
        is_hidden: false
      },
      currency: {
        is_hidden: false
      },
      work_types: {
        is_hidden: false
      },
      schedules: {
        is_hidden: false
      },
      place_of_work_id: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        professional_roles: true,
        title: true,
        schedules: true,
        work_types: true,
        place_of_work_id: null,
        salary: false,
        currency: false
      },
      superjob: {
        professional_roles: true,
        title: true,
        schedules: null,
        work_types: false,
        place_of_work_id: false,
        salary: false,
        currency: null
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    watch(
      () => providers.value,
      () => {
        walkThroughFields(providers.value);
      }
    );
    const sectionData = ref({});
    const getFields = (newObject) => {
      var _a2;
      var _a;
      return {
        title: newObject.title,
        salary: newObject.salary,
        currency: newObject.currency,
        place_of_work_id: (_a2 = (_a = newObject.place_of_work) == null ? void 0 : _a.id) != null ? _a2 : null,
        work_types: Object.keys(newObject.work_types).map((item) => parseInt(item)),
        schedules: Object.keys(newObject.schedules).map((item) => parseInt(item)),
        professional_roles: newObject.professional_roles.map((item) => item.id)
      };
    };
    watch(
      () => resumeStore.my_resume,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    const placeOfWorkOptions = computed(() => {
      return dictionaryStore.place_of_works.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const scheduleOptions = computed(() => {
      return dictionaryStore.schedules.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u044C\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let resData = {};
      resData = await updateResume(resumeID.value, {
        ...JSON.parse(JSON.stringify(values)),
        form_data: "PROFESSION_DETAILS_DATA"
      });
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      setErrors({});
      resetForm({ values });
      isSaved.value = false;
      isUpdated.value = false;
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myResume = my_resume.value;
      if (myResume && !isCollapsed.value) {
        return myResume.address && myResume.address.address;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeVeeProfessionalDetailsProfessionalRoles = __nuxt_component_0$4;
      const _component_VeeCustomSelect = __nuxt_component_2$1;
      const _component_VeeMultiSelectWithSearch = __nuxt_component_1$1;
      const _component_CreateResumeVeeProfessionalDetailsWorkTypes = __nuxt_component_3;
      const _component_Field = Field;
      const _component_ErrorMessage = ErrorMessage;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0414\u0435\u0442\u0430\u043B\u0438 \u0440\u0435\u0437\u044E\u043C\u0435</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div><div class="text-danger d-block p-4">${ssrInterpolate(unref(errorMessage))}</div><div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><form><div class="input-row"><label for="name">\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438<b>*</b></label><div class="input-wrapper"><div class="c1 mt-1">`);
      _push(ssrRenderComponent(ResumeTextInput, { name: "title" }, null, _parent));
      _push(`</div></div></div><div class="input-row"><label>\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_CreateResumeVeeProfessionalDetailsProfessionalRoles, { name: "professional_roles" }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).place_of_work_id.is_hidden ? null : { display: "none" })}"><label>\u041C\u0435\u0441\u0442\u043E \u0440\u0430\u0431\u043E\u0442\u044B:</label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        name: "place_of_work_id",
        options: unref(placeOfWorkOptions),
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).schedules.is_hidden ? null : { display: "none" })}"><label>\u0413\u0440\u0430\u0444\u0438\u043A\u043E\u0432 \u0440\u0430\u0431\u043E\u0442\u044B:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, {
        options: unref(scheduleOptions),
        name: "schedules",
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u0422\u0438\u043F \u0440\u0430\u0431\u043E\u0442\u044B:<b>*</b></label><div class="input-wrapper mt-2">`);
      _push(ssrRenderComponent(_component_CreateResumeVeeProfessionalDetailsWorkTypes, { name: "work_types" }, null, _parent));
      _push(`</div></div><div class="input-row"><label>\u041A\u0430\u043A\u043E\u0439 \u0434\u043E\u0445\u043E\u0434 \u0432\u044B \u0440\u0430\u0441\u0441\u043C\u0430\u0442\u0440\u0438\u0432\u0430\u0435\u0442\u0435?</label><div class="row-container"><div class="row"><div class="col-8"><div class="${ssrRenderClass([{
        "input-wrapper": !unref(state).currency.is_hidden,
        "input-group": unref(state).currency.is_hidden
      }, "mb-3"])}">`);
      _push(ssrRenderComponent(_component_Field, {
        style: !unref(state).salary.is_hidden ? null : { display: "none" },
        name: "salary",
        class: { "form-control": unref(state).currency.is_hidden },
        type: "number",
        placeholder: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0441\u0443\u043C\u043C\u0443"
      }, null, _parent));
      _push(`<span class="input-group-text" style="${ssrRenderStyle(unref(state).currency.is_hidden ? null : { display: "none" })}">\u20BD</span></div><div class="text-danger">`);
      _push(ssrRenderComponent(_component_ErrorMessage, { name: "salary" }, null, _parent));
      _push(`</div></div><div class="col-4" style="${ssrRenderStyle(!unref(state).currency.is_hidden ? null : { display: "none" })}">`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        name: "currency",
        label: "\u0412\u0430\u043B\u044E\u0442\u0430",
        options: unref(currencyOptions)
      }, null, _parent));
      _push(`</div></div></div></div></form></div></div>`);
    };
  }
};
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeProfessionDetailsCard.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main$d;
const _sfc_main$c = {
  __name: "VeeForeignLanguagesCard",
  __ssrInlineRender: true,
  props: {
    title: {
      default: "-",
      required: false
    }
  },
  setup(__props, { expose: __expose }) {
    useProfileStore();
    const route = useRoute();
    const resumeID = computed(() => route.params.id);
    const resumeStore = useResumeStore();
    const { updateResume } = resumeStore;
    const my_resume = computed(() => resumeStore.my_resume);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const schema = computed(() => {
      return toTypedSchema(
        z.object({
          languages: z.array(
            z.object({
              language_id: z.number(),
              level_id: z.number()
            })
          )
        })
      );
    });
    const initialValues = ref({
      languages: []
    });
    const {
      errors,
      values,
      setErrors,
      meta,
      validate,
      setValues,
      resetForm,
      resetField
    } = useForm({
      initialValues,
      validationSchema: schema.value
    });
    ref({
      hh: {
        languages: true
      },
      superjob: {
        languages: true
      }
    });
    const sectionData = ref({});
    const getFields = (newObject) => {
      return {
        languages: newObject.languages.map((item) => ({
          language_id: item.language.id,
          level_id: item.level.id
        }))
      };
    };
    watch(
      () => resumeStore.my_resume,
      (newResume) => {
        if (newResume) {
          sectionData.value = getFields(newResume);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    ref(false);
    const errorMessage = ref(null);
    const isLoading = ref(false);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let resData = {};
      const jsonData = { ...values };
      jsonData.form_data = "LANGUAGES_DATA";
      resData = await updateResume(resumeID.value, jsonData);
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = false;
      setErrors({});
      resetForm({ values });
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
      return true;
    };
    const isCompleted = computed(() => {
      const myResume = my_resume.value;
      if (myResume && !isCollapsed.value) {
        return myResume.address && myResume.address.address;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeForeignLanguagesVeeForm = __nuxt_component_0$2$1;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u042F\u0437\u044B\u043A\u0438</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div><div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div><div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      if (unref(my_resume)) {
        _push(ssrRenderComponent(_component_CreateResumeForeignLanguagesVeeForm, { name: "languages" }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeForeignLanguagesCard.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$c;
const _sfc_main$b = {
  __name: "VeeDriverLicensesCard",
  __ssrInlineRender: true,
  props: {
    title: {
      default: "-",
      required: false
    }
  },
  setup(__props, { expose: __expose }) {
    const resumeStore = useResumeStore();
    useProfileStore();
    const route = useRoute();
    const resumeID = computed(() => route.params.id);
    const { updateResume, getMyResume } = resumeStore;
    const my_resume = computed(() => resumeStore.my_resume);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const schema = computed(() => {
      const s = toTypedSchema(
        z.object({
          has_vehicle: z.boolean().nullable(),
          driver_license_types: z.number().array().optional()
        })
      );
      return s;
    });
    const initialValues = ref({
      has_vehicle: false,
      driver_license_types: []
    });
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: schema
    });
    const fields = ref({
      hh: {
        driver_license_types: false,
        has_vehicle: false
      },
      superjob: {
        driver_license_types: false,
        has_vehicle: null
      }
    });
    const state = reactive({
      driver_license_types: {
        is_hidden: false
      },
      has_vehicle: {
        is_hidden: false
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    const { providers } = useProviders();
    watch(
      () => providers.value,
      () => {
        walkThroughFields(providers.value);
      }
    );
    const sectionData = ref({});
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    const getFields = (newObject) => {
      var _a, _b;
      return {
        driver_license_types: (_a = newObject.driver_license_types.map((item) => item.id)) != null ? _a : [],
        has_vehicle: (_b = newObject.has_vehicle) != null ? _b : false
      };
    };
    watch(
      () => resumeStore.my_resume,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    useDictionaryStore();
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let resData = {};
      resData = await updateResume(resumeID.value, {
        form_data: "DRIVER_LICENSES_DATA",
        ...JSON.parse(JSON.stringify(values))
      });
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = false;
      setErrors({});
      resetForm({ values });
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myResume = my_resume.value;
      if (myResume && !isCollapsed.value) {
        return myResume.driver_license_types.length > 0;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeDriverLicensesForm = __nuxt_component_0$1$1;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0412\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0435 \u043F\u0440\u0430\u0432\u0430</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(errorMessage)) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errorMessage))}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      _push(ssrRenderComponent(_component_CreateResumeDriverLicensesForm, { name: "driver_license_types" }, null, _parent));
      _push(`<div class="mt-4" style="${ssrRenderStyle(!unref(state).has_vehicle.is_hidden ? null : { display: "none" })}">`);
      _push(ssrRenderComponent(ResumeCheckboxInput, {
        name: "has_vehicle",
        label: "\u0443 \u0412\u0430\u0441 \u0435\u0441\u0442\u044C \u043B\u0438\u0447\u043D\u044B\u0439 \u0430\u0432\u0442\u043E\u043C\u043E\u0431\u0438\u043B\u044C"
      }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeDriverLicensesCard.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$b;
const _sfc_main$a = {
  __name: "VeeKnowledgeAndSkillsCard",
  __ssrInlineRender: true,
  setup(__props, { expose: __expose }) {
    const route = useRoute();
    const resumeStore = useResumeStore();
    useDictionaryStore();
    const resumeID = computed(() => route.params.id);
    const isShown = ref(false);
    const isChanged = ref(false);
    const isSaved = ref(false);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const { providers } = useProviders();
    const schema = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false) {
        return z.object({
          skills: z.string().array().nonempty(),
          other_skills: z.string()
        });
      }
      if (providers.value.hh === false && providers.value.superjob === true) {
        return z.object({
          skills: z.string().array().nullable().optional(),
          other_skills: z.string().nullable().optional()
        });
      }
      return z.object({
        skills: z.string().array().nonempty(),
        other_skills: z.string()
      });
    });
    const initialValues = ref({
      skills: [],
      other_skills: null
    });
    const { errors, values, setErrors, meta, setValues, resetForm, validate } = useForm({
      initialValues,
      validationSchema: toTypedSchema(schema.value)
    });
    reactive({
      skills: {
        is_hidden: false
      },
      other_skills: {
        is_hidden: false
      }
    });
    const sectionData = ref({
      skills: []
    });
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData, []);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    const getFields = (newObject) => {
      return {
        skills: Object.values(newObject == null ? void 0 : newObject.skills),
        other_skills: newObject == null ? void 0 : newObject.other_skills
      };
    };
    watch(
      () => resumeStore.my_resume,
      (newData) => {
        if (newData) {
          sectionData.value = getFields(newData);
        }
      }
    );
    watch(
      () => isCollapsed.value,
      (newData) => {
        if (!newData) {
          isShown.value = true;
        }
      }
    );
    const { getResume, updateResume } = resumeStore;
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    ref(false);
    ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        return false;
      }
      setErrors({});
      const resData = await updateResume(resumeID.value, {
        ...JSON.parse(JSON.stringify(values)),
        form_data: "KNOWLEDGE_AND_SKILLS_DATA"
      });
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = true;
      setErrors({});
      resetForm({ values });
    };
    const isCompleted = computed(() => {
      var _a, _b;
      return ((_b = (_a = resumeStore.resume) == null ? void 0 : _a.skills) == null ? void 0 : _b.length) > 0;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeKnowledgeAndSkillsVeeForm = __nuxt_component_0$9;
      const _component_ErrorMessage = ErrorMessage;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0417\u043D\u0430\u043D\u0438\u044F \u0438 \u043D\u0430\u0432\u044B\u043A\u0438</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div><div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div><div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="row"><div class="col-12"><div class="input-row"><label for="description">\u041A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u043D\u0430\u0432\u044B\u043A\u0438:<b>*</b></label><div class="input-wrapper">`);
      if (unref(resumeStore).my_resume) {
        _push(ssrRenderComponent(_component_CreateResumeKnowledgeAndSkillsVeeForm, { name: "skills" }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="text-danger">`);
      _push(ssrRenderComponent(_component_ErrorMessage, { name: "skills" }, null, _parent));
      _push(`</div></div></div></div><div class="col-12 mt-4"><div class="input-row"><label for="description">\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F:</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(ResumeTextarea, { name: "other_skills" }, null, _parent));
      _push(`</div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeKnowledgeAndSkillsCard.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main$a;
const __nuxt_component_1_lazy = defineAsyncComponent(() => import('./Form-CTtjKFwU.mjs').then((c) => c.default || c));
const _sfc_main$9 = {
  __name: "VeeEducationCard",
  __ssrInlineRender: true,
  setup(__props, { expose: __expose }) {
    const educationElement = ref(false);
    const route = useRoute();
    const resumeStore = useResumeStore();
    const resumeID = computed(() => route.params.id);
    const dictionaryStore = useDictionaryStore();
    const { providers } = useProviders();
    const schema = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false) {
        const educationScheme2 = z.object({
          type_id: z.number().nullable().optional(),
          end_year: z.number(),
          institute: z.string(),
          profession: z.string().nullable().optional(),
          faculty: z.string().nullish().optional(),
          form_id: z.number().nullable().optional()
        });
        return z.object({
          education_level_id: z.number().nullable(),
          educations: z.array(educationScheme2).optional()
        });
      }
      if (providers.value.hh === false && providers.value.superjob === true) {
        const educationScheme2 = z.object({
          type_id: z.number(),
          end_year: z.number().nullish().optional(),
          institute: z.string().nullish().optional(),
          profession: z.string().nullable().optional(),
          faculty: z.string().nullish().optional(),
          form_id: z.number().nullable().optional()
        });
        return z.object({
          education_level_id: z.number().nullable(),
          educations: z.array(educationScheme2).optional()
        });
      }
      const educationScheme = z.object({
        type_id: z.number(),
        profession: z.string().nullable().optional(),
        institute: z.string(),
        faculty: z.string().nullish().optional(),
        form_id: z.number().nullable().optional(),
        end_year: z.number()
      });
      return z.object({
        education_level_id: z.number().nullable(),
        educations: z.array(educationScheme).optional()
      });
    });
    const initialValues = ref({
      education_level_id: null,
      educations: []
    });
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const fields = ref({
      hh: {
        education_level_id: true,
        educations: null
      },
      superjob: {
        education_level_id: null,
        educations: null
      }
    });
    const state = reactive({
      education_level_id: {
        is_hidden: false
      },
      educations: {
        is_hidden: false
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    watch(
      () => providers.value,
      () => {
        walkThroughFields(providers.value);
      }
    );
    const isShown = ref(true);
    const isChanged = ref(false);
    const isSaved = ref(false);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const educationLevelOptions = computed(() => {
      return dictionaryStore.resume_educations.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const sectionData = ref({
      educations: []
    });
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        var _a;
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          if (((_a = newData.educations) == null ? void 0 : _a.length) > 0) {
            isShown.value = true;
          }
          resetForm({ values: newData });
        }
      }
    );
    const getFields = (newObject) => {
      var _a, _b;
      return {
        educations: (_a = newObject == null ? void 0 : newObject.educations) == null ? void 0 : _a.primary.map((item) => {
          var _a2, _b2;
          return {
            faculty: item.faculty,
            institute: item.institute,
            profession: item.profession,
            end_year: item.end_year,
            type_id: (_a2 = item.type) == null ? void 0 : _a2.id,
            form_id: (_b2 = item.form) == null ? void 0 : _b2.id
          };
        }),
        education_level_id: (_b = newObject == null ? void 0 : newObject.educations.education_level) == null ? void 0 : _b.id
      };
    };
    watch(
      () => resumeStore.my_resume,
      (newResume) => {
        if (newResume) {
          sectionData.value = getFields(newResume);
        }
      }
    );
    watch(
      () => isCollapsed.value,
      (newData) => {
        if (!newData) {
          isShown.value = true;
        }
      }
    );
    const { getResume, updateResume } = resumeStore;
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    ref(false);
    ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        return false;
      }
      setErrors({});
      const resData = await updateResume(resumeID.value, {
        form_data: "EDUCATION_DATA",
        educations: {
          primary: values.educations,
          education_level_id: values.education_level_id
        }
      });
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = true;
      setErrors({});
      resetForm({ values });
    };
    const isCompleted = computed(() => {
      var _a, _b;
      return ((_b = (_a = resumeStore.resume) == null ? void 0 : _a.educations.primary) == null ? void 0 : _b.length) > 0;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeCustomSelect = __nuxt_component_2$1;
      const _component_LazyCreateResumeVeeEducationForm = __nuxt_component_1_lazy;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div><div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div><div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      if (unref(isShown)) {
        _push(`<div class=""><div class="row"><div class="input-row"><label for="position">\u0423\u0440\u043E\u0432\u0435\u043D \u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435 1<b>*</b></label><div class="input-wrapper">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(educationLevelOptions),
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435",
          name: "education_level_id"
        }, null, _parent));
        _push(`</div></div><div class="mt-3">`);
        _push(ssrRenderComponent(_component_LazyCreateResumeVeeEducationForm, {
          ref_key: "educationElement",
          ref: educationElement,
          name: "educations",
          parent_type_id: unref(state).education_level_id.val
        }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<div class="empty-area"><span>\u0417\u0434\u0435\u0441\u044C \u0432\u044B \u043C\u043E\u0436\u0435\u0442\u0435 \u0443\u043A\u0430\u0437\u0430\u0442\u044C</span><button class="add" type="button"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button></div>`);
      }
      if (unref(isSaved)) {
        _push(`<span class="p-3 d-inline-flex justify-content-center align-items-center" style="${ssrRenderStyle({ "color": "#0c0" })}"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="me-2"><path fill="#0c0" d="M10.041 17l-4.5-4.319 1.395-1.435 3.08 2.937 7.021-7.183 1.422 1.409-8.418 8.591zm5.959 7v-2h-8v2h8zm0-24v2h-8v-2h8zm2 0h1c2.762 0 5 2.239 5 5v1h-2v-1c0-1.654-1.346-3-3-3h-1v-2zm6 16h-2v-8h2v8zm-18 8h-1c-2.762 0-5-2.239-5-5v-1h2v1c0 1.654 1.346 3 3 3h1v2zm18-6v1c0 2.761-2.238 5-5 5h-1v-2h1c1.654 0 3-1.346 3-3v-1h2zm-24-12v-1c0-2.761 2.238-5 5-5h1v2h-1c-1.654 0-3 1.346-3 3v1h-2zm0 2h2v8h-2v-8z"></path></svg> \u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D </span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeEducationCard.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_8 = _sfc_main$9;
const _sfc_main$8 = {
  __name: "Item",
  __ssrInlineRender: true,
  props: ["idx", "name"],
  emits: ["remove"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const { idx, name } = toRefs(props);
    const yearOptions = computed(
      () => useYearOptions(1950, (/* @__PURE__ */ new Date()).getUTCFullYear() + 5)
    );
    useDictionaryStore();
    const { providers } = useProviders();
    const state = reactive({
      title: {
        is_hidden: false
      },
      organization: {
        is_hidden: false
      },
      end_year: {
        is_hidden: false
      },
      profession: {
        is_hidden: false
      },
      certificate_url: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        title: true,
        organization: true,
        end_year: true,
        profession: false,
        certificate_url: null
      },
      superjob: {
        title: false,
        organization: true,
        end_year: true,
        profession: null,
        certificate_url: false
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    watch(
      () => providers.value,
      () => {
        walkThroughFields(providers.value);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeCustomSelect = __nuxt_component_2$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row position-relative empty-area" }, _attrs))} data-v-36348602><span class="position-absolute absoluted_icon" data-v-36348602><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" data-v-36348602><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-36348602></path></svg></span><div class="input-row" style="${ssrRenderStyle(!unref(state).organization.is_hidden ? null : { display: "none" })}" data-v-36348602><label for="position" data-v-36348602>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435<b data-v-36348602>*</b></label><div class="input-wrapper" data-v-36348602>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${unref(name)}[${unref(idx)}].title`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).organization.is_hidden ? null : { display: "none" })}" data-v-36348602><label for="organization" data-v-36348602>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0437\u0430\u0432\u0435\u0434\u0435\u043D\u0438\u044F<b data-v-36348602>*</b></label><div class="input-wrapper" data-v-36348602>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${unref(name)}[${unref(idx)}].organization`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).profession.is_hidden ? null : { display: "none" })}" data-v-36348602><label for="position" data-v-36348602>\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C</label><div class="input-wrapper" data-v-36348602>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${unref(name)}[${unref(idx)}].profession`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).certificate_url.is_hidden ? null : { display: "none" })}" data-v-36348602><label for="position" data-v-36348602>\u0421\u0441\u044B\u043B\u043A\u0430 \u043A \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442</label><div class="input-wrapper" data-v-36348602>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${unref(name)}[${unref(idx)}].certificate_url`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).end_year.is_hidden ? null : { display: "none" })}" data-v-36348602><label for="position" data-v-36348602>\u0413\u043E\u0434 \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435<b data-v-36348602>*</b></label><div class="input-wrapper" data-v-36348602>`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        options: unref(yearOptions),
        name: `${unref(name)}[${unref(idx)}].end_year`,
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeCourses/Item.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_0$3 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["__scopeId", "data-v-36348602"]]);
const _sfc_main$7 = {
  __name: "Form",
  __ssrInlineRender: true,
  props: ["name", "parent_type_id", "providers"],
  setup(__props) {
    const props = __props;
    const { push, fields, remove } = useFieldArray(() => props.name);
    useDictionaryStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeVeeCoursesItem = __nuxt_component_0$3;
      _push(`<!--[--><!--[-->`);
      ssrRenderList(unref(fields), (field, idx) => {
        _push(`<div class="m-2">`);
        _push(ssrRenderComponent(_component_CreateResumeVeeCoursesItem, {
          onRemove: unref(remove),
          name: props.name,
          providers: props.providers,
          idx
        }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]-->`);
      if (unref(fields).length === 0) {
        _push(`<button type="button" class="btn btn-primary btn-sm mt-1"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(fields).length > 0) {
        _push(`<button type="button" class="btn btn-primary mt-1 btn-sm"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435 </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeCourses/Form.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_0$2 = _sfc_main$7;
const _sfc_main$6 = {
  __name: "VeeCoursesCard",
  __ssrInlineRender: true,
  props: {
    title: {
      default: "-",
      required: false
    }
  },
  setup(__props, { expose: __expose }) {
    var _a2;
    var _a;
    const educationElement = ref(false);
    const route = useRoute();
    const resumeStore = useResumeStore();
    const resumeID = computed(() => route.params.id);
    useDictionaryStore();
    ref((_a2 = (_a = resumeStore.resume) == null ? void 0 : _a.educations.courses) != null ? _a2 : []);
    const isShown = ref(false);
    const isChanged = ref(false);
    const isSaved = ref(false);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const { providers } = useProviders();
    const schema = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false) {
        const coursesScheme2 = z.object({
          title: z.string(),
          organization: z.string(),
          end_year: z.number(),
          profession: z.string().nullish().optional(),
          certificate_url: z.string().nullish().optional()
        });
        return z.object({
          courses: z.array(coursesScheme2).optional()
        });
      }
      if (providers.value.hh === false && providers.value.superjob === true) {
        const coursesScheme2 = z.object({
          title: z.string().nullish().optional(),
          organization: z.string(),
          end_year: z.number(),
          profession: z.string().nullish().optional(),
          certificate_url: z.string().nullish().optional()
        });
        return z.object({
          courses: z.array(coursesScheme2).optional()
        });
      }
      const coursesScheme = z.object({
        title: z.string(),
        organization: z.string(),
        end_year: z.number(),
        profession: z.string().nullish().optional(),
        certificate_url: z.string().nullish().optional()
      });
      return z.object({
        courses: z.array(coursesScheme).optional()
      });
    });
    const initialValues = ref({
      courses: []
    });
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const sectionData = ref({
      courses: []
    });
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        var _a22;
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          if (((_a22 = newData.courses) == null ? void 0 : _a22.length) > 0) {
            isShown.value = true;
          }
          resetForm({ values: newData });
        }
      }
    );
    const getFields = (newObject) => {
      var _a22;
      return {
        courses: (_a22 = newObject == null ? void 0 : newObject.educations) == null ? void 0 : _a22.courses.map((item) => ({
          title: item.title,
          organization: item.organization,
          profession: item.profession,
          end_year: item.end_year,
          certificate_url: item.certificate_url
        }))
      };
    };
    watch(
      () => resumeStore.my_resume,
      (newResume) => {
        if (newResume) {
          sectionData.value = getFields(newResume);
        }
      }
    );
    watch(
      () => isCollapsed.value,
      (newData) => {
        if (!newData) {
          isShown.value = true;
        }
      }
    );
    const { getSelectedProviders } = useResumeHooks();
    const { getResume, updateResume } = resumeStore;
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          console.log(backendErrors);
          setErrors(backendErrors);
        }
      }
    );
    ref(false);
    ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        return false;
      }
      setErrors({});
      const resData = await updateResume(resumeID.value, {
        form_data: "EDUCATION_DATA",
        educations: {
          courses: values.courses
        },
        providers: getSelectedProviders(providers.value)
      });
      console.log(resData);
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = true;
      setErrors({});
      resetForm({ values });
    };
    const isCompleted = computed(() => {
      var _a22, _b;
      return ((_b = (_a22 = resumeStore.resume) == null ? void 0 : _a22.educations.primary) == null ? void 0 : _b.length) > 0;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeVeeCoursesForm = __nuxt_component_0$2;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u041A\u0443\u0440\u0441\u044B</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      if (unref(isShown)) {
        _push(`<div class=""><div class="row"><div class="mt-3">`);
        _push(ssrRenderComponent(_component_CreateResumeVeeCoursesForm, {
          ref_key: "educationElement",
          ref: educationElement,
          name: "courses"
        }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<div class="empty-area"><span>\u0417\u0434\u0435\u0441\u044C \u0432\u044B \u043C\u043E\u0436\u0435\u0442\u0435 \u0443\u043A\u0430\u0437\u0430\u0442\u044C</span><button class="add" type="button"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button></div>`);
      }
      if (unref(isSaved)) {
        _push(`<span class="p-3 d-inline-flex justify-content-center align-items-center" style="${ssrRenderStyle({ "color": "#0c0" })}"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="me-2"><path fill="#0c0" d="M10.041 17l-4.5-4.319 1.395-1.435 3.08 2.937 7.021-7.183 1.422 1.409-8.418 8.591zm5.959 7v-2h-8v2h8zm0-24v2h-8v-2h8zm2 0h1c2.762 0 5 2.239 5 5v1h-2v-1c0-1.654-1.346-3-3-3h-1v-2zm6 16h-2v-8h2v8zm-18 8h-1c-2.762 0-5-2.239-5-5v-1h2v1c0 1.654 1.346 3 3 3h1v2zm18-6v1c0 2.761-2.238 5-5 5h-1v-2h1c1.654 0 3-1.346 3-3v-1h2zm-24-12v-1c0-2.761 2.238-5 5-5h1v2h-1c-1.654 0-3 1.346-3 3v1h-2zm0 2h2v8h-2v-8z"></path></svg> \u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D </span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeCoursesCard.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_9 = _sfc_main$6;
const _sfc_main$5 = {
  __name: "Item",
  __ssrInlineRender: true,
  props: ["idx", "name"],
  emits: ["remove"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const { idx, name } = toRefs(props);
    const yearOptions = computed(
      () => useYearOptions(1950, (/* @__PURE__ */ new Date()).getUTCFullYear() + 5)
    );
    useDictionaryStore();
    const { providers } = useProviders();
    const state = reactive({
      name: {
        is_hidden: false
      },
      organization: {
        is_hidden: false
      },
      year: {
        is_hidden: false
      },
      profession: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        name: true,
        organization: true,
        year: true,
        profession: null
      },
      superjob: {
        name: true,
        profession: null,
        organization: true,
        year: true
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    watch(
      () => providers.value,
      () => {
        walkThroughFields(providers.value);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeCustomSelect = __nuxt_component_2$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row position-relative empty-area" }, _attrs))} data-v-1449cedf><span class="position-absolute absoluted_icon" data-v-1449cedf><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" data-v-1449cedf><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-1449cedf></path></svg></span><div class="input-row" style="${ssrRenderStyle(!unref(state).name.is_hidden ? null : { display: "none" })}" data-v-1449cedf><label for="position" data-v-1449cedf>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435<b data-v-1449cedf>*</b></label><div class="input-wrapper" data-v-1449cedf>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${unref(name)}[${unref(idx)}].name`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).organization.is_hidden ? null : { display: "none" })}" data-v-1449cedf><label for="organization" data-v-1449cedf>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0437\u0430\u0432\u0435\u0434\u0435\u043D\u0438\u044F<b data-v-1449cedf>*</b></label><div class="input-wrapper" data-v-1449cedf>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${unref(name)}[${unref(idx)}].organization`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).profession.is_hidden ? null : { display: "none" })}" data-v-1449cedf><label for="position" data-v-1449cedf>\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C</label><div class="input-wrapper" data-v-1449cedf>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${unref(name)}[${unref(idx)}].profession`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" style="${ssrRenderStyle(!unref(state).year.is_hidden ? null : { display: "none" })}" data-v-1449cedf><label for="position" data-v-1449cedf>\u0413\u043E\u0434 \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435<b data-v-1449cedf>*</b></label><div class="input-wrapper" data-v-1449cedf>`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        options: unref(yearOptions),
        name: `${unref(name)}[${unref(idx)}].year`,
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeTestsAndExams/Item.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-1449cedf"]]);
const _sfc_main$4 = {
  __name: "Form",
  __ssrInlineRender: true,
  props: ["name", "parent_type_id", "providers"],
  setup(__props) {
    const props = __props;
    const { push, fields, remove } = useFieldArray(() => props.name);
    useDictionaryStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeVeeTestsAndExamsItem = __nuxt_component_0$1;
      _push(`<!--[--><!--[-->`);
      ssrRenderList(unref(fields), (field, idx) => {
        _push(`<div class="mt-2">`);
        _push(ssrRenderComponent(_component_CreateResumeVeeTestsAndExamsItem, {
          onRemove: unref(remove),
          name: props.name,
          providers: props.providers,
          idx
        }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]-->`);
      if (unref(fields).length === 0) {
        _push(`<button type="button" class="btn btn-primary btn-sm mt-1"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(fields).length > 0) {
        _push(`<button type="button" class="btn btn-primary mt-1 btn-sm"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435 </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeTestsAndExams/Form.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "VeeTestsAndExamsCard",
  __ssrInlineRender: true,
  props: {
    title: {
      default: "-",
      required: false
    },
    providers: {
      default: {
        hh: false,
        superjob: false
      },
      required: true
    }
  },
  setup(__props, { expose: __expose }) {
    var _a2;
    var _a;
    const props = __props;
    const educationElement = ref(false);
    const route = useRoute();
    const resumeStore = useResumeStore();
    const resumeID = computed(() => route.params.id);
    useDictionaryStore();
    const completed_test_or_exams = ref(
      (_a2 = (_a = resumeStore.resume) == null ? void 0 : _a.educations.completed_test_or_exams) != null ? _a2 : []
    );
    const isShown = ref(false);
    const isChanged = ref(false);
    const isSaved = ref(false);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const { providers } = useProviders();
    const schema = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false) {
        const testScheme2 = z.object({
          name: z.string(),
          profession: z.string(),
          organization: z.string(),
          year: z.number()
        });
        return z.object({
          completed_test_or_exams: z.array(testScheme2).optional()
        });
      }
      if (providers.value.hh === false && providers.value.superjob === true) {
        const testScheme2 = z.object({
          name: z.string(),
          profession: z.string(),
          organization: z.string(),
          year: z.number()
        });
        return z.object({
          completed_test_or_exams: z.array(testScheme2).optional()
        });
      }
      const testScheme = z.object({
        name: z.string(),
        profession: z.string(),
        organization: z.string(),
        year: z.number()
      });
      return z.object({
        completed_test_or_exams: z.array(testScheme).optional()
      });
    });
    const initialValues = ref({
      completed_test_or_exams: []
    });
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const sectionData = ref({
      educations: []
    });
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        var _a22;
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          if (((_a22 = newData.completed_test_or_exams) == null ? void 0 : _a22.length) > 0) {
            isShown.value = true;
          }
          resetForm({ values: newData });
        }
      }
    );
    const getFields = (newObject) => {
      var _a22;
      return {
        completed_test_or_exams: (_a22 = newObject == null ? void 0 : newObject.educations) == null ? void 0 : _a22.completed_test_or_exams.map(
          (item) => ({
            name: item.name,
            organization: item.organization,
            profession: item.profession,
            year: item.year
          })
        )
      };
    };
    watch(
      () => resumeStore.my_resume,
      (newResume) => {
        if (newResume) {
          sectionData.value = getFields(newResume);
        }
      }
    );
    watch(
      () => completed_test_or_exams.value,
      (newData) => {
        isChanged.value = true;
      }
    );
    watch(
      () => isCollapsed.value,
      (newData) => {
        if (!newData) {
          isShown.value = true;
        }
      }
    );
    const { getSelectedProviders } = useResumeHooks();
    const { getResume, updateResume } = resumeStore;
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          console.log(backendErrors);
          setErrors(backendErrors);
        }
      }
    );
    ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        return false;
      }
      setErrors({});
      const resData = await updateResume(resumeID.value, {
        form_data: "EDUCATION_DATA",
        educations: {
          completed_test_or_exams: values.completed_test_or_exams
        },
        providers: getSelectedProviders(props.providers)
      });
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = true;
      setErrors({});
      resetForm({ values });
    };
    const isCompleted = computed(() => {
      var _a22, _b;
      return ((_b = (_a22 = resumeStore.resume) == null ? void 0 : _a22.educations.primary) == null ? void 0 : _b.length) > 0;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeVeeTestsAndExamsForm = __nuxt_component_0;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0422\u0435\u0441\u0442\u043E\u0432 \u0438\u043B\u0438 \u044D\u043A\u0437\u0430\u043C\u0435\u043D\u043E\u0432</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "text-danger d-block p-4" }, ssrGetDirectiveProps(_ctx, _directive_click_outside, (e) => unref(errors).message = "")))}>${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}">`);
      if (unref(isShown)) {
        _push(`<div class=""><div class="row"><div class="mt-3">`);
        _push(ssrRenderComponent(_component_CreateResumeVeeTestsAndExamsForm, {
          ref_key: "educationElement",
          ref: educationElement,
          name: "completed_test_or_exams"
        }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<div class="empty-area"><span>\u0417\u0434\u0435\u0441\u044C \u0432\u044B \u043C\u043E\u0436\u0435\u0442\u0435 \u0443\u043A\u0430\u0437\u0430\u0442\u044C</span><button class="add" type="button"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button></div>`);
      }
      if (unref(isSaved)) {
        _push(`<span class="p-3 d-inline-flex justify-content-center align-items-center" style="${ssrRenderStyle({ "color": "#0c0" })}"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="me-2"><path fill="#0c0" d="M10.041 17l-4.5-4.319 1.395-1.435 3.08 2.937 7.021-7.183 1.422 1.409-8.418 8.591zm5.959 7v-2h-8v2h8zm0-24v2h-8v-2h8zm2 0h1c2.762 0 5 2.239 5 5v1h-2v-1c0-1.654-1.346-3-3-3h-1v-2zm6 16h-2v-8h2v8zm-18 8h-1c-2.762 0-5-2.239-5-5v-1h2v1c0 1.654 1.346 3 3 3h1v2zm18-6v1c0 2.761-2.238 5-5 5h-1v-2h1c1.654 0 3-1.346 3-3v-1h2zm-24-12v-1c0-2.761 2.238-5 5-5h1v2h-1c-1.654 0-3 1.346-3 3v1h-2zm0 2h2v8h-2v-8z"></path></svg> \u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D </span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeTestsAndExamsCard.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_10 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "VeeCitizenshipAndFamilyCard",
  __ssrInlineRender: true,
  async setup(__props, { expose: __expose }) {
    let __temp, __restore;
    const resumeStore = useResumeStore();
    const profileStore = useProfileStore();
    const dictionaryStore = useDictionaryStore();
    const { getMaritalStatusForResume, getTravelTimeOptions, getResumeChildren } = dictionaryStore;
    [__temp, __restore] = withAsyncContext(() => getMaritalStatusForResume()), await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => getTravelTimeOptions()), await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => getResumeChildren()), await __temp, __restore();
    const { getCountries } = profileStore;
    [__temp, __restore] = withAsyncContext(() => getCountries()), await __temp, __restore();
    const countryOptions = computed(
      () => profileStore.countries.map((item) => ({ name: item.name, value: item.id }))
    );
    const maritalStatusOptions = computed(
      () => dictionaryStore.resume_marital_statuses.map((item) => ({
        value: item.id,
        name: item.name
      }))
    );
    const travelTimeOptions = computed(
      () => dictionaryStore.travel_times.map((item) => ({
        value: item.id,
        name: item.name
      }))
    );
    const childrenOptions = computed(
      () => dictionaryStore.resume_children.map((item) => ({
        value: item.id,
        name: item.name
      }))
    );
    const route = useRoute();
    const resumeID = computed(() => route.params.id);
    const my_resume = computed(() => resumeStore.my_resume);
    const isShown = ref(false);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(true);
    const isUpdated = ref(false);
    const { providers } = useProviders();
    const state = reactive({
      citizenship: {
        is_hidden: false
      },
      work_tickets: {
        is_hidden: false
      },
      children_id: {
        is_hidden: false
      },
      marital_status_id: {
        is_hidden: false
      },
      travel_time_id: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        citizenship: true,
        work_tickets: false,
        children_id: null,
        marital_status_id: null,
        travel_time_id: true
      },
      superjob: {
        citizenship: false,
        work_tickets: null,
        travel_time_id: null,
        children_id: false,
        marital_status_id: false
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    watch(
      () => providers.value,
      () => {
        walkThroughFields(providers.value);
      }
    );
    const schema = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false) {
        return z.object({
          citizenship: z.array(z.number()).nonempty(),
          work_tickets: z.number().array().nonempty(),
          marital_status_id: z.number().optional(),
          travel_time_id: z.number(),
          children_id: z.number().optional()
        });
      }
      if (providers.value.hh === false && providers.value.superjob === true) {
        return z.object({
          citizenship: z.array(z.number()).nonempty(),
          work_tickets: z.number().array().nonempty().nullable().optional(),
          marital_status_id: z.number().optional().nullable(),
          travel_time_id: z.number().nullish().optional(),
          children_id: z.number().nullable().optional()
        });
      }
      return z.object({
        citizenship: z.array(z.number()).nonempty(),
        work_tickets: z.number().array().nonempty(),
        marital_status_id: z.number().optional(),
        travel_time_id: z.number(),
        children_id: z.number().nullable()
      });
    });
    const initialValues = ref({
      citizenship: [],
      work_tickets: [],
      marital_status_id: null,
      travel_time_id: null,
      children_id: null
    });
    const {
      values,
      errors,
      meta,
      resetForm,
      setValues,
      setErrors,
      handleSubmit,
      validate
    } = useForm({
      initialValues,
      initialTouched: true,
      validationSchema: toTypedSchema(schema.value)
    });
    const sectionData = ref({});
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    const getFields = (newObject) => {
      var _a2, _b2;
      var _a, _b, _c;
      return {
        citizenship: newObject == null ? void 0 : newObject.citizenship.map((item) => item.id),
        work_tickets: newObject == null ? void 0 : newObject.work_tickets.map((item) => item.id),
        children_id: (_a2 = (_a = newObject == null ? void 0 : newObject.children) == null ? void 0 : _a.id) != null ? _a2 : null,
        marital_status_id: (_b2 = (_b = newObject == null ? void 0 : newObject.marital_status) == null ? void 0 : _b.id) != null ? _b2 : null,
        travel_time_id: (_c = newObject == null ? void 0 : newObject.travel_time) == null ? void 0 : _c.id
      };
    };
    watch(
      () => resumeStore.my_resume,
      (newResume) => {
        if (newResume) {
          sectionData.value = getFields(newResume);
        }
      }
    );
    watch(
      () => isCollapsed.value,
      (newData) => {
        if (!newData) {
          isShown.value = true;
        }
      }
    );
    const { updateResume } = resumeStore;
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    ref(false);
    const isLoading = ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        return false;
      }
      isLoading.value = true;
      setErrors({});
      errorMessage.value = "";
      let resData = {};
      resData = await updateResume(resumeID.value, {
        form_data: "CITIZENSHIP_AND_FAMILY_DATA",
        ...JSON.parse(JSON.stringify(values))
      });
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = false;
      setErrors({});
      resetForm({ values });
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const myResume = my_resume.value;
      if (myResume) {
        return myResume.citizenship && myResume.about && myResume.has_children && myResume.marital_status_id;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeMultiSelectWithSearch = __nuxt_component_1$1;
      const _component_VeeCustomSelect = __nuxt_component_2$1;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0413\u0440\u0430\u0436\u0434\u0430\u043D\u0441\u0442\u0432\u043E \u0438 \u0421\u0435\u043C\u044C\u044F</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
      if (unref(errors).message) {
        _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="row w-100 mt-2" style="${ssrRenderStyle(!unref(state).citizenship.is_hidden ? null : { display: "none" })}"><div class="col-12"><label for="about_me">\u0413\u0440\u0430\u0436\u0434\u0430\u043D\u0441\u0442\u0432\u043E</label>`);
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, {
        options: unref(countryOptions),
        name: "citizenship",
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="row w-100 mt-4"><div class="col-12"><label for="about_me">\u0421\u0442\u0440\u0430\u043D\u044B \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043E \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C</label>`);
      _push(ssrRenderComponent(_component_VeeMultiSelectWithSearch, {
        options: unref(countryOptions),
        name: "work_tickets",
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div class="row w-100 mt-4" style="${ssrRenderStyle(!unref(state).marital_status_id.is_hidden ? null : { display: "none" })}"><div class="input-row"><label for="remote-work">\u0421\u0435\u043C\u0435\u0439\u043D\u043E\u0435 \u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435",
        options: unref(maritalStatusOptions),
        name: "marital_status_id"
      }, null, _parent));
      _push(`</div></div></div><div class="row w-100 mt-4" style="${ssrRenderStyle(!unref(state).travel_time_id.is_hidden ? null : { display: "none" })}"><div class="input-row"><label for="remote-work">\u0416\u0435\u043B\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u0432\u0440\u0435\u043C\u044F \u0432 \u043F\u0443\u0442\u0438 \u0434\u043E \u0440\u0430\u0431\u043E\u0442\u044B</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        options: unref(travelTimeOptions),
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435",
        name: "travel_time_id"
      }, null, _parent));
      _push(`</div></div></div><div class="row w-100 mt-4" style="${ssrRenderStyle(!unref(state).children_id.is_hidden ? null : { display: "none" })}"><div class="input-row"><label for="remote-work">\u041D\u0430\u043B\u0438\u0447\u0438\u0435 \u0434\u0435\u0442\u0435\u0439</label><div class="input-wrapper">`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        options: unref(childrenOptions),
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435",
        name: "children_id"
      }, null, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeCitizenshipAndFamilyCard.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_12 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "VeeAccessTypeCard",
  __ssrInlineRender: true,
  props: ["title", "providers"],
  setup(__props, { expose: __expose }) {
    var _a;
    const resumeStore = useResumeStore();
    useProfileStore();
    const route = useRoute();
    const resumeID = computed(() => route.params.id);
    const { updateResume, getMyResume } = resumeStore;
    const my_resume = computed(() => resumeStore.my_resume);
    const isSaved = ref(false);
    const isChanged = ref(false);
    ref(true);
    const isCollapsed = ref(false);
    const isUpdated = ref(false);
    const { providers } = useProviders();
    const isHidden = ref((_a = providers.value.hh) != null ? _a : false);
    watch(
      () => providers.value,
      (newProviders) => {
        isHidden.value = newProviders.hh;
      }
    );
    const schema = computed(() => {
      if (providers.value.hh === true && providers.value.superjob === false) {
        return z.object({
          resume_access_type_id: z.number()
        });
      }
      if (providers.value.hh === false && providers.value.superjob === true) {
        return z.object({
          resume_access_type_id: z.number().optional()
        });
      }
      return z.object({
        resume_access_type_id: z.number()
      });
    });
    const initialValues = ref({
      resume_access_type_id: null
    });
    const { errors, values, setErrors, meta, setValues, resetForm, validate } = useForm({
      initialValues,
      validationSchema: toTypedSchema(schema.value)
    });
    const state = reactive({
      resume_access_type_id: {
        val: null,
        isValid: true
      },
      isFormValid: true,
      isNew: true,
      isLoading: false,
      error: null,
      success: null
    });
    const sectionData = ref({});
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    watch(
      () => resumeStore.my_resume,
      (newData) => {
        var _a2;
        if (newData) {
          sectionData.value = {
            resume_access_type_id: (_a2 = newData.resume_access_type) == null ? void 0 : _a2.id
          };
        }
      }
    );
    const dictionaryStore = useDictionaryStore();
    const resumeAccessTypeOptions = computed(() => {
      return dictionaryStore.resume_access_types.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const { errors: serverErrors, handleErrorResponse } = useFormValidation();
    watch(
      () => serverErrors.value,
      (newErrors) => {
        if (Object.keys(newErrors).length > 0) {
          const backendErrors = {};
          Object.keys(newErrors).map(
            (item) => backendErrors[item] = newErrors[item]
          );
          setErrors(backendErrors);
        }
      }
    );
    const isFocused = ref(false);
    ref(false);
    const errorMessage = ref(null);
    const save = async (is_from_parent = false) => {
      validate();
      if (!meta.value.dirty) {
        return true;
      }
      if (!meta.value.valid) {
        errorMessage.value = "\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F";
        return false;
      }
      state.isLoading = true;
      setErrors({});
      state.errorMessage = "";
      let resData = {};
      resData = await updateResume(resumeID.value, {
        form_data: "ACCESS_DATA",
        ...values
      });
      isUpdated.value = true;
      if (resData.status !== "success") {
        errorMessage.value = resData.message;
        if (resData.hasOwnProperty("errors")) {
          setErrors(resData.errors);
          return;
        }
        return;
      }
      isChanged.value = false;
      isSaved.value = false;
      isUpdated.value = false;
      isFocused.value = false;
      setErrors({});
      resetForm({ values });
      if (is_from_parent) {
        return new Promise((resolve, reject) => {
          resolve(true);
        });
      }
    };
    const isCompleted = computed(() => {
      const newData = my_resume.value;
      if (newData && !isCollapsed.value) {
        return newData.type && newData.type.id;
      }
      return false;
    });
    __expose({
      save
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeCustomSelect = __nuxt_component_2$1;
      const _directive_click_outside = resolveDirective("click-outside");
      if (unref(isHidden)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-box" }, _attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, save)))}><div class="w-box-head"><h3 class="title">\u0412\u0438\u0434\u0438\u043C\u043E\u0441\u0442\u044C</h3><span class="${ssrRenderClass([{ up: unref(isCollapsed), "is-completed": unref(isCompleted) }, "arrow"])}"></span></div>`);
        if (unref(errors).message) {
          _push(`<div class="text-danger d-block p-4">${ssrInterpolate(unref(errors).message)}</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="${ssrRenderClass([{ collapse: unref(isCollapsed) }, "w-box-body"])}"><div class="input-row"><label>\u0422\u0438\u043F \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438:<b>*</b></label><div class="input-wrapper mt-2">`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(resumeAccessTypeOptions),
          name: "resume_access_type_id",
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeAccessTypeCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_13 = _sfc_main$1;
const __nuxt_component_11_lazy = defineAsyncComponent(() => import('./VeeWorkExperienceCard-DhDYPBF_.mjs').then((c) => c.default || c));
const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const resumeStore = useResumeStore();
    computed(() => resumeStore.my_resume);
    const providers = ref({
      superjob: false,
      hh: false
    });
    const { setProviders } = useProviders();
    watch(
      () => providers.value,
      (newValues) => {
        setProviders(newValues);
      }
    );
    const { getMyResume, publishResume } = resumeStore;
    const resumeID = computed(() => route.params.id);
    watch(
      () => route.params.id,
      (newDraftId) => {
        if (newDraftId) {
          getMyResume(resumeID.value);
        }
      }
    );
    const pageTitle = computed(() => {
      var _a;
      if (resumeID == null ? void 0 : resumeID.value) {
        return "Jobeek - " + ((_a = resumeStore.my_resume) == null ? void 0 : _a.title);
      }
      return "\u041C\u043E\u0435 \u0440\u0435\u0437\u044E\u043C\u0435";
    });
    useHead({
      title: pageTitle
    });
    computed(() => {
      return route.query.message;
    });
    const { handleAlert } = useAlert();
    watch(() => route.query.message, handleAlert);
    computed(() => {
      if (providers.value.hh && providers.value.superjob) {
        return ["hh", "superjob"];
      }
      if (providers.value.hh) {
        return ["hh"];
      }
      if (providers.value.superjob) {
        return ["superjob"];
      }
      return [];
    });
    computed(() => {
      const items = [];
      if (hhPublishable.value) {
        items.push("hh");
      }
      if (superjobPublishable.value) {
        items.push("superjob");
      }
      return items;
    });
    const canBePublished = computed(() => {
      if (hhPublishable.value || superjobPublishable.value)
        return true;
      return false;
    });
    const publishableProviderName = computed(() => {
      if (hhPublishable.value === true || superjobPublishable.value === true) {
        if (hhPublishable.value) {
          return "hh";
        }
        if (superjobPublishable.value) {
          return "superjob";
        }
      }
      return null;
    });
    const hhPublishable = ref(false);
    const superjobPublishable = ref(false);
    watch(
      () => resumeStore.my_resume,
      (newResume) => {
        var _a, _b;
        const { can_published } = newResume;
        if (can_published) {
          hhPublishable.value = (_a = can_published.hh) != null ? _a : false;
          superjobPublishable.value = (_b = can_published.superjob) != null ? _b : false;
        }
      }
    );
    const photo_el = ref();
    const personal_fields_el = ref();
    const profession_fields_el = ref();
    const foreign_language_el = ref();
    const driver_licences_el = ref();
    const work_experience_el = ref();
    const education_el = ref();
    const courses_el = ref();
    const citizenship_el = ref();
    const knowledge_and_skills_el = ref();
    const access_el = ref();
    ref(null);
    ref(null);
    ref(null);
    const errors = ref([]);
    const isLoading = ref(false);
    const canOnlyOnePublished = computed(() => {
      if ((hhPublishable.value === true || superjobPublishable.value === true) && (superjobPublishable.value === false || hhPublishable.value === false)) {
        return true;
      }
      return false;
    });
    ref("");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0$7;
      const _component_CreateResumeProviders = __nuxt_component_1;
      const _component_CreateResumePhotoCard = __nuxt_component_2;
      const _component_CreateResumeVeePersonalFieldsCard = __nuxt_component_3$1;
      const _component_CreateResumeVeeProfessionDetailsCard = __nuxt_component_4;
      const _component_CreateResumeVeeForeignLanguagesCard = __nuxt_component_5;
      const _component_CreateResumeVeeDriverLicensesCard = __nuxt_component_6;
      const _component_CreateResumeVeeKnowledgeAndSkillsCard = __nuxt_component_7;
      const _component_CreateResumeVeeEducationCard = __nuxt_component_8;
      const _component_CreateResumeVeeCoursesCard = __nuxt_component_9;
      const _component_CreateResumeVeeTestsAndExamsCard = __nuxt_component_10;
      const _component_LazyCreateResumeVeeWorkExperienceCard = __nuxt_component_11_lazy;
      const _component_CreateResumeVeeCitizenshipAndFamilyCard = __nuxt_component_12;
      const _component_CreateResumeVeeAccessTypeCard = __nuxt_component_13;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet my-resumes-page",
        role: "main"
      }, _attrs))} data-v-0d64b8d6><div class="bg-wrapper position-relative pb-5" data-v-0d64b8d6>`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="wrapper wrapper-1290" data-v-0d64b8d6><div class="update-resume" data-v-0d64b8d6>`);
      if (unref(errors).length) {
        _push(`<div class="errors" data-v-0d64b8d6><!--[-->`);
        ssrRenderList(unref(errors), (item) => {
          _push(`<p class="alert alert-info" data-v-0d64b8d6>${ssrInterpolate(item)}</p>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_CreateResumeProviders, {
        modelValue: unref(providers),
        "onUpdate:modelValue": ($event) => isRef(providers) ? providers.value = $event : null
      }, null, _parent));
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_CreateResumePhotoCard, {
          ref_key: "photo_el",
          ref: photo_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_CreateResumeVeePersonalFieldsCard, {
          key: `personal_fields_el_key_${unref(providers).hh + unref(providers).superjob}`,
          ref_key: "personal_fields_el",
          ref: personal_fields_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_CreateResumeVeeProfessionDetailsCard, {
          key: `prof_fields_el_key_${unref(providers).hh + unref(providers).superjob}`,
          ref_key: "profession_fields_el",
          ref: profession_fields_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_CreateResumeVeeForeignLanguagesCard, {
          key: `languages_el_key_${unref(providers).hh + unref(providers).superjob}`,
          ref_key: "foreign_language_el",
          ref: foreign_language_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_CreateResumeVeeDriverLicensesCard, {
          key: `driver_licenses_el_${unref(providers).hh + unref(providers).superjob}`,
          ref_key: "driver_licences_el",
          ref: driver_licences_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_CreateResumeVeeKnowledgeAndSkillsCard, {
          key: `knowledge_and_skills_el_${unref(providers).hh + unref(providers).superjob}`,
          ref_key: "knowledge_and_skills_el",
          ref: knowledge_and_skills_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_CreateResumeVeeEducationCard, {
          key: `education_el_${unref(providers).hh + unref(providers).superjob}`,
          ref_key: "education_el",
          ref: education_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_CreateResumeVeeCoursesCard, {
          key: `courses_el_${unref(providers).hh + unref(providers).superjob}`,
          ref_key: "courses_el",
          ref: courses_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_CreateResumeVeeTestsAndExamsCard, {
          key: `tests_el_${unref(providers).hh + unref(providers).superjob}`,
          ref_key: "courses_el",
          ref: courses_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_LazyCreateResumeVeeWorkExperienceCard, {
          key: `experience_el_${unref(providers).hh + unref(providers).superjob}`,
          ref_key: "work_experience_el",
          ref: work_experience_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_CreateResumeVeeCitizenshipAndFamilyCard, {
          key: `citizenship_el_${unref(providers).hh + unref(providers).superjob}`,
          ref_key: "citizenship_el",
          ref: citizenship_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(resumeID)) {
        _push(ssrRenderComponent(_component_CreateResumeVeeAccessTypeCard, {
          key: `access_el_${unref(providers).hh + unref(providers).superjob}`,
          ref_key: "access_el",
          ref: access_el,
          providers: unref(providers)
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<p class="text-lg-end" data-v-0d64b8d6> \u041F\u0440\u0438 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0438 \u0440\u0435\u0437\u044E\u043C\u0435 \u0432\u044B \u0441\u043E\u0433\u043B\u0430\u0448\u0430\u0435\u0442\u0435\u0441\u044C \u0441 <a target="_blank" href="https://reg.jobeek.me/rules.pdf" data-v-0d64b8d6>\u043F\u0440\u0430\u0432\u0438\u043B\u0430\u043C\u0438 \u0440\u0430\u0431\u043E\u0442\u044B \u0441\u0435\u0440\u0432\u0438\u0441\u0430</a> \u0438 \u0434\u0430\u0435\u0442\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u0435 \u043D\u0430 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445, \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u0440\u0430\u0441\u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0435\u043D\u0438\u044F </p><div class="form-submit-container mt-2" data-v-0d64b8d6><button class="btn btn-outline-primary" type="button" data-v-0d64b8d6> \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043A\u0430\u043A \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A </button><button class="${ssrRenderClass([{ disabled: !unref(canBePublished) }, "button-accent"])}" type="submit" data-v-0d64b8d6>`);
      if (unref(isLoading)) {
        _push(`<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true" data-v-0d64b8d6></span>`);
      } else {
        _push(`<!---->`);
      }
      _push(` \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0438 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C </button></div>`);
      if (unref(canOnlyOnePublished)) {
        _push(`<p class="float-end text-primary-secondary mt-2" data-v-0d64b8d6> \u0411\u0443\u0434\u0435\u0442 \u043E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u043D\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430 <span class="text-primary" data-v-0d64b8d6>${ssrInterpolate(unref(publishableProviderName).toUpperCase())}</span></p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/my-resume/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-0d64b8d6"]]);

export { _id_ as default };
//# sourceMappingURL=_id_-DOBshS61.mjs.map
