import { V as VeeForm_vue_vue_type_style_index_0_scoped_3f4bdef7_lang } from './VeeForm-styles-1.mjs-BBheLIjb.mjs';
import { V as VeeForm_vue_vue_type_style_index_1_scoped_3f4bdef7_lang } from './VeeForm-styles-2.mjs-BgRI04s2.mjs';

const VeeFormStyles_CdN5gEUy = [VeeForm_vue_vue_type_style_index_0_scoped_3f4bdef7_lang, VeeForm_vue_vue_type_style_index_1_scoped_3f4bdef7_lang];

export { VeeFormStyles_CdN5gEUy as default };
//# sourceMappingURL=VeeForm-styles.CdN5gEUy.mjs.map
