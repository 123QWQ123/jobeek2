const Step03_vue_vue_type_style_index_0_lang = ".form-check-input{height:1.5rem;width:1.5rem}.form-check-input~*{padding-left:1rem}@media (min-width:768px){.create-vacancy__form .step3 .c2{display:flex}.create-vacancy__form .step3 .c2>div{flex:1;width:50%;text-wrap:normal}}.create-vacancy__form .step3 .c2>div .check-block{align-items:center;justify-content:start;white-space:normal}.create-vacancy__form .step3 .c2>div .check-block label{white-space:normal}";

const Step03Styles_CiKryRZC = [Step03_vue_vue_type_style_index_0_lang];

export { Step03Styles_CiKryRZC as default };
//# sourceMappingURL=Step03-styles.CiKryRZC.mjs.map
