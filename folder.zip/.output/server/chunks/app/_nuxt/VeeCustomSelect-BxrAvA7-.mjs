import { useSSRContext, ref, computed, watch, resolveDirective, mergeProps, unref } from 'vue';
import { useField } from 'vee-validate';
import { ssrRenderAttrs, ssrGetDirectiveProps, ssrInterpolate, ssrRenderStyle, ssrRenderList } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const __default__ = {
  name: "CustomSelect"
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: [
    "options",
    "modelValue",
    "label",
    "name",
    "vacancy",
    "listStyles",
    "class"
  ],
  emits: ["change", "update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const isOpen = ref(false);
    const options = computed(() => props.options);
    const label = computed(() => {
      if (selectedOption.value) {
        return selectedOption.value.name;
      }
      return props.label;
    });
    const { value, errorMessage } = useField(() => props.name);
    const selectedOption = ref(null);
    const reApply = (newValue) => {
      const selectedItem = props.options.find(
        (item) => String(value.value) === String(item.value)
      );
      if (selectedItem) {
        selectedOption.value = selectedItem;
      }
    };
    watch(() => value.value, reApply);
    watch(() => props.options, reApply);
    function close() {
      isOpen.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<!--[--><div${ssrRenderAttrs(mergeProps({
        onfocusout: "close",
        class: ["nice-select n-select d-select", { open: unref(isOpen) }],
        style: props.style,
        tabindex: "0"
      }, ssrGetDirectiveProps(_ctx, _directive_click_outside, close)))} data-v-280b0657><span class="current" data-v-280b0657>${ssrInterpolate(unref(label))}</span>`);
      if (unref(isOpen)) {
        _push(`<ul class="list" style="${ssrRenderStyle(__props.listStyles)}" data-v-280b0657><!--[-->`);
        ssrRenderList(unref(options), (item) => {
          _push(`<li class="option" data-v-280b0657>${ssrInterpolate(item.name)}</li>`);
        });
        _push(`<!--]--></ul>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="text-danger d-block" data-v-280b0657>${ssrInterpolate(unref(errorMessage))}</div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/VeeCustomSelect.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-280b0657"]]);

export { __nuxt_component_2 as default };
//# sourceMappingURL=VeeCustomSelect-BxrAvA7-.mjs.map
