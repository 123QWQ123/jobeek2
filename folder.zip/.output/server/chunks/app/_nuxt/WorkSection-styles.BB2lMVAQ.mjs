const WorkSection_vue_vue_type_style_index_0_scoped_b9ab9de4_lang = ".section-head .more[data-v-b9ab9de4]{gap:.3rem}";

const WorkSectionStyles_BB2lMVAQ = [WorkSection_vue_vue_type_style_index_0_scoped_b9ab9de4_lang];

export { WorkSectionStyles_BB2lMVAQ as default };
//# sourceMappingURL=WorkSection-styles.BB2lMVAQ.mjs.map
