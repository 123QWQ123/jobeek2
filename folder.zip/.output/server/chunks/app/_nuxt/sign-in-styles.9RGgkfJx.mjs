const signIn_vue_vue_type_style_index_0_scoped_eab0dd40_lang = ".note p[data-v-eab0dd40]{font-size:15px}@media only screen and (max-width:768px){.note p[data-v-eab0dd40]{font-size:14px}}";

const signInStyles_9RGgkfJx = [signIn_vue_vue_type_style_index_0_scoped_eab0dd40_lang];

export { signInStyles_9RGgkfJx as default };
//# sourceMappingURL=sign-in-styles.9RGgkfJx.mjs.map
