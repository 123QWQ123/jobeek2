import { E as EmployerEditForm_vue_vue_type_style_index_0_lang } from './EmployerEditForm-styles-1.mjs-LUqCgKGD.mjs';
import { E as EmployerEditForm_vue_vue_type_style_index_1_scoped_21aeda6f_lang } from './EmployerEditForm-styles-2.mjs-DQOn_E2F.mjs';

const EmployerEditFormStyles_oY_u7S9s = [EmployerEditForm_vue_vue_type_style_index_0_lang, EmployerEditForm_vue_vue_type_style_index_1_scoped_21aeda6f_lang];

export { EmployerEditFormStyles_oY_u7S9s as default };
//# sourceMappingURL=EmployerEditForm-styles.oY_u7S9s.mjs.map
