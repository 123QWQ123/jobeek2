const Metro_vue_vue_type_style_index_0_scoped_f3b3e42c_lang = ".check-block label[data-v-f3b3e42c]{white-space:pre-wrap}.with_scroll[data-v-f3b3e42c]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-f3b3e42c]{font-weight:700}.is_header .radio-mask[data-v-f3b3e42c],.is_header input[data-v-f3b3e42c]{display:none}input[type=search][data-v-f3b3e42c]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const MetroStyles_CsrCauZs = [Metro_vue_vue_type_style_index_0_scoped_f3b3e42c_lang];

export { MetroStyles_CsrCauZs as default };
//# sourceMappingURL=Metro-styles.CsrCauZs.mjs.map
