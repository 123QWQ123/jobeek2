const Providers_vue_vue_type_style_index_0_scoped_2c852ab4_lang = ".import-box[data-v-2c852ab4]{cursor:pointer}";

const ProvidersStyles_Cg7JVfAQ = [Providers_vue_vue_type_style_index_0_scoped_2c852ab4_lang];

export { ProvidersStyles_Cg7JVfAQ as default };
//# sourceMappingURL=Providers-styles.Cg7JVfAQ.mjs.map
