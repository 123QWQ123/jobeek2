import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0$2 } from './SearchMobile-WfXJ1gHL.mjs';
import { _ as __nuxt_component_0 } from './PageLoader-CgN00RaA.mjs';
import { _ as __nuxt_component_0$1, a as __nuxt_component_1$1, P as PhoneDisabledInput, b as __nuxt_component_4 } from './EmailInput-XpLRM13e.mjs';
import { _ as __nuxt_component_5 } from './BaseButton-CWRjb9_h.mjs';
import { useSSRContext, computed, ref, watch, mergeProps, unref, withCtx, createTextVNode } from 'vue';
import { m as useProfileStore, s as storeToRefs, e as useRoute, u as useHead, k as useAuthStore, d as navigateTo } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { a as useCheckJSON, u as useAlert } from './useAlert-CPK6c05f.mjs';
import { u as useDiff } from './useDiff-Chx28f43.mjs';
import { useForm } from 'vee-validate';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { P as Premium } from './Premium-A3GoIzm5.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './search-CNCM2ROA.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import 'vue-router';
import 'imask';
import './Loader-UZvrxmyZ.mjs';
import './nuxt-link-BdrY0gEc.mjs';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const avatar = "" + buildAssetsURL("company.Dfa_rN2-.png");
const _sfc_main$1 = {
  __name: "EmployerEditForm",
  __ssrInlineRender: true,
  setup(__props) {
    const profileStore = useProfileStore();
    storeToRefs(profileStore);
    const schema = computed(() => {
      return {
        company_name: "required|min:1|max:100",
        company_url: "required|min:1|max:2500",
        company_description: "required|min:1|max:255",
        email: { required: true, email: true }
      };
    });
    const { values, errors, meta, setErrors, resetForm, validate } = useForm({
      initialValues: {
        logo: null,
        company_name: null,
        company_url: null,
        company_description: null,
        email: null
      },
      initialTouched: true,
      validationSchema: schema
    });
    const sectionData = ref({});
    const getFields = (newObject) => {
      var _a;
      return {
        logo: (_a = newObject.logo) != null ? _a : null,
        company_name: newObject.company_name,
        company_description: newObject.company_description,
        email: newObject.email,
        company_url: newObject.company_url,
        logo_url: newObject.logo_url,
        phone: newObject.phone
      };
    };
    watch(
      () => profileStore.employer,
      (newObject) => {
        if (newObject) {
          sectionData.value = getFields(newObject);
        }
      }
    );
    watch(
      () => sectionData.value,
      (newData, oldData) => {
        const diffData = useDiff(newData, oldData);
        if (Object.keys(diffData).length) {
          resetForm({ values: newData });
        }
      }
    );
    const route = useRoute();
    computed(() => {
      if (useCheckJSON(route.query.message)) {
        return JSON.parse(route.query.message).text;
      }
      return route.query.message;
    });
    const isLoading = ref(false);
    ref(null);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PageLoader = __nuxt_component_0;
      const _component_ProfilePhotoInput = __nuxt_component_0$1;
      const _component_CustomTextInput = __nuxt_component_1$1;
      const _component_ProfilePhoneDisabledInput = PhoneDisabledInput;
      const _component_ProfileEmailInput = __nuxt_component_4;
      const _component_base_button = __nuxt_component_5;
      _push(`<form${ssrRenderAttrs(mergeProps({
        class: "w-box-body",
        style: { overflowY: "hidden" }
      }, _attrs))} data-v-21aeda6f>`);
      if (unref(isLoading)) {
        _push(ssrRenderComponent(_component_PageLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_ProfilePhotoInput, {
        name: "logo",
        preview: "logo_url",
        avatar: unref(avatar)
      }, null, _parent));
      _push(`<div class="input-row" data-v-21aeda6f><label for="password" data-v-21aeda6f>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438 <b data-v-21aeda6f>*</b></label><div class="input-wrapper position-relative" data-v-21aeda6f>`);
      _push(ssrRenderComponent(_component_CustomTextInput, {
        type: "text",
        name: "company_name",
        placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435"
      }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-21aeda6f><label for="password" data-v-21aeda6f>\u041E \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438 <b data-v-21aeda6f>*</b></label><div class="input-wrapper position-relative" data-v-21aeda6f>`);
      _push(ssrRenderComponent(_component_CustomTextInput, {
        type: "text",
        name: "company_description"
      }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-21aeda6f><label for="password" data-v-21aeda6f>\u0421\u0430\u0439\u0442 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438<b data-v-21aeda6f>*</b></label><div class="input-wrapper position-relative" data-v-21aeda6f>`);
      _push(ssrRenderComponent(_component_CustomTextInput, {
        type: "text",
        name: "company_url",
        placeholder: "https://"
      }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-21aeda6f><label for="phone" data-v-21aeda6f>\u0422\u0435\u043B\u0435\u0444\u043E\u043D</label><div class="input-wrapper" data-v-21aeda6f>`);
      _push(ssrRenderComponent(_component_ProfilePhoneDisabledInput, { name: "phone" }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-21aeda6f><label for="email" data-v-21aeda6f>\u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u0430\u044F \u043F\u043E\u0447\u0442\u0430<b data-v-21aeda6f>*</b></label><div class="input-wrapper" data-v-21aeda6f>`);
      _push(ssrRenderComponent(_component_ProfileEmailInput, {
        name: "email",
        type: "employer",
        key: "employer_email"
      }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-21aeda6f><label for="password" data-v-21aeda6f>\u041F\u0430\u0440\u043E\u043B\u044C<b data-v-21aeda6f>*</b></label><div class="input-wrapper position-relative" data-v-21aeda6f>`);
      _push(ssrRenderComponent(_component_CustomTextInput, {
        type: "password",
        name: "password",
        placeholder: "********"
      }, null, _parent));
      _push(`</div></div><div class="input-row" data-v-21aeda6f><div class="input-wrapper" data-v-21aeda6f>`);
      _push(ssrRenderComponent(_component_base_button, { type: "submit" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C`);
          } else {
            return [
              createTextVNode("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></form>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Profile/EmployerEditForm.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-21aeda6f"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u0412\u0430\u0448 \u0430\u043A\u043A\u0430\u0443\u043D\u0442"
    });
    const authStore = useAuthStore();
    computed(() => authStore.isEmployer);
    const route = useRoute();
    computed(() => {
      return route.query.message;
    });
    const isCompleted = computed(() => {
      if (!authStore.isEmployer) {
        if (authStore.seeker) {
          return authStore.seeker.is_completed;
        }
        return false;
      }
      if (authStore.isEmployer) {
        if (authStore.employer) {
          return authStore.employer.is_completed;
        }
        return false;
      }
      return false;
    });
    useAlert();
    watch(
      () => authStore.isEmployer,
      (newValue) => {
        console.log(newValue);
        if (!newValue) {
          navigateTo({ name: "profile-seeker" });
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0$2;
      const _component_ProfileEmployerEditForm = __nuxt_component_1;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet profile-page bg-wrapper",
        role: "main"
      }, _attrs))} data-v-c1eda587>`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(`<div class="has-sidebar has-sidebar--v2 wrapper wrapper-1290" data-v-c1eda587><div class="content" data-v-c1eda587>`);
      if (!unref(isCompleted)) {
        _push(`<div class="w-box bg-white" data-v-c1eda587><p class="text-danger p-3" data-v-c1eda587> \u041F\u0435\u0440\u0435\u0434 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u0438 \u0441\u0435\u0440\u0432\u0438\u0441\u0430 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u0432\u0430\u0448\u0435\u0433\u043E \u043F\u0440\u043E\u0444\u0438\u043B\u044F. </p></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="w-box w-box--main" data-v-c1eda587><div class="w-box-head" data-v-c1eda587><h1 class="title" data-v-c1eda587>\u041F\u0440\u043E\u0444\u0438\u043B\u044C</h1></div>`);
      _push(ssrRenderComponent(_component_ProfileEmployerEditForm, null, null, _parent));
      _push(`</div></div><aside class="sidebar" data-v-c1eda587>`);
      _push(ssrRenderComponent(Premium, null, null, _parent));
      _push(`</aside></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/profile/employer/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-c1eda587"]]);

export { index as default };
//# sourceMappingURL=index-C9_3ReZ3.mjs.map
