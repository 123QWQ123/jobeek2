const Item_vue_vue_type_style_index_0_scoped_36348602_lang = ".absoluted_icon[data-v-36348602]{cursor:pointer;font-size:1rem;left:-.5rem;max-width:3rem;position:absolute;top:.5rem;z-index:1}.absoluted_icon svg[data-v-36348602]{height:24px;width:24px}";

const ItemStyles_DJZcywhg = [Item_vue_vue_type_style_index_0_scoped_36348602_lang];

export { ItemStyles_DJZcywhg as default };
//# sourceMappingURL=Item-styles.DJZcywhg.mjs.map
