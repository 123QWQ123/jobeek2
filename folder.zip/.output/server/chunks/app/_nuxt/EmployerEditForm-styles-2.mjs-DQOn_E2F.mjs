const EmployerEditForm_vue_vue_type_style_index_1_scoped_21aeda6f_lang = "@media (max-width:768px){.position-absolute[data-v-21aeda6f],.position-relative[data-v-21aeda6f]{position:static!important}}#photo[data-v-21aeda6f]{cursor:pointer}";

export { EmployerEditForm_vue_vue_type_style_index_1_scoped_21aeda6f_lang as E };
//# sourceMappingURL=EmployerEditForm-styles-2.mjs-DQOn_E2F.mjs.map
