import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as _imports_0, a as __nuxt_component_0$2 } from './search-CNCM2ROA.mjs';
import { u as useQueryParams, _ as __nuxt_component_1$1 } from './useQueryParams-Bpl0Cf82.mjs';
import { useSSRContext, ref, watch, unref, isRef, mergeProps, computed, withCtx, createTextVNode, createVNode, openBlock, createBlock, toDisplayString, Fragment, renderList } from 'vue';
import { o as defineStore, u as useHead, k as useAuthStore, a as useRouter, e as useRoute, l as useVacancyStore, m as useProfileStore, q as useApi, j as useNuxtApp } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { _ as __nuxt_component_0$3 } from './nuxt-link-BdrY0gEc.mjs';
import { _ as __nuxt_component_0$4 } from './BlockLoader-RiL0eLJn.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { _ as _imports_0$1 } from './megafon-UViF3Tze.mjs';
import { _ as __nuxt_component_2$1, a as __nuxt_component_3$1 } from './SearchSection-BlAf03bK.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './state-D1MfAAni.mjs';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './dictionary--F10-rgU.mjs';

const _sfc_main$5 = {
  __name: "Form2",
  __ssrInlineRender: true,
  props: {
    with_wrapper: {
      default: false
    }
  },
  setup(__props) {
    var _a2, _b;
    var _a;
    const props = __props;
    useAuthStore();
    const { getCurrentQueryParams, getQueryParam } = useQueryParams();
    ref((_a2 = getCurrentQueryParams()) != null ? _a2 : {});
    useRouter();
    const route = useRoute();
    useVacancyStore();
    const profileStore = useProfileStore();
    const search = ref((_b = (_a = route.query) == null ? void 0 : _a.name) != null ? _b : void 0);
    const salary = ref({
      min: void 0,
      max: void 0,
      value: void 0
    });
    salary.value = getQueryParam("salary");
    const city = ref(null);
    watch(
      () => getQueryParam("salary"),
      (newValue) => {
        console.log(newValue);
        salary.value = newValue;
      }
    );
    const onCityChange = (cityItem) => {
      if (cityItem.value === null) {
        city.value = void 0;
      } else {
        city.value = cityItem.value;
      }
    };
    const { searchCities } = profileStore;
    const updateCityInput = async (newValue = "") => {
      var _a3;
      const items = (_a3 = await searchCities({ search: newValue })) != null ? _a3 : [];
      cityOptions.value = items.map((item) => ({
        value: item.id,
        name: item.name
      }));
    };
    const cityOptions = ref([]);
    ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderSalarySelectInForm = __nuxt_component_0$2;
      const _component_SelectWithSearch = __nuxt_component_1$1;
      if (props.with_wrapper) {
        _push(`<div${ssrRenderAttrs(_attrs)} data-v-79b81ab5><div class="wrapper" data-v-79b81ab5><form class="search-form" role="form" autocomplete="off" data-v-79b81ab5><div class="search-row" data-v-79b81ab5><div class="input-wrap has-icon has-label" data-v-79b81ab5><img class="icon"${ssrRenderAttr("src", _imports_0)} alt="#" data-v-79b81ab5><label for="name" data-v-79b81ab5>\u041F\u043E\u0438\u0441\u043A </label><input type="text" name="name" id="keyword" placeholder="\u041A\u0430\u043A\u0443\u044E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E \u0432\u044B \u0438\u0449\u0435\u0442\u0435" autocomplete="off"${ssrRenderAttr("value", unref(search))} data-v-79b81ab5></div><div class="input-wrap has-label" data-v-79b81ab5><label for="salary" data-v-79b81ab5>\u0416\u0435\u043B\u0430\u0435\u043C\u0430\u044F \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0430</label>`);
        _push(ssrRenderComponent(_component_HeaderSalarySelectInForm, {
          modelValue: unref(salary),
          "onUpdate:modelValue": ($event) => isRef(salary) ? salary.value = $event : null
        }, null, _parent));
        _push(`</div><div class="input-wrap has-label" data-v-79b81ab5><label for="salary" data-v-79b81ab5>\u0413\u043E\u0440\u043E\u0434</label>`);
        _push(ssrRenderComponent(_component_SelectWithSearch, {
          options: unref(cityOptions),
          modelValue: unref(city),
          "onUpdate:modelValue": ($event) => isRef(city) ? city.value = $event : null,
          modelModifiers: { number: true },
          placeholder: "\u0413\u043E\u0440\u043E\u0434",
          onInput: updateCityInput,
          onChange: onCityChange
        }, null, _parent));
        _push(`</div><button class="button-accent submit-search-form" type="button" data-v-79b81ab5> \u041F\u043E\u0438\u0441\u043A </button></div></form></div></div>`);
      } else {
        _push(`<form${ssrRenderAttrs(mergeProps({
          class: "search-form",
          role: "form",
          autocomplete: "off"
        }, _attrs))} data-v-79b81ab5><div class="search-row" data-v-79b81ab5><div class="input-wrap has-icon has-label" data-v-79b81ab5><img class="icon"${ssrRenderAttr("src", _imports_0)} alt="#" data-v-79b81ab5><label for="name" data-v-79b81ab5>\u041F\u043E\u0438\u0441\u043A </label><input type="text" name="name" id="keyword"${ssrRenderAttr("placeholder", _ctx.searchPlaceHolder)} autocomplete="off"${ssrRenderAttr("value", unref(search))} data-v-79b81ab5></div><div class="input-wrap has-label" data-v-79b81ab5><label for="salary" data-v-79b81ab5>\u0416\u0435\u043B\u0430\u0435\u043C\u0430\u044F \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0430</label>`);
        _push(ssrRenderComponent(_component_HeaderSalarySelectInForm, {
          modelValue: unref(salary),
          "onUpdate:modelValue": ($event) => isRef(salary) ? salary.value = $event : null
        }, null, _parent));
        _push(`</div><div class="input-wrap has-label" data-v-79b81ab5><label for="salary" data-v-79b81ab5>\u0413\u043E\u0440\u043E\u0434</label>`);
        _push(ssrRenderComponent(_component_SelectWithSearch, {
          options: unref(cityOptions),
          modelValue: unref(city),
          "onUpdate:modelValue": ($event) => isRef(city) ? city.value = $event : null,
          modelModifiers: { number: true },
          placeholder: "\u0413\u043E\u0440\u043E\u0434",
          class: "no_bg",
          onInput: updateCityInput,
          onChange: onCityChange
        }, null, _parent));
        _push(`</div><button class="button-accent submit-search-form" type="button" data-v-79b81ab5> \u041F\u043E\u0438\u0441\u043A </button></div></form>`);
      }
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Search/Form2.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-79b81ab5"]]);
const _sfc_main$4 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  const _component_SearchForm2 = __nuxt_component_0$1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "main-section" }, _attrs))}><div class="wrapper wrapper--xl"><div class="main-section-title"><h1 class="title">\u041F\u043E\u0438\u0441\u043A \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439</h1></div>`);
  _push(ssrRenderComponent(_component_SearchForm2, null, null, _parent));
  _push(`</div></div>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/MainSection.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$2]]);
const _sfc_main$3 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$3;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "place-section section wrapper" }, _attrs))}><div class="place-card place-card--vacancy"><h4 class="place-card-title">\u0420\u0430\u0431\u043E\u0442\u0430</h4><p class="place-card-descr"><strong>Jobeek</strong> \u2014 \u044D\u0442\u043E \u043B\u0443\u0447\u0448\u0438\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0432\u044B\u0441\u043E\u043A\u043E\u043E\u043F\u043B\u0430\u0447\u0438\u0432\u0430\u0435\u043C\u043E\u0439 \u0440\u0430\u0431\u043E\u0442\u044B \u043E\u0442\xA0\u0440\u043E\u0441\u0441\u0438\u0439\u0441\u043A\u0438\u0445 \u0438\xA0 \u0437\u0430\u0440\u0443\u0431\u0435\u0436\u043D\u044B\u0445 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0439.</p>`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: { name: "create-resume" },
    class: "btn button-accent button-accent--ts-bigger"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u0420\u0430\u0437\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0440\u0435\u0437\u044E\u043C\u0435`);
      } else {
        return [
          createTextVNode("\u0420\u0430\u0437\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0440\u0435\u0437\u044E\u043C\u0435")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="place-card place-card--resume"><h4 class="place-card-title">\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0438</h4><p class="place-card-descr"><strong>Jobeek</strong> \u2014 \u0441\u0430\u043C\u0430\u044F \u0431\u043E\u043B\u044C\u0448\u0430\u044F \u0438\xA0\u043A\u0430\u0447\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u0431\u0430\u0437\u0430 \u0440\u0435\u0437\u044E\u043C\u0435 \u043B\u0443\u0447\u0448\u0438\u0445 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0441\u0442\u043E\u0432 \u0432\xA0\u0420\u043E\u0441\u0441\u0438\u0438.</p>`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: { name: "create-vacancy" },
    class: "btn button-accent button-accent--ts-bigger"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u0420\u0430\u0437\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E `);
      } else {
        return [
          createTextVNode("\u0420\u0430\u0437\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/PlaceSection.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$1]]);
const useAreaStore = defineStore("area", {
  state: () => {
    return {
      countries: [],
      regions: [],
      cities: [],
      location: {}
    };
  },
  actions: {
    async getRegions(payload) {
      const { data } = await useApi("area/regions", {
        method: "get",
        payload
      });
      if (data) {
        this.regions = data.data.regions;
      }
      return data;
    },
    async getLocation(payload) {
      const { data } = await useApi("area/location", {
        method: "get",
        params: payload
      });
      if (data) {
        this.location = data.data;
      }
      return data;
    }
  }
});
const _sfc_main$2 = {
  __name: "VacancySection",
  __ssrInlineRender: true,
  setup(__props) {
    const { $format_number } = useNuxtApp();
    const vacancyStore = useVacancyStore();
    useAreaStore();
    const isLoading = ref(false);
    const vacancies = computed(() => vacancyStore.vacancies_in_my_city.sort());
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$3;
      const _component_BlockLoader = __nuxt_component_0$4;
      const _component_swiper = Swiper;
      const _component_swiper_slide = SwiperSlide;
      const _component_nuxt_link = __nuxt_component_0$3;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "vacancy-section section wrapper" }, _attrs))}><div class="section-head"><h2 class="section-title">\u0412\u0430\u043A\u0430\u043D\u0441\u0438\u0438 \u0432 \u0432\u0430\u0448\u0435\u043C \u0433\u043E\u0440\u043E\u0434\u0435</h2>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "more",
        to: {
          name: "search-vacancies",
          query: { countries: [1], regions: [22] }
        }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u0412\u0441\u0435 <span class="ms-1"${_scopeId}> \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 </span><svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId}><path d="M19.75 12.2256L4.75 12.2256" stroke="#5375FD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M13.7002 6.20124L19.7502 12.2252L13.7002 18.2502" stroke="#5375FD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path></svg>`);
          } else {
            return [
              createTextVNode(" \u0412\u0441\u0435 "),
              createVNode("span", { class: "ms-1" }, " \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 "),
              (openBlock(), createBlock("svg", {
                width: "24",
                height: "25",
                viewBox: "0 0 24 25",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
              }, [
                createVNode("path", {
                  d: "M19.75 12.2256L4.75 12.2256",
                  stroke: "#5375FD",
                  "stroke-width": "1.5",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                }),
                createVNode("path", {
                  d: "M13.7002 6.20124L19.7502 12.2252L13.7002 18.2502",
                  stroke: "#5375FD",
                  "stroke-width": "1.5",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (unref(isLoading)) {
        _push(`<div class="position-relative">`);
        _push(ssrRenderComponent(_component_BlockLoader, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_swiper, {
          "slides-per-view": "auto",
          "space-between": 20,
          class: "cards-slider",
          "wrapper-class": "vacancy-list"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<!--[-->`);
              ssrRenderList(unref(vacancies), (item) => {
                _push2(ssrRenderComponent(_component_swiper_slide, null, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<div class="vacancy-card"${_scopeId2}><div class="vacancy-card-body"${_scopeId2}><div class="company"${_scopeId2}><div class="company-logo"${_scopeId2}><img${ssrRenderAttr("src", _imports_0$1)} alt="#"${_scopeId2}></div><div class="company-name"${_scopeId2}><strong${_scopeId2}>${ssrInterpolate(item.company)}</strong><span class="location"${_scopeId2}>${ssrInterpolate(item.city)}</span></div></div>`);
                      _push3(ssrRenderComponent(_component_nuxt_link, {
                        to: {
                          name: "vacancies-slug",
                          params: { slug: item.id },
                          query: { provider: item.provider }
                        },
                        class: "vacancy-card-title"
                      }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`${ssrInterpolate(item.name)}`);
                          } else {
                            return [
                              createTextVNode(toDisplayString(item.name), 1)
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                      if (item.salary_from) {
                        _push3(`<span class="vacancy-card-dop-info"${_scopeId2}>\u041E\u0442 ${ssrInterpolate(unref($format_number)(item.salary_from))} \u20BD</span>`);
                      } else {
                        _push3(`<span class="vacancy-card-dop-info"${_scopeId2}>\u0414\u043E ${ssrInterpolate(unref($format_number)(item.salary_to))} \u20BD</span>`);
                      }
                      _push3(`</div><div class="vacancy-card-footer"${_scopeId2}><a class="btn button-md" href="#"${_scopeId2}>\u041E\u0442\u043A\u043B\u0438\u043A\u043D\u0443\u0442\u044C\u0441\u044F</a></div></div>`);
                    } else {
                      return [
                        createVNode("div", { class: "vacancy-card" }, [
                          createVNode("div", { class: "vacancy-card-body" }, [
                            createVNode("div", { class: "company" }, [
                              createVNode("div", { class: "company-logo" }, [
                                createVNode("img", {
                                  src: _imports_0$1,
                                  alt: "#"
                                })
                              ]),
                              createVNode("div", { class: "company-name" }, [
                                createVNode("strong", null, toDisplayString(item.company), 1),
                                createVNode("span", { class: "location" }, toDisplayString(item.city), 1)
                              ])
                            ]),
                            createVNode(_component_nuxt_link, {
                              to: {
                                name: "vacancies-slug",
                                params: { slug: item.id },
                                query: { provider: item.provider }
                              },
                              class: "vacancy-card-title"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(item.name), 1)
                              ]),
                              _: 2
                            }, 1032, ["to"]),
                            item.salary_from ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "vacancy-card-dop-info"
                            }, "\u041E\u0442 " + toDisplayString(unref($format_number)(item.salary_from)) + " \u20BD", 1)) : (openBlock(), createBlock("span", {
                              key: 1,
                              class: "vacancy-card-dop-info"
                            }, "\u0414\u043E " + toDisplayString(unref($format_number)(item.salary_to)) + " \u20BD", 1))
                          ]),
                          createVNode("div", { class: "vacancy-card-footer" }, [
                            createVNode("a", {
                              class: "btn button-md",
                              href: "#"
                            }, "\u041E\u0442\u043A\u043B\u0438\u043A\u043D\u0443\u0442\u044C\u0441\u044F")
                          ])
                        ])
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
            } else {
              return [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(vacancies), (item) => {
                  return openBlock(), createBlock(_component_swiper_slide, null, {
                    default: withCtx(() => [
                      createVNode("div", { class: "vacancy-card" }, [
                        createVNode("div", { class: "vacancy-card-body" }, [
                          createVNode("div", { class: "company" }, [
                            createVNode("div", { class: "company-logo" }, [
                              createVNode("img", {
                                src: _imports_0$1,
                                alt: "#"
                              })
                            ]),
                            createVNode("div", { class: "company-name" }, [
                              createVNode("strong", null, toDisplayString(item.company), 1),
                              createVNode("span", { class: "location" }, toDisplayString(item.city), 1)
                            ])
                          ]),
                          createVNode(_component_nuxt_link, {
                            to: {
                              name: "vacancies-slug",
                              params: { slug: item.id },
                              query: { provider: item.provider }
                            },
                            class: "vacancy-card-title"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(item.name), 1)
                            ]),
                            _: 2
                          }, 1032, ["to"]),
                          item.salary_from ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "vacancy-card-dop-info"
                          }, "\u041E\u0442 " + toDisplayString(unref($format_number)(item.salary_from)) + " \u20BD", 1)) : (openBlock(), createBlock("span", {
                            key: 1,
                            class: "vacancy-card-dop-info"
                          }, "\u0414\u043E " + toDisplayString(unref($format_number)(item.salary_to)) + " \u20BD", 1))
                        ]),
                        createVNode("div", { class: "vacancy-card-footer" }, [
                          createVNode("a", {
                            class: "btn button-md",
                            href: "#"
                          }, "\u041E\u0442\u043A\u043B\u0438\u043A\u043D\u0443\u0442\u044C\u0441\u044F")
                        ])
                      ])
                    ]),
                    _: 2
                  }, 1024);
                }), 256))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      }
      _push(`</section>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/VacancySection.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$2;
const _imports_1 = "" + buildAssetsURL("logo1.B2QDyeyN.svg");
const _imports_2 = "" + buildAssetsURL("logo2.B2pZHhRH.svg");
const _imports_3 = "" + buildAssetsURL("logo3.knVlDNHx.svg");
const _imports_4 = "" + buildAssetsURL("logo4.kRuTzZij.svg");
const _imports_5 = "" + buildAssetsURL("logo5.DUiB4nnM.svg");
const _imports_6 = "" + buildAssetsURL("logo6.nxhwF33s.svg");
const _imports_7 = "" + buildAssetsURL("logo7.D9AYPMuw.svg");
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "companies-section section wrapper" }, _attrs))}><div class="section-head"><h2 class="section-title"> \u0420\u0430\u0431\u043E\u0442\u0430\u0439\u0442\u0435 \u0443 \u043B\u0443\u0447\u0448\u0438\u0445</h2></div><ul class="companies-list"><li><a class="company company-card" href="#"><div class="company-logo"><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div><div class="company-name"><strong>\u041C\u0435\u0433\u0430\u0444\u043E\u043D</strong><span class="count">21 142 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</span></div></a></li><li><a class="company company-card" href="#"><div class="company-logo"><img${ssrRenderAttr("src", _imports_1)} alt="#"></div><div class="company-name"><strong>\u041C\u0435\u0433\u0430\u0444\u043E\u043D</strong><span class="count">21 142 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</span></div></a></li><li><a class="company company-card" href="#"><div class="company-logo"><img${ssrRenderAttr("src", _imports_2)} alt="#"></div><div class="company-name"><strong>\u041C\u0435\u0433\u0430\u0444\u043E\u043D</strong><span class="count">21 142 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</span></div></a></li><li><a class="company company-card" href="#"><div class="company-logo"><img${ssrRenderAttr("src", _imports_3)} alt="#"></div><div class="company-name"><strong>\u041C\u0435\u0433\u0430\u0444\u043E\u043D</strong><span class="count">21 142 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</span></div></a></li><li><a class="company company-card" href="#"><div class="company-logo"><img${ssrRenderAttr("src", _imports_4)} alt="#"></div><div class="company-name"><strong>\u041C\u0435\u0433\u0430\u0444\u043E\u043D</strong><span class="count">21 142 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</span></div></a></li><li><a class="company company-card" href="#"><div class="company-logo"><img${ssrRenderAttr("src", _imports_5)} alt="#"></div><div class="company-name"><strong>\u041C\u0435\u0433\u0430\u0444\u043E\u043D</strong><span class="count">21 142 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</span></div></a></li><li><a class="company company-card" href="#"><div class="company-logo"><img${ssrRenderAttr("src", _imports_6)} alt="#"></div><div class="company-name"><strong>\u041C\u0435\u0433\u0430\u0444\u043E\u043D</strong><span class="count">21 142 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</span></div></a></li><li><a class="company company-card" href="#"><div class="company-logo"><img${ssrRenderAttr("src", _imports_7)} alt="#"></div><div class="company-name"><strong>\u041C\u0435\u0433\u0430\u0444\u043E\u043D</strong><span class="count">21 142 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 </span></div></a></li></ul></section>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/CompaniesSection.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Jobeek - \u0432\u0441\u0435 \u0434\u043B\u044F \u0432\u0430\u0448\u0435\u0433\u043E \u0443\u0434\u043E\u0431\u0441\u0442\u0432\u0430"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HomeMainSection = __nuxt_component_0;
      const _component_HomePlaceSection = __nuxt_component_1;
      const _component_HomeVacancySection = __nuxt_component_2;
      const _component_HomeCompaniesSection = __nuxt_component_3;
      const _component_HomeWorkSection = __nuxt_component_2$1;
      const _component_HomeSearchSection = __nuxt_component_3$1;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_HomeMainSection, null, null, _parent));
      _push(ssrRenderComponent(_component_HomePlaceSection, null, null, _parent));
      _push(ssrRenderComponent(_component_HomeVacancySection, null, null, _parent));
      _push(ssrRenderComponent(_component_HomeCompaniesSection, null, null, _parent));
      _push(ssrRenderComponent(_component_HomeWorkSection, null, null, _parent));
      _push(ssrRenderComponent(_component_HomeSearchSection, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-De9AoKx_.mjs.map
