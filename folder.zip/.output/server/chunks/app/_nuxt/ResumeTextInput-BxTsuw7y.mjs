import { useSSRContext, unref } from 'vue';
import { ssrRenderDynamicModel, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { useField } from 'vee-validate';

const __default__ = {
  name: "ResumeTextInput"
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __ssrInlineRender: true,
  props: {
    name: String,
    type: String,
    placeholder: String
  },
  setup(__props) {
    const props = __props;
    const { value, errorMessage } = useField(() => props.name);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><input${ssrRenderDynamicModel(props.type, unref(value), null)}${ssrRenderAttr("type", props.type)}${ssrRenderAttr("placeholder", props.placeholder)}>`);
      if (unref(errorMessage)) {
        _push(`<div class="text-danger d-block">${ssrInterpolate(unref(errorMessage))}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/ResumeTextInput.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ResumeTextInput = _sfc_main;

export { ResumeTextInput as R };
//# sourceMappingURL=ResumeTextInput-BxTsuw7y.mjs.map
