import { useSSRContext, mergeProps, ref, watch, unref, computed } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseEqual, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import { _ as _imports_0$2 } from './check-BGWLIG1L.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const _sfc_main$3 = {
  __name: "Radio",
  __ssrInlineRender: true,
  props: {
    name: String,
    label: String,
    value: {},
    id: String,
    modelValue: {
      default: void 0
    },
    is_header: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const modelValue = ref(props.modelValue);
    watch(
      () => props.modelValue,
      (newValue) => {
        modelValue.value = newValue;
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-9568e619><div class="checkbox" data-v-9568e619><input type="radio"${ssrRenderAttr("value", props.value)}${ssrIncludeBooleanAttr(ssrLooseEqual(unref(modelValue), props.value)) ? " checked" : ""}${ssrRenderAttr("name", props.name)}${ssrRenderAttr("id", props.id)} data-v-9568e619><div class="radio-mask" data-v-9568e619><img${ssrRenderAttr("src", _imports_0$2)} alt="#" data-v-9568e619></div></div><label${ssrRenderAttr("for", props.id)} class="fs-14 l-wrap" data-v-9568e619>${ssrInterpolate(props.label)}</label></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Radio.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0$2 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-9568e619"]]);
const _imports_0$1 = "data:image/svg+xml,%3csvg%20width='20'%20height='20'%20viewBox='0%200%2020%2020'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M5%207.5L10%2012.5L15%207.5'%20stroke='%2378757E'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e";
const _sfc_main$2 = {
  __name: "Checkbox",
  __ssrInlineRender: true,
  props: {
    name: String,
    label: String,
    checked: {
      type: Boolean,
      required: true,
      default: false
    },
    is_header: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  emits: ["change"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    computed(() => {
      return props.checked;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["check-block", { is_header: props.is_header }]
      }, _attrs))} data-v-0f2f834e>`);
      if (!props.is_header) {
        _push(`<div class="checkbox" data-v-0f2f834e><input type="checkbox"${ssrRenderAttr("name", props.name)}${ssrRenderAttr("id", props.name)}${ssrIncludeBooleanAttr(props.checked) ? " checked" : ""} data-v-0f2f834e><div class="${ssrRenderClass([{ checked: props.checked }, "checkbox-mask"])}" data-v-0f2f834e><img${ssrRenderAttr("src", _imports_0$2)} alt="#" data-v-0f2f834e></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<label${ssrRenderAttr("for", props.name)} class="fs-14 l-wrap" data-v-0f2f834e>${ssrInterpolate(props.label)}</label></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Checkbox.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-0f2f834e"]]);
const _sfc_main$1 = {
  name: "SkeletonCard"
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<li${ssrRenderAttrs(_attrs)} data-v-bb22c79e><div class="favorites-card skeleton-card" data-v-bb22c79e><div class="favorites-card-head" data-v-bb22c79e><div class="company" data-v-bb22c79e><div class="company-logo" data-v-bb22c79e><img class="img" data-v-bb22c79e></div><div class="company-name" data-v-bb22c79e><span class="count" data-v-bb22c79e></span></div></div><div class="salary" data-v-bb22c79e></div></div><div class="favorites-card-body" data-v-bb22c79e><div class="time-location" data-v-bb22c79e><span data-v-bb22c79e></span><strong data-v-bb22c79e></strong></div><p data-v-bb22c79e></p></div><div class="favorites-card-footer" data-v-bb22c79e><div class="favorites-card-footer-row" data-v-bb22c79e><div class="group" data-v-bb22c79e><button class="group-action btn button-md" data-v-bb22c79e></button></div><div class="group" data-v-bb22c79e><button class="group-action ic-btn fav-btn" data-v-bb22c79e><svg width="23" height="21" viewBox="0 0 23 21" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-bb22c79e><path d="M11.0641 0.796788C11.2552 0.45665 11.7448 0.456649 11.9359 0.796789L14.7993 5.89364C15.0135 6.27499 15.3835 6.54383 15.8124 6.62973L21.5446 7.77794C21.9272 7.85457 22.0785 8.32027 21.8141 8.60711L17.8515 12.9053C17.555 13.2269 17.4137 13.6619 17.4645 14.0964L18.1439 19.9029C18.1892 20.2903 17.793 20.5782 17.4385 20.4153L12.1262 17.9749C11.7287 17.7923 11.2713 17.7923 10.8738 17.9749L5.56148 20.4153C5.20696 20.5782 4.81081 20.2903 4.85614 19.9029L5.53549 14.0964C5.58632 13.6619 5.44498 13.2269 5.1485 12.9053L1.18593 8.60711C0.921493 8.32027 1.07281 7.85457 1.45535 7.77794L7.18757 6.62973C7.61645 6.54383 7.98648 6.27499 8.20072 5.89364L11.0641 0.796788Z" stroke="#C8C8C8" data-v-bb22c79e></path></svg></button></div></div></div></div></li>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/SkeletonCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1], ["__scopeId", "data-v-bb22c79e"]]);
const _imports_0 = "data:image/svg+xml,%3csvg%20width='15'%20height='17'%20viewBox='0%200%2015%2017'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M7.27441%2015.75L7.27441%200.75'%20stroke='%235375FD'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M13.299%209.7002L7.275%2015.7502L1.25%209.7002'%20stroke='%235375FD'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e";
function useSortingOptions() {
  return [
    { value: null, name: "\u041F\u043E \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u044E" },
    { value: "date_asc", name: "\u041E\u0442 \u0441\u0442\u0430\u0440\u044B\u0445 \u043A \u043D\u043E\u0432\u044B\u043C" },
    { value: "date_desc", name: "\u041E\u0442 \u043D\u043E\u0432\u044B\u0445 \u043A \u0441\u0442\u0430\u0440\u044B\u043C" },
    { value: "salary_asc", name: "\u041F\u043E \u0443\u0431\u044B\u0432\u0430\u043D\u0438\u044E \u0437\u0430\u0440\u043F\u043B\u0430\u0442" },
    { value: "salary_desc", name: "\u041F\u043E \u0432\u043E\u0437\u0440\u0430\u0441\u0442\u0430\u043D\u0438\u044E \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u044B" }
  ];
}
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<svg${ssrRenderAttrs(mergeProps({
    xmlns: "http://www.w3.org/2000/svg",
    version: "1.1",
    width: "20",
    height: "20",
    viewBox: "0 0 256 256",
    "xml:space": "preserve"
  }, _attrs))}><desc>Created with Fabric.js 1.7.22</desc><defs></defs><g transform="translate(128 128) scale(0.72 0.72)" style="${ssrRenderStyle({})}"><g style="${ssrRenderStyle({ "stroke": "none", "stroke-width": "0", "stroke-dasharray": "none", "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-miterlimit": "10", "fill": "none", "fill-rule": "nonzero", "opacity": "1" })}" transform="translate(-175.05 -175.05000000000004) scale(3.89 3.89)"><path d="M 15.205 90 c -1.104 0 -2 -0.896 -2 -2 V 55.115 c 0 -1.104 0.896 -2 2 -2 s 2 0.896 2 2 V 88 C 17.205 89.104 16.31 90 15.205 90 z" style="${ssrRenderStyle({ "stroke": "none", "stroke-width": "1", "stroke-dasharray": "none", "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-miterlimit": "10", "fill": "rgb(0, 0, 0)", "fill-rule": "nonzero", "opacity": "1" })}" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"></path><path d="M 74.795 59.357 c -1.104 0 -2 -0.896 -2 -2 V 2 c 0 -1.104 0.896 -2 2 -2 s 2 0.896 2 2 v 55.357 C 76.795 58.462 75.899 59.357 74.795 59.357 z" style="${ssrRenderStyle({ "stroke": "none", "stroke-width": "1", "stroke-dasharray": "none", "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-miterlimit": "10", "fill": "rgb(0, 0, 0)", "fill-rule": "nonzero", "opacity": "1" })}" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"></path><path d="M 45 90 c -1.104 0 -2 -0.896 -2 -2 V 27.922 c 0 -1.104 0.896 -2 2 -2 s 2 0.896 2 2 V 88 C 47 89.104 46.104 90 45 90 z" style="${ssrRenderStyle({ "stroke": "none", "stroke-width": "1", "stroke-dasharray": "none", "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-miterlimit": "10", "fill": "rgb(0, 0, 0)", "fill-rule": "nonzero", "opacity": "1" })}" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"></path><path d="M 45 29.922 c -5.464 0 -9.91 -4.445 -9.91 -9.91 s 4.445 -9.91 9.91 -9.91 c 5.465 0 9.91 4.445 9.91 9.91 S 50.465 29.922 45 29.922 z M 45 14.103 c -3.259 0 -5.91 2.651 -5.91 5.91 s 2.651 5.91 5.91 5.91 s 5.91 -2.651 5.91 -5.91 S 48.259 14.103 45 14.103 z" style="${ssrRenderStyle({ "stroke": "none", "stroke-width": "1", "stroke-dasharray": "none", "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-miterlimit": "10", "fill": "rgb(0, 0, 0)", "fill-rule": "nonzero", "opacity": "1" })}" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"></path><path d="M 15.205 57.115 c -5.464 0 -9.91 -4.445 -9.91 -9.91 c 0 -5.464 4.445 -9.91 9.91 -9.91 s 9.91 4.445 9.91 9.91 C 25.115 52.67 20.669 57.115 15.205 57.115 z M 15.205 41.295 c -3.259 0 -5.91 2.651 -5.91 5.91 s 2.651 5.91 5.91 5.91 s 5.91 -2.651 5.91 -5.91 S 18.464 41.295 15.205 41.295 z" style="${ssrRenderStyle({ "stroke": "none", "stroke-width": "1", "stroke-dasharray": "none", "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-miterlimit": "10", "fill": "rgb(0, 0, 0)", "fill-rule": "nonzero", "opacity": "1" })}" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"></path><path d="M 74.795 75.177 c -5.464 0 -9.909 -4.445 -9.909 -9.91 c 0 -5.464 4.445 -9.909 9.909 -9.909 c 5.465 0 9.91 4.445 9.91 9.909 C 84.705 70.731 80.26 75.177 74.795 75.177 z M 74.795 59.357 c -3.259 0 -5.909 2.65 -5.909 5.909 s 2.65 5.91 5.909 5.91 s 5.91 -2.651 5.91 -5.91 S 78.054 59.357 74.795 59.357 z" style="${ssrRenderStyle({ "stroke": "none", "stroke-width": "1", "stroke-dasharray": "none", "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-miterlimit": "10", "fill": "rgb(0, 0, 0)", "fill-rule": "nonzero", "opacity": "1" })}" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"></path><path d="M 15.205 41.295 c -1.104 0 -2 -0.896 -2 -2 V 2 c 0 -1.104 0.896 -2 2 -2 s 2 0.896 2 2 v 37.295 C 17.205 40.4 16.31 41.295 15.205 41.295 z" style="${ssrRenderStyle({ "stroke": "none", "stroke-width": "1", "stroke-dasharray": "none", "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-miterlimit": "10", "fill": "rgb(0, 0, 0)", "fill-rule": "nonzero", "opacity": "1" })}" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"></path><path d="M 45 14.103 c -1.104 0 -2 -0.896 -2 -2 V 2 c 0 -1.104 0.896 -2 2 -2 s 2 0.896 2 2 v 10.103 C 47 13.207 46.104 14.103 45 14.103 z" style="${ssrRenderStyle({ "stroke": "none", "stroke-width": "1", "stroke-dasharray": "none", "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-miterlimit": "10", "fill": "rgb(0, 0, 0)", "fill-rule": "nonzero", "opacity": "1" })}" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"></path><path d="M 74.795 90 c -1.104 0 -2 -0.896 -2 -2 V 73.177 c 0 -1.104 0.896 -2 2 -2 s 2 0.896 2 2 V 88 C 76.795 89.104 75.899 90 74.795 90 z" style="${ssrRenderStyle({ "stroke": "none", "stroke-width": "1", "stroke-dasharray": "none", "stroke-linecap": "butt", "stroke-linejoin": "miter", "stroke-miterlimit": "10", "fill": "rgb(0, 0, 0)", "fill-rule": "nonzero", "opacity": "1" })}" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"></path></g></g></svg>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/FilterIcon.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const FilterIcon = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { FilterIcon as F, _imports_0$1 as _, __nuxt_component_0$1 as a, __nuxt_component_0$2 as b, _imports_0 as c, __nuxt_component_0 as d, useSortingOptions as u };
//# sourceMappingURL=FilterIcon-Bk66Krbt.mjs.map
