globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { _ as __nuxt_component_0$1 } from './nuxt-link-BdrY0gEc.mjs';
import { _ as __nuxt_component_0$2 } from './CustomSelectWithRadio-CUSovK5B.mjs';
import { r as useResumeStore, l as useVacancyStore, k as useAuthStore, j as useNuxtApp } from '../server.mjs';
import { useSSRContext, computed, ref, unref, withCtx, createTextVNode, toDisplayString } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderComponent, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderClass } from 'vue/server-renderer';
import moment from 'moment';

const _sfc_main = {
  __name: "Item",
  __ssrInlineRender: true,
  props: ["item"],
  setup(__props) {
    var _a;
    const { $format_number } = useNuxtApp();
    const props = __props;
    const { item } = props;
    const salaryText = computed(() => {
      if (item.salary_from && item.salary_to) {
        return `${$format_number(item.salary_from)} - ${$format_number(item.salary_to)} ${item.currency}`;
      } else if (item.salary_from && !item.salary_to) {
        return `\u041E\u0442 ${$format_number(item.salary_from)} ${item.currency}`;
      } else if (!item.salary_from && item.salary_to) {
        return `\u0414\u043E ${$format_number(item.salary_from)} ${item.currency}`;
      }
      return "\u041F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0443";
    });
    const isFavorite = ref((_a = item.is_favorite) != null ? _a : false);
    const selectedResume = ref(null);
    const resumeStore = useResumeStore();
    const myResumeOptions = computed(() => {
      return resumeStore.my_resumes.map((item2) => ({
        name: item2.title,
        value: item2.id
      }));
    });
    const vacancyDescription = computed(() => {
      if (item.description) {
        let text = item.description.slice(0, 150);
        if (item.description.length > 150) {
          text += "...";
        }
        return text;
      }
      return item.description;
    });
    const selectedResumeError = ref(null);
    useVacancyStore();
    const employerLogo = computed(() => {
      if (item && item.logo) {
        return item.logo;
      } else
        return new URL("/assets/img/logos/superjob.svg", globalThis._importMeta_.url);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_CustomSelectWithRadio = __nuxt_component_0$2;
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<li${ssrRenderAttrs(_attrs)}><div class="favorites-card"><div class="favorites-card-head"><div class="company"><div class="company-logo"><img class="w-100"${ssrRenderAttr("src", unref(employerLogo))}${ssrRenderAttr("alt", unref(item).company)}></div><div class="company-name">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: {
          name: "vacancies-slug",
          params: { slug: unref(item).id },
          query: { provider: "hh" }
        }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref(item).name)}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref(item).name), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<span class="count">${ssrInterpolate(unref(item).company)}</span></div></div><div class="salary">${ssrInterpolate(unref(salaryText))}</div></div><div class="favorites-card-body"><div class="time-location"><span>${ssrInterpolate(unref(moment)(unref(item).published_date).format("hh:mm"))}</span><strong>${ssrInterpolate(unref(item).city)}</strong></div><p>${ssrInterpolate(unref(vacancyDescription))}</p></div><div class="favorites-card-footer"><div class="favorites-card-footer-row"><div class="group me-auto">`);
      if (unref(useAuthStore)().isAuthed) {
        _push(`<div class="select-resume-row"><div class="custom-select-wrapper">`);
        _push(ssrRenderComponent(_component_CustomSelectWithRadio, {
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0435\u0437\u044E\u043C\u0435",
          modelValue: selectedResume.value,
          "onUpdate:modelValue": ($event) => selectedResume.value = $event,
          options: unref(myResumeOptions)
        }, null, _parent));
        _push(`<button id="apply-button" class="btn apply-button button-accent"${ssrIncludeBooleanAttr(!selectedResume.value) ? " disabled" : ""}> \u041E\u0442\u043A\u043B\u0438\u043A\u043D\u0443\u0442\u044C\u0441\u044F </button></div>`);
        if (selectedResumeError.value) {
          _push(`<span class="text text-danger">${ssrInterpolate(selectedResumeError.value)}</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="select-resume-row d-inline-flex justify-content-center align-items-center">`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        class: "button-accent",
        to: { name: "sign-in" }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0412\u043E\u0439\u0442\u0438`);
          } else {
            return [
              createTextVNode("\u0412\u043E\u0439\u0442\u0438")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` \u0447\u0442\u043E\u0431\u044B \u043E\u0442\u043A\u043B\u0438\u043A\u0430\u0442\u044C\u0441\u044F </div></div><div class="group"><button class="${ssrRenderClass([{ active: isFavorite.value }, "group-action ic-btn fav-btn"])}"><svg width="23" height="21" viewBox="0 0 23 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.0641 0.796788C11.2552 0.45665 11.7448 0.456649 11.9359 0.796789L14.7993 5.89364C15.0135 6.27499 15.3835 6.54383 15.8124 6.62973L21.5446 7.77794C21.9272 7.85457 22.0785 8.32027 21.8141 8.60711L17.8515 12.9053C17.555 13.2269 17.4137 13.6619 17.4645 14.0964L18.1439 19.9029C18.1892 20.2903 17.793 20.5782 17.4385 20.4153L12.1262 17.9749C11.7287 17.7923 11.2713 17.7923 10.8738 17.9749L5.56148 20.4153C5.20696 20.5782 4.81081 20.2903 4.85614 19.9029L5.53549 14.0964C5.58632 13.6619 5.44498 13.2269 5.1485 12.9053L1.18593 8.60711C0.921493 8.32027 1.07281 7.85457 1.45535 7.77794L7.18757 6.62973C7.61645 6.54383 7.98648 6.27499 8.20072 5.89364L11.0641 0.796788Z" stroke="#C8C8C8"></path></svg></button></div></div></div></div></li>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Item.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=Item-EOkX6xfY.mjs.map
