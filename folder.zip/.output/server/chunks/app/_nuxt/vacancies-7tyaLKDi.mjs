import { _ as _imports_0, a as __nuxt_component_0$3, u as useSalaryOptions } from './search-CNCM2ROA.mjs';
import { u as useQueryParams, _ as __nuxt_component_1$3 } from './useQueryParams-Bpl0Cf82.mjs';
import { defineAsyncComponent, computed, watch, useSSRContext, ref, unref, isRef, mergeProps, withAsyncContext } from 'vue';
import { u as useHead, k as useAuthStore, e as useRoute, d as navigateTo, a as useRouter, l as useVacancyStore, m as useProfileStore, s as storeToRefs, r as useResumeStore, j as useNuxtApp } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrIncludeBooleanAttr, ssrRenderClass, ssrRenderSuspense } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { _ as __nuxt_component_0$4 } from './BlockLoader-RiL0eLJn.mjs';
import { _ as _imports_0$1, u as useSortingOptions, F as FilterIcon, a as __nuxt_component_0$1$1, b as __nuxt_component_0$2$1, c as _imports_0$3, d as __nuxt_component_0$5 } from './FilterIcon-Bk66Krbt.mjs';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { _ as _imports_0$2 } from './check-BGWLIG1L.mjs';
import { u as useSort } from './useSort-Dy_x39w5.mjs';
import { u as useState } from './state-D1MfAAni.mjs';
import { u as useUIStore } from './ui-DaXXToyC.mjs';
import { useForm } from 'vee-validate';
import { u as useCurrencyOptions } from './useCurrencyOptions-BsifIVKS.mjs';
import { u as useVacancyForm } from './useVacancyForm-UJ-LLtx0.mjs';
import 'vue-router';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main$e = {
  __name: "VacancyForm",
  __ssrInlineRender: true,
  props: {
    with_wrapper: {
      default: false
    }
  },
  setup(__props) {
    var _a2, _b;
    var _a;
    const props = __props;
    useAuthStore();
    const { getCurrentQueryParams, getQueryParam } = useQueryParams();
    ref((_a2 = getCurrentQueryParams()) != null ? _a2 : {});
    useRouter();
    const route = useRoute();
    useVacancyStore();
    const profileStore = useProfileStore();
    const search = ref((_b = (_a = route.query) == null ? void 0 : _a.search) != null ? _b : void 0);
    const salary = ref({
      min: void 0,
      max: void 0,
      value: void 0
    });
    salary.value = getQueryParam("salary");
    const city = ref(null);
    watch(
      () => getQueryParam("salary"),
      (newValue) => {
        console.log(newValue);
        salary.value = newValue;
      }
    );
    const onCityChange = (cityItem) => {
      if (cityItem.value === null) {
        city.value = void 0;
      } else {
        city.value = cityItem.value;
      }
    };
    const { searchCities } = profileStore;
    const updateCityInput = async (newValue = "") => {
      var _a3;
      const items = (_a3 = await searchCities({ search: newValue })) != null ? _a3 : [];
      cityOptions.value = items.map((item) => ({
        value: item.id,
        name: item.name
      }));
    };
    const cityOptions = ref([]);
    ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderSalarySelectInForm = __nuxt_component_0$3;
      const _component_SelectWithSearch = __nuxt_component_1$3;
      if (props.with_wrapper) {
        _push(`<div${ssrRenderAttrs(_attrs)} data-v-2b77d9e4><div class="wrapper" data-v-2b77d9e4><form class="search-form" role="form" autocomplete="off" data-v-2b77d9e4><div class="search-row" data-v-2b77d9e4><div class="input-wrap has-icon has-label" data-v-2b77d9e4><img class="icon"${ssrRenderAttr("src", _imports_0)} alt="#" data-v-2b77d9e4><label for="name" data-v-2b77d9e4>\u041F\u043E\u0438\u0441\u043A </label><input type="text" name="name" id="keyword" placeholder="\u041A\u0430\u043A\u043E\u0439 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0441\u0442 \u0432\u044B \u0438\u0449\u0435\u0442\u0435?" autocomplete="off"${ssrRenderAttr("value", unref(search))} data-v-2b77d9e4></div><div class="input-wrap has-label" data-v-2b77d9e4><label for="salary" data-v-2b77d9e4>\u0416\u0435\u043B\u0430\u0435\u043C\u0430\u044F \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0430</label>`);
        _push(ssrRenderComponent(_component_HeaderSalarySelectInForm, {
          modelValue: unref(salary),
          "onUpdate:modelValue": ($event) => isRef(salary) ? salary.value = $event : null
        }, null, _parent));
        _push(`</div><div class="input-wrap has-label" data-v-2b77d9e4><label for="salary" data-v-2b77d9e4>\u0413\u043E\u0440\u043E\u0434</label>`);
        _push(ssrRenderComponent(_component_SelectWithSearch, {
          options: unref(cityOptions),
          modelValue: unref(city),
          "onUpdate:modelValue": ($event) => isRef(city) ? city.value = $event : null,
          modelModifiers: { number: true },
          placeholder: "\u0413\u043E\u0440\u043E\u0434",
          onInput: updateCityInput,
          onChange: onCityChange
        }, null, _parent));
        _push(`</div><button class="button-accent submit-search-form" type="button" data-v-2b77d9e4> \u041F\u043E\u0438\u0441\u043A </button></div></form></div></div>`);
      } else {
        _push(`<form${ssrRenderAttrs(mergeProps({
          class: "search-form",
          role: "form",
          autocomplete: "off"
        }, _attrs))} data-v-2b77d9e4><div class="search-row" data-v-2b77d9e4><div class="input-wrap has-icon has-label" data-v-2b77d9e4><img class="icon"${ssrRenderAttr("src", _imports_0)} alt="#" data-v-2b77d9e4><label for="name" data-v-2b77d9e4>\u041F\u043E\u0438\u0441\u043A </label><input type="text" name="name" id="keyword" placeholder="\u041A\u0430\u043A\u0443\u044E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E \u0432\u044B \u0438\u0449\u0435\u0442\u0435?" autocomplete="off"${ssrRenderAttr("value", unref(search))} data-v-2b77d9e4></div><div class="input-wrap has-label" data-v-2b77d9e4><label for="salary" data-v-2b77d9e4>\u0416\u0435\u043B\u0430\u0435\u043C\u0430\u044F \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0430</label>`);
        _push(ssrRenderComponent(_component_HeaderSalarySelectInForm, {
          modelValue: unref(salary),
          "onUpdate:modelValue": ($event) => isRef(salary) ? salary.value = $event : null
        }, null, _parent));
        _push(`</div><div class="input-wrap has-label" data-v-2b77d9e4><label for="salary" data-v-2b77d9e4>\u0413\u043E\u0440\u043E\u0434</label>`);
        _push(ssrRenderComponent(_component_SelectWithSearch, {
          options: unref(cityOptions),
          modelValue: unref(city),
          "onUpdate:modelValue": ($event) => isRef(city) ? city.value = $event : null,
          modelModifiers: { number: true },
          placeholder: "\u0413\u043E\u0440\u043E\u0434",
          class: "no_bg",
          onInput: updateCityInput,
          onChange: onCityChange
        }, null, _parent));
        _push(`</div><button class="button-accent submit-search-form" type="button" data-v-2b77d9e4> \u041F\u043E\u0438\u0441\u043A </button></div></form>`);
      }
    };
  }
};
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Search/VacancyForm.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const __nuxt_component_0$2 = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["__scopeId", "data-v-2b77d9e4"]]);
const _sfc_main$d = {
  __name: "Salary",
  __ssrInlineRender: true,
  setup(__props) {
    var _a2;
    var _a;
    useVacancyStore();
    useDictionaryStore();
    const filterClass = ref(true);
    ref("");
    const filterItems = ref([]);
    const { getQueryParam, updateQueryParam } = useQueryParams();
    const getSalaryValue = () => {
      var _a3;
      return (_a3 = getQueryParam("salary")) != null ? _a3 : {
        value: void 0,
        name: "\u0412\u0441\u0435"
      };
    };
    const salary = ref(getSalaryValue());
    const salary_id = ref((_a2 = (_a = salary.value) == null ? void 0 : _a.value) != null ? _a2 : void 0);
    watch(
      () => getSalaryValue(),
      (newValues, oldValues) => {
        salary.value = newValues;
      }
    );
    watch(
      () => salary.value,
      (newValues, oldValues) => {
        salary_id.value = newValues.value;
        prepare([...salaryOptions.value]);
      }
    );
    const onUpdated = (newValue) => {
      if (newValue) {
        const found = [...salaryOptions.value].find(
          (item) => item.value === newValue
        );
        updateQueryParam("salary", { ...found });
        console.log("updated");
      } else {
        updateQueryParam("salary", void 0);
      }
    };
    const salaryOptions = ref(useSalaryOptions());
    const prepare = (items) => {
      items = items.map((item) => ({
        ...item,
        is_checked: item.value === salary_id.value
      }));
      filterItems.value = items;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesRadio = __nuxt_component_0$2$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["filter-box", { open: unref(filterClass) }]
      }, _attrs))}><div class="filter-box-handle"><strong>\u0417\u0430\u0440\u043F\u043B\u0430\u0442\u0430</strong><img${ssrRenderAttr("src", _imports_0$1)} alt="#"></div><div class="filter-box-body"><div class="check-block-list all-visible"><!--[-->`);
      ssrRenderList(unref(filterItems), (item) => {
        _push(ssrRenderComponent(_component_VacanciesRadio, {
          class: "check-block",
          modelValue: unref(salary_id),
          "onUpdate:modelValue": onUpdated,
          value: item.value,
          name: "salary_id",
          id: `salary_${item.value}`,
          label: item.name
        }, null, _parent));
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/Salary.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const __nuxt_component_0$1 = _sfc_main$d;
const __nuxt_component_0_lazy = defineAsyncComponent(() => import('./IndustryModal-D_1j5hwQ.mjs').then((c) => c.default || c));
const _sfc_main$c = {
  __name: "Industry",
  __ssrInlineRender: true,
  props: ["name", "isOpen"],
  emits: ["onFormChange"],
  async setup(__props, { emit: __emit }) {
    var _a;
    let __temp, __restore;
    const vacancyStore = useVacancyStore();
    const { updateQueryParam, getQueryParam } = useQueryParams();
    const { getIndustries } = vacancyStore;
    const { industries } = storeToRefs(vacancyStore);
    const industry_ids = ref((_a = getQueryParam("industries")) != null ? _a : []);
    watch(
      () => {
        var _a2;
        return (_a2 = getQueryParam("industries")) != null ? _a2 : [];
      },
      (newValues, oldValues) => {
        if (JSON.stringify(newValues) !== JSON.stringify(oldValues)) {
          industry_ids.value = newValues;
          prepare(vacancyStore.regions_formatted);
        }
      }
    );
    const isModalOpen = ref(false);
    const firstItems = ref([]);
    const toggleModal = () => isModalOpen.value = !isModalOpen.value;
    const industryItems = ref([]);
    const prepare = (newItems, oldItems) => {
      industryItems.value = newItems;
      if (!newItems || newItems.length < 1)
        return;
      for (let i = 0; i < 5; i++) {
        let item = newItems[i];
        let is_checked = false;
        if (industry_ids.value.includes(item.id)) {
          is_checked = true;
        }
        firstItems.value.push({
          id: item.id,
          title: item.title,
          is_checked
        });
      }
    };
    watch(() => vacancyStore.industries_formatted_for_filter, prepare);
    const filterClass = ref(true);
    [__temp, __restore] = withAsyncContext(() => getIndustries()), await __temp, __restore();
    return (_ctx, _push, _parent, _attrs) => {
      var _a2;
      const _component_LazyVacanciesFiltersIndustryModal = __nuxt_component_0_lazy;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["filter-box", { open: unref(filterClass) }]
      }, _attrs))} data-v-332efe31><div class="filter-box-handle" data-v-332efe31><strong data-v-332efe31>\u041E\u0442\u0440\u0430\u0441\u043B\u044C \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438(${ssrInterpolate((_a2 = unref(industries)) == null ? void 0 : _a2.length)})</strong><img${ssrRenderAttr("src", _imports_0$1)} alt="#" data-v-332efe31></div><div class="filter-box-body" data-v-332efe31><div class="check-block-list" data-v-332efe31><!--[-->`);
      ssrRenderList(unref(firstItems), (item) => {
        _push(`<div class="check-block" data-v-332efe31><div class="checkbox" data-v-332efe31><input type="checkbox"${ssrRenderAttr("id", item.id)}${ssrIncludeBooleanAttr(item.is_checked) ? " checked" : ""} data-v-332efe31><div class="checkbox-mask" data-v-332efe31><img${ssrRenderAttr("src", _imports_0$2)} alt="#" data-v-332efe31></div></div><div class="l-wrap" data-v-332efe31><label${ssrRenderAttr("for", item.id)} data-v-332efe31>${ssrInterpolate(item.title)}</label></div></div>`);
      });
      _push(`<!--]--></div>`);
      _push(ssrRenderComponent(_component_LazyVacanciesFiltersIndustryModal, {
        title: "\u041E\u0442\u0440\u0430\u0441\u043B\u044C \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438",
        "is-open": unref(isModalOpen),
        onClose: toggleModal,
        name: "industries",
        items: unref(vacancyStore).industries_formatted_for_filter
      }, null, _parent));
      _push(`<button class="more-filters" data-v-332efe31>\u0412\u044B\u0431\u0440\u0430\u0442\u044C</button></div></div>`);
    };
  }
};
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/Industry.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const __nuxt_component_1$2 = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["__scopeId", "data-v-332efe31"]]);
const _sfc_main$b = {
  __name: "Region",
  __ssrInlineRender: true,
  props: ["name", "isOpen", "selectedCountry"],
  emits: ["onFormChange"],
  setup(__props, { emit: __emit }) {
    var _a, _b;
    const { updateQueryParam, getQueryParam } = useQueryParams();
    const countries = ref((_a = getQueryParam("countries")) != null ? _a : [1]);
    watch(
      () => {
        var _a2;
        return (_a2 = getQueryParam("countries")) != null ? _a2 : [1];
      },
      // default country is 1
      async (newValues, oldValues) => {
        if (JSON.stringify(newValues) !== JSON.stringify(oldValues)) {
          countries.value = newValues;
          await getRegions({ country_ids: countries.value });
          prepare(vacancyStore.regions_formatted);
        }
      }
    );
    const regions2 = ref((_b = getQueryParam("regions")) != null ? _b : []);
    watch(
      () => {
        var _a2;
        return (_a2 = getQueryParam("regions")) != null ? _a2 : [];
      },
      (newValues, oldValues) => {
        if (JSON.stringify(newValues) !== JSON.stringify(oldValues)) {
          regions2.value = newValues;
          prepare(vacancyStore.regions_formatted);
        }
      }
    );
    const vacancyStore = useVacancyStore();
    const search = ref("");
    const total = computed(() => {
      if (vacancyStore.regions.length > 5) {
        return vacancyStore.regions.length - 5;
      } else {
        return 0;
      }
    });
    const filterClass = ref(true);
    const isMore = ref(false);
    const groupedFilterItems = ref([]);
    const selectedItems = ref([]);
    const firstXSelectedItems = computed(() => {
      return vacancyStore.regions_formatted.slice(0, 5);
    });
    const toggleRegion = (id) => {
      let selected_ids = [...regions2.value];
      if (!selected_ids.includes(id)) {
        selected_ids.push(id);
      } else {
        selected_ids = selected_ids.filter((item) => item !== id);
      }
      selected_ids = selected_ids.length === 0 ? void 0 : selected_ids;
      updateQueryParam("regions", selected_ids);
    };
    ref(false);
    useRouter();
    const { sort } = useSort();
    const prepare = (items) => {
      let filterItems = items;
      let selected_ids = [...regions2.value];
      if (filterItems.length < 1) {
        groupedFilterItems.value = [];
        return;
      }
      selectedItems.value = [...filterItems].filter((item) => {
        return selected_ids.includes(item.value);
      });
      filterItems = filterItems.filter(
        (item) => !selected_ids.includes(item.value)
      );
      filterItems = sort(filterItems, { by: "alpha" });
      groupedFilterItems.value = [];
      filterItems.map((item, key) => {
        const firstLetter = item.name.charAt(0);
        if (key === 0) {
          groupedFilterItems.value.push({
            value: firstLetter,
            name: firstLetter,
            is_header: true
          });
        } else {
          let prevFirstLetter;
          if (filterItems[key - 1] !== void 0) {
            prevFirstLetter = filterItems[key - 1].name.charAt(0);
          }
          if (firstLetter !== prevFirstLetter) {
            groupedFilterItems.value.push({
              value: firstLetter,
              name: firstLetter,
              is_header: true
            });
          }
        }
        groupedFilterItems.value.push({
          value: item.value,
          name: item.name,
          is_header: false
        });
      });
    };
    const { getRegions } = vacancyStore;
    watch(() => vacancyStore.regions_formatted, prepare);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesCheckbox = __nuxt_component_0$1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["filter-box", { open: unref(filterClass) }]
      }, _attrs))} data-v-c6f16caf><div class="filter-box-handle" data-v-c6f16caf><strong data-v-c6f16caf>\u0420\u0435\u0433\u0438\u043E\u043D\u044B(${ssrInterpolate(unref(total))})</strong><img${ssrRenderAttr("src", _imports_0$1)} alt="#" data-v-c6f16caf></div>`);
      if (unref(isMore)) {
        _push(`<div class="filter-box-body" data-v-c6f16caf><div class="search_area" data-v-c6f16caf><input type="search"${ssrRenderAttr("value", unref(search))} data-v-c6f16caf></div><span class="fw-bold is_header mb-2" data-v-c6f16caf>\u0412\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0435 \u0440\u0435\u0433\u0438\u043E\u043D\u044B</span><div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list with_scroll mt-2"])}" data-v-c6f16caf><!--[-->`);
        ssrRenderList(unref(selectedItems), (item) => {
          _push(ssrRenderComponent(_component_VacanciesCheckbox, {
            class: ["check-block", { is_header: item.is_header }],
            checked: true,
            onChange: ($event) => toggleRegion(item.value),
            name: `selected_region_${item.value}`,
            key: `selected_region_${item.value}`,
            label: item.name
          }, null, _parent));
        });
        _push(`<!--]--></div><div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list with_scroll mt-3"])}" data-v-c6f16caf><!--[-->`);
        ssrRenderList(unref(groupedFilterItems), (item) => {
          _push(ssrRenderComponent(_component_VacanciesCheckbox, {
            class: ["check-block", { is_header: item.is_header }],
            checked: item.is_checked,
            onChange: ($event) => toggleRegion(item.value),
            name: `unselected_region_${item.value}`,
            label: item.name,
            is_header: item.is_header,
            key: `unselected_region_${item.value}`
          }, null, _parent));
        });
        _push(`<!--]--></div><button class="more-filters" data-default-text="\u0415\u0449\u0435 25" data-hide-text="\u0421\u043A\u0440\u044B\u0442\u044C" data-v-c6f16caf> \u0421\u043A\u0440\u044B\u0442\u044C </button></div>`);
      } else {
        _push(`<div class="filter-box-body" data-v-c6f16caf>`);
        if (unref(selectedItems).length) {
          _push(`<div class="check-block-list" data-v-c6f16caf><!--[-->`);
          ssrRenderList(unref(selectedItems), (item) => {
            _push(ssrRenderComponent(_component_VacanciesCheckbox, {
              class: "check-block",
              checked: true,
              onChange: ($event) => toggleRegion(item.value),
              name: `selected_region_${item.value}`,
              label: item.name,
              key: `selected_region_${item.value}`
            }, null, _parent));
          });
          _push(`<!--]--></div>`);
        } else {
          _push(`<div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list with_scroll"])}" data-v-c6f16caf><!--[-->`);
          ssrRenderList(unref(firstXSelectedItems), (item) => {
            _push(ssrRenderComponent(_component_VacanciesCheckbox, {
              class: "check-block",
              checked: false,
              onChange: ($event) => toggleRegion(item.value),
              name: `region_${item.value}`,
              label: item.name,
              key: `region_${item.value}`
            }, null, _parent));
          });
          _push(`<!--]--></div>`);
        }
        if (unref(total) > 0) {
          _push(`<button class="more-filters"${ssrRenderAttr("data-default-text", `\u0415\u0449\u0435 ${unref(total)}`)} data-hide-text="\u041F\u043E\u043A\u0430\u0437\u0430\u0442" data-v-c6f16caf> \u0415\u0449\u0435 ${ssrInterpolate(unref(total))}</button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/Region.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const __nuxt_component_2$1 = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["__scopeId", "data-v-c6f16caf"]]);
function useVacancySearchParams(name = "vacancy_search_params", initialValues = null) {
  console.log(name);
  const values = useState(name, () => initialValues);
  const setParams = (new_values) => {
    const keys = Object.keys(new_values);
    for (let key in keys) {
      values[key] = new_values[key];
    }
  };
  const parseParams = (route) => {
    const params = { ...route.query };
    for (const key in params) {
      try {
        params[key] = JSON.parse(params[key]);
      } catch (error) {
      }
    }
    setParams(params);
    return params;
  };
  const toFrond = (newParams) => {
    const params = { ...newParams };
    for (let prop in params) {
      if (Array.isArray(params[prop]) || typeof params[prop] === "object") {
        if (Array.isArray(params[prop]) && params[prop].length === 0) {
          delete params[prop];
        } else {
          params[prop] = JSON.stringify(params[prop]);
        }
      }
    }
    return params;
  };
  return { values, setParams, toFrond, parseParams };
}
const _sfc_main$a = {
  __name: "City",
  __ssrInlineRender: true,
  props: ["name", "isOpen"],
  emits: ["onFormChange"],
  setup(__props, { emit: __emit }) {
    var _a, _b;
    const { updateQueryParam, getQueryParam } = useQueryParams();
    const cities = ref((_a = getQueryParam("cities")) != null ? _a : []);
    const regions2 = ref((_b = getQueryParam("regions")) != null ? _b : []);
    watch(
      () => {
        var _a2;
        return (_a2 = getQueryParam("regions")) != null ? _a2 : [];
      },
      (newValues, oldValues) => {
        if (JSON.stringify(newValues) !== JSON.stringify(oldValues)) {
          regions2.value = newValues;
          getCities({ region_ids: regions2.value });
          prepare(vacancyStore.cities_formatted);
        }
      }
    );
    watch(
      () => {
        var _a2;
        return (_a2 = getQueryParam("cities")) != null ? _a2 : [];
      },
      (newValues, oldValues) => {
        if (JSON.stringify(newValues) !== JSON.stringify(oldValues)) {
          cities.value = newValues;
          prepare(vacancyStore.cities_formatted);
        }
      }
    );
    const vacancyStore = useVacancyStore();
    const search = ref("");
    const total = computed(() => {
      if (vacancyStore.cities_formatted.length > 5) {
        return vacancyStore.cities_formatted.length - 5;
      } else {
        return 0;
      }
    });
    const filterClass = ref(true);
    const isMore = ref(false);
    const groupedFilterItems = ref([]);
    const selectedItems = ref([]);
    const firstXSelectedItems = computed(() => {
      return vacancyStore.cities_formatted.slice(0, 5);
    });
    useVacancySearchParams();
    const toggleRegion = (id) => {
      let selected_ids = [...cities.value];
      if (!selected_ids.includes(id)) {
        selected_ids.push(id);
      } else {
        selected_ids = selected_ids.filter((item) => item !== id);
      }
      selected_ids = selected_ids.length === 0 ? void 0 : selected_ids;
      updateQueryParam("cities", selected_ids);
    };
    ref(false);
    useRouter();
    const { sort } = useSort();
    const prepare = (items) => {
      let filterItems = items;
      let selected_ids = [...cities.value];
      if (filterItems.length < 1) {
        groupedFilterItems.value = [];
        return;
      }
      selectedItems.value = [...filterItems].filter((item) => {
        return selected_ids.includes(item.value);
      });
      filterItems = filterItems.filter(
        (item) => !selected_ids.includes(item.value)
      );
      filterItems = sort(filterItems, { by: "alpha" });
      groupedFilterItems.value = [];
      filterItems.map((item, key) => {
        const firstLetter = item.name.charAt(0);
        if (key === 0) {
          groupedFilterItems.value.push({
            value: firstLetter,
            name: firstLetter,
            is_header: true
          });
        } else {
          let prevFirstLetter;
          if (filterItems[key - 1] !== void 0) {
            prevFirstLetter = filterItems[key - 1].name.charAt(0);
          }
          if (firstLetter !== prevFirstLetter) {
            groupedFilterItems.value.push({
              value: firstLetter,
              name: firstLetter,
              is_header: true
            });
          }
        }
        groupedFilterItems.value.push({
          value: item.value,
          name: item.name,
          is_header: false
        });
      });
    };
    const { getCities } = vacancyStore;
    watch(() => vacancyStore.cities_formatted, prepare);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesCheckbox = __nuxt_component_0$1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["filter-box", { open: unref(filterClass) }]
      }, _attrs))} data-v-08343c95><div class="filter-box-handle" data-v-08343c95><strong data-v-08343c95>\u0413\u043E\u0440\u043E\u0434\u0430(${ssrInterpolate(unref(total))})</strong><img${ssrRenderAttr("src", _imports_0$1)} alt="#" data-v-08343c95></div>`);
      if (unref(isMore)) {
        _push(`<div class="filter-box-body" data-v-08343c95><div class="search_area" data-v-08343c95><input type="search"${ssrRenderAttr("value", unref(search))} data-v-08343c95></div><span class="fw-bold is_header mb-2" data-v-08343c95>\u0412\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0435 \u0433\u043E\u0440\u043E\u0434\u0430</span><div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list with_scroll mt-2"])}" data-v-08343c95><!--[-->`);
        ssrRenderList(unref(selectedItems), (item) => {
          _push(ssrRenderComponent(_component_VacanciesCheckbox, {
            class: ["check-block", { is_header: item.is_header }],
            checked: true,
            onChange: ($event) => toggleRegion(item.value),
            name: `selected_city_${item.value}`,
            key: `selected_city_${item.value}`,
            label: item.name
          }, null, _parent));
        });
        _push(`<!--]--></div><div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list with_scroll mt-3"])}" data-v-08343c95><!--[-->`);
        ssrRenderList(unref(groupedFilterItems), (item) => {
          _push(ssrRenderComponent(_component_VacanciesCheckbox, {
            class: ["check-block", { is_header: item.is_header }],
            checked: item.is_checked,
            onChange: ($event) => toggleRegion(item.value),
            name: `unselected_city_${item.value}`,
            label: item.name,
            is_header: item.is_header,
            key: `unselected_city_${item.value}`
          }, null, _parent));
        });
        _push(`<!--]--></div><button class="more-filters" data-default-text="\u0415\u0449\u0435 25" data-hide-text="\u0421\u043A\u0440\u044B\u0442\u044C" data-v-08343c95> \u0421\u043A\u0440\u044B\u0442\u044C </button></div>`);
      } else {
        _push(`<div class="filter-box-body" data-v-08343c95>`);
        if (unref(selectedItems).length) {
          _push(`<div class="check-block-list" data-v-08343c95><!--[-->`);
          ssrRenderList(unref(selectedItems), (item) => {
            _push(ssrRenderComponent(_component_VacanciesCheckbox, {
              class: "check-block",
              checked: true,
              onChange: ($event) => toggleRegion(item.value),
              name: `selected_city_${item.value}`,
              label: item.name,
              key: `selected_city_${item.value}`
            }, null, _parent));
          });
          _push(`<!--]--></div>`);
        } else {
          _push(`<div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list with_scroll"])}" data-v-08343c95><!--[-->`);
          ssrRenderList(unref(firstXSelectedItems), (item) => {
            _push(ssrRenderComponent(_component_VacanciesCheckbox, {
              class: "check-block",
              checked: false,
              onChange: ($event) => toggleRegion(item.value),
              name: `city_${item.value}`,
              label: item.name,
              key: `city_${item.value}`
            }, null, _parent));
          });
          _push(`<!--]--></div>`);
        }
        if (unref(total) > 0) {
          _push(`<button class="more-filters"${ssrRenderAttr("data-default-text", `\u0415\u0449\u0435 ${unref(total)}`)} data-hide-text="\u041F\u043E\u043A\u0430\u0437\u0430\u0442" data-v-08343c95> \u0415\u0449\u0435 ${ssrInterpolate(unref(total))}</button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/City.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["__scopeId", "data-v-08343c95"]]);
const _sfc_main$9 = {
  __name: "Metro",
  __ssrInlineRender: true,
  props: ["name", "isOpen"],
  emits: ["onFormChange"],
  setup(__props, { emit: __emit }) {
    var _a, _b;
    const { updateQueryParam, getQueryParam } = useQueryParams();
    ref((_a = getQueryParam("cities")) != null ? _a : []);
    const metros = ref((_b = getQueryParam("metros")) != null ? _b : []);
    watch(
      () => {
        var _a2;
        return (_a2 = getQueryParam("cities")) != null ? _a2 : [];
      },
      (newValues, oldValues) => {
        if (JSON.stringify(newValues) !== JSON.stringify(oldValues)) {
          regions.value = newValues;
          getMetros({ region_ids: regions.value });
          prepare(vacancyStore.metros_formatted);
        }
      }
    );
    watch(
      () => {
        var _a2;
        return (_a2 = getQueryParam("metros")) != null ? _a2 : [];
      },
      (newValues, oldValues) => {
        if (JSON.stringify(newValues) !== JSON.stringify(oldValues)) {
          metros.value = newValues;
          prepare(vacancyStore.metros_formatted);
        }
      }
    );
    const vacancyStore = useVacancyStore();
    const search = ref("");
    const total = computed(() => {
      if (vacancyStore.metros_formatted.length > 5) {
        return vacancyStore.metros_formatted.length - 5;
      } else {
        return 0;
      }
    });
    const filterClass = ref(true);
    const isMore = ref(false);
    const groupedFilterItems = ref([]);
    const selectedItems = ref([]);
    const firstXSelectedItems = computed(() => {
      return vacancyStore.metros_formatted.slice(0, 5);
    });
    useVacancySearchParams();
    const toggleRegion = (id) => {
      let selected_ids = [...metros.value];
      if (!selected_ids.includes(id)) {
        selected_ids.push(id);
      } else {
        selected_ids = selected_ids.filter((item) => item !== id);
      }
      selected_ids = selected_ids.length === 0 ? void 0 : selected_ids;
      updateQueryParam("metros", selected_ids);
    };
    ref(false);
    useRouter();
    const { sort } = useSort();
    const prepare = (items) => {
      let filterItems = items;
      let selected_ids = [...metros.value];
      if (filterItems.length < 1) {
        groupedFilterItems.value = [];
        return;
      }
      selectedItems.value = [...filterItems].filter((item) => {
        return selected_ids.includes(item.value);
      });
      filterItems = filterItems.filter(
        (item) => !selected_ids.includes(item.value)
      );
      filterItems = sort(filterItems, { by: "alpha" });
      groupedFilterItems.value = [];
      filterItems.map((item, key) => {
        const firstLetter = item.name.charAt(0);
        if (key === 0) {
          groupedFilterItems.value.push({
            value: firstLetter,
            name: firstLetter,
            is_header: true
          });
        } else {
          let prevFirstLetter;
          if (filterItems[key - 1] !== void 0) {
            prevFirstLetter = filterItems[key - 1].name.charAt(0);
          }
          if (firstLetter !== prevFirstLetter) {
            groupedFilterItems.value.push({
              value: firstLetter,
              name: firstLetter,
              is_header: true
            });
          }
        }
        groupedFilterItems.value.push({
          value: item.value,
          name: item.name,
          is_header: false
        });
      });
    };
    const { getMetros } = vacancyStore;
    watch(() => vacancyStore.metros_formatted, prepare);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesCheckbox = __nuxt_component_0$1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["filter-box", { open: unref(filterClass) }]
      }, _attrs))} data-v-680feddc><div class="filter-box-handle" data-v-680feddc><strong data-v-680feddc>\u041C\u0435\u0442\u0440\u043E(${ssrInterpolate(unref(total))})</strong><img${ssrRenderAttr("src", _imports_0$1)} alt="#" data-v-680feddc></div>`);
      if (unref(isMore)) {
        _push(`<div class="filter-box-body" data-v-680feddc><div class="search_area" data-v-680feddc><input type="search"${ssrRenderAttr("value", unref(search))} data-v-680feddc></div><span class="fw-bold is_header mb-2" data-v-680feddc>\u0412\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0435 \u043C\u0435\u0442\u0440\u043E</span><div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list with_scroll mt-2"])}" data-v-680feddc><!--[-->`);
        ssrRenderList(unref(selectedItems), (item) => {
          _push(ssrRenderComponent(_component_VacanciesCheckbox, {
            class: ["check-block", { is_header: item.is_header }],
            checked: true,
            onChange: ($event) => toggleRegion(item.value),
            name: `selected_city_${item.value}`,
            key: `selected_city_${item.value}`,
            label: item.name
          }, null, _parent));
        });
        _push(`<!--]--></div><div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list with_scroll mt-3"])}" data-v-680feddc><!--[-->`);
        ssrRenderList(unref(groupedFilterItems), (item) => {
          _push(ssrRenderComponent(_component_VacanciesCheckbox, {
            class: ["check-block", { is_header: item.is_header }],
            checked: item.is_checked,
            onChange: ($event) => toggleRegion(item.value),
            name: `unselected_city_${item.value}`,
            label: item.name,
            is_header: item.is_header,
            key: `unselected_city_${item.value}`
          }, null, _parent));
        });
        _push(`<!--]--></div><button class="more-filters" data-default-text="\u0415\u0449\u0435 25" data-hide-text="\u0421\u043A\u0440\u044B\u0442\u044C" data-v-680feddc> \u0421\u043A\u0440\u044B\u0442\u044C </button></div>`);
      } else {
        _push(`<div class="filter-box-body" data-v-680feddc>`);
        if (unref(selectedItems).length) {
          _push(`<div class="check-block-list" data-v-680feddc><!--[-->`);
          ssrRenderList(unref(selectedItems), (item) => {
            _push(ssrRenderComponent(_component_VacanciesCheckbox, {
              class: "check-block",
              checked: true,
              onChange: ($event) => toggleRegion(item.value),
              name: `selected_city_${item.value}`,
              label: item.name,
              key: `selected_city_${item.value}`
            }, null, _parent));
          });
          _push(`<!--]--></div>`);
        } else {
          _push(`<div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list with_scroll"])}" data-v-680feddc><!--[-->`);
          ssrRenderList(unref(firstXSelectedItems), (item) => {
            _push(ssrRenderComponent(_component_VacanciesCheckbox, {
              class: "check-block",
              checked: false,
              onChange: ($event) => toggleRegion(item.value),
              name: `city_${item.value}`,
              label: item.name,
              key: `city_${item.value}`
            }, null, _parent));
          });
          _push(`<!--]--></div>`);
        }
        if (unref(total) > 0) {
          _push(`<button class="more-filters"${ssrRenderAttr("data-default-text", `\u0415\u0449\u0435 ${unref(total)}`)} data-hide-text="\u041F\u043E\u043A\u0430\u0437\u0430\u0442" data-v-680feddc> \u0415\u0449\u0435 ${ssrInterpolate(unref(total))}</button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/Metro.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-680feddc"]]);
const _sfc_main$8 = {
  __name: "PartTime",
  __ssrInlineRender: true,
  emits: ["onFormChange"],
  setup(__props, { emit: __emit }) {
    var _a;
    useVacancyStore();
    const dictionaryStore = useDictionaryStore();
    const filterClass = ref(true);
    const isMore = ref(true);
    ref("");
    const filterItems = ref([]);
    const { getQueryParam, updateQueryParam } = useQueryParams();
    const part_times = ref((_a = getQueryParam("part_times")) != null ? _a : []);
    watch(
      () => {
        var _a2;
        return (_a2 = getQueryParam("part_times")) != null ? _a2 : [];
      },
      (newValues) => {
        part_times.value = newValues;
      }
    );
    ref([]);
    const toggle = (id) => {
      let selected_ids = [...part_times.value];
      if (!selected_ids.includes(id)) {
        selected_ids.push(id);
      } else {
        selected_ids = selected_ids.filter((item) => item !== id);
      }
      selected_ids = selected_ids.length === 0 ? void 0 : selected_ids;
      updateQueryParam("part_times", selected_ids);
    };
    const { sort } = useSort();
    const prepare = (items) => {
      let selected_ids = [...part_times.value];
      const sortedItems = sort(items, { by: "alpha" });
      items = sortedItems.map((item) => ({
        ...item,
        is_checked: selected_ids.includes(item.id)
      }));
      filterItems.value = items;
    };
    watch(() => dictionaryStore.part_times, prepare);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesCheckbox = __nuxt_component_0$1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["filter-box", { open: unref(filterClass) }]
      }, _attrs))} data-v-4e37f63c><div class="filter-box-handle" data-v-4e37f63c><strong data-v-4e37f63c>\u041F\u043E\u0434\u0440\u0430\u0431\u043E\u0442\u043A\u0430</strong><img${ssrRenderAttr("src", _imports_0$1)} alt="#" data-v-4e37f63c></div><div class="filter-box-body" data-v-4e37f63c><div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list"])}" data-v-4e37f63c><!--[-->`);
      ssrRenderList(unref(filterItems), (item) => {
        _push(ssrRenderComponent(_component_VacanciesCheckbox, {
          class: "check-block",
          checked: item.is_checked,
          onChange: ($event) => toggle(item.id),
          name: `work_type_${item.id}`,
          label: item.name
        }, null, _parent));
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/PartTime.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["__scopeId", "data-v-4e37f63c"]]);
const _sfc_main$7 = {
  __name: "Experience",
  __ssrInlineRender: true,
  emits: ["onFormChange"],
  setup(__props, { emit: __emit }) {
    var _a;
    useVacancyStore();
    const dictionaryStore = useDictionaryStore();
    const filterClass = ref(true);
    const filterItems = ref([]);
    const { getQueryParam, updateQueryParam } = useQueryParams();
    const experiences = ref((_a = getQueryParam("experiences")) != null ? _a : []);
    watch(
      () => {
        var _a2;
        return (_a2 = getQueryParam("experiences")) != null ? _a2 : [];
      },
      (newValues) => {
        experiences.value = newValues;
      }
    );
    const toggle = (id) => {
      let selected_ids = [...experiences.value];
      if (!selected_ids.includes(id)) {
        selected_ids.push(id);
      } else {
        selected_ids = selected_ids.filter((item) => item !== id);
      }
      selected_ids = selected_ids.length === 0 ? void 0 : selected_ids;
      updateQueryParam("experiences", selected_ids);
    };
    const { sort } = useSort();
    const prepare = (items) => {
      let selected_ids = [...experiences.value];
      const sortedItems = sort(items, { by: "alpha" });
      items = sortedItems.map((item) => ({
        ...item,
        is_checked: selected_ids.includes(item.id)
      }));
      filterItems.value = items;
    };
    watch(() => dictionaryStore.experiences, prepare);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesCheckbox = __nuxt_component_0$1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["filter-box", { open: unref(filterClass) }]
      }, _attrs))} data-v-5c12e5a2><div class="filter-box-handle" data-v-5c12e5a2><strong data-v-5c12e5a2>\u041E\u043F\u044B\u0442 \u0440\u0430\u0431\u043E\u0442\u044B</strong><img${ssrRenderAttr("src", _imports_0$1)} alt="#" data-v-5c12e5a2></div><div class="filter-box-body" data-v-5c12e5a2><div class="check-block-list" data-v-5c12e5a2><!--[-->`);
      ssrRenderList(unref(filterItems), (item) => {
        _push(ssrRenderComponent(_component_VacanciesCheckbox, {
          class: "check-block",
          checked: item.is_checked,
          name: `experience_${item.id}`,
          onChange: ($event) => toggle(item.id),
          label: item.name
        }, null, _parent));
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/Experience.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-5c12e5a2"]]);
const _sfc_main$6 = {
  __name: "WorkType",
  __ssrInlineRender: true,
  emits: ["onFormChange"],
  setup(__props, { emit: __emit }) {
    var _a;
    useVacancyStore();
    const dictionaryStore = useDictionaryStore();
    const filterClass = ref(true);
    const isMore = ref(true);
    ref("");
    const filterItems = ref([]);
    const { getQueryParam, updateQueryParam } = useQueryParams();
    const work_types = ref((_a = getQueryParam("work_types")) != null ? _a : []);
    watch(
      () => {
        var _a2;
        return (_a2 = getQueryParam("work_types")) != null ? _a2 : [];
      },
      (newValues) => {
        work_types.value = newValues;
      }
    );
    ref([]);
    const toggle = (id) => {
      let selected_ids = [...work_types.value];
      if (!selected_ids.includes(id)) {
        selected_ids.push(id);
      } else {
        selected_ids = selected_ids.filter((item) => item !== id);
      }
      selected_ids = selected_ids.length === 0 ? void 0 : selected_ids;
      updateQueryParam("work_types", selected_ids);
    };
    const { sort } = useSort();
    const prepare = (items) => {
      let selected_ids = [...work_types.value];
      const sortedItems = sort(items, { by: "alpha" });
      items = sortedItems.map((item) => ({
        ...item,
        is_checked: selected_ids.includes(item.id)
      }));
      filterItems.value = items;
    };
    watch(() => dictionaryStore.work_types, prepare);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesCheckbox = __nuxt_component_0$1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["filter-box", { open: unref(filterClass) }]
      }, _attrs))} data-v-028bd976><div class="filter-box-handle" data-v-028bd976><strong data-v-028bd976>\u0422\u0438\u043F \u0437\u0430\u043D\u044F\u0442\u043E\u0441\u0442\u0438</strong><img${ssrRenderAttr("src", _imports_0$1)} alt="#" data-v-028bd976></div><div class="filter-box-body" data-v-028bd976><div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list"])}" data-v-028bd976><!--[-->`);
      ssrRenderList(unref(filterItems), (item) => {
        _push(ssrRenderComponent(_component_VacanciesCheckbox, {
          class: "check-block",
          checked: item.is_checked,
          onChange: ($event) => toggle(item.id),
          name: `work_type_${item.id}`,
          label: item.name
        }, null, _parent));
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/WorkType.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_7 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-028bd976"]]);
const _sfc_main$5 = {
  __name: "Schedule",
  __ssrInlineRender: true,
  emits: ["onFormChange"],
  setup(__props, { emit: __emit }) {
    var _a;
    useVacancyStore();
    const dictionaryStore = useDictionaryStore();
    const filterClass = ref(true);
    const isMore = ref(true);
    ref("");
    const filterItems = ref([]);
    const { getQueryParam, updateQueryParam } = useQueryParams();
    const schedules = ref((_a = getQueryParam("schedules")) != null ? _a : []);
    watch(
      () => {
        var _a2;
        return (_a2 = getQueryParam("schedules")) != null ? _a2 : [];
      },
      (newValues) => {
        schedules.value = newValues;
      }
    );
    ref([]);
    const toggle = (id) => {
      let selected_ids = [...schedules.value];
      if (!selected_ids.includes(id)) {
        selected_ids.push(id);
      } else {
        selected_ids = selected_ids.filter((item) => item !== id);
      }
      selected_ids = selected_ids.length === 0 ? void 0 : selected_ids;
      updateQueryParam("schedules", selected_ids);
    };
    const { sort } = useSort();
    const prepare = (items) => {
      let selected_ids = [...schedules.value];
      const sortedItems = sort(items, { by: "alpha" });
      items = sortedItems.map((item) => ({
        ...item,
        is_checked: selected_ids.includes(item.id)
      }));
      filterItems.value = items;
    };
    watch(() => dictionaryStore.schedules, prepare);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesCheckbox = __nuxt_component_0$1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["filter-box", { open: unref(filterClass) }]
      }, _attrs))} data-v-dbabdf13><div class="filter-box-handle" data-v-dbabdf13><strong data-v-dbabdf13>\u0413\u0440\u0430\u0444\u0438\u043A \u0440\u0430\u0431\u043E\u0442\u044B</strong><img${ssrRenderAttr("src", _imports_0$1)} alt="#" data-v-dbabdf13></div><div class="filter-box-body" data-v-dbabdf13><div class="${ssrRenderClass([{ "all-visible": unref(isMore) }, "check-block-list"])}" data-v-dbabdf13><!--[-->`);
      ssrRenderList(unref(filterItems), (item) => {
        _push(ssrRenderComponent(_component_VacanciesCheckbox, {
          class: "check-block",
          checked: item.is_checked,
          onChange: ($event) => toggle(item.id),
          name: `schedule_${item.id}`,
          label: item.name
        }, null, _parent));
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters/Schedule.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_8 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-dbabdf13"]]);
const _sfc_main$4 = {
  __name: "Filters",
  __ssrInlineRender: true,
  setup(__props) {
    var _a;
    useVacancyStore();
    const uiStore = useUIStore();
    const isSidebarOpen = computed(() => uiStore.isSidebarOpen);
    const { $isMobile } = useNuxtApp();
    const { turnOnMobileMode, turnOffMobileMode } = uiStore;
    const isMobile = computed(() => $isMobile());
    if (isMobile) {
      turnOnMobileMode();
    } else {
      turnOffMobileMode();
    }
    const initialValues = {
      industries: [],
      countries: [1],
      regions: [],
      cities: []
    };
    const { getCurrentQueryParams } = useQueryParams();
    const currentParams = ref((_a = getCurrentQueryParams(initialValues)) != null ? _a : {});
    const { values, setValues } = useForm({
      initialValues
    });
    setValues(currentParams.value);
    const isCityMode = computed(() => {
      return false;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesFiltersSalary = __nuxt_component_0$1;
      const _component_VacanciesFiltersIndustry = __nuxt_component_1$2;
      const _component_VacanciesFiltersRegion = __nuxt_component_2$1;
      const _component_VacanciesFiltersCity = __nuxt_component_3;
      const _component_VacanciesFiltersMetro = __nuxt_component_4;
      const _component_VacanciesFiltersPartTime = __nuxt_component_5;
      const _component_VacanciesFiltersExperience = __nuxt_component_6;
      const _component_VacanciesFiltersWorkType = __nuxt_component_7;
      const _component_VacanciesFiltersSchedule = __nuxt_component_8;
      _push(`<aside${ssrRenderAttrs(mergeProps({
        class: ["aside", { active: unref(isSidebarOpen) }]
      }, _attrs))} data-v-07ab2c90><div class="filter-container" data-v-07ab2c90><div class="filter-head" data-v-07ab2c90><strong data-v-07ab2c90>\u0424\u0438\u043B\u044C\u0442\u0440\u044B</strong><button class="clear-all" data-v-07ab2c90>\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0432\u0441\u0435</button></div>`);
      _push(ssrRenderComponent(_component_VacanciesFiltersSalary, null, null, _parent));
      _push(ssrRenderComponent(_component_VacanciesFiltersIndustry, null, null, _parent));
      _push(ssrRenderComponent(_component_VacanciesFiltersRegion, { "is-city-mode": unref(isCityMode) }, null, _parent));
      _push(ssrRenderComponent(_component_VacanciesFiltersCity, null, null, _parent));
      _push(ssrRenderComponent(_component_VacanciesFiltersMetro, null, null, _parent));
      _push(ssrRenderComponent(_component_VacanciesFiltersPartTime, null, null, _parent));
      _push(ssrRenderComponent(_component_VacanciesFiltersExperience, null, null, _parent));
      _push(ssrRenderComponent(_component_VacanciesFiltersWorkType, null, null, _parent));
      _push(ssrRenderComponent(_component_VacanciesFiltersSchedule, null, null, _parent));
      _push(`</div><button class="close-aside" data-v-07ab2c90><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="20" height="20" viewBox="0 0 122.878 122.88" enable-background="new 0 0 122.878 122.88" xml:space="preserve" data-v-07ab2c90><g data-v-07ab2c90><path d="M1.426,8.313c-1.901-1.901-1.901-4.984,0-6.886c1.901-1.902,4.984-1.902,6.886,0l53.127,53.127l53.127-53.127 c1.901-1.902,4.984-1.902,6.887,0c1.901,1.901,1.901,4.985,0,6.886L68.324,61.439l53.128,53.128c1.901,1.901,1.901,4.984,0,6.886 c-1.902,1.902-4.985,1.902-6.887,0L61.438,68.326L8.312,121.453c-1.901,1.902-4.984,1.902-6.886,0 c-1.901-1.901-1.901-4.984,0-6.886l53.127-53.128L1.426,8.313L1.426,8.313z" data-v-07ab2c90></path></g></svg></button></aside>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Filters.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_1$1 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-07ab2c90"]]);
const _sfc_main$3 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_SkeletonCard = __nuxt_component_0$5;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "content" }, _attrs))}><div><ul class="favorites-list"><!--[-->`);
  ssrRenderList(10, (item) => {
    _push(ssrRenderComponent(_component_SkeletonCard, { key: item }, null, _parent));
  });
  _push(`<!--]--></ul><button id="load_more_button" class="create-button show-more"> \u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0435\u0449\u0435 <div class="ms-2 spinner-grow spinner-grow-sm" role="status"><span class="visually-hidden">Loading...</span></div><img${ssrRenderAttr("src", _imports_0$3)} alt="#"></button></div></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/LoadingList.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$2 = {
  __name: "List",
  __ssrInlineRender: true,
  setup(__props) {
    const AsyncList = defineAsyncComponent(() => import('./AsyncList-BJFJi0sp.mjs'));
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VacanciesLoadingList = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "content" }, _attrs))}>`);
      ssrRenderSuspense(_push, {
        default: () => {
          _push(ssrRenderComponent(unref(AsyncList), null, null, _parent));
        },
        fallback: () => {
          _push(ssrRenderComponent(_component_VacanciesLoadingList, null, null, _parent));
        },
        _: 1
      });
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/List.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "Results",
  __ssrInlineRender: true,
  setup(__props) {
    var _a;
    const { $format_number } = useNuxtApp();
    const vacancyStore = useVacancyStore();
    useDictionaryStore();
    const uiStore = useUIStore();
    const total = ref((_a = $format_number(vacancyStore.total)) != null ? _a : 0);
    computed(() => uiStore.isSidebarOpen);
    const route = useRoute();
    const { name: search_keyword } = route.query;
    ref(useCurrencyOptions());
    ref(useSortingOptions());
    ref(useVacancyForm());
    const isLoading = ref(false);
    useRouter();
    useResumeStore();
    const { getVacancies } = vacancyStore;
    const { getCurrentQueryParams } = useQueryParams();
    const currentParams = ref(getCurrentQueryParams());
    watch(
      () => ({ ...getCurrentQueryParams() }),
      async (newValues) => {
        isLoading.value = true;
        console.log(newValues);
        currentParams.value = newValues;
        await getVacancies(newValues);
        isLoading.value = false;
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BlockLoader = __nuxt_component_0$4;
      const _component_VacanciesFilters = __nuxt_component_1$1;
      const _component_VacanciesList = __nuxt_component_2;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main results-page",
        role: "main"
      }, _attrs))} data-v-37c99b22><div class="results-page-content" data-v-37c99b22><div class="wrapper" data-v-37c99b22><div class="search-head" data-v-37c99b22><div class="col" data-v-37c99b22><div class="search-item" data-v-37c99b22>${ssrInterpolate(unref(search_keyword))}</div><div class="found-count" data-v-37c99b22> \u041D\u0430\u0439\u0434\u0435\u043D\u043E ${ssrInterpolate(unref(total))} \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439 </div></div><div class="col d-flex justify-content-end" data-v-37c99b22><div class="d-inline-flex" data-v-37c99b22></div></div></div><button class="mob-get-aside-btn" data-v-37c99b22>`);
      _push(ssrRenderComponent(FilterIcon, null, null, _parent));
      _push(` \u0424\u0438\u043B\u044C\u0442\u0440\u044B </button><div class="aside-container" data-v-37c99b22>`);
      if (unref(isLoading)) {
        _push(ssrRenderComponent(_component_BlockLoader, { class: "position-fixed" }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_VacanciesFilters, null, null, _parent));
      _push(ssrRenderComponent(_component_VacanciesList, {
        key: _ctx.$route.fullPath
      }, null, _parent));
      _push(`</div></div></div></main>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Results.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-37c99b22"]]);
const _sfc_main = {
  __name: "vacancies",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u041F\u043E\u0438\u0441\u043A \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0439 - Jobeek"
    });
    const authStore = useAuthStore();
    computed(() => authStore.isEmployer);
    useRoute();
    watch(
      () => authStore.isEmployer,
      (new_value) => {
        if (!new_value) {
          navigateTo({ name: "search-resumes" });
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SearchVacancyForm = __nuxt_component_0$2;
      const _component_VacanciesResults = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SearchVacancyForm, { with_wrapper: "true" }, null, _parent));
      _push(ssrRenderComponent(_component_VacanciesResults, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/search/vacancies.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=vacancies-7tyaLKDi.mjs.map
