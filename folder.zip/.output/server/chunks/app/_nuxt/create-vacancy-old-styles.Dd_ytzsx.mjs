import { c as createVacancyOld_vue_vue_type_style_index_0_lang } from './create-vacancy-old-styles-1.mjs-da2iGGot.mjs';
import { c as createVacancyOld_vue_vue_type_style_index_1_lang } from './create-vacancy-old-styles-2.mjs-CKJ3T12n.mjs';

const createVacancyOldStyles_Dd_ytzsx = [createVacancyOld_vue_vue_type_style_index_0_lang, createVacancyOld_vue_vue_type_style_index_1_lang];

export { createVacancyOldStyles_Dd_ytzsx as default };
//# sourceMappingURL=create-vacancy-old-styles.Dd_ytzsx.mjs.map
