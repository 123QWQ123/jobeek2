const VeeItem_vue_vue_type_style_index_0_scoped_600cc5bf_lang = ".absoluted_icon[data-v-600cc5bf]{cursor:pointer;font-size:2rem;left:-1.5rem;max-width:3rem;top:1rem;z-index:1}.start-to-end[data-v-600cc5bf]{display:inline-flex;flex:1 1;gap:1rem}.hour_c2[data-v-600cc5bf]{flex-basis:fit-content;flex:1}";

const VeeItemStyles_BGKWY27_ = [VeeItem_vue_vue_type_style_index_0_scoped_600cc5bf_lang];

export { VeeItemStyles_BGKWY27_ as default };
//# sourceMappingURL=VeeItem-styles.BGKWY27-.mjs.map
