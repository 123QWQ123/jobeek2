const VeeSelectWithSearch_vue_vue_type_style_index_0_lang = ".select2-container .select2-selection--multiple .select2-selection__rendered{flex-wrap:wrap!important}";

export { VeeSelectWithSearch_vue_vue_type_style_index_0_lang as V };
//# sourceMappingURL=VeeSelectWithSearch-styles-1.mjs-DH5SIHl1.mjs.map
