const index_vue_vue_type_style_index_0_scoped_21be425e_lang = ".content-enter-active[data-v-21be425e],.content-leave-active[data-v-21be425e]{transition:opacity .5s ease}.content-enter-from[data-v-21be425e],.content-leave-to[data-v-21be425e]{opacity:0}@media (max-width:768px){.content[data-v-21be425e]{order:2}.sidebar[data-v-21be425e]{order:1}}";

const indexStyles_BGg3Kw6b = [index_vue_vue_type_style_index_0_scoped_21be425e_lang];

export { indexStyles_BGg3Kw6b as default };
//# sourceMappingURL=index-styles.BGg3Kw6b.mjs.map
