import { _ as __nuxt_component_0 } from './nuxt-link-BdrY0gEc.mjs';
import { useSSRContext, withAsyncContext, mergeProps, withCtx, createVNode, createTextVNode, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { _ as _imports_0 } from './jobeek-dark-BM969tB2.mjs';
import { u as useUIStore } from './ui-DaXXToyC.mjs';

const _sfc_main = {
  __name: "TheFooter",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const uiStore = useUIStore();
    const { getFooterSettings } = uiStore;
    [__temp, __restore] = withAsyncContext(() => getFooterSettings()), await __temp, __restore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<footer${ssrRenderAttrs(mergeProps({ class: "main-footer" }, _attrs))}><div class="main-footer-content wrapper">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "logo"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="#"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "#"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="footer-navigation navigation" role="navigation"><div class="col"><h5 class="col-title">\u0420\u0430\u0431\u043E\u0442\u043E\u0434\u0430\u0442\u0435\u043B\u044F\u043C</h5><ul><li>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "create-vacancy" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E `);
          } else {
            return [
              createTextVNode("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "search-resumes" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041F\u043E\u0438\u0441\u043A \u0441\u043E\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 `);
          } else {
            return [
              createTextVNode("\u041F\u043E\u0438\u0441\u043A \u0441\u043E\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "advice" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0421\u043E\u0432\u0435\u0442\u044B`);
          } else {
            return [
              createTextVNode("\u0421\u043E\u0432\u0435\u0442\u044B")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></div><div class="col"><h5 class="col-title">\u0421\u043E\u0438\u0441\u043A\u0430\u0442\u0435\u043B\u044F\u043C</h5><ul><li>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "create-vacancy" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0440\u0435\u0437\u044E\u043C\u0435 `);
          } else {
            return [
              createTextVNode("\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0440\u0435\u0437\u044E\u043C\u0435 ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "search-vacancies" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041F\u043E\u0438\u0441\u043A \u0440\u0430\u0431\u043E\u0442\u044B `);
          } else {
            return [
              createTextVNode("\u041F\u043E\u0438\u0441\u043A \u0440\u0430\u0431\u043E\u0442\u044B ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "advice" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0421\u043E\u0432\u0435\u0442\u044B`);
          } else {
            return [
              createTextVNode("\u0421\u043E\u0432\u0435\u0442\u044B")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></div><div class="col"><h5 class="col-title">\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F</h5><ul><li>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "profile" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041B\u0438\u0447\u043D\u044B\u0439 \u043A\u0430\u0431\u0438\u043D\u0435\u0442`);
          } else {
            return [
              createTextVNode("\u041B\u0438\u0447\u043D\u044B\u0439 \u043A\u0430\u0431\u0438\u043D\u0435\u0442")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: { name: "support" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041F\u043E\u043C\u043E\u0449\u044C`);
          } else {
            return [
              createTextVNode("\u041F\u043E\u043C\u043E\u0449\u044C")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li><a href="https://reg.jobeek.me/rules.pdf">\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u0441\u043A\u043E\u0435 \u0441\u043E\u0433\u043B\u0430\u0448\u0435\u043D\u0438\u0435</a></li><li><a href="https://reg.jobeek.me/default-jobeek/control">\u041E\u0442\u043C\u0435\u043D\u0430 \u043F\u0440\u0435\u043C\u0438\u0443\u043C\u0430</a></li></ul></div></div></div><div class="main-footer-bottom"><div class="wrapper"><span>\xA9 2018\u2013${ssrInterpolate((/* @__PURE__ */ new Date()).getFullYear())} Jobeek </span></div></div><div class="main-footer-bottom"><div class="wrapper"><div class="text-center">${unref(uiStore).footer_settings}</div></div></div></footer>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TheFooter.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_2 as _ };
//# sourceMappingURL=TheFooter-D-Qn_ABY.mjs.map
