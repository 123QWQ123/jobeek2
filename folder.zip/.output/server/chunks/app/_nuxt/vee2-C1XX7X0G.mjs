import { useForm, Field, ErrorMessage } from 'vee-validate';
import { _ as __nuxt_component_2 } from './Form-Bl6z4ElR.mjs';
import { mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import * as yup from 'yup';
import { useI18n } from 'vue-i18n';
import './VeeCustomSelect-BxrAvA7-.mjs';
import './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './dictionary--F10-rgU.mjs';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './useProviderFields-B2EuWWWy.mjs';
import './useProviders-Ck9yopDY.mjs';
import './state-D1MfAAni.mjs';
import './VuePhoneInput-C5R34atv.mjs';
import './useResumeHooks-BM2nRo7f.mjs';
import './ResumeCheckboxInput-DBsB0Z0m.mjs';
import './check-BGWLIG1L.mjs';

const _sfc_main = {
  __name: "vee2",
  __ssrInlineRender: true,
  setup(__props) {
    const initialData = {
      phones: [
        {
          type_id: null,
          phone: null,
          comment: null,
          start_available_time_phone: null,
          end_available_time_phone: null,
          is_preferred: false
        }
      ],
      email: ""
    };
    const { t } = useI18n();
    const schema = yup.object().shape({
      phones: yup.array().of(
        yup.object().shape({
          type_id: yup.string().required(t("create_resume.validation.required")),
          comment: yup.string().required(t("create_resume.validation.required")),
          start_available_time_phone: yup.string().required(t("create_resume.validation.required")),
          end_available_time_phone: yup.string().required(t("create_resume.validation.required")),
          phone: yup.string().email().required().label("phone"),
          is_preferred: yup.bool().required(t("create_resume.validation.required"))
        })
      ).strict(),
      email: yup.string().email(t("create_resume.validation.invalid_email")).required(t("create_resume.validation.required"))
    });
    const schema2 = {
      email: "required|email"
    };
    console.log(schema);
    console.log(schema2);
    const { values, setValues, errors, handleSubmit, validate } = useForm({
      initialValues: initialData,
      validationSchema: schema
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Field = Field;
      const _component_ErrorMessage = ErrorMessage;
      const _component_CreateResumeVeePhoneFieldsForm = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="p-5"><h1>vee-validate array fields</h1><form><div class="input-group"><label for="email">Parent Email</label>`);
      _push(ssrRenderComponent(_component_Field, {
        id: "email",
        name: "email",
        type: "email"
      }, null, _parent));
      _push(ssrRenderComponent(_component_ErrorMessage, { name: "email" }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_CreateResumeVeePhoneFieldsForm, { name: "phones" }, null, _parent));
      _push(` ${ssrInterpolate(unref(values))} <br><button class="btn btn-primary" type="submit">Submit</button></form></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vee2.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=vee2-C1XX7X0G.mjs.map
