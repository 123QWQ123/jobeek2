import { _ as __nuxt_component_0 } from './SearchMobile-WfXJ1gHL.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { _ as __nuxt_component_2, a as __nuxt_component_3 } from './SearchSection-BlAf03bK.mjs';
import './search-CNCM2ROA.mjs';
import './useQueryParams-Bpl0Cf82.mjs';
import './state-D1MfAAni.mjs';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './nuxt-link-BdrY0gEc.mjs';
import './BlockLoader-RiL0eLJn.mjs';
import 'swiper/vue';
import './dictionary--F10-rgU.mjs';

const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "place-section place-section--t2 section wrapper" }, _attrs))}><a class="place-card place-card--place-resume" href="#"><h4 class="place-card-title">\u0420\u0430\u0437\u043C\u0435\u0441\u0442\u0438\u0442\u0435 \u0440\u0435\u0437\u044E\u043C\u0435</h4><p class="place-card-descr">\u0422\u0430\u043A \u0432\u044B \u043D\u0430\u0439\u0434\u0435\u0442\u0435 \u0440\u0430\u0431\u043E\u0442\u0443 \u0432 5 \u0440\u0430\u0437 \u0431\u044B\u0441\u0442\u0440\u0435\u0435, \u0432\u0435\u0434\u044C \u0440\u0430\u0431\u043E\u0442\u0430 \u0431\u0443\u0434\u0435\u0442 \u0438\u0441\u043A\u0430\u0442\u044C \u0432\u0430\u0441 \u0441\u0430\u043C\u0430!</p><button class="btn button-accent button-accent--ts-bigger">\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0440\u0435\u0437\u044E\u043C\u0435</button></a><a class="place-card place-card--premium" href="#"><h4 class="place-card-title">\u041F\u0440\u0435\u043C\u0438\u0443\u043C</h4><p class="place-card-descr">\u0423 \u0432\u0430\u0441 \u0443\u0436\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D \u043F\u0440\u0435\u043C\u0438\u0443\u043C, \u0432\u0441\u0435 \u043F\u0440\u0435\u0438\u043C\u0443\u0449\u0435\u0441\u0442\u0432\u0430 \u0432\u043A\u043B\u044E\u0447\u0435\u043D\u044B</p></a></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/PersonalCabinet/Cards.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "cabinet",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_PersonalCabinetSearchMobile = __nuxt_component_0;
      const _component_PersonalCabinetCards = __nuxt_component_1;
      const _component_HomeWorkSection = __nuxt_component_2;
      const _component_HomeSearchSection = __nuxt_component_3;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet",
        role: "main"
      }, _attrs))}><div class="bg-wrapper">`);
      _push(ssrRenderComponent(_component_PersonalCabinetSearchMobile, null, null, _parent));
      _push(ssrRenderComponent(_component_PersonalCabinetCards, null, null, _parent));
      _push(ssrRenderComponent(_component_HomeWorkSection, null, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_HomeSearchSection, null, null, _parent));
      _push(`</main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/cabinet.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=cabinet-BKpUXPx_.mjs.map
