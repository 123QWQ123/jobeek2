import { ref, computed, watch, unref, useSSRContext } from 'vue';
import { r as useResumeStore, m as useProfileStore, e as useRoute, p as useRequestURL } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderAttr, ssrRenderClass, ssrInterpolate } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1 } from './superjob-DOWPfj1m.mjs';
import moment from 'moment';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const _sfc_main = {
  __name: "ConnectedProviders",
  __ssrInlineRender: true,
  setup(__props) {
    const resumeStore = useResumeStore();
    useProfileStore();
    const providers = ref({
      hh: {
        slug: "hh",
        url: null,
        is_connected: false
      },
      superjob: {
        slug: "superjob",
        url: null,
        is_connected: false
      }
    });
    const isSyncing = ref(false);
    const lastSyncedTime = computed(() => {
      return moment().format("h:mm \u0447, DD.MM.Y");
    });
    const isSuperjobConnected = computed(() => {
      return resumeStore.providers.superjob;
    });
    const isHHConnected = computed(() => {
      return resumeStore.providers.hh;
    });
    providers.value.hh.is_connected = resumeStore.providers.hh;
    providers.value.superjob.is_connected = resumeStore.providers.superjob;
    watch(
      () => resumeStore.providers,
      (newProviders) => {
        providers.value.hh.is_connected = newProviders.hh;
        providers.value.superjob.is_connected = newProviders.superjob;
      }
    );
    const isAnyProviderConnected = computed(() => {
      if (resumeStore.providers.hh === true || resumeStore.providers.superjob === true)
        return true;
      else
        return false;
    });
    useRoute();
    useRequestURL();
    ref();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-9d1010b4><h1 class="lk-page-title mb-4" data-v-9d1010b4>C\u0435\u0440\u0432\u0438\u0441\u044B</h1><div class="card mb-4 border-0 px-2 py-0" style="${ssrRenderStyle({ "border-radius": "12px" })}" data-v-9d1010b4><div class="row align-baseline justify-between" data-v-9d1010b4><div class="col-6 list-of-providers" data-v-9d1010b4><a${ssrRenderAttr("href", unref(providers).hh.url)} target="_blank" class="${ssrRenderClass([{ navigated: unref(isHHConnected) }, "provider-item"])}" data-v-9d1010b4><span class="provider-label success" data-v-9d1010b4>`);
      if (unref(isHHConnected)) {
        _push(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="limegreen" class="bi bi-check connected" viewBox="0 0 16 16" data-v-9d1010b4><path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z" data-v-9d1010b4></path></svg>`);
      } else {
        _push(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#f14646" class="bi bi-x" viewBox="0 0 16 16" data-v-9d1010b4><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-9d1010b4></path></svg>`);
      }
      if (unref(isHHConnected)) {
        _push(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#f14646" class="bi bi-x remove" viewBox="0 0 16 16" data-v-9d1010b4><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-9d1010b4></path></svg>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</span><img${ssrRenderAttr("src", _imports_0)} class="w-100" data-v-9d1010b4></a><a${ssrRenderAttr("href", unref(providers).superjob.url)} target="_blank" class="${ssrRenderClass([{ navigated: unref(isSuperjobConnected) }, "provider-item"])}" data-v-9d1010b4><span class="provider-label success" data-v-9d1010b4>`);
      if (unref(isSuperjobConnected)) {
        _push(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="limegreen" class="bi bi-check connected" viewBox="0 0 16 16" data-v-9d1010b4><path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z" data-v-9d1010b4></path></svg>`);
      } else {
        _push(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#f14646" class="bi bi-x" viewBox="0 0 16 16" data-v-9d1010b4><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-9d1010b4></path></svg>`);
      }
      if (unref(isHHConnected)) {
        _push(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#f14646" class="bi bi-x remove" viewBox="0 0 16 16" data-v-9d1010b4><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-9d1010b4></path></svg>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</span><img${ssrRenderAttr("src", _imports_1)} class="w-100" data-v-9d1010b4></a></div><div class="col-6 refresh-button_col" data-v-9d1010b4><div class="h-100 d-flex align-items-center" data-v-9d1010b4><div class="sync-card d-flex flex-column pe-4" data-v-9d1010b4><button class="${ssrRenderClass([{ rotating: unref(isSyncing) }, "sync-button"])}" data-v-9d1010b4><svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" fill="#5375FD" class="bi bi-arrow-repeat" viewBox="0 0 16 16" data-v-9d1010b4><path d="M11.534 7h3.932a.25.25 0 0 1 .192.41l-1.966 2.36a.25.25 0 0 1-.384 0l-1.966-2.36a.25.25 0 0 1 .192-.41zm-11 2h3.932a.25.25 0 0 0 .192-.41L2.692 6.23a.25.25 0 0 0-.384 0L.342 8.59A.25.25 0 0 0 .534 9z" data-v-9d1010b4></path><path fill-rule="evenodd" d="M8 3c-1.552 0-2.94.707-3.857 1.818a.5.5 0 1 1-.771-.636A6.002 6.002 0 0 1 13.917 7H12.9A5.002 5.002 0 0 0 8 3zM3.1 9a5.002 5.002 0 0 0 8.757 2.182.5.5 0 1 1 .771.636A6.002 6.002 0 0 1 2.083 9H3.1z" data-v-9d1010b4></path></svg></button>`);
      {
        _push(`<span class="" data-v-9d1010b4>\u0432 ${ssrInterpolate(unref(lastSyncedTime))}</span>`);
      }
      _push(`</div></div></div></div>`);
      if (!unref(isAnyProviderConnected)) {
        _push(`<div class="mb-4" data-v-9d1010b4> \u041D\u0435 \u043E\u0434\u0438\u043D \u0441\u0435\u0440\u0432\u0438\u0441 \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D! </div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MyResumes/ConnectedProviders.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-9d1010b4"]]);

export { __nuxt_component_1 as _ };
//# sourceMappingURL=ConnectedProviders-HekmsW6F.mjs.map
