globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { _ as __nuxt_component_0$1, a as __nuxt_component_2 } from './LikeList-D7jOt6wI.mjs';
import { e as useRoute, l as useVacancyStore, s as storeToRefs, u as useHead, j as useNuxtApp, x as __nuxt_component_0$1$1, r as useResumeStore } from '../server.mjs';
import { _ as __nuxt_component_0 } from './CustomSelectWithRadio-CUSovK5B.mjs';
import { useSSRContext, ref, withAsyncContext, computed, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrRenderAttr, ssrRenderStyle, ssrIncludeBooleanAttr, ssrRenderList } from 'vue/server-renderer';
import { _ as _imports_1 } from './akar-icons_whatsapp-fill-DXuWDQDi.mjs';
import moment from 'moment';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './search-CNCM2ROA.mjs';
import './location-6cdwV0kl.mjs';
import './megafon-UViF3Tze.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const _sfc_main$2 = {
  __name: "ContentSidebar",
  __ssrInlineRender: true,
  props: {
    data: {
      required: true
    }
  },
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const props = __props;
    const { data } = storeToRefs(props);
    const isFavorite = ref((_a = data.value.is_favorite) != null ? _a : false);
    useVacancyStore();
    const resumeStore = useResumeStore();
    const { getMyResumes, submitResume } = resumeStore;
    storeToRefs(resumeStore);
    [__temp, __restore] = withAsyncContext(() => getMyResumes()), await __temp, __restore();
    const isContactsShown = ref(false);
    const selectedResume = ref(null);
    const responseLetter = ref(null);
    const requiredLetter = computed(() => {
      var _a2;
      return (_a2 = data.value.response_letter_required) != null ? _a2 : false;
    });
    const selectedResumeError = ref();
    const myResumeOptions = computed(() => {
      return resumeStore.my_resumes.map((item) => ({
        name: item.title,
        value: item.id
      }));
    });
    const vacancyPhones = computed(() => {
      var _a2;
      return (_a2 = data.value.contacts.phones) != null ? _a2 : [];
    });
    const getPhoneHref = (phone) => {
      return "href: +" + phone;
    };
    const employerLogo = computed(() => {
      if (data.value && data.value.logo) {
        return data.value.logo;
      } else
        return new URL("/assets/img/logos/superjob.svg", globalThis._importMeta_.url);
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2;
      const _component_CustomSelectWithRadio = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="company-col"><div class="favorites-card-footer-row"><div class="group"><button class="${ssrRenderClass([{ active: isFavorite.value }, "group-action ic-btn fav-btn"])}"><svg width="23" height="21" viewBox="0 0 23 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.0641 0.796788C11.2552 0.45665 11.7448 0.456649 11.9359 0.796789L14.7993 5.89364C15.0135 6.27499 15.3835 6.54383 15.8124 6.62973L21.5446 7.77794C21.9272 7.85457 22.0785 8.32027 21.8141 8.60711L17.8515 12.9053C17.555 13.2269 17.4137 13.6619 17.4645 14.0964L18.1439 19.9029C18.1892 20.2903 17.793 20.5782 17.4385 20.4153L12.1262 17.9749C11.7287 17.7923 11.2713 17.7923 10.8738 17.9749L5.56148 20.4153C5.20696 20.5782 4.81081 20.2903 4.85614 19.9029L5.53549 14.0964C5.58632 13.6619 5.44498 13.2269 5.1485 12.9053L1.18593 8.60711C0.921493 8.32027 1.07281 7.85457 1.45535 7.77794L7.18757 6.62973C7.61645 6.54383 7.98648 6.27499 8.20072 5.89364L11.0641 0.796788Z" stroke="#C8C8C8"></path></svg></button></div></div><div class="company-logo"><img class="w-100"${ssrRenderAttr("src", unref(employerLogo))}${ssrRenderAttr("alt", unref(data).company)}></div><h3 class="title">${ssrInterpolate(unref(data).company)}</h3><p>\u041A\u043B\u0438\u0435\u043D\u0442 SuperJob \u0441 2003 \u0433\u043E\u0434\u0430</p><p>${ssrInterpolate((_a2 = unref(data).vacancy_count) != null ? _a2 : 0)} \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</p><p>${unref(data).company_activity}</p><div class="count">123 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</div><div class="grade-box-container"><div class="title">\u041E\u0446\u0435\u043D\u043A\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432</div><div class="grade-box"><div class="grade-box-circle"><svg class="progress" data-complete="0.75" xmlns="http://www.w3.org/2000/svg" viewBox="-1 -1 34 34"><circle cx="16" cy="16" r="15.9155" class="progress-bar__background"></circle><circle cx="16" cy="16" r="15.9155" class="progress-bar__progress js-progress-bar" style="${ssrRenderStyle({ "stroke-dashoffset": "25px" })}"></circle></svg><span>7.5</span></div><div class="grade-box-text"><strong>\u0425\u043E\u0440\u043E\u0448\u043E</strong><a href="#">12 \u043E\u0442\u0437\u044B\u0432\u043E\u0432 </a></div></div><span class="txt">55% \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u044E\u0442 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u044E</span></div></div><div class="company-col"><span class="select-resume-title title">\u041C\u043E\u0438 \u0440\u0435\u0437\u044E\u043C\u0435</span><div class="select-resume-row"><div class="custom-select-wrapper">`);
      _push(ssrRenderComponent(_component_CustomSelectWithRadio, {
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0435\u0437\u044E\u043C\u0435",
        modelValue: selectedResume.value,
        "onUpdate:modelValue": ($event) => selectedResume.value = $event,
        options: unref(myResumeOptions)
      }, null, _parent));
      _push(`<button id="apply-button" class="btn apply-button button-accent"${ssrIncludeBooleanAttr(!selectedResume.value) ? " disabled" : ""}> \u041E\u0442\u043A\u043B\u0438\u043A\u043D\u0443\u0442\u044C\u0441\u044F </button></div><span class="text text-danger">${ssrInterpolate(selectedResumeError.value)}</span></div>`);
      if (unref(requiredLetter)) {
        _push(`<textarea class="form-control mt-1" placeholder="C\u043E\u043F\u0440\u043E\u0432\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u043F\u0438\u0441\u044C\u043C\u043E">${ssrInterpolate(responseLetter.value)}</textarea>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="company-col"><div class="${ssrRenderClass([{ open: isContactsShown.value }, "telephones-row telephones-row-handle"])}">`);
      if (unref(vacancyPhones).length > 0) {
        _push(`<ul><!--[-->`);
        ssrRenderList(unref(vacancyPhones), (phone) => {
          _push(`<li><a class="tel"${ssrRenderAttr("href", getPhoneHref(phone))}><img${ssrRenderAttr("src", _imports_1)} alt="#"> ${ssrInterpolate(phone)}</a></li>`);
        });
        _push(`<!--]--></ul>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (!isContactsShown.value) {
        _push(`<button class="group-action btn button-md js-show-contacts"> \u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u044B </button>`);
      } else {
        _push(`<!---->`);
      }
      if (isContactsShown.value) {
        _push(`<button class="group-action btn button-md js-show-contacts"> \u0421\u043A\u0440\u044B\u0442\u044C \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u044B </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/Single/ContentSidebar.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1$1 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "ItemContent",
  __ssrInlineRender: true,
  props: {
    data: {
      required: true
    }
  },
  setup(__props) {
    var _a;
    const props = __props;
    const { data } = storeToRefs(props);
    const { $format_number } = useNuxtApp();
    ref((_a = data.value.is_favorite) != null ? _a : false);
    computed(() => {
      return $format_number(data.value.salary_from);
    });
    computed(() => {
      return $format_number(data.value.salary_to);
    });
    useVacancyStore();
    computed(() => {
      if (data.value && data.value.logo) {
        return data.value.logo;
      } else
        return new URL("/assets/img/logos/superjob.svg", globalThis._importMeta_.url);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_client_only = __nuxt_component_0$1$1;
      const _component_VacanciesSingleContentSidebar = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "has-sidebar has-sidebar--v3" }, _attrs))}><div class="content"><div class="vacancy-single"><div class="vacancy-single-head"><h1 class="title">${ssrInterpolate(unref(data).name)}</h1><div class="adress"><span>${ssrInterpolate(unref(data).address)}</span></div><div class="requirements">${ssrInterpolate(unref(data).experience && unref(data).experience + ",")} ${ssrInterpolate(unref(data).education && unref(data).education + ",")} ${ssrInterpolate(unref(data).work_type)}, ${ssrInterpolate(unref(moment).unix(unref(data).published_date).format("YYYY.MM.DD"))}</div>`);
      _push(ssrRenderComponent(_component_client_only, null, {}, _parent));
      _push(`</div><div class="vacancy-single-body">${unref(data).description}</div><div class="vacancy-single-footer"><button class="btn button-accent button-accent--ts-bigger"> \u041E\u0442\u043A\u043B\u0438\u043A\u043D\u0443\u0442\u044C\u0441\u044F </button></div></div></div><aside class="sidebar">`);
      _push(ssrRenderComponent(_component_VacanciesSingleContentSidebar, { data: unref(data) }, null, _parent));
      _push(`</aside></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vacancies/ItemContent.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$1;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    ref(true);
    const route = useRoute();
    const vacancyStore = useVacancyStore();
    const { getVacancy } = vacancyStore;
    const { vacancy } = storeToRefs(vacancyStore);
    const { slug } = route.params;
    const { provider } = route.query;
    const vacancyData = ([__temp, __restore] = withAsyncContext(() => getVacancy(slug, { provider })), __temp = await __temp, __restore(), __temp);
    const pageTitle = computed(() => {
      var _a2;
      return ((_a2 = vacancyData[provider]) == null ? void 0 : _a2.name) + " - Jobeek";
    });
    useHead({
      title: (_a = pageTitle.value) != null ? _a : "Loading"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SearchForm = __nuxt_component_0$1;
      const _component_VacanciesItemContent = __nuxt_component_1;
      const _component_VacanciesSingleLikeList = __nuxt_component_2;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main cabinet vacansy-page",
        role: "main"
      }, _attrs))} data-v-56917ac8><div class="bg-wrapper pt" data-v-56917ac8><div class="main-section main-section-mob" data-v-56917ac8><div class="wrapper wrapper--xl" data-v-56917ac8>`);
      _push(ssrRenderComponent(_component_SearchForm, null, null, _parent));
      _push(`</div></div>`);
      if (unref(vacancy)) {
        _push(`<div class="wrapper wrapper-1290" data-v-56917ac8>`);
        _push(ssrRenderComponent(_component_VacanciesItemContent, {
          data: unref(vacancy)[unref(provider)]
        }, null, _parent));
        _push(`<h2 class="lk-page-title" data-v-56917ac8>\u041F\u043E\u0445\u043E\u0436\u0438\u0435 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438</h2><div class="favorites-list-container" data-v-56917ac8>`);
        _push(ssrRenderComponent(_component_VacanciesSingleLikeList, null, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vacancies/[slug]/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-56917ac8"]]);

export { index as default };
//# sourceMappingURL=index-Dq-Enc_I.mjs.map
