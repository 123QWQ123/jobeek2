import { S as SeekerEditForm_vue_vue_type_style_index_0_lang } from './SeekerEditForm-styles-1.mjs-D7IIqgMQ.mjs';
import { S as SeekerEditForm_vue_vue_type_style_index_1_scoped_25e47d92_lang } from './SeekerEditForm-styles-2.mjs-u0YZBwRF.mjs';

const SeekerEditFormStyles_DEMTJIk = [SeekerEditForm_vue_vue_type_style_index_0_lang, SeekerEditForm_vue_vue_type_style_index_1_scoped_25e47d92_lang];

export { SeekerEditFormStyles_DEMTJIk as default };
//# sourceMappingURL=SeekerEditForm-styles.DEM-TJIk.mjs.map
