const PartTime_vue_vue_type_style_index_0_scoped_874b1c35_lang = ".check-block label[data-v-874b1c35]{white-space:pre-wrap}.with_scroll[data-v-874b1c35]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-874b1c35]{font-weight:700}.is_header .radio-mask[data-v-874b1c35],.is_header input[data-v-874b1c35]{display:none}input[type=search][data-v-874b1c35]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const PartTimeStyles_UnavPOPt = [PartTime_vue_vue_type_style_index_0_scoped_874b1c35_lang];

export { PartTimeStyles_UnavPOPt as default };
//# sourceMappingURL=PartTime-styles.UnavPOPt.mjs.map
