const _imports_0 = "data:image/svg+xml,%3csvg%20width='16'%20height='11'%20viewBox='0%200%2016%2011'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M1%205.5L5.5%2010L14.5%201'%20stroke='white'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e";

export { _imports_0 as _ };
//# sourceMappingURL=check-BGWLIG1L.mjs.map
