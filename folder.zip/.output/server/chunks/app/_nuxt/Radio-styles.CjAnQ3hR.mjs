const Radio_vue_vue_type_style_index_0_scoped_9568e619_lang = ".checked .checkbox-mask img[data-v-9568e619]{opacity:1}.is_header label[data-v-9568e619]{font-weight:700}";

const RadioStyles_CjAnQ3hR = [Radio_vue_vue_type_style_index_0_scoped_9568e619_lang];

export { RadioStyles_CjAnQ3hR as default };
//# sourceMappingURL=Radio-styles.CjAnQ3hR.mjs.map
