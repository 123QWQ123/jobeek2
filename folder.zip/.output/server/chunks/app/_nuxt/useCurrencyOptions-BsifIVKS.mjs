function useCurrencyOptions(symbol_as_name = false) {
  if (symbol_as_name) {
    return [
      { value: "RUB", name: "\u20BD", symbol: "\u20BD" },
      { value: "USD", name: "$", symbol: "$" },
      { value: "EUR", name: "\u20AC", symbol: "\u20AC" }
    ];
  }
  return [
    { value: "RUB", name: "\u20BD - RUB", symbol: "\u20BD" },
    { value: "USD", name: "$ - USD", symbol: "$" },
    { value: "EUR", name: "\u20AC - EUR", symbol: "\u20AC" }
  ];
}

export { useCurrencyOptions as u };
//# sourceMappingURL=useCurrencyOptions-BsifIVKS.mjs.map
