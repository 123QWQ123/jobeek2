const SalarySelectInForm_vue_vue_type_style_index_0_lang = ".no_bg{background:none!important}";

const SalarySelectInFormStyles_CRhtFGlt = [SalarySelectInForm_vue_vue_type_style_index_0_lang];

export { SalarySelectInFormStyles_CRhtFGlt as default };
//# sourceMappingURL=SalarySelectInForm-styles.CRhtFGlt.mjs.map
