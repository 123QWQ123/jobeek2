const Form_vue_vue_type_style_index_0_scoped_e495bc1c_lang = ".absoluted_icon[data-v-e495bc1c]{cursor:pointer;font-size:1rem;left:-1.8rem;max-width:3rem;position:absolute;top:.5rem;z-index:1}.absoluted_icon svg[data-v-e495bc1c]{height:24px;width:24px}";

const FormStyles_rdmT30oL = [Form_vue_vue_type_style_index_0_scoped_e495bc1c_lang];

export { FormStyles_rdmT30oL as default };
//# sourceMappingURL=Form-styles.rdmT30oL.mjs.map
