const Item_vue_vue_type_style_index_0_scoped_90b65a1e_lang = ".absoluted_icon[data-v-90b65a1e]{cursor:pointer;font-size:1rem;max-width:3rem;position:absolute;right:-2rem;top:.5rem;z-index:1}.absoluted_icon svg[data-v-90b65a1e]{height:24px;width:24px}";

const ItemStyles_DHXYaM94 = [Item_vue_vue_type_style_index_0_scoped_90b65a1e_lang];

export { ItemStyles_DHXYaM94 as default };
//# sourceMappingURL=Item-styles.DHXYaM94.mjs.map
