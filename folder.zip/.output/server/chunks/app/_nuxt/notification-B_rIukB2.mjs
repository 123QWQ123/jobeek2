import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + buildAssetsURL("photo.DqOrI5Ju.png");
const _imports_1 = "data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M12%2022.5C17.799%2022.5%2022.5%2017.799%2022.5%2012C22.5%206.20101%2017.799%201.5%2012%201.5C6.20101%201.5%201.5%206.20101%201.5%2012C1.5%2017.799%206.20101%2022.5%2012%2022.5Z'%20fill='%235375FD'/%3e%3cpath%20d='M11%2011H13V16.5H11V11Z'%20fill='white'/%3e%3cpath%20d='M12%209.5C12.6904%209.5%2013.25%208.94036%2013.25%208.25C13.25%207.55964%2012.6904%207%2012%207C11.3096%207%2010.75%207.55964%2010.75%208.25C10.75%208.94036%2011.3096%209.5%2012%209.5Z'%20fill='white'/%3e%3c/svg%3e";

export { _imports_0 as _, _imports_1 as a };
//# sourceMappingURL=notification-B_rIukB2.mjs.map
