import { _ as __nuxt_component_0 } from './Item-BZivtBWi.mjs';
import { ref, withAsyncContext, watch, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { c as _imports_0 } from './FilterIcon-Bk66Krbt.mjs';
import { r as useResumeStore, s as storeToRefs } from '../server.mjs';
import { u as useQueryParams } from './useQueryParams-Bpl0Cf82.mjs';
import './nuxt-link-BdrY0gEc.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'moment';
import './check-BGWLIG1L.mjs';
import './_plugin-vue_export-helper-1tPrXgE0.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './state-D1MfAAni.mjs';

const _sfc_main = {
  __name: "AsyncList",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b;
    let __temp, __restore;
    const resumeStore = useResumeStore();
    const { getResumes } = resumeStore;
    storeToRefs(resumeStore);
    ref();
    const isLoading = ref(false);
    const isMore = ref(false);
    const { getQueryParam, getCurrentQueryParams } = useQueryParams();
    const current_params = (_a = getCurrentQueryParams()) != null ? _a : {};
    {
      [__temp, __restore] = withAsyncContext(() => getResumes({ ...getCurrentQueryParams("back") }, false, true)), await __temp, __restore();
    }
    const resumes = ref((_b = resumeStore.resumes) != null ? _b : []);
    watch(
      () => resumeStore.resumes,
      () => {
        resumes.value = resumeStore.resumes;
      }
    );
    const params = ref(current_params);
    watch(
      () => getCurrentQueryParams(),
      (newParams) => {
        isLoading.value = true;
        params.value = newParams;
      }
    );
    watch(resumes, (newValues) => {
      if (newValues.length > 0) {
        isMore.value = true;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ResumesItem = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "content" }, _attrs))}><div>${ssrInterpolate(unref(resumes))} <ul class="favorites-list"><!--[-->`);
      ssrRenderList(unref(resumes), (item) => {
        _push(ssrRenderComponent(_component_ResumesItem, {
          key: item.id,
          item
        }, null, _parent));
      });
      _push(`<!--]--></ul>`);
      if (unref(isMore)) {
        _push(`<button id="load_more_button" class="create-button show-more"> \u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0435\u0449\u0435 `);
        if (unref(isLoading)) {
          _push(`<div class="ms-2 spinner-grow spinner-grow-sm" role="status"><span class="visually-hidden">Loading...</span></div>`);
        } else {
          _push(`<img${ssrRenderAttr("src", _imports_0)} alt="#">`);
        }
        _push(`</button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Resumes/AsyncList.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=AsyncList-54QJjVxm.mjs.map
