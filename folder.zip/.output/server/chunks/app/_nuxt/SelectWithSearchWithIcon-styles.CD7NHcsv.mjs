import { S as SelectWithSearchWithIcon_vue_vue_type_style_index_0_lang } from './SelectWithSearchWithIcon-styles-1.mjs-BLrFJS4M.mjs';
import { S as SelectWithSearchWithIcon_vue_vue_type_style_index_1_scoped_e1188478_lang } from './SelectWithSearchWithIcon-styles-2.mjs-CZHC0-HD.mjs';

const SelectWithSearchWithIconStyles_CD7NHcsv = [SelectWithSearchWithIcon_vue_vue_type_style_index_0_lang, SelectWithSearchWithIcon_vue_vue_type_style_index_1_scoped_e1188478_lang];

export { SelectWithSearchWithIconStyles_CD7NHcsv as default };
//# sourceMappingURL=SelectWithSearchWithIcon-styles.CD7NHcsv.mjs.map
