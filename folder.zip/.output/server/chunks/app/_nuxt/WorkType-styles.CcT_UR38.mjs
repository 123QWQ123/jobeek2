const WorkType_vue_vue_type_style_index_0_scoped_028bd976_lang = ".check-block label[data-v-028bd976]{white-space:pre-wrap}.with_scroll[data-v-028bd976]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-028bd976]{font-weight:700}.is_header .radio-mask[data-v-028bd976],.is_header input[data-v-028bd976]{display:none}input[type=search][data-v-028bd976]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const WorkTypeStyles_CcT_UR38 = [WorkType_vue_vue_type_style_index_0_scoped_028bd976_lang];

export { WorkTypeStyles_CcT_UR38 as default };
//# sourceMappingURL=WorkType-styles.CcT_UR38.mjs.map
