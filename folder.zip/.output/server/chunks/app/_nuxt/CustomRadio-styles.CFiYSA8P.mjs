const CustomRadio_vue_vue_type_style_index_0_scoped_426c409e_lang = ".radio-label[data-v-426c409e]{align-items:center;box-shadow:0 0 20px rgba(28,27,98,.04);color:#0a2540;cursor:pointer;display:inline-flex;font-weight:400;justify-content:center;padding:5px;text-align:center}.radio-label.active[data-v-426c409e]{background-color:#3e85f6;color:#f5f8fa}.radio-label input.hidden[data-v-426c409e]{display:none}";

const CustomRadioStyles_CFiYSA8P = [CustomRadio_vue_vue_type_style_index_0_scoped_426c409e_lang];

export { CustomRadioStyles_CFiYSA8P as default };
//# sourceMappingURL=CustomRadio-styles.CFiYSA8P.mjs.map
