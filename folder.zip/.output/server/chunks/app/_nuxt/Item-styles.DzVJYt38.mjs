const Item_vue_vue_type_style_index_0_scoped_20a2eee9_lang = ".absoluted_icon[data-v-20a2eee9]{cursor:pointer;font-size:1rem;left:-.5rem;max-width:3rem;position:absolute;top:.5rem;z-index:1}.absoluted_icon svg[data-v-20a2eee9]{height:24px;width:24px}";

const ItemStyles_DzVJYt38 = [Item_vue_vue_type_style_index_0_scoped_20a2eee9_lang];

export { ItemStyles_DzVJYt38 as default };
//# sourceMappingURL=Item-styles.DzVJYt38.mjs.map
