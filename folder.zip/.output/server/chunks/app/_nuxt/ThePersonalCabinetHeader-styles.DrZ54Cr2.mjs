const ThePersonalCabinetHeader_vue_vue_type_style_index_0_scoped_ef85f583_lang = ".nav-link[data-v-ef85f583]{color:#fff!important}.router-link-exact-active[data-v-ef85f583]{color:#6c757d!important}.search-form--widget .search-row[data-v-ef85f583]{grid-template-columns:34.17% 22.56% 1fr 20%}";

const ThePersonalCabinetHeaderStyles_DrZ54Cr2 = [ThePersonalCabinetHeader_vue_vue_type_style_index_0_scoped_ef85f583_lang];

export { ThePersonalCabinetHeaderStyles_DrZ54Cr2 as default };
//# sourceMappingURL=ThePersonalCabinetHeader-styles.DrZ54Cr2.mjs.map
