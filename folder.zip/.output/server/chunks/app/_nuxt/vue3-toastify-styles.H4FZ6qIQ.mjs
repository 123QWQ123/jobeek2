import { i as index } from './entry-styles-23.mjs-AsrYHrMu.mjs';

const vue3ToastifyStyles_H4FZ6qIQ = [index];

export { vue3ToastifyStyles_H4FZ6qIQ as default };
//# sourceMappingURL=vue3-toastify-styles.H4FZ6qIQ.mjs.map
