const SeekerEditForm_vue_vue_type_style_index_1_scoped_25e47d92_lang = "#photo[data-v-25e47d92]{cursor:pointer}";

export { SeekerEditForm_vue_vue_type_style_index_1_scoped_25e47d92_lang as S };
//# sourceMappingURL=SeekerEditForm-styles-2.mjs-u0YZBwRF.mjs.map
