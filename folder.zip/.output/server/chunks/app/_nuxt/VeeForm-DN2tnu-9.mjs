import { _ as __nuxt_component_0$4 } from './VeeSelectWithSearch-CuZCClCB.mjs';
import __nuxt_component_2 from './VeeCustomSelect-BxrAvA7-.mjs';
import { useSSRContext, defineAsyncComponent, mergeProps, unref, ref, watch, toRefs, computed } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderComponent, ssrRenderAttr, ssrIncludeBooleanAttr, ssrInterpolate } from 'vue/server-renderer';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { useFieldArray } from 'vee-validate';
import { e as useRoute } from '../server.mjs';
import { _ as _imports_0 } from './check-BGWLIG1L.mjs';

const _sfc_main$3 = {
  __name: "VeeItem",
  __ssrInlineRender: true,
  props: ["idx", "name"],
  emits: ["remove"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    toRefs(props);
    const dictionaryStore = useDictionaryStore();
    const languageLevelOptions = computed(() => {
      return dictionaryStore.resume_language_levels.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const languageOptions = computed(() => {
      return dictionaryStore.foreign_languages.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeSelectWithSearch = __nuxt_component_0$4;
      const _component_VeeCustomSelect = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row position-relative" }, _attrs))} data-v-90ccc832><span class="position-absolute absoluted_icon" data-v-90ccc832><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" data-v-90ccc832><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-90ccc832></path></svg></span><div class="col-12" data-v-90ccc832><div class="c2 w-100" data-v-90ccc832><div class="input-wrapper" data-v-90ccc832>`);
      _push(ssrRenderComponent(_component_VeeSelectWithSearch, {
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u044F\u0437\u044B\u043A",
        options: unref(languageOptions),
        name: `${props.name}[${props.idx}].language_id`
      }, null, _parent));
      _push(`</div><div class="input-wrapper" data-v-90ccc832>`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        label: "\u0423\u0440\u043E\u0432\u0435\u043D",
        options: unref(languageLevelOptions),
        name: `${props.name}[${props.idx}].level_id`
      }, null, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/ForeignLanguages/VeeItem.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0$3 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-90ccc832"]]);
const _sfc_main$2 = {
  __name: "VeeForm",
  __ssrInlineRender: true,
  props: ["name"],
  setup(__props) {
    const props = __props;
    const { push, fields, remove } = useFieldArray(() => props.name);
    useDictionaryStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeForeignLanguagesVeeItem = __nuxt_component_0$3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "pe-4" }, _attrs))}><!--[-->`);
      ssrRenderList(unref(fields), (field, idx) => {
        _push(`<div class="mt-2">`);
        _push(ssrRenderComponent(_component_CreateResumeForeignLanguagesVeeItem, {
          onRemove: unref(remove),
          name: props.name,
          idx
        }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]-->`);
      if (unref(fields).length === 0) {
        _push(`<button type="button" class="btn btn-primary btn-sm mt-1"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(fields).length > 0) {
        _push(`<button type="button" class="btn btn-primary mt-1 btn-sm"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435 </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/ForeignLanguages/VeeForm.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0$2 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "DriverLicensesForm",
  __ssrInlineRender: true,
  props: ["name", "parent_type_id", "providers"],
  setup(__props) {
    ref(false);
    useRoute();
    const dictionaryStore = useDictionaryStore();
    const props = __props;
    const { fields, replace } = useFieldArray(() => props.name);
    watch(
      () => fields.value,
      (newIds) => {
        driving_license_item_options.value = dictionaryStore.driver_licenses;
      }
    );
    const driver_licenses = ref([]);
    const driving_license_item_options = ref([]);
    watch(
      () => dictionaryStore.driver_licenses,
      (newValues) => {
        driving_license_item_options.value = newValues;
      }
    );
    const check = (id) => {
      const IDs = [...fields.value].map((item) => item.value);
      return IDs.includes(id);
    };
    ref(false);
    ref(false);
    watch(
      () => driver_licenses.value,
      (newData) => {
        replace(newData);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "form_content" }, _attrs))} data-v-fc17c82a><div class="checkboxes-row" data-v-fc17c82a><!--[-->`);
      ssrRenderList(unref(driving_license_item_options), (item) => {
        _push(`<div class="check-block" data-v-fc17c82a><div class="checkbox" data-v-fc17c82a><input type="checkbox"${ssrRenderAttr("id", item.id)}${ssrIncludeBooleanAttr(check(item.id)) ? " checked" : ""} data-v-fc17c82a><div class="checkbox-mask" data-v-fc17c82a><img${ssrRenderAttr("src", _imports_0)} alt="#" data-v-fc17c82a></div></div><label${ssrRenderAttr("for", item.id)} data-v-fc17c82a>${ssrInterpolate(item.name)}</label></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/DriverLicensesForm.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-fc17c82a"]]);
const __nuxt_component_0_lazy = defineAsyncComponent(() => import('./InputWrapper-DzB22z5L.mjs').then((c) => c.default || c));
const _sfc_main = {
  __name: "VeeForm",
  __ssrInlineRender: true,
  props: {
    name: {
      required: true,
      default: "name"
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const { remove, push, fields, update } = useFieldArray(() => props.name);
    const isNew = ref(true);
    const currentSkillId = ref(null);
    const currentSkill = ref(null);
    const addItem = (newItem) => {
      push(newItem);
    };
    const updateItem = (id, newItem) => {
      update(currentSkillId.value, newItem);
      currentSkillId.value = null;
      currentSkill.value = null;
      isNew.value = true;
    };
    const deleteItem = (deleteItem2) => {
      console.log(deleteItem2);
      remove(deleteItem2);
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_LazyCreateResumeKnowledgeAndSkillsInputWrapper = __nuxt_component_0_lazy;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-100" }, _attrs))} data-v-3f4bdef7>`);
      if (props.message) {
        _push(`<div class="text-danger d-block p-4" data-v-3f4bdef7>${ssrInterpolate(props.message)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="row" data-v-3f4bdef7><div class="col-lg-6 col-xs-12" data-v-3f4bdef7>`);
      if (unref(fields).length > 0) {
        _push(`<div class="selection selected-options" data-v-3f4bdef7><ul class="selected-options" id="select2--container" data-v-3f4bdef7><!--[-->`);
        ssrRenderList(unref(fields), (item, index) => {
          _push(`<li class="multi-select_selected-item" data-v-3f4bdef7><button type="button" class="select2-selection__choice__remove" data-v-3f4bdef7><span aria-hidden="true" data-v-3f4bdef7>\xD7</span></button><span class="select2-selection__choice__display" data-v-3f4bdef7>${ssrInterpolate(item.value)}</span></li>`);
        });
        _push(`<!--]--></ul></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="row" data-v-3f4bdef7>`);
      _push(ssrRenderComponent(_component_LazyCreateResumeKnowledgeAndSkillsInputWrapper, {
        "is-new": unref(isNew),
        id: unref(currentSkillId),
        skill: unref(currentSkill),
        onAdd: addItem,
        onUpdate: updateItem,
        onDelete: deleteItem
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/KnowledgeAndSkills/VeeForm.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-3f4bdef7"]]);

export { __nuxt_component_0$2 as _, __nuxt_component_0$1 as a, __nuxt_component_0 as b };
//# sourceMappingURL=VeeForm-DN2tnu-9.mjs.map
