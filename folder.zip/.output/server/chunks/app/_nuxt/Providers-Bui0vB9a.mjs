import { e as useRoute, l as useVacancyStore, p as useRequestURL } from '../server.mjs';
import { computed, ref, watch, unref, useSSRContext } from 'vue';
import { ssrRenderClass, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1, b as _imports_2 } from './sb-_CyfLtbf.mjs';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const _sfc_main = {
  __name: "Providers",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      required: false,
      default: {}
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    useDictionaryStore();
    const route = useRoute();
    computed(() => route.query.draft_id);
    computed(() => route.query.vacancy_id);
    const vacancyStore = useVacancyStore();
    const enabledProviders = ref(vacancyStore.providers);
    watch(
      () => vacancyStore.providers,
      () => {
        enabledProviders.value = vacancyStore.providers;
      }
    );
    const isHHEnabled = computed(() => {
      var _a2;
      var _a;
      return (_a2 = (_a = enabledProviders.value) == null ? void 0 : _a.hh) != null ? _a2 : false;
    });
    const isSuperjobEnabled = computed(
      () => {
        var _a2;
        var _a;
        return (_a2 = (_a = enabledProviders.value) == null ? void 0 : _a.superjob) != null ? _a2 : false;
      }
    );
    const resetObject = {
      superjob: false,
      hh: false
    };
    const vacancyProviders = computed(() => {
      let selectedProvidersValue = [];
      if (!vacancyStore.my_vacancy) {
        return resetObject;
      }
      const providersNewValues = { ...resetObject };
      if (!vacancyStore.my_vacancy.hasOwnProperty("providers")) {
        return providersNewValues;
      }
      if (vacancyStore.my_vacancy.providers.length > 0) {
        selectedProvidersValue = vacancyStore.my_vacancy.providers.map(
          (item) => item.name
        );
      }
      if (selectedProvidersValue.includes("hh")) {
        providersNewValues.hh = true;
      } else {
        providersNewValues.superjob = false;
      }
      if (selectedProvidersValue.includes("superjob")) {
        providersNewValues.superjob = true;
      } else {
        providersNewValues.superjob = false;
      }
      return providersNewValues;
    });
    watch(
      () => vacancyProviders.value,
      (newValue) => {
        selectedProviders.value = newValue;
      }
    );
    const selectedProviders = ref(resetObject);
    watch(
      () => selectedProviders.value,
      (newSelectedItems) => {
        emit("update:modelValue", newSelectedItems);
      }
    );
    computed(() => props.errors);
    const isHHSelected = computed(() => selectedProviders.value.hh);
    const isSuperjobSelected = computed(() => selectedProviders.value.superjob);
    useRequestURL();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="carryover-box" data-v-bd0b1e1a><div class="carryover-box-label" data-v-bd0b1e1a> \u0415\u0441\u0442\u044C \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 \u043D\u0430 hh \u0438\u043B\u0438 SuperJob? \u041F\u0440\u043E\u0441\u0442\u043E \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0438\u0442\u0435 \u0435\u0433\u043E! </div><div class="import-grid" data-v-bd0b1e1a><div class="${ssrRenderClass([{
        "import-is-complete": unref(isHHSelected),
        disabled: !unref(isHHEnabled),
        "is-connected": unref(isHHEnabled)
      }, "import-box"])}" data-v-bd0b1e1a><div class="import-box-dvnld" data-v-bd0b1e1a><div class="logo" data-v-bd0b1e1a><img${ssrRenderAttr("src", _imports_0)} alt="#" data-v-bd0b1e1a><div class="check" data-v-bd0b1e1a><img${ssrRenderAttr("src", _imports_1)} alt="#" data-v-bd0b1e1a></div></div><span data-v-bd0b1e1a>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 HeadHunters.ru</span></div><div class="import-complete" data-v-bd0b1e1a><div class="logo logo-fake" data-v-bd0b1e1a></div><span data-v-bd0b1e1a>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 HeadHunters.ru</span><button class="close" type="button" data-v-bd0b1e1a><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-bd0b1e1a><path d="M18.9951 4.99512L5.00586 18.9843" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-bd0b1e1a></path><path d="M19.0009 18.9928L5 4.98901" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-bd0b1e1a></path></svg></button></div></div><div class="${ssrRenderClass([{
        "import-is-complete": unref(isSuperjobSelected),
        disabled: !unref(isSuperjobEnabled),
        "is-connected": unref(isSuperjobEnabled)
      }, "import-box"])}" data-v-bd0b1e1a><div class="import-box-dvnld" data-v-bd0b1e1a><div class="logo" data-v-bd0b1e1a><img${ssrRenderAttr("src", _imports_2)} alt="#" data-v-bd0b1e1a><div class="check" data-v-bd0b1e1a><img${ssrRenderAttr("src", _imports_1)} alt="#" data-v-bd0b1e1a></div></div><span data-v-bd0b1e1a>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 Superjob.ru </span></div><div class="import-complete" data-v-bd0b1e1a><div class="logo logo-fake" data-v-bd0b1e1a></div><span data-v-bd0b1e1a>\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u043D\u0430 Superjob.ru</span><button class="close" type="button" data-v-bd0b1e1a><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-bd0b1e1a><path d="M18.9951 4.99512L5.00586 18.9843" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-bd0b1e1a></path><path d="M19.0009 18.9928L5 4.98901" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-bd0b1e1a></path></svg></button></div></div></div></div> ${ssrInterpolate(unref(selectedProviders))}<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateVacancy/Providers.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-bd0b1e1a"]]);

export { __nuxt_component_1 as _ };
//# sourceMappingURL=Providers-Bui0vB9a.mjs.map
