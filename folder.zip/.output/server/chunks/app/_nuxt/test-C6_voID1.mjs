import { _ as __nuxt_component_0 } from './VeeTipTapRichEditor-C3vw1Km2.mjs';
import { useForm, useField } from 'vee-validate';
import { useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import '@tiptap/pm/state';
import '@tiptap/pm/model';
import '@tiptap/pm/transform';
import '@tiptap/pm/commands';
import '@tiptap/pm/schema-list';
import '@tiptap/pm/dropcursor';
import '@tiptap/pm/gapcursor';
import '@tiptap/pm/history';

const _sfc_main = {
  __name: "test",
  __ssrInlineRender: true,
  setup(__props) {
    useForm({
      initialValues: {
        content: "<p>gdfgdfg</p><ol><li><p>451451</p></li></ol><p></p><hr><ol><li><p><em>5415641</em></p></li><li><p></p></li></ol><p><strong>fghfghf</strong></p><p></p>"
      }
    });
    useField("content");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeTipTapRichEditor = __nuxt_component_0;
      _push(`<!--[--><button>Change</button>`);
      _push(ssrRenderComponent(_component_VeeTipTapRichEditor, { name: "content" }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/test.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=test-C6_voID1.mjs.map
