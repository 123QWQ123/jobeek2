const SearchMobile_vue_vue_type_style_index_0_scoped_43176773_lang = ".search-form--widget[data-v-43176773]{display:block}.main-section-mob[data-v-43176773]{margin-bottom:3rem;margin-top:1rem;padding-top:3rem}@media only screen and (max-width:960px){.search-form-mobile[data-v-43176773]{display:none}}";

const SearchMobileStyles_CqMSG7 = [SearchMobile_vue_vue_type_style_index_0_scoped_43176773_lang];

export { SearchMobileStyles_CqMSG7 as default };
//# sourceMappingURL=SearchMobile-styles.Cq-M-sG7.mjs.map
