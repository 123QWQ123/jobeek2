import { V as VeeForm_vue_vue_type_style_index_1_scoped_3f4bdef7_lang } from './VeeForm-styles-2.mjs-BgRI04s2.mjs';

const VeeFormStyles_oe3POjDu = [VeeForm_vue_vue_type_style_index_1_scoped_3f4bdef7_lang];

export { VeeFormStyles_oe3POjDu as default };
//# sourceMappingURL=VeeForm-styles.oe3POjDu.mjs.map
