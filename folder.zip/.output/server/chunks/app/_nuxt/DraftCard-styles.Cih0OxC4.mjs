const DraftCard_vue_vue_type_style_index_0_lang = '.w-box-body.disabled{position:relative}.w-box-body.disabled:before{background:rgba(0,0,0,.5);content:"";height:100%;left:0;position:absolute;top:0;width:100%;z-index:999}';

const DraftCardStyles_Cih0OxC4 = [DraftCard_vue_vue_type_style_index_0_lang];

export { DraftCardStyles_Cih0OxC4 as default };
//# sourceMappingURL=DraftCard-styles.Cih0OxC4.mjs.map
