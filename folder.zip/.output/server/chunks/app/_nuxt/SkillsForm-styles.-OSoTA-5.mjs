const SkillsForm_vue_vue_type_style_index_0_scoped_4009e766_lang = ".absoluted_icon[data-v-4009e766]{cursor:pointer;font-size:1rem;left:-2rem;max-width:3rem;position:absolute;top:.5rem;z-index:1}.absoluted_icon svg[data-v-4009e766]{height:24px;width:24px}";

const SkillsFormStyles_OSoTA5 = [SkillsForm_vue_vue_type_style_index_0_scoped_4009e766_lang];

export { SkillsFormStyles_OSoTA5 as default };
//# sourceMappingURL=SkillsForm-styles.-OSoTA-5.mjs.map
