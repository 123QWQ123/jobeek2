const DraftItem_vue_vue_type_style_index_0_scoped_ad8b2272_lang = ".push_and_context_wrapper[data-v-ad8b2272]{align-items:center;display:flex;justify-content:flex-end;width:100%}@media (max-width:768px){.option-group[data-v-ad8b2272]{flex-direction:row;justify-content:space-between;width:100%}.selector-group .option+.option[data-v-ad8b2272]{margin-top:unset}}.theme-checker.disabled *[data-v-ad8b2272]{filter:grayscale(100%)}@keyframes placeHolderShimmer-ad8b2272{0%{background-position:0 0}to{background-position:100em 0}}.animated[data-v-ad8b2272]{animation-duration:20s;animation-fill-mode:forwards;animation-iteration-count:infinite;animation-name:placeHolderShimmer-ad8b2272;animation-timing-function:linear;background:#fff;background:linear-gradient(90deg,#eee 8%,#ddd 18%,#eee 33%);border-radius:43px;height:calc(100% + 2px);padding:3px;position:absolute;width:calc(100% + 2px);z-index:9999;//padding-top:50px;-webkit-backface-visibility:hidden;bottom:0;left:-1px;right:0;top:-1px}";

const DraftItemStyles_CoLAEhrq = [DraftItem_vue_vue_type_style_index_0_scoped_ad8b2272_lang];

export { DraftItemStyles_CoLAEhrq as default };
//# sourceMappingURL=DraftItem-styles.CoLAEhrq.mjs.map
