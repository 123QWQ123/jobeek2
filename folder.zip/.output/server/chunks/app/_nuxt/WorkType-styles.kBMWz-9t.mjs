const WorkType_vue_vue_type_style_index_0_scoped_cc8b4843_lang = ".check-block label[data-v-cc8b4843]{white-space:pre-wrap}.with_scroll[data-v-cc8b4843]{max-height:300px;overflow:auto}.is_header .l-wrap label[data-v-cc8b4843]{font-weight:700}.is_header .radio-mask[data-v-cc8b4843],.is_header input[data-v-cc8b4843]{display:none}input[type=search][data-v-cc8b4843]{border:1px solid #cbcbcb;margin-bottom:1rem;padding:.1rem .3rem;width:100%}";

const WorkTypeStyles_kBMWz9t = [WorkType_vue_vue_type_style_index_0_scoped_cc8b4843_lang];

export { WorkTypeStyles_kBMWz9t as default };
//# sourceMappingURL=WorkType-styles.kBMWz-9t.mjs.map
