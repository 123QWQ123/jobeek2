import { v as vue3TelInput } from './entry-styles-24.mjs-bF4kFPI6.mjs';

const vueTelInputStyles_Je3z_HSP = [vue3TelInput];

export { vueTelInputStyles_Je3z_HSP as default };
//# sourceMappingURL=vueTelInput-styles.Je3z_HSP.mjs.map
