import { S as SelectWithSearch_vue_vue_type_style_index_1_scoped_75e232fb_lang } from './SelectWithSearch-styles-2.mjs-YiKsBPV1.mjs';

const SelectWithSearchStyles_BK0tOC = [SelectWithSearch_vue_vue_type_style_index_1_scoped_75e232fb_lang];

export { SelectWithSearchStyles_BK0tOC as default };
//# sourceMappingURL=SelectWithSearch-styles.BK0t-O-C.mjs.map
