import { o as defineStore, q as useApi, e as useRoute, x as __nuxt_component_0$1 } from '../server.mjs';
import { useSSRContext, ref, watch, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';

const useScamStore = defineStore("scam", {
  state: () => {
    return {
      frequency_options: [],
      rate_options: [],
      categories: [],
      history_items: [],
      subscribed_items: []
    };
  },
  actions: {
    async searchPhone(payload = {}) {
      const response = await useApi("scam/getPhoneInfo", {
        method: "get",
        params: payload
      });
      return response;
    },
    async getHistory(payload = {}) {
      const { data } = await useApi("scam/getHistory", {
        method: "get",
        params: payload
      });
      if (data && data.hasOwnProperty("data")) {
        this.history_items = data.data;
        return this.history_items;
      }
      return data;
    },
    async getSubscribedPhones(payload = {}) {
      const { data } = await useApi("scam/getFavorite", {
        method: "get",
        params: payload
      });
      if (data && data.hasOwnProperty("data")) {
        this.subscribed_items = data.data;
        return this.subscribed_items;
      }
      return data;
    },
    async addFavorite(payload = {}) {
      const response = await useApi("scam/addFavorite", {
        method: "post",
        payload
      });
      this.getHistory();
      this.getSubscribedPhones();
      return response;
    },
    async saveComment(payload = {}) {
      const response = await useApi("scam/saveComment", {
        method: "post",
        payload
      });
      return response;
    },
    async removeFavorite(payload = {}) {
      const response = await useApi("scam/addFavorite", {
        method: "delete",
        params: payload
      });
      this.getHistory();
      this.getSubscribedPhones();
      return response;
    },
    async getScamOptions(payload = {}) {
      const { data } = await useApi("scam/getOptions", {
        method: "get",
        params: payload
      });
      if (data) {
        this.frequency_options = data.frequency;
        this.rate_options = data.rate;
        this.categories = data.categories;
        return data.data;
      }
      return data;
    }
  }
});
const _sfc_main = {
  __name: "search-phone",
  __ssrInlineRender: true,
  setup(__props) {
    const scamStore = useScamStore();
    const errorMessage = ref(null);
    const { searchPhone: searchPhone2, getScamOptions } = scamStore;
    const route = useRoute();
    ref();
    const phoneMask = ref(null);
    const isLoading = ref(false);
    const phones = ref([]);
    watch(
      () => route.query.phone,
      async (newPhone) => {
        isLoading.value = true;
        phoneMask.value.value = newPhone;
        const resData = await searchPhone2({ phone: newPhone });
        isLoading.value = false;
        if (resData.status !== "success") {
          errorMessage.value = resData.message;
          return;
        }
        phones.value = resData.data;
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_client_only = __nuxt_component_0$1;
      _push(`<main${ssrRenderAttrs(mergeProps({
        class: "main bg-wrapper scam-phone-page",
        role: "main"
      }, _attrs))} data-v-4a99e80e><div class="head-w-section" data-v-4a99e80e><div class="wrapper wrapper-1290" data-v-4a99e80e><h1 class="head-w-section__title" data-v-4a99e80e>\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043D\u043E\u043C\u0435\u0440\u0443 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430</h1><form class="search-row" data-v-4a99e80e><button class="search-button" data-v-4a99e80e><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" data-v-4a99e80e><circle cx="11.7659" cy="11.7666" r="8.98856" stroke="#B8BFC6" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-4a99e80e></circle><path d="M18.0195 18.4851L21.5436 22" stroke="#B8BFC6" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-4a99e80e></path></svg></button><input class="search-phone-input" type="text" placeholder="+7" data-v-4a99e80e><button class="button-accent" data-v-4a99e80e>\u041F\u043E\u0438\u0441\u043A</button></form><span class="text-danger" data-v-4a99e80e>${ssrInterpolate(unref(errorMessage))}</span></div></div><div class="wrapper wrapper-1290" data-v-4a99e80e>`);
      _push(ssrRenderComponent(_component_client_only, null, {}, _parent));
      _push(`</div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/services/search-phone.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const searchPhone = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-4a99e80e"]]);

export { searchPhone as default };
//# sourceMappingURL=search-phone-C-uYOCEh.mjs.map
