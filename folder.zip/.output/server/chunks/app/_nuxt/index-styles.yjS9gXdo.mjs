const index_vue_vue_type_style_index_0_scoped_79ebb9f2_lang = ".progress[data-v-79ebb9f2]{background:none}";

const indexStyles_yjS9gXdo = [index_vue_vue_type_style_index_0_scoped_79ebb9f2_lang];

export { indexStyles_yjS9gXdo as default };
//# sourceMappingURL=index-styles.yjS9gXdo.mjs.map
