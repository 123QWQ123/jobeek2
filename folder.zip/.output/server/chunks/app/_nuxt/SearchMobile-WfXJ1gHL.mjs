import { _ as _imports_0, a as __nuxt_component_0$1 } from './search-CNCM2ROA.mjs';
import { u as useQueryParams, _ as __nuxt_component_1 } from './useQueryParams-Bpl0Cf82.mjs';
import { computed, ref, watch, mergeProps, unref, isRef, useSSRContext } from 'vue';
import { k as useAuthStore, a as useRouter, e as useRoute, l as useVacancyStore, m as useProfileStore, s as storeToRefs } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';

const _sfc_main = {
  __name: "SearchMobile",
  __ssrInlineRender: true,
  props: {
    with_wrapper: {
      default: false
    }
  },
  setup(__props) {
    var _a2;
    var _a;
    const props = __props;
    const auth = useAuthStore();
    computed(() => auth.isEmployer);
    const searchPlaceHolder = computed(
      () => auth.isEmployer ? "\u041A\u0430\u043A\u043E\u0439 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0441\u0442 \u0432\u044B \u0438\u0449\u0435\u0442\u0435?" : "\u041A\u0430\u043A\u0443\u044E \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E \u0432\u044B \u0438\u0449\u0435\u0442\u0435?"
    );
    const { getCurrentQueryParams, getQueryParam } = useQueryParams();
    const params = getCurrentQueryParams();
    useRouter();
    const route = useRoute();
    const vacancyStore = useVacancyStore();
    const profileStore = useProfileStore();
    const { searchCities } = profileStore;
    const search = ref((_a2 = (_a = route.query) == null ? void 0 : _a.search) != null ? _a2 : void 0);
    const salary = ref({
      from: void 0,
      to: void 0,
      id: void 0
    });
    salary.value = getQueryParam("salary");
    const city = ref(null);
    watch(
      () => getQueryParam("salary"),
      (newValue) => {
        salary.value = newValue;
      }
    );
    const onCityChange = (cityItem) => {
      if (cityItem.value === null) {
        city.value = void 0;
      } else {
        city.value = cityItem.value;
      }
    };
    const updateCityInput = async (newValue = "") => {
      var _a3;
      const items = (_a3 = await searchCities({ search: newValue })) != null ? _a3 : [];
      cityOptions.value = items.map((item) => ({
        value: item.id,
        name: item.name
      }));
    };
    computed(() => vacancyStore.vacancies);
    storeToRefs(vacancyStore);
    const cityOptions = ref([]);
    useRoute();
    computed(() => {
      if (params.countries && params.countries.length === 1) {
        return params.countries[0];
      } else
        return 1;
    });
    ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderSalarySelectInForm = __nuxt_component_0$1;
      const _component_SelectWithSearch = __nuxt_component_1;
      if (props.with_wrapper) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "main-section-mob" }, _attrs))} data-v-43176773><div class="wrapper" data-v-43176773><form class="search-form" role="form" autocomplete="off" data-v-43176773><div class="search-row" data-v-43176773><div class="input-wrap has-icon has-label" data-v-43176773><img class="icon"${ssrRenderAttr("src", _imports_0)} alt="#" data-v-43176773><label for="name" data-v-43176773>\u041F\u043E\u0438\u0441\u043A </label><input type="text" name="name" id="keyword"${ssrRenderAttr("placeholder", unref(searchPlaceHolder))} autocomplete="off"${ssrRenderAttr("value", unref(search))} data-v-43176773></div><div class="input-wrap has-label" data-v-43176773><label for="salary" data-v-43176773>\u0416\u0435\u043B\u0430\u0435\u043C\u0430\u044F \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0430</label>`);
        _push(ssrRenderComponent(_component_HeaderSalarySelectInForm, {
          modelValue: unref(salary),
          "onUpdate:modelValue": ($event) => isRef(salary) ? salary.value = $event : null
        }, null, _parent));
        _push(`</div><div class="input-wrap has-label" data-v-43176773><label for="salary" data-v-43176773>\u0413\u043E\u0440\u043E\u0434</label>`);
        _push(ssrRenderComponent(_component_SelectWithSearch, {
          options: unref(cityOptions),
          modelValue: unref(city),
          "onUpdate:modelValue": ($event) => isRef(city) ? city.value = $event : null,
          modelModifiers: { number: true },
          placeholder: "\u0413\u043E\u0440\u043E\u0434",
          onInput: updateCityInput,
          onChange: onCityChange,
          not_found: "\u0413\u043E\u0440\u043E\u0434 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E"
        }, null, _parent));
        _push(`</div><button class="button-accent submit-search-form" type="button" data-v-43176773> \u041F\u043E\u0438\u0441\u043A </button></div></form></div></div>`);
      } else {
        _push(`<form${ssrRenderAttrs(mergeProps({
          class: "search-form main-section-mob",
          role: "form",
          autocomplete: "off"
        }, _attrs))} data-v-43176773><div class="search-row" data-v-43176773><div class="input-wrap has-icon has-label" data-v-43176773><img class="icon"${ssrRenderAttr("src", _imports_0)} alt="#" data-v-43176773><label for="name" data-v-43176773>\u041F\u043E\u0438\u0441\u043A </label><input type="text" name="name" id="keyword"${ssrRenderAttr("placeholder", unref(searchPlaceHolder))} autocomplete="off"${ssrRenderAttr("value", unref(search))} data-v-43176773></div><div class="input-wrap has-label" data-v-43176773><label for="salary" data-v-43176773>\u0416\u0435\u043B\u0430\u0435\u043C\u0430\u044F \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0430</label>`);
        _push(ssrRenderComponent(_component_HeaderSalarySelectInForm, {
          modelValue: unref(salary),
          "onUpdate:modelValue": ($event) => isRef(salary) ? salary.value = $event : null
        }, null, _parent));
        _push(`</div><div class="input-wrap has-label" data-v-43176773><label for="salary" data-v-43176773>\u0413\u043E\u0440\u043E\u0434</label>`);
        _push(ssrRenderComponent(_component_SelectWithSearch, {
          options: unref(cityOptions),
          modelValue: unref(city),
          "onUpdate:modelValue": ($event) => isRef(city) ? city.value = $event : null,
          modelModifiers: { number: true },
          placeholder: "\u0413\u043E\u0440\u043E\u0434",
          class: "no_bg",
          onInput: updateCityInput,
          onChange: onCityChange
        }, null, _parent));
        _push(`</div><button class="button-accent submit-search-form" type="button" data-v-43176773> \u041F\u043E\u0438\u0441\u043A </button></div></form>`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/PersonalCabinet/SearchMobile.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-43176773"]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=SearchMobile-WfXJ1gHL.mjs.map
