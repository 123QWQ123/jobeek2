const ListActions_vue_vue_type_style_index_0_scoped_f8dde991_lang = ".provider_buttons[data-v-f8dde991]{background-color:#fff;border-radius:1rem;padding:1rem 1.5rem}.vacancy_tabs .nav-link[data-v-f8dde991]{padding:.8rem 2rem .5rem}.theme-checker input~.theme-checker-ui .circle.left[data-v-f8dde991]{transform:translate(3px,-50%)}.theme-checker input~.theme-checker-ui .circle.right[data-v-f8dde991]{transform:translate(30px,-50%)}";

const ListActionsStyles_CEx9C0mf = [ListActions_vue_vue_type_style_index_0_scoped_f8dde991_lang];

export { ListActionsStyles_CEx9C0mf as default };
//# sourceMappingURL=ListActions-styles.CEx9C0mf.mjs.map
