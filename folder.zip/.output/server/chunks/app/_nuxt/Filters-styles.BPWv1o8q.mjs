const Filters_vue_vue_type_style_index_0_scoped_07ab2c90_lang = ".check-block label[data-v-07ab2c90]{white-space:pre-wrap}";

const FiltersStyles_BPWv1o8q = [Filters_vue_vue_type_style_index_0_scoped_07ab2c90_lang];

export { FiltersStyles_BPWv1o8q as default };
//# sourceMappingURL=Filters-styles.BPWv1o8q.mjs.map
