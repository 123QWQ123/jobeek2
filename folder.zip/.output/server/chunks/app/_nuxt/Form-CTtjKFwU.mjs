import __nuxt_component_2 from './VeeCustomSelect-BxrAvA7-.mjs';
import { unref, useSSRContext, toRefs, computed, reactive, ref, watch, mergeProps } from 'vue';
import { u as useYearOptions } from './useYearOptions--VQWJCm5.mjs';
import { ssrRenderList, ssrRenderComponent, ssrRenderAttrs, ssrRenderStyle } from 'vue/server-renderer';
import { useFieldArray, useField } from 'vee-validate';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';
import { R as ResumeTextInput } from './ResumeTextInput-BxTsuw7y.mjs';
import { u as useProviders } from './useProviders-Ck9yopDY.mjs';
import { u as useProviderFields } from './useProviderFields-B2EuWWWy.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'firebase/messaging';
import 'axios';
import 'mobile-detect';
import 'imask';
import 'vue-i18n';
import 'moment';
import 'click-outside-vue3';
import 'vue3-toastify';
import 'vue3-tel-input';
import './state-D1MfAAni.mjs';

const _sfc_main$1 = {
  __name: "Item",
  __ssrInlineRender: true,
  props: ["idx", "name"],
  emits: ["remove"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const { idx, name } = toRefs(props);
    const { value: type_id } = useField(
      () => props.name + "[" + props.idx + "]type_id"
    );
    const yearOptions = computed(
      () => useYearOptions(1950, (/* @__PURE__ */ new Date()).getUTCFullYear() + 5)
    );
    const isMoreFields = computed(() => type_id.value != 115);
    const isSchoolGraduate = computed(() => type_id.value == 116);
    const dictionaryStore = useDictionaryStore();
    const educationLevelOptions = computed(() => {
      return dictionaryStore.resume_educations.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const educationFormatOptions = computed(() => {
      return dictionaryStore.resume_education_forms.map((item) => ({
        name: item.name,
        value: item.id
      }));
    });
    const { providers } = useProviders();
    const state = reactive({
      type_id: {
        is_hidden: false
      },
      profession: {
        is_hidden: false
      },
      end_year: {
        is_hidden: false
      },
      faculty: {
        is_hidden: false
      },
      institute: {
        is_hidden: false
      },
      form_id: {
        is_hidden: false
      }
    });
    const fields = ref({
      hh: {
        type_id: null,
        profession: false,
        end_year: true,
        faculty: false,
        institute: false,
        form_id: false
      },
      superjob: {
        type_id: true,
        profession: false,
        end_year: true,
        faculty: false,
        institute: true,
        form_id: null
      }
    });
    const { walkThroughFields } = useProviderFields(state, fields);
    watch(
      () => providers.value,
      () => {
        walkThroughFields(providers.value);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeCustomSelect = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row position-relative empty-area" }, _attrs))} data-v-cd1d43bc><span class="position-absolute absoluted_icon" data-v-cd1d43bc><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16" data-v-cd1d43bc><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" data-v-cd1d43bc></path></svg></span><div class="input-row" style="${ssrRenderStyle(!unref(state).type_id.is_hidden ? null : { display: "none" })}" data-v-cd1d43bc><label for="position" data-v-cd1d43bc>\u0423\u0440\u043E\u0432\u0435\u043D \u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435 2<b data-v-cd1d43bc>*</b></label><div class="input-wrapper" data-v-cd1d43bc>`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        options: unref(educationLevelOptions),
        name: `${unref(name)}[${unref(idx)}].type_id`,
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div><div style="${ssrRenderStyle(!unref(state).profession.is_hidden ? null : { display: "none" })}" class="mt-2" data-v-cd1d43bc>`);
      if (unref(isMoreFields)) {
        _push(`<div class="input-row" data-v-cd1d43bc><label for="position" data-v-cd1d43bc>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C<b data-v-cd1d43bc>*</b></label><div class="input-wrapper" data-v-cd1d43bc>`);
        _push(ssrRenderComponent(ResumeTextInput, {
          name: `${unref(name)}[${unref(idx)}].profession`,
          placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="input-row mt-2" style="${ssrRenderStyle(!unref(state).institute.is_hidden ? null : { display: "none" })}" data-v-cd1d43bc><label for="position" data-v-cd1d43bc>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0437\u0430\u0432\u0435\u0434\u0435\u043D\u0438\u044F<b data-v-cd1d43bc>*</b></label><div class="input-wrapper" data-v-cd1d43bc>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${unref(name)}[${unref(idx)}].institute`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0437\u0430\u0432\u0435\u0434\u0435\u043D\u0438\u044F"
      }, null, _parent));
      _push(`</div></div><div class="input-row mt-2" style="${ssrRenderStyle(!unref(state).faculty.is_hidden ? null : { display: "none" })}" data-v-cd1d43bc><label for="position" data-v-cd1d43bc>\u0424\u0430\u043A\u0443\u043B\u044C\u0442\u0435\u0442<b data-v-cd1d43bc>*</b></label><div class="input-wrapper" data-v-cd1d43bc>`);
      _push(ssrRenderComponent(ResumeTextInput, {
        name: `${unref(name)}[${unref(idx)}].faculty`,
        placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0444\u0430\u043A\u0443\u043B\u044C\u0442\u0435\u0442"
      }, null, _parent));
      _push(`</div></div><div style="${ssrRenderStyle(!unref(state).form_id.is_hidden ? null : { display: "none" })}" class="mt-2" data-v-cd1d43bc>`);
      if (!unref(isSchoolGraduate)) {
        _push(`<div class="input-row" data-v-cd1d43bc><label for="position" data-v-cd1d43bc>\u0424\u043E\u0440\u043C\u0430\u0442 \u0443\u0447\u0435\u0431\u044B</label><div class="input-wrapper" data-v-cd1d43bc>`);
        _push(ssrRenderComponent(_component_VeeCustomSelect, {
          options: unref(educationFormatOptions),
          name: `${unref(name)}[${unref(idx)}].form_id`,
          label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="input-row mt-2" style="${ssrRenderStyle(!unref(state).end_year.is_hidden ? null : { display: "none" })}" data-v-cd1d43bc><label for="position" data-v-cd1d43bc>\u0413\u043E\u0434 \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435<b data-v-cd1d43bc>*</b></label><div class="input-wrapper" data-v-cd1d43bc>`);
      _push(ssrRenderComponent(_component_VeeCustomSelect, {
        options: unref(yearOptions),
        name: `${unref(name)}[${unref(idx)}].end_year`,
        label: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435"
      }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeEducation/Item.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-cd1d43bc"]]);
const _sfc_main = {
  __name: "Form",
  __ssrInlineRender: true,
  props: ["name", "parent_type_id", "providers"],
  setup(__props) {
    const props = __props;
    const { push, fields, remove } = useFieldArray(() => props.name);
    useDictionaryStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CreateResumeVeeEducationItem = __nuxt_component_0;
      _push(`<!--[--><!--[-->`);
      ssrRenderList(unref(fields), (field, idx) => {
        _push(`<div class="m-2">`);
        _push(ssrRenderComponent(_component_CreateResumeVeeEducationItem, {
          onRemove: unref(remove),
          name: props.name,
          idx
        }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]-->`);
      if (unref(fields).length === 0) {
        _push(`<button type="button" class="btn btn-primary btn-sm mt-1"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C </button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(fields).length > 0) {
        _push(`<button type="button" class="btn btn-primary mt-1 btn-sm"> \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0435 </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CreateResume/VeeEducation/Form.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=Form-CTtjKFwU.mjs.map
