import { _ as __nuxt_component_0 } from './nuxt-link-BdrY0gEc.mjs';
import { _ as __nuxt_component_0$1 } from './BlockLoader-RiL0eLJn.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { ref, mergeProps, withCtx, createTextVNode, createVNode, openBlock, createBlock, unref, toDisplayString, Fragment, renderList, useSSRContext, computed } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import { l as useVacancyStore, s as storeToRefs } from '../server.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { u as useDictionaryStore } from './dictionary--F10-rgU.mjs';

const _sfc_main$1 = {
  __name: "WorkSection",
  __ssrInlineRender: true,
  setup(__props) {
    const vacancyStore = useVacancyStore();
    const { top_10: vacancies } = storeToRefs(vacancyStore);
    const isLoading = ref(false);
    const getProfessionalRoles = (objectData) => {
      if (objectData)
        return Object.keys(objectData);
      return [];
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_BlockLoader = __nuxt_component_0$1;
      const _component_swiper = Swiper;
      const _component_swiper_slide = SwiperSlide;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "work-section section wrapper" }, _attrs))} data-v-b9ab9de4><div class="section-head" data-v-b9ab9de4><h2 class="section-title" data-v-b9ab9de4>\u0420\u0430\u0431\u043E\u0442\u0430 \u0438 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 \u0432 \u041C\u043E\u0441\u043A\u0432\u0435</h2>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "more",
        to: {
          name: "search-vacancies",
          query: { countries: [1], regions: [22] }
        }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u0412\u0441\u0435 <span data-v-b9ab9de4${_scopeId}> \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 </span><svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-b9ab9de4${_scopeId}><path d="M19.75 12.2256L4.75 12.2256" stroke="#5375FD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-b9ab9de4${_scopeId}></path><path d="M13.7002 6.20124L19.7502 12.2252L13.7002 18.2502" stroke="#5375FD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-b9ab9de4${_scopeId}></path></svg>`);
          } else {
            return [
              createTextVNode(" \u0412\u0441\u0435 "),
              createVNode("span", null, " \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u0438 "),
              (openBlock(), createBlock("svg", {
                width: "24",
                height: "25",
                viewBox: "0 0 24 25",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
              }, [
                createVNode("path", {
                  d: "M19.75 12.2256L4.75 12.2256",
                  stroke: "#5375FD",
                  "stroke-width": "1.5",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                }),
                createVNode("path", {
                  d: "M13.7002 6.20124L19.7502 12.2252L13.7002 18.2502",
                  stroke: "#5375FD",
                  "stroke-width": "1.5",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (unref(isLoading)) {
        _push(`<div class="position-relative" data-v-b9ab9de4>`);
        _push(ssrRenderComponent(_component_BlockLoader, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<div data-v-b9ab9de4><div class="swiper cards-slider-row" data-v-b9ab9de4>`);
        _push(ssrRenderComponent(_component_swiper, {
          "slides-per-view": "auto",
          "space-between": 20,
          class: "cards-slider",
          "wrapper-class": "cards-grid"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<!--[-->`);
              ssrRenderList(unref(vacancies), (item) => {
                _push2(ssrRenderComponent(_component_swiper_slide, null, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(_component_NuxtLink, {
                        class: "tile-card",
                        to: {
                          name: "search-vacancies",
                          query: {
                            countries: [1],
                            regions: [22],
                            professional_roles: getProfessionalRoles(
                              item.professional_roles
                            )
                          }
                        }
                      }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`<h4 class="tile-card-title" data-v-b9ab9de4${_scopeId3}>${ssrInterpolate(item.name)}</h4>`);
                            if (item.salary_to) {
                              _push4(`<span class="tile-card-dop-info" data-v-b9ab9de4${_scopeId3}>\u0414\u043E ${ssrInterpolate(_ctx.vueNumberFormat(item.salary_to, {}))} \u20BD / \u043C\u0435\u0441\u044F\u0446</span>`);
                            } else {
                              _push4(`<span class="tile-card-dop-info" data-v-b9ab9de4${_scopeId3}>\u041E\u0442 ${ssrInterpolate(_ctx.vueNumberFormat(item.salary_from, {}))} \u20BD / \u043C\u0435\u0441\u044F\u0446</span>`);
                            }
                          } else {
                            return [
                              createVNode("h4", { class: "tile-card-title" }, toDisplayString(item.name), 1),
                              item.salary_to ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "tile-card-dop-info"
                              }, "\u0414\u043E " + toDisplayString(_ctx.vueNumberFormat(item.salary_to, {})) + " \u20BD / \u043C\u0435\u0441\u044F\u0446", 1)) : (openBlock(), createBlock("span", {
                                key: 1,
                                class: "tile-card-dop-info"
                              }, "\u041E\u0442 " + toDisplayString(_ctx.vueNumberFormat(item.salary_from, {})) + " \u20BD / \u043C\u0435\u0441\u044F\u0446", 1))
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(_component_NuxtLink, {
                          class: "tile-card",
                          to: {
                            name: "search-vacancies",
                            query: {
                              countries: [1],
                              regions: [22],
                              professional_roles: getProfessionalRoles(
                                item.professional_roles
                              )
                            }
                          }
                        }, {
                          default: withCtx(() => [
                            createVNode("h4", { class: "tile-card-title" }, toDisplayString(item.name), 1),
                            item.salary_to ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "tile-card-dop-info"
                            }, "\u0414\u043E " + toDisplayString(_ctx.vueNumberFormat(item.salary_to, {})) + " \u20BD / \u043C\u0435\u0441\u044F\u0446", 1)) : (openBlock(), createBlock("span", {
                              key: 1,
                              class: "tile-card-dop-info"
                            }, "\u041E\u0442 " + toDisplayString(_ctx.vueNumberFormat(item.salary_from, {})) + " \u20BD / \u043C\u0435\u0441\u044F\u0446", 1))
                          ]),
                          _: 2
                        }, 1032, ["to"])
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
            } else {
              return [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(vacancies), (item) => {
                  return openBlock(), createBlock(_component_swiper_slide, null, {
                    default: withCtx(() => [
                      createVNode(_component_NuxtLink, {
                        class: "tile-card",
                        to: {
                          name: "search-vacancies",
                          query: {
                            countries: [1],
                            regions: [22],
                            professional_roles: getProfessionalRoles(
                              item.professional_roles
                            )
                          }
                        }
                      }, {
                        default: withCtx(() => [
                          createVNode("h4", { class: "tile-card-title" }, toDisplayString(item.name), 1),
                          item.salary_to ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "tile-card-dop-info"
                          }, "\u0414\u043E " + toDisplayString(_ctx.vueNumberFormat(item.salary_to, {})) + " \u20BD / \u043C\u0435\u0441\u044F\u0446", 1)) : (openBlock(), createBlock("span", {
                            key: 1,
                            class: "tile-card-dop-info"
                          }, "\u041E\u0442 " + toDisplayString(_ctx.vueNumberFormat(item.salary_from, {})) + " \u20BD / \u043C\u0435\u0441\u044F\u0446", 1))
                        ]),
                        _: 2
                      }, 1032, ["to"])
                    ]),
                    _: 2
                  }, 1024);
                }), 256))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div>`);
      }
      _push(`</section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/WorkSection.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-b9ab9de4"]]);
const _sfc_main = {
  __name: "SearchSection",
  __ssrInlineRender: true,
  setup(__props) {
    const vacancyStore = useVacancyStore();
    const dictionaryStore = useDictionaryStore();
    const schedules = computed(() => dictionaryStore.schedules);
    const isMoreIndustries = ref(false);
    const industries = computed(() => {
      return vacancyStore.top_20_industries;
    });
    useVacancyStore();
    const isLoading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BlockLoader = __nuxt_component_0$1;
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "search-section" }, _attrs))} data-v-b7a385ee><div class="wrapper" data-v-b7a385ee><div class="divided-box" data-v-b7a385ee><div class="divided-box-title" data-v-b7a385ee><h3 class="section-title" data-v-b7a385ee>\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043E\u0442\u0440\u0430\u0441\u043B\u044F\u043C</h3></div>`);
      if (unref(isLoading)) {
        _push(`<div class="position-relative" data-v-b7a385ee>`);
        _push(ssrRenderComponent(_component_BlockLoader, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<div data-v-b7a385ee><div class="divided-box-content" data-v-b7a385ee><div class="${ssrRenderClass([{ expanded: unref(isMoreIndustries) }, "labels-list-box"])}" data-v-b7a385ee><ul class="labels-list" data-v-b7a385ee><!--[-->`);
        ssrRenderList(unref(industries), (item) => {
          _push(`<li data-v-b7a385ee>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: {
              name: "search-vacancies",
              query: { industries: [item.id] }
            },
            class: "label"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(item.title)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(item.title), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div>`);
        if (!unref(isMoreIndustries)) {
          _push(`<button class="more more--down" data-v-b7a385ee> \u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0435\u0449\u0435 <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-b7a385ee><path d="M19.75 12.2256L4.75 12.2256" stroke="#5375FD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-b7a385ee></path><path d="M13.7002 6.20124L19.7502 12.2252L13.7002 18.2502" stroke="#5375FD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-b7a385ee></path></svg></button>`);
        } else {
          _push(`<button class="more more--up" data-v-b7a385ee> \u0421\u043A\u0440\u044B\u0442\u044C <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-b7a385ee><path d="M19.75 12.2256L4.75 12.2256" stroke="#5375FD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-b7a385ee></path><path d="M13.7002 6.20124L19.7502 12.2252L13.7002 18.2502" stroke="#5375FD" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-b7a385ee></path></svg></button>`);
        }
        _push(`</div></div>`);
      }
      _push(`</div><div class="divided-box" data-v-b7a385ee><div class="divided-box-title" data-v-b7a385ee><h3 class="section-title" data-v-b7a385ee>\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u0433\u0440\u0430\u0444\u0438\u043A\u0443</h3></div><div class="divided-box-content" data-v-b7a385ee><div class="labels-list-box" data-v-b7a385ee><ul class="labels-list" data-v-b7a385ee><!--[-->`);
      ssrRenderList(unref(schedules), (item) => {
        _push(`<li data-v-b7a385ee>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          class: "label",
          to: {
            name: "search-vacancies",
            query: { schedules: [item.id] }
          }
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(item.name)}`);
            } else {
              return [
                createTextVNode(toDisplayString(item.name), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></div></div></div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/SearchSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-b7a385ee"]]);

export { __nuxt_component_2 as _, __nuxt_component_3 as a };
//# sourceMappingURL=SearchSection-BlAf03bK.mjs.map
