import { S as SelectWithSearch_vue_vue_type_style_index_0_lang } from './SelectWithSearch-styles-1.mjs-CL189Rzv.mjs';

const SelectWithSearchStyles_BoN_LQRa = [SelectWithSearch_vue_vue_type_style_index_0_lang];

export { SelectWithSearchStyles_BoN_LQRa as default };
//# sourceMappingURL=SelectWithSearch-styles.BoN_LQRa.mjs.map
