const _id__vue_vue_type_style_index_0_scoped_0d64b8d6_lang = ".button-accent.disabled[data-v-0d64b8d6]{filter:grayscale(180%)}.button-accent.disabled[data-v-0d64b8d6]:hover{background:#5375fd}@media (max-width:768px){.form-submit-container[data-v-0d64b8d6]{flex-direction:column-reverse}.button-accent[data-v-0d64b8d6]{margin-bottom:1rem}}";

const _id_Styles_BimZvn2X = [_id__vue_vue_type_style_index_0_scoped_0d64b8d6_lang];

export { _id_Styles_BimZvn2X as default };
//# sourceMappingURL=_id_-styles.BimZvn2X.mjs.map
