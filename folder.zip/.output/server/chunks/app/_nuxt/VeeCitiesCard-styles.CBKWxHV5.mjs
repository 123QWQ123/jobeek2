const VeeCitiesCard_vue_vue_type_style_index_0_lang = "";

const VeeCitiesCardStyles_CBKWxHV5 = [VeeCitiesCard_vue_vue_type_style_index_0_lang];

export { VeeCitiesCardStyles_CBKWxHV5 as default };
//# sourceMappingURL=VeeCitiesCard-styles.CBKWxHV5.mjs.map
