const SkillsForm_vue_vue_type_style_index_0_scoped_b785f731_lang = ".absoluted_icon[data-v-b785f731]{cursor:pointer;font-size:1rem;left:-2rem;max-width:3rem;position:absolute;top:.5rem;z-index:1}.absoluted_icon svg[data-v-b785f731]{height:24px;width:24px}";

const SkillsFormStyles_CkZrTPAl = [SkillsForm_vue_vue_type_style_index_0_scoped_b785f731_lang];

export { SkillsFormStyles_CkZrTPAl as default };
//# sourceMappingURL=SkillsForm-styles.CkZrTPAl.mjs.map
