const ProvidersInput_vue_vue_type_style_index_0_scoped_82fe56ff_lang = ".import-box[data-v-82fe56ff]{cursor:pointer}.is-connected .import-box-dvnld .logo .check[data-v-82fe56ff]{display:block}.import-box.disabled[data-v-82fe56ff]{background:#fff;border-radius:12px;box-shadow:0 0 20px rgb(0 0 0/4%)}.import-box.disabled .import-box-dvnld[data-v-82fe56ff]{border:1px dashed #8c8c8c;color:#8c8c8c}.import-box.disabled .import-box-dvnld .logo[data-v-82fe56ff]{filter:grayscale(100%)}.import-box.disabled .import-box-dvnld span[data-v-82fe56ff]{color:#8c8c8c}";

const ProvidersInputStyles_IkFN9Jg = [ProvidersInput_vue_vue_type_style_index_0_scoped_82fe56ff_lang];

export { ProvidersInputStyles_IkFN9Jg as default };
//# sourceMappingURL=ProvidersInput-styles.-IkFN9Jg.mjs.map
