import"./entry.nFPs2vmr.js";const e=""+new URL("tele2.BJT7ig5a.svg",import.meta.url).href;export{e as _};
