import"./entry.nFPs2vmr.js";const o=""+new URL("jobeek-dark.Do_KXeWm.svg",import.meta.url).href;export{o as _};
