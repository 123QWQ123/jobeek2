import{Q as e,R as t}from"./swiper-vue.DwRi8LbX.js";const o={__name:"results",setup(r){return(s,a)=>(e(),t("div"))}};export{o as default};
