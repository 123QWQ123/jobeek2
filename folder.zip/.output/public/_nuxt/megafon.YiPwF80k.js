import"./entry.nFPs2vmr.js";const r=""+new URL("megafon.CRFUFZpu.svg",import.meta.url).href;export{r as _};
