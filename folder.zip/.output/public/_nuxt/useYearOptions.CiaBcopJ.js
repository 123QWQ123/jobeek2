function t(u=null,l=null,r=!0){const n=[];u||(u=new Date().getFullYear()-50),l||(l=new Date().getFullYear());for(let e=u;e<=l;e++)n.push({name:e,value:e});return r&&n.reverse(),n}export{t as u};
