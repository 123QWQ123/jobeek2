import"./entry.nFPs2vmr.js";const o=""+new URL("crown2.C009jjv_.svg",import.meta.url).href;export{o as _};
